!function() {
    "use strict";
    var e = document.getElementById("stage"), t = document.getElementById("tabbar"), n = document.getElementById("toast"), i = 0;
    function o(e) {
        var t = j() ? B() : document.body;
        n.parentNode !== t && t.appendChild(n), n.textContent = e, n.classList.add("on"), 
        clearTimeout(i), i = setTimeout(function() {
            n.classList.remove("on"), setTimeout(function() {
                n.parentNode && n.parentNode !== document.body && document.body.appendChild(n);
            }, 260);
        }, 1900);
    }
    var a = /duoju-lite-app/i.test(navigator.userAgent || ""), r = /; wv\)|TBS\/|MQQBrowser|X5\/|hiker|MicroMessenger|baiduboxapp|UCBrowser|Quark|HeyTap|VivoBrowser|OppoBrowser|MiuiBrowser/i.test(navigator.userAgent || ""), s = function() {
        try {
            var e = new RegExp("[?&]nofs=([^&]*)").exec(location.search || "");
            if (e) return decodeURIComponent(e[1]);
            var t = String(location.hash || ""), n = t.indexOf("?");
            if (n >= 0) {
                var i = new RegExp("[?&]nofs=([^&]*)").exec(t.slice(n));
                if (i) return decodeURIComponent(i[1]);
            }
        } catch (e) {}
        return "";
    }(), c = "1" !== s && ("0" === s || !a && !r), l = "1" !== s && ("0" === s || a || !r);
    function d(e) {
        return String(null == e ? "" : e).replace(/[&<>"']/g, function(e) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            }[e];
        });
    }
    document.addEventListener("error", function(e) {
        var t = e.target;
        if (t && "IMG" === t.tagName && t.parentNode && t.parentNode.classList && (t.parentNode.classList.contains("cover") || t.parentNode.classList.contains("dcov"))) {
            var n = document.createElement("span");
            n.className = "nopic", n.textContent = (t.getAttribute("data-np") || "剧").slice(0, 1), 
            t.replaceWith(n);
        }
    }, !0);
    var u = null;
    function v(e) {
        return new Promise(function(t) {
            var n = document.createElement("div");
            n.className = "mask askmask";
            var i = document.createElement("div");
            i.className = "askbox confirm", e.danger && i.classList.add("danger"), i.innerHTML = '<div class="cico">!</div><b>' + d(e.title || "") + "</b>" + (e.tip ? "<p>" + d(e.tip) + "</p>" : "") + '<div class="askbtns"><button type="button" class="cancel">' + d(e.cancelText || "取消") + '</button><button type="button" class="ok">' + d(e.okText || "确定") + "</button></div>", 
            document.body.appendChild(n), document.body.appendChild(i);
            var o = Z(function() {
                return a(!1), !0;
            });
            function a(e) {
                i.parentNode && (ee(o), n.classList.remove("on"), i.classList.remove("on"), setTimeout(function() {
                    n.parentNode && n.remove(), i.parentNode && i.remove();
                }, 220), t(e));
            }
            n.classList.add("on"), i.classList.add("on"), i.querySelector(".cancel").addEventListener("click", function() {
                a(!1);
            }), n.addEventListener("click", function() {
                a(!1);
            }), i.querySelector(".ok").addEventListener("click", function() {
                a(!0);
            });
        });
    }
    var f = null, p = !1, h = 0, m = 0;
    function g(e, t) {
        f || ((f = document.createElement("div")).id = "netbar", document.body.appendChild(f));
        var n = j() ? B() : document.body;
        if (f.parentNode !== n && n.appendChild(f), f.textContent = e ? t ? "网络已恢复" : "" : "网络已断开，恢复后自动重试", 
        f.classList.toggle("on", !!f.textContent), p = !e, e) {
            if (h && (clearInterval(h), h = 0), t && Date.now() - m > 4e3) {
                m = Date.now(), setTimeout(function() {
                    f.classList.remove("on");
                }, 1800);
                try {
                    window.dispatchEvent(new CustomEvent("jk:online"));
                } catch (e) {}
            }
        } else h || (h = setInterval(function() {
            !1 !== navigator.onLine && y().then(function(e) {
                e && p && g(!0, !0);
            });
        }, 2500));
    }
    function y() {
        return fetch("/", {
            cache: "no-store"
        }).then(function(e) {
            return e.ok;
        }).catch(function() {
            return !1;
        });
    }
    function b(e, t) {
        return function n(i) {
            if (!1 === navigator.onLine) return Promise.reject(new Error("当前没有网络连接"));
            var o = t.timeout && window.AbortController ? new AbortController : null, a = fetch("/web/api" + e, o ? {
                headers: {
                    Accept: "application/json"
                },
                signal: o.signal
            } : {
                headers: {
                    Accept: "application/json"
                }
            }).then(function(e) {
                return e.ok ? e.json() : e.json().catch(function() {
                    return {};
                }).then(function(t) {
                    var n = new Error(t && t.msg ? t.msg : "HTTP " + e.status);
                    throw n.status = e.status, n;
                });
            }).then(function(e) {
                if (200 !== e.code) throw new Error(e.msg || "请求失败");
                return e.data;
            }), r = function(e) {
                if (e instanceof TypeError && !p && g(!1), i > 1 && !e.__timeout) return new Promise(function(e) {
                    setTimeout(e, 450);
                }).then(function() {
                    return n(i - 1);
                });
                throw e;
            };
            if (!o) return a.catch(r);
            var s = 0, c = new Promise(function(e, n) {
                s = setTimeout(function() {
                    try {
                        o.abort();
                    } catch (e) {}
                    var e = new Error("等待服务端超时（" + Math.round(t.timeout / 1e3) + "s）");
                    e.__timeout = !0, n(e);
                }, t.timeout);
            });
            return Promise.race([ a, c ]).then(function(e) {
                return clearTimeout(s), e;
            }, function(e) {
                return clearTimeout(s), r(e);
            });
        }(!1 === (t = t || {}).retry ? 1 : 2);
    }
    window.addEventListener("offline", function() {
        g(!1);
    }), window.addEventListener("online", function() {
        y().then(function(e) {
            g(e, e);
        });
    }), window.addEventListener("jk:online", function() {
        if (at && at.onOnline) try {
            at.onOnline();
        } catch (e) {}
    }), "boolean" != typeof navigator.onLine || navigator.onLine || g(!1);
    var w = 4e4;
    function E(e) {
        for (var t = "", n = 0; n < e; n++) t += '<div class="card skel"><div class="cover"></div><div class="meta"><i class="l1"></i><i class="l2"></i></div></div>';
        return '<div class="grid">' + t + "</div>";
    }
    function L() {
        var e = document.getElementById("splash");
        e && !e.classList.contains("off") && (e.classList.add("off"), setTimeout(function() {
            e.parentNode && e.remove();
        }, 320));
    }
    function k() {
        var e = document.getElementById("welcome");
        if (e && !e.dataset.done) {
            if (a) return e.dataset.done = "1", window.__gestured = !0, window.__autoBlocked = !0, 
            Oe(), Fe(), void setTimeout(Fe, 260);
            e.classList.add("on");
            var t = function(n) {
                n && (n.preventDefault(), n.stopPropagation()), e.dataset.done = "1", e.classList.remove("on");
                try {
                    e.removeEventListener("click", t);
                } catch (e) {}
                window.__gestured = !0, window.__autoBlocked = !0, c && ce(se()).then(function() {
                    Q();
                }), Fe(), Oe(), setTimeout(Fe, 260);
            };
            e.addEventListener("click", t);
        }
    }
    function T(e) {
        var t = /^https?:\/\/(?:127\.0\.0\.1|localhost|\[::1\])(?::\d+)?(\/.*)?$/i.exec(String(e || ""));
        return t ? t[1] || "/" : e || "";
    }
    function S(e, t) {
        if (!e) return "";
        if ("/" === (e = T(e)).charAt(0)) return e;
        var n = "dec=img&url=" + encodeURIComponent(e);
        return t && (n += "&ref=" + encodeURIComponent(t)), "/media?" + n;
    }
    window.__jkHideSplash = L, setTimeout(L, 6e3);
    var C = "jk.cover.v1";
    function M() {
        try {
            var e = JSON.parse(localStorage.getItem(C) || "{}");
            return e && "object" == typeof e ? e : {};
        } catch (e) {
            return {};
        }
    }
    function x(e, t, n) {
        if (e && t && n) {
            var i = M(), o = e + "|" + t;
            if (i[o] !== n) {
                i[o] = n;
                for (var a = Object.keys(i), r = 0; r < a.length - 400; r++) delete i[a[r]];
                try {
                    localStorage.setItem(C, JSON.stringify(i));
                } catch (e) {}
            }
        }
    }
    function q(e, t) {
        return e && t && M()[e + "|" + t] || "";
    }
    function H(e, t) {
        var n = t || location.hash.slice(1), i = n.indexOf("?");
        if (i < 0) return "";
        var o = new RegExp("[?&]" + e + "=([^&]*)").exec(n.slice(i));
        return o ? decodeURIComponent(o[1]) : "";
    }
    var N = [ 1, 1.25, 1.5, 2, 3, .75 ];
    function _(e) {
        return (e % 1 == 0 ? e.toFixed(1) : String(e)) + "x";
    }
    function I(e) {
        if (!e || isNaN(e)) return "00:00";
        var t = Math.floor(e), n = Math.floor(t / 60), i = t % 60;
        return (n < 10 ? "0" + n : n) + ":" + (i < 10 ? "0" + i : i);
    }
    var A = '<path d="M4 9V4h5v2H6v3H4zm11-5h5v5h-2V6h-3V4zM4 15h2v3h3v2H4v-5zm14 0h2v5h-5v-2h3v-3z"/>', R = '<path d="M9 4v5H4V7h3V4h2zm6 0h2v3h3v2h-5V4zM4 15h5v5H7v-3H4v-2zm12 0h5v2h-3v3h-2v-5z"/>';
    function P() {
        return !!(document.fullscreenElement || document.webkitFullscreenElement || document.webkitCurrentFullScreenElement);
    }
    function F(e) {
        return '<svg viewBox="0 0 24 24">' + (e ? R : A) + "</svg>";
    }
    var O = [];
    function B() {
        var e = document.querySelector(".slide.rotfs");
        if (e && document.body.contains(e)) return e;
        var t = document.fullscreenElement || document.webkitFullscreenElement || document.webkitCurrentFullScreenElement;
        return t && t.appendChild ? t : document.body;
    }
    function U() {
        var e = B();
        O.forEach(function(t) {
            t.parentNode !== e && e.appendChild(t);
        });
    }
    function j() {
        return P() || !!document.querySelector(".slide.rotfs") || !!ke;
    }
    function D() {
        document.body.classList.toggle("fsview", !!ke), document.body.classList.toggle("fsland", !(!ke || !Se)), 
        document.body.classList.toggle("cssfs", !(!ke || P()));
    }
    var z = 0;
    function Y(e) {
        ke && e && (ie.forEach(function(t) {
            t.immersed = t === e;
        }), ke = e, Te = Date.now(), xe(), D(), Q());
    }
    function J() {
        return window.performance && performance.now ? performance.now() : Date.now();
    }
    function X(e) {
        return e.changedTouches && e.changedTouches.length ? e.changedTouches[0] : e.touches && e.touches.length ? e.touches[0] : e;
    }
    function V(e, t) {
        if (!e || e.__silk) return e.__silk;
        var n = {
            feed: e,
            hooks: t || {},
            dragging: !1,
            consumed: !1,
            animating: !1,
            raf: 0,
            startX: 0,
            startY: 0,
            startTop: 0,
            lastY: 0,
            lastT: 0,
            v: 0,
            axis: 0,
            els: null,
            tops: null,
            wheelAcc: 0,
            wheelAt: 0
        };
        function i() {
            for (var t = [].slice.call(e.querySelectorAll(".slide")), i = new Array(t.length), o = 0; o < t.length; o++) i[o] = t[o].offsetTop;
            n.els = t, n.tops = i;
        }
        function o() {
            return !!e.querySelector(".slide.rotfs");
        }
        function a(t) {
            if (n.dragging && (n.dragging = !1, n.axis)) {
                var i = X(t), o = (null == i.clientY ? 0 : i.clientY) - n.startY, a = e.clientHeight || window.innerHeight || 800;
                if (Math.abs(o) > .14 * a || Math.abs(n.v) > .35) {
                    var r = Math.abs(o) > 4 ? o < 0 ? 1 : -1 : n.v < 0 ? 1 : -1;
                    n.page(r, Math.abs(n.v) > 1.2);
                } else n.animateTo(n.startTop, 240);
            }
        }
        return e.__silk = n, n.stop = function() {
            n.raf && (cancelAnimationFrame(n.raf), n.raf = 0), n.animating = !1, e.classList.remove("silking");
        }, n.animateTo = function(t, i, o) {
            n.stop();
            var a = e.scrollTop, r = Math.max(0, e.scrollHeight - e.clientHeight);
            t < 0 ? t = 0 : t > r && (t = r);
            var s = t - a;
            if (Math.abs(s) < 1) return e.scrollTop = t, void (o && o());
            if (!i) {
                var c = e.clientHeight || window.innerHeight || 800;
                i = Math.round(Math.min(380, Math.max(200, 200 + Math.abs(s) / c * 240)));
            }
            n.animating = !0, e.classList.add("silking");
            var l = J();
            !function r() {
                var c = Math.min(1, (J() - l) / i);
                e.scrollTop = a + s * (1 - Math.pow(1 - c, 4)), c < 1 ? n.raf = requestAnimationFrame(r) : (n.raf = 0, 
                n.animating = !1, e.scrollTop = t, e.classList.remove("silking"), o && o());
            }();
        }, n.page = function(t, o) {
            if (i(), n.tops && n.tops.length) {
                var a = function(e, t) {
                    for (var n = 0, i = 1 / 0, o = 0; o < e.length; o++) {
                        var a = Math.abs(e[o] - t);
                        a < i && (i = a, n = o);
                    }
                    return n;
                }(n.tops, e.scrollTop), r = Math.max(0, Math.min(n.tops.length - 1, a + t));
                if (r !== a) {
                    var s = n.els[r];
                    s && s.classList && s.classList.contains("spacer") ? n.animateTo(n.tops[r]) : n.animateTo(n.tops[r], o ? 240 : 0, function() {
                        n.hooks.onCommit && n.hooks.onCommit(r, s);
                    });
                } else n.animateTo(n.tops[a], 240);
            }
        }, e.addEventListener("touchstart", function(t) {
            if (n.consumed = !1, n.dragging = !1, !o() && !(function(t) {
                for (;t && t !== e; ) {
                    if (t.classList && (t.classList.contains("drawer") || t.classList.contains("vprog"))) return !0;
                    t = t.parentElement;
                }
                return !1;
            }(t.target) || t.touches && t.touches.length > 1)) {
                n.stop();
                var a = X(t);
                n.startX = a.clientX, n.startY = a.clientY, n.lastY = a.clientY, n.lastT = J(), 
                n.startTop = e.scrollTop, n.v = 0, n.axis = 0, n.dragging = !0, i();
            }
        }, {
            passive: !0
        }), e.addEventListener("touchmove", function(t) {
            if (n.dragging) {
                var i = X(t), o = i.clientY - n.startY;
                if (!n.axis) {
                    if (Math.abs(i.clientX - n.startX) > 8 && Math.abs(o) < 8) return void (n.dragging = !1);
                    if (Math.abs(o) < 8) return;
                    n.axis = 1, n.consumed = !0, e.classList.add("silking");
                }
                var a = J(), r = a - n.lastT;
                if (r > 0) {
                    var s = (i.clientY - n.lastY) / Math.max(r, 8);
                    n.v = .4 * n.v + .6 * s, n.v > 4 ? n.v = 4 : n.v < -4 && (n.v = -4), n.lastY = i.clientY, 
                    n.lastT = a;
                }
                var c = n.startTop - o, l = e.scrollHeight - e.clientHeight;
                c < 0 ? c *= .32 : c > l && (c = l + .32 * (c - l)), e.scrollTop = c, t.cancelable && t.preventDefault();
            }
        }, {
            passive: !1
        }), e.addEventListener("touchend", a), e.addEventListener("touchcancel", a), e.addEventListener("wheel", function(e) {
            if (!o() && (e.cancelable && e.preventDefault(), !n.animating)) {
                var t = J();
                if (t - n.wheelAt > 500 && (n.wheelAcc = 0), n.wheelAt = t, n.v = 0, n.wheelAcc += e.deltaY, 
                !(Math.abs(n.wheelAcc) < 60)) {
                    var i = n.wheelAcc > 0 ? 1 : -1;
                    n.wheelAcc = 0, n.page(i);
                }
            }
        }, {
            passive: !1
        }), n;
    }
    function W(e, t, n, i) {
        if (!e || !t) return i && i(), 0;
        var o;
        if (t.classList && t.classList.contains("rotfs")) {
            var a = e.clientHeight || t.offsetHeight || window.innerHeight;
            o = e.scrollTop + n * a;
        } else o = t.offsetTop;
        var r = e.__silk;
        return r ? (r.animateTo(o, 0, i || function() {
            Y(_e(t));
        }), o) : (e.scrollTo ? e.scrollTo({
            top: o
        }) : e.scrollTop = o, function(e, t) {
            if (e && null != t) {
                var n = ++z, i = 0;
                !function o() {
                    n === z && (i++ > 14 || (Math.abs(e.scrollTop - t) > 2 && (e.scrollTop = t), requestAnimationFrame(o)));
                }();
            }
        }(e, o), Y(_e(t)), i && setTimeout(i, 30), o);
    }
    function K(e, t) {
        var n = 0, i = 1 / 0;
        return (e || []).forEach(function(e, o) {
            if (e) {
                var a = Math.abs(e.offsetTop - t);
                a < i && (i = a, n = o);
            }
        }), n;
    }
    function Q() {
        U();
        var e = F(j());
        try {
            document.querySelectorAll(".sqfs").forEach(function(t) {
                t.innerHTML = e, t.classList.toggle("on", j());
            });
        } catch (e) {}
    }
    var $ = [], G = 0;
    function Z(e) {
        return $.push(e), e;
    }
    function ee(e) {
        var t = $.indexOf(e);
        t >= 0 && $.splice(t, 1);
    }
    var te = {
        "/feed": 1,
        "/cats": 1,
        "/search": 1,
        "/mine": 1
    };
    function ne() {
        return !!te[(location.hash.slice(1) || "/feed").split("?")[0]];
    }
    window.JK = {
        version: "1.4.37",
        back: function() {
            return function() {
                if (function() {
                    for (var e = $.length - 1; e >= 0; e--) {
                        var t = !1;
                        try {
                            t = !!$[e]();
                        } catch (e) {}
                        if (t) return !0;
                    }
                    return !1;
                }()) return "consume";
                if (!ne()) return "back";
                var e = Date.now();
                return e - G < 2200 ? (G = 0, "exit") : (G = e, o("再按一次退出"), "consume");
            }();
        },
        onResume: function() {
            G = 0;
        },
        wake: function() {
            return Fe();
        },
        state: function() {
            return {
                home: ne(),
                hooks: $.length,
                since: Date.now() - (G || 0)
            };
        }
    };
    var jkWake = function() {
        var lock = null, want = !1;
        function acquire() {
            if (!want || lock || document.hidden || !navigator.wakeLock) return;
            try {
                navigator.wakeLock.request("screen").then(function(l) {
                    if (!want) {
                        try {
                            l.release();
                        } catch (e) {}
                        return;
                    }
                    lock = l, l.addEventListener("release", function() {
                        lock === l && (lock = null);
                    });
                }).catch(function() {});
            } catch (e) {}
        }
        document.addEventListener("visibilitychange", function() {
            if (document.hidden) {
                if (lock) {
                    try {
                        lock.release();
                    } catch (e) {}
                    lock = null;
                }
            } else acquire();
        });
        return {
            on: function() {
                want = !0, acquire();
            },
            off: function() {
                want = !1;
                if (lock) {
                    try {
                        lock.release();
                    } catch (e) {}
                    lock = null;
                }
            }
        };
    }();
    var ie = [];
    function wakeSync() {
        for (var e = 0; e < ie.length; e++) if (ie[e].video && !ie[e].video.paused) return jkWake.on();
        jkWake.off();
    }
    function oe(e) {
        for (var t = 0; t < ie.length; t++) {
            var n = ie[t];
            n !== e && n.video && !n.video.paused && n.pause();
        }
    }
    function ae() {
        try {
            document.querySelectorAll("video").forEach(function(e) {
                if (!e.paused) try {
                    e.pause();
                } catch (e) {}
            });
        } catch (e) {}
        ie.forEach(function(e) {
            e.video && !e.video.paused && e.pause();
        });
    }
    Ee.prototype.pushAudio = function() {
        var e = this.video;
        if (e) {
            var t = !!Be.muted() || !!this.forceMuted;
            e.muted !== t && (e.muted = t);
            try {
                if (t) e.volume > 0 && (e.dataset.vol = String(e.volume), e.volume = 0); else {
                    var n = parseFloat(e.dataset.vol || "1");
                    n > 0 || (n = 1), e.volume <= 0 && (e.volume = n);
                }
            } catch (e) {}
        }
    };
    var re = null;
    function se() {
        return document.getElementById("app");
    }
    function ce(e) {
        try {
            var t = e.requestFullscreen || e.webkitRequestFullscreen || e.webkitRequestFullScreen || e.msRequestFullscreen;
            if (!t) return Promise.resolve(!1);
            var n = t.call(e);
            if (n && n.then) return n.then(function() {
                return !0;
            }, function() {
                return !1;
            });
        } catch (e) {}
        return Promise.resolve(!1);
    }
    function le() {
        try {
            (document.exitFullscreen || document.webkitExitFullscreen || document.webkitCancelFullScreen || document.msExitFullscreen).call(document);
        } catch (e) {}
        ye(), ue();
    }
    function de(e) {
        try {
            var t = screen.orientation || screen.mozOrientation || screen.msOrientation;
            if (t && t.lock) return t.lock(e).then(function() {
                return !0;
            }, function() {
                return !1;
            });
            if (screen.lockOrientation) return Promise.resolve(!!screen.lockOrientation(e));
            if (screen.mozLockOrientation) return Promise.resolve(!!screen.mozLockOrientation(e));
            if (screen.msLockOrientation) return Promise.resolve(!!screen.msLockOrientation(e));
        } catch (e) {}
        return Promise.resolve(!1);
    }
    function ue() {
        try {
            var e = screen.orientation || screen.mozOrientation || screen.msOrientation;
            if (e && e.unlock) {
                var t = e.unlock();
                return void (t && t.catch && t.catch(function() {}));
            }
            screen.unlockOrientation && screen.unlockOrientation();
        } catch (e) {}
    }
    function ve() {
        ue(), setTimeout(function() {
            window.innerWidth > window.innerHeight && de("portrait").then(function() {
                setTimeout(ue, 250);
            });
        }, 350);
    }
    function fe(e) {
        try {
            if (window.JKNative && window.JKNative.orient) return window.JKNative.orient(e), 
            !0;
        } catch (e) {}
        return !1;
    }
    function pe(e) {
        try {
            if (window.JKNative && window.JKNative.immersive) return window.JKNative.immersive(!!e), 
            !0;
        } catch (e) {}
        return !1;
    }
    function he() {
        l && (a && fe("portrait") || ue());
    }
    !function() {
        if ("mediaSession" in navigator) try {
            navigator.mediaSession.setActionHandler("play", function() {
                re && re.play(!0);
                try {
                    navigator.mediaSession.playbackState = "playing";
                } catch (e) {}
            }), navigator.mediaSession.setActionHandler("pause", function() {
                ae();
                try {
                    navigator.mediaSession.playbackState = "paused";
                } catch (e) {}
            });
        } catch (e) {}
    }(), document.addEventListener("visibilitychange", function() {
        if (document.hidden) {
            if (ke && Date.now() - Te < 3e3 && (P() || document.querySelector(".slide.rotfs") || Se)) return;
            Ve(), ae(), jkWake.off();
            try {
                "mediaSession" in navigator && (navigator.mediaSession.playbackState = "paused");
            } catch (e) {}
        } else ke && Ne(ke), window.__autoBlocked && setTimeout(Fe, 60);
    }), window.addEventListener("pagehide", ae);
    var me = null;
    function ge() {
        var e = document.querySelector(".slide.rotfs"), t = e ? e.parentElement : null;
        document.body.classList.remove("rotfs");
        try {
            document.querySelectorAll(".slide.rotfs").forEach(function(e) {
                e.classList.remove("rotfs");
            });
        } catch (e) {}
        if (e && t && t.classList && t.classList.contains("feed")) {
            for (var n = [].slice.call(t.querySelectorAll(".slide")), i = n.indexOf(e), o = 0, a = 0; a < i && a < n.length; a++) o += n[a].offsetHeight || t.clientHeight || 0;
            try {
                t.scrollTop = o;
            } catch (e) {}
        }
    }
    function ye() {
        me = null, ge();
    }
    function be(e) {
        me = e || null, we();
    }
    function we() {
        if (!me || !document.body.contains(me)) return ye(), void Q();
        ge(), window.innerWidth <= window.innerHeight && (me.classList.add("rotfs"), document.body.classList.add("rotfs")), 
        Q();
    }
    function Ee(e) {
        var t;
        this.opts = e || {}, this.src = "", this.loaded = !1, this.err = 0, this.rate = (t = Number(localStorage.getItem("jk_rate")), 
        N.indexOf(t) >= 0 ? t : 1), this.fast = !1;
        var n = document.createElement("section");
        n.className = "slide loading", n.innerHTML = '<video playsinline webkit-playsinline preload="none" loop></video><div class="poster"></div><div class="vload"><span class="sp"></span>缓冲中…</div><div class="verr"><div class="msg">播放失败</div><button class="again" type="button">重试</button><button class="swap" type="button">换线路</button></div><div class="vtap"><div class="pp"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></div></div><div class="vhint"></div><div class="vprog"><span class="pt cur">00:00</span><div class="ptrack"><i></i></div><span class="pt tot">00:00</span></div>', 
        this.el = n, this.video = n.querySelector("video");
        var i = this;
        this.video.addEventListener("playing", function() {
            i.autoBlocked = !1, window.__autoBlocked = !1, i.unmuteTry(), i.pushAudio(), 
            jkWake.on(), re && re !== i && i.pause();
        }), [ "loadstart", "loadeddata", "canplay", "volumechange" ].forEach(function(e) {
            i.video.addEventListener(e, function() {
                i.pushAudio();
            });
        }), this.bar = n.querySelector(".ptrack"), this.progEl = n.querySelector(".vprog"), 
        this.pcur = n.querySelector(".vprog .cur"), this.ptot = n.querySelector(".vprog .tot"), 
        this.dragging = !1, ie.push(this), this.bumpProg();
        var a = this.opts;
        this.coverUrl = a.cover || "", a.cover && (n.querySelector(".poster").style.backgroundImage = 'url("' + a.cover + '")');
        var r = document.createElement("div");
        r.className = "vside", r.innerHTML = '<button type="button" class="spd"><b>1.0x</b><span>倍速</span></button><button type="button" class="fav' + (a.fav && Be.isFav(a.fav) ? " on" : "") + '"><svg viewBox="0 0 24 24"><path d="M12 21s-8-4.7-8-10a4.6 4.6 0 018-3 4.6 4.6 0 018 3c0 5.3-8 10-8 10z"/></svg><span>追剧</span></button>', 
        this.el.appendChild(r), this.spdEl = r.querySelector(".spd"), this.spdEl.addEventListener("click", function(e) {
            e.stopPropagation(), b.cycleRate();
        }), this.favEl = r.querySelector(".fav"), this.favEl.addEventListener("click", function(e) {
            if (e.stopPropagation(), a.fav) {
                var t = Be.toggleFav(a.fav);
                null !== t && (b.favEl.classList.toggle("on", t), t && Ue(b), o(t ? "已收藏，可在「我的」里查看" : "已取消收藏"));
            } else o("这条暂时收藏不了");
        }), this.pushAudio(), ie.forEach(function(e) {
            e.pushAudio && e.pushAudio();
        }), this.applyRate();
        var s = document.createElement("div");
        s.className = "vmeta";
        var c = a.tags && a.tags.length ? '<div class="tags">' + a.tags.map(function(e) {
            return '<span class="src">' + d(e) + "</span>";
        }).join("") + "</div>" : "";
        s.innerHTML = '<div class="vt">' + (a.badge ? '<i class="vbadge">' + d(a.badge) + "</i>" : "") + d(a.title || "") + (a.onTitle ? '<span class="ar"></span>' : "") + "</div>" + (a.desc ? '<div class="vd clamp">' + d(a.desc) + "</div>" : "") + (c ? '<div class="row">' + c + "</div>" : "") + (a.btn && a.btn.cap ? '<div class="cbar"><button class="epbtn cap" type="button"><span class="capl">' + (a.btn.play ? '<span class="tric"></span>' : "") + '<span class="tx">' + d(a.btn.text) + '</span></span><span class="caret"></span></button>' + (a.btn.fs ? '<button class="sqfs" type="button" aria-label="全屏">' + F(!1) + "</button>" : "") + "</div>" : "") + (a.btn && !a.btn.cap ? '<button class="epbtn" type="button">' + d(a.btn.text) + "</button>" : ""), 
        this.el.appendChild(s);
        var l = s.querySelector(".sqfs");
        if (l && l.addEventListener("click", function(e) {
            e.stopPropagation(), b.videoFullscreen();
        }), a.before) {
            var u = document.createElement("div");
            for (u.innerHTML = a.before; u.firstChild; ) n.appendChild(u.firstChild);
        }
        var v = n.querySelector(".vtop");
        if (v) {
            var f = v.querySelector(".bk");
            f && f.addEventListener("click", function(e) {
                e.stopPropagation(), a.onBack ? a.onBack() : Le();
            });
            var p = v.querySelector(".sel");
            p && p.addEventListener("click", function(e) {
                e.stopPropagation(), a.onSelect && a.onSelect();
            });
            var h = v.querySelector(".vclose");
            h && h.addEventListener("click", function(e) {
                e.stopPropagation(), b.close();
            });
        }
        var m = s.querySelector(".epbtn");
        m && a.btn && a.btn.onClick && m.addEventListener("click", a.btn.onClick);
        var g = s.querySelector(".vt");
        g && a.onTitle && g.addEventListener("click", function(e) {
            e.stopPropagation(), a.onTitle();
        });
        var y = s.querySelector(".vd");
        y && y.addEventListener("click", function() {
            y.classList.toggle("clamp");
        });
        var b = this, w = n.querySelector(".vtap");
        n.querySelector(".again").addEventListener("click", function(e) {
            e.stopPropagation(), b.err = 0, b.play();
        });
        var E = n.querySelector(".verr .swap");
        E && E.addEventListener("click", function(e) {
            e.stopPropagation(), a.onFail ? a.onFail(b) : (b.err = 0, b.loaded = !1, b.play());
        });
        var L = 0, k = 0, T = 0, S = 0, C = !1, M = !1;
        function x(e) {
            return e.touches && e.touches.length ? e.touches[0] : e.changedTouches && e.changedTouches.length ? e.changedTouches[0] : e;
        }
        function q(e) {
            if (e.touches && e.touches.length > 1) C = !0; else {
                var t = x(e);
                T = t.clientX, S = t.clientY, C = !1, M = !0, document.body.classList.contains("fsidle") ? (b.wokeIdle = !0, 
                xe()) : b.wokeIdle = !1, b.bumpProg(), clearTimeout(k), k = setTimeout(function() {
                    !C && M && b.setFast(!0);
                }, 380);
            }
        }
        function H(e) {
            if (M) {
                var t = x(e);
                (Math.abs(t.clientX - T) > 12 || Math.abs(t.clientY - S) > 12) && (C = !0, clearTimeout(k), 
                b.setFast(!1));
            }
        }
        function _(e) {
            if (M) {
                M = !1, clearTimeout(k);
                var t = b.fast;
                if (b.setFast(!1), C) {
                    var n = b.el.parentElement;
                    if (n && n.__silk && n.__silk.consumed) return;
                    if (b.el.classList.contains("rotfs")) {
                        var i = (x(e).clientX || 0) - T;
                        Math.abs(i) > 40 && b.swipe(i > 0 ? 1 : -1);
                    } else if (ke === b) {
                        var o = (x(e).clientY || 0) - S;
                        Math.abs(o) > 40 && b.swipe(o < 0 ? 1 : -1);
                    }
                } else if (!t) {
                    if (b.opts && b.opts.feed) return b.wokeIdle = !1, L = 0, b.bumpProg(), void b.toggle();
                    if (b.wokeIdle) return b.wokeIdle = !1, void (L = 0);
                    var a = Date.now();
                    a - L < 300 ? (L = 0, b.toggle()) : (L = a, b.bumpProg());
                }
            }
        }
        var I = !1;
        w.addEventListener("touchstart", function(e) {
            I = !0, q(e);
        }, {
            passive: !0
        }), w.addEventListener("touchmove", H, {
            passive: !0
        }), w.addEventListener("touchend", _), w.addEventListener("touchcancel", function() {
            M = !1, clearTimeout(k), b.setFast(!1);
        }), w.addEventListener("mousedown", function(e) {
            I || q(e);
        }), w.addEventListener("mousemove", function(e) {
            I || H(e);
        }), w.addEventListener("mouseup", function(e) {
            I || _(e);
        }), w.addEventListener("mouseleave", function() {
            M = !1, clearTimeout(k), b.setFast(!1);
        });
        var A = !1;
        function R(e) {
            if (e) {
                var t = b.bar.getBoundingClientRect(), n = e.touches && e.touches[0] ? e.touches[0] : e, i = Math.max(0, Math.min(1, (n.clientX - t.left) / (t.width || 1))), o = b.video;
                b.setBar(100 * i);
                var a = o.duration || 0;
                if (a > 0) {
                    try {
                        o.currentTime = a * i;
                    } catch (e) {}
                    b.setTime(a * i, a);
                }
            }
        }
        function P(e) {
            if (A = !0, b.dragging = !0, b.seeking = !0, b.bumpProg(), e.stopPropagation(), 
            e.preventDefault(), R(e), b.progEl.setPointerCapture && null != e.pointerId) try {
                b.progEl.setPointerCapture(e.pointerId);
            } catch (e) {}
        }
        function O(e) {
            A && (b.bumpProg(), e.stopPropagation(), e.cancelable && e.preventDefault(), R(e));
        }
        function B(e) {
            A && (A = !1, b.dragging = !1, b.seeking = !1, b.bumpProg(), e && (e.stopPropagation(), 
            e.cancelable && e.preventDefault()));
        }
        b.progEl.addEventListener("pointerdown", P), b.progEl.addEventListener("pointermove", O), 
        b.progEl.addEventListener("pointerup", B), b.progEl.addEventListener("pointercancel", B), 
        window.PointerEvent || (b.progEl.addEventListener("touchstart", P, {
            passive: !1
        }), b.progEl.addEventListener("touchmove", O, {
            passive: !1
        }), b.progEl.addEventListener("touchend", B), b.progEl.addEventListener("mousedown", P), 
        b.progEl.addEventListener("mousemove", O), window.addEventListener("mouseup", B)), 
        this.video.addEventListener("loadedmetadata", function() {
            var e = b.video.videoWidth, t = b.video.videoHeight;
            if (e > 0 && t > 0) {
                try {
                    b.video.style.aspectRatio = e + " / " + t;
                } catch (e) {}
                n.classList.toggle("land", e > 1.05 * t);
            }
        }), this.video.addEventListener("pause", function() {
            ke !== b || b.userPaused || b.err || b.video.ended || document.hidden || Date.now() - Te > 4e3 || setTimeout(function() {
                ke !== b || b.userPaused || b.err || document.hidden || b.video.ended || b.video.paused && b.play(!0);
            }, 350);
        }), this.video.addEventListener("waiting", function() {
            n.classList.add("loading");
        }), this.video.addEventListener("playing", function() {
            n.classList.remove("loading", "error"), n.classList.add("playing", "played");
        }), this.video.addEventListener("loadeddata", function() {
            n.classList.remove("loading");
        }), this.video.addEventListener("error", function() {
            b.loaded && b.fail();
        }), [ "loadedmetadata", "durationchange", "canplay" ].forEach(function(e) {
            b.video.addEventListener(e, function() {
                b.setTime(b.video.currentTime, b.video.duration);
            });
        }), this.video.addEventListener("timeupdate", function() {
            var e = b.video, t = e.duration > 0 ? e.currentTime / e.duration * 100 : 0;
            b.seeking || (b.setBar(t), b.setTime(e.currentTime, e.duration));
        }), this.video.addEventListener("ended", function() {
            if (b.setBar(0), b.setTime(0, b.video.duration), a.onEnded) a.onEnded(); else try {
                b.video.currentTime = 0, b.video.play();
            } catch (e) {}
        }), this.video.loop = !a.onEnded;
    }
    function Le() {
        var e = window.__lastList || "#/feed";
        location.hash !== e ? location.hash = e : history.length > 1 ? history.back() : location.hash = "#/feed";
    }
    window.addEventListener("resize", we), window.addEventListener("orientationchange", we), 
    [ "fullscreenchange", "webkitfullscreenchange" ].forEach(function(e) {
        document.addEventListener(e, function() {
            ke && !P() && Date.now() - Te > 1200 && He(), Q();
        });
    }), Ee.prototype.hint = function(e, t) {
        var n = this.el.querySelector(".vhint");
        if (n) {
            n.textContent = e, n.classList.add("on"), clearTimeout(this._hintT);
            var i = this;
            this._hintT = setTimeout(function() {
                var e = i.el.querySelector(".vhint");
                e && e.classList.remove("on");
            }, t || 700);
        }
    }, Ee.prototype.applyRate = function() {
        try {
            this.video.playbackRate = this.rate;
        } catch (e) {}
        this.spdEl && (this.spdEl.querySelector("b").textContent = _(this.rate), this.spdEl.classList.toggle("on", 1 !== this.rate));
    }, Ee.prototype.setRate = function(e) {
        this.rate = e;
        try {
            localStorage.setItem("jk_rate", String(e));
        } catch (e) {}
        this.applyRate(), this.hint("倍速 " + _(e));
    }, Ee.prototype.cycleRate = function() {
        var e = N.indexOf(this.rate);
        e = e < 0 ? 0 : (e + 1) % N.length, this.setRate(N[e]);
    }, Ee.prototype.setFast = function(e) {
        e && !this.fast ? (this.fast = !0, this._prevRate = this.rate, this.rate = 3, this.applyRate(), 
        this.hint("⏩ 3.0x 快进中", 6e4)) : !e && this.fast && (this.fast = !1, this.rate = this._prevRate || 1, 
        this.applyRate(), this.hint(""));
    }, Ee.prototype.seek = function(e, t) {
        var n = this.video;
        try {
            var i = n.duration || 0, o = n.currentTime + e;
            o < 0 && (o = 0), i > 0 && o > i - .2 && (o = Math.max(0, i - .2)), n.currentTime = o;
        } catch (e) {}
        this.hint((t ? "« " : "") + Math.abs(e) + " 秒" + (t ? "" : " »"));
    }, Ee.prototype.close = function() {
        this.pause(), Le();
    };
    var ke = null, Te = 0, Se = !1, Ce = 0, Me = 2e3;
    function xe() {
        document.body.classList.remove("fsidle"), clearTimeout(Ce), Ce = setTimeout(function() {
            document.body.classList.add("fsidle");
        }, Me);
    }
    function qe() {
        try {
            ie.forEach(function(e) {
                e.immersed = !1, e.orientLocked = !1;
            });
        } catch (e) {}
    }
    function He() {
        var e = ke;
        ke = null, z++, xe(), ye(), Ae(!1), D(), document.querySelectorAll(".feed").forEach(function(e) {
            "snap" in e.dataset && (e.style.scrollSnapType = e.dataset.snap, delete e.dataset.snap);
        }), P() && le(), Se && l ? he() : ve(), Se = !1, pe(!1), qe(), Q(), Ne(e || re);
    }
    function Ne(e) {
        e && e.video && [ 60, 300, 900 ].forEach(function(t) {
            setTimeout(function() {
                !e.video || e.userPaused || e.err || e.video.paused && e.play(!0);
            }, t);
        });
    }
    function _e(e) {
        if (!e) return null;
        for (var t = 0; t < ie.length; t++) if (ie[t].el === e) return ie[t];
        return null;
    }
    function Ie(e) {
        me && e && document.body.contains(e) && (be(e), Y(_e(e)));
    }
    function Ae(e) {
        try {
            var t = document.getElementById("tabbar");
            t && t.classList.toggle("nobar", !!e);
        } catch (e) {}
    }
    function Re(e) {
        return !!e && /NotAllowed/i.test(e.name || String(e));
    }
    [ "pointermove", "click", "wheel" ].forEach(function(e) {
        document.addEventListener(e, function() {
            xe();
        }, {
            capture: !0,
            passive: !0
        });
    }), Ee.prototype.exitImmersive = function() {
        He();
    }, Ee.prototype.videoFullscreen = function() {
        this.setFast(!1);
        var e = this;
        if (ke || j()) He(); else {
            oe(this), this.immersed = !0, ke = this, Te = Date.now(), Ae(!0), pe(!0), D();
            var t = this.el.classList.contains("land");
            Se = !!t;
            try {
                var n = this.el.parentElement;
                n && n.classList.contains("feed") && (n.dataset.snap = n.style.scrollSnapType || "", 
                n.style.scrollSnapType = "none");
            } catch (e) {}
            a ? i() : t || c ? ce(se()).then(function(e) {
                e || o("当前浏览器不支持全屏"), D(), i();
            }) : i();
        }
        function i() {
            ke === e && e.immersed && (t && (a && fe("landscape") || de("landscape")), setTimeout(function() {
                ke === e && e.immersed && (t && window.innerWidth <= window.innerHeight && be(e.el), 
                D(), Q());
            }, 800), xe(), Ne(e), Q());
        }
    }, Ee.prototype.rotateFs = function(e) {
        this.immersed = !!e, Se = !!e, ke = e ? this : null, e ? be(this.el) : ye(), D(), 
        Q();
    }, Ee.prototype.swipe = function(e) {
        var t = this.el.parentElement;
        if (t) {
            var n = [].slice.call(t.querySelectorAll(".slide")), i = n.indexOf(this.el);
            if (!(i < 0)) {
                var o = n[i + e];
                if (o && (!o.classList || !o.classList.contains("spacer"))) if (this.opts && this.opts.onSwipe) this.opts.onSwipe(e); else {
                    W(t, o, e), Ie(o);
                    var a = _e(o);
                    a && (Y(a), setTimeout(function() {
                        a.play(!0);
                    }, 60));
                }
            }
        }
    }, Ee.prototype.fail = function() {
        return this.err++, this.err <= 1 && this.wanted ? (this.src = "", this.loaded = !1, 
        void this.play()) : this.wanted ? (this.el.classList.remove("loading"), this.el.classList.add("error"), 
        void (this.el.querySelector(".verr .msg").textContent = "这一集暂时播不了，可以试试上下切换或换个线路")) : (this.src = "", 
        void (this.loaded = !1));
    }, Ee.prototype.detach = function() {
        if (this.video._hls) {
            try {
                this.video._hls.destroy();
            } catch (e) {}
            this.video._hls = null;
        }
        try {
            this.video.removeAttribute("src"), this.video.load();
        } catch (e) {}
    }, Ee.prototype.setSource = function(e, t) {
        this.pending = {
            src: e,
            m3u8: t
        };
    }, Ee.prototype.loadNow = function() {
        this.pending && this.src !== this.pending.src && this.load(this.pending.src, this.pending.m3u8);
    }, Ee.prototype.load = function(e, t) {
        if (e && this.src !== e) {
            this.src = e, this.loaded = !0, this.detach();
            var n = this.video;
            n.preload = "auto", t && function() {
                var e = navigator.userAgent || "", t = /iP(hone|ad|od)/i.test(e) || /Macintosh/i.test(e) && /Safari/i.test(e) && !/Chrome|Chromium|Edg|Firefox/i.test(e), n = /Android/i.test(e) && !/Firefox|FxiOS|EdgA|OPR/i.test(e);
                if (!t && !n) return !1;
                try {
                    if (document.createElement("video").canPlayType("application/vnd.apple.mpegurl")) return !0;
                } catch (e) {}
                return n;
            }() ? this.loadNative(e) : t && window.Hls && Hls.isSupported() ? this.loadHls(e) : (n.src = e, 
            this.el.classList.remove("error"));
        }
    }, Ee.prototype.loadNative = function(e) {
        window.__jkNativeTry = (window.__jkNativeTry || 0) + 1;
        var t = this, n = this.video, i = !1;
        function o() {
            n.removeEventListener("loadedmetadata", a), n.removeEventListener("canplay", a), 
            n.removeEventListener("error", r), clearTimeout(s);
        }
        function a() {
            i || (i = !0, o(), t.el.classList.remove("error"));
        }
        function r() {
            i || (i = !0, o(), window.Hls && Hls.isSupported() ? t.loadHls(e) : t.fail());
        }
        var s = setTimeout(r, 9e3);
        n.addEventListener("loadedmetadata", a), n.addEventListener("canplay", a), n.addEventListener("error", r), 
        n.src = e;
        try {
            n.load();
        } catch (e) {
            r();
        }
    }, Ee.prototype.loadHls = function(e) {
        var t = new Hls({
            enableWorker: !0,
            maxBufferLength: 30,
            capLevelToPlayerSize: !0
        }), n = this;
        this.video._hls = t, t.on(Hls.Events.ERROR, function(e, t) {
            t && t.fatal && n.fail();
        }), t.loadSource(e), t.attachMedia(this.video), this.el.classList.remove("error");
    }, Ee.prototype.play = function(e) {
        if (!this.el || this.el.isConnected) {
            var t = this;
            if (this.bumpProg(), !this.userPaused || e) {
                if (this.userPaused = !1, this.wanted = !0, oe(this), !this.src) {
                    if (!this.pending) return this.opts && this.opts.onNeedSrc ? this.opts.onNeedSrc(this) : void 0;
                    this.loadNow();
                }
                this.el.classList.add("loading");
                var n = this.video;
                this.pushAudio(), window.__gestured && !Be.muted() && (n.dataset.unlocked = "1"), 
                this.applyRate(), re = this, function(e) {
                    if ("mediaSession" in navigator && "function" == typeof window.MediaMetadata) try {
                        navigator.mediaSession.metadata = new window.MediaMetadata({
                            title: String(e.title || "短剧").replace(/^《|》$/g, ""),
                            artist: e.tags && e.tags[0] || "多聚短剧",
                            artwork: e.cover ? [ {
                                src: S(e.cover),
                                sizes: "512x512",
                                type: "image/jpeg"
                            } ] : []
                        });
                    } catch (e) {}
                }(this.opts);
                try {
                    "mediaSession" in navigator && (navigator.mediaSession.playbackState = "playing");
                } catch (e) {}
                var i = n.play();
                i && i.catch && i.catch(function(e) {
                    if ((i = e) && /Abort/i.test(i.name || String(i))) return t.aborted = (t.aborted || 0) + 1, 
                    void (t.aborted <= 2 && setTimeout(function() {
                        re !== t || t.userPaused || t.play(!0);
                    }, 250));
                    var i;
                    if (Re(e)) {
                        t.forceMuted = !0, n.muted = !0, n.volume > 0 && (n.dataset.vol = String(n.volume), 
                        n.volume = 0);
                        var o = n.play();
                        o && o.then && o.then(function() {
                            setTimeout(function() {
                                t.unmuteTry();
                            }, 60);
                        }), o && o.catch && o.catch(function(e) {
                            Re(e) ? t.hold() : t.fail();
                        });
                    } else if (n.muted) t.fail(); else {
                        n.muted = !0;
                        var a = n.play();
                        a && a.catch && a.catch(function() {
                            t.fail();
                        });
                    }
                });
            }
        }
    }, Ee.prototype.hold = function() {
        this.autoBlocked = !0, window.__autoBlocked = !0, this.el.classList.remove("error", "loading"), 
        this.el.classList.add("paused"), Oe();
    }, Ee.prototype.unmuteTry = function() {
        var e = this, t = this.video;
        if (!this.forceMuted || !window.__gestured || Be.muted()) return;
        if ((this.unmuteN || 0) >= 2) return void (this.unmuteShown || (this.unmuteShown = !0, 
        this.hint("轻触屏幕恢复声音", 2400)));
        this.unmuteN = (this.unmuteN || 0) + 1, this.forceMuted = !1;
        try {
            t.muted = !1;
            var n = parseFloat(t.dataset.vol || "1");
            t.volume = n > 0 ? n : 1;
        } catch (e) {}
        setTimeout(function() {
            e.userPaused || !e.el || !e.el.isConnected || !e.video.paused || e.video.ended || e.play(!0);
        }, 280);
    }, Ee.prototype.pause = function() {
        this.setFast(!1), this.userPaused = !0, this.wanted = !1;
        try {
            this.video.pause();
        } catch (e) {}
        this.el.classList.add("paused"), this.el.classList.remove("playing"), wakeSync();
    }, Ee.prototype.toggle = function() {
        this.bumpProg(), this.video.paused ? (this.el.classList.remove("paused"), this.play(!0)) : this.pause();
    }, Ee.prototype.reset = function() {
        try {
            this.video.currentTime = 0;
        } catch (e) {}
        this.setBar(0);
    }, Ee.prototype.setBar = function(e) {
        var t = this.bar.firstElementChild;
        t ? t.style.width = e + "%" : this.bar.style.width = e + "%";
    }, Ee.prototype.setTime = function(e, t) {
        this.pcur && (this.pcur.textContent = I(e)), this.ptot && (this.ptot.textContent = t > 0 && isFinite(t) ? I(t) : "--:--");
    }, Ee.prototype.bumpProg = function() {
        xe(), this.progEl && (this.progEl.classList.remove("hide"), clearTimeout(this._progT));
    }, Ee.prototype.release = function() {
        this.detach(), this.src = "", this.loaded = !1;
    }, Ee.prototype.freeCover = function() {
        if (this.coverUrl) {
            var e = this.el.querySelector(".poster");
            e && (e.style.backgroundImage = "");
        }
    }, Ee.prototype.restoreCover = function() {
        if (this.coverUrl) {
            var e = this.el.querySelector(".poster");
            e && !e.style.backgroundImage && (e.style.backgroundImage = 'url("' + this.coverUrl + '")');
        }
    }, Ee.prototype.dispose = function() {
        var e = ie.indexOf(this);
        e >= 0 && ie.splice(e, 1), re === this && (re = null), this.release(), wakeSync();
    },     [ "touchstart", "pointerdown", "click", "keydown" ].forEach(function(e) {
        window.addEventListener(e, function() {
            window.__gestured || (window.__gestured = !0);
            try {
                if (!Be.muted()) {
                    ie.forEach(function(e) {
                        e.forceMuted = !1, e.unmuteN = 0;
                    });
                    document.querySelectorAll(".slide video").forEach(function(e) {
                        e.muted && (e.muted = !1, e.dataset.unlocked = "1");
                        try {
                            e.volume <= 0 && (e.volume = parseFloat(e.dataset.vol || "1") || 1);
                        } catch (e) {}
                    });
                    ie.forEach(function(e) {
                        e.pushAudio && e.pushAudio(), e.wanted && !e.userPaused && e.video && e.video.paused && !e.video.ended && e.play(!0);
                    });
                }
            } catch (e) {}
        }, {
            passive: !0
        });
    });
    var Pe = !1;
    function Fe() {
        var e = re;
        return !(!e || e.userPaused || (e.video && !e.video.paused ? (window.__autoBlocked = !1, 
        0) : (e.autoBlocked = !1, e.play(!0), 0)));
    }
    function Oe() {
        Pe || (Pe = !0, [ 500, 1500, 3500 ].forEach(function(e) {
            setTimeout(function() {
                window.__autoBlocked && Fe();
            }, e);
        }), [ "touchstart", "pointerdown", "mousedown", "keydown" ].forEach(function(e) {
            var t = function() {
                try {
                    window.removeEventListener(e, t, !0);
                } catch (e) {}
                window.__autoBlocked && Fe();
            };
            window.addEventListener(e, t, {
                capture: !0,
                passive: !0
            });
        }));
    }
    var Be = function() {
        var e = "jk_hist", t = "jk_fav", n = "jk_pure", i = "jk_mute";
        function a(e) {
            try {
                var t = localStorage.getItem(e), n = t ? JSON.parse(t) : [];
                return "[object Array]" === Object.prototype.toString.call(n) ? n : [];
            } catch (e) {
                return [];
            }
        }
        var r = 0;
        function s(e, t) {
            try {
                return localStorage.setItem(e, JSON.stringify(t)), !0;
            } catch (e) {
                var n = Date.now();
                return n - r > 5e3 && (r = n, o("本地存储空间已满，请先清理部分收藏或历史")), !1;
            }
        }
        function c(e) {
            return (e.plat || "") + "|" + (e.id || "");
        }
        function l(e) {
            return {
                plat: e.plat || "",
                id: e.id || "",
                name: e.name || "",
                pname: e.pname || "",
                cover: T(e.cover || ""),
                ep: Number(e.ep) || 1,
                ts: Date.now()
            };
        }
        return {
            history: function() {
                return a(e);
            },
            favs: function() {
                return a(t);
            },
            isFav: function(e) {
                var n = c(e);
                return a(t).some(function(e) {
                    return c(e) === n;
                });
            },
            pushHistory: function(t) {
                var n = c(t), i = a(e).filter(function(e) {
                    return c(e) !== n;
                });
                i.unshift(l(t)), i.length > 60 && (i = i.slice(0, 60)), s(e, i), Be.syncFav(t);
            },
            fillCover: function(n, i, o) {
                if (o) {
                    var r = "fav" === n ? t : e, l = a(r), d = !1;
                    l.forEach(function(e) {
                        c(e) !== i || e.cover || (e.cover = T(o), d = !0);
                    }), d && s(r, l);
                }
            },
            lastEp: function(t) {
                var n = c(t), i = 0;
                return a(e).forEach(function(e) {
                    c(e) === n && (i = Number(e.ep) || 0);
                }), i;
            },
            toggleFav: function(e) {
                var n = c(e), i = a(t), r = !1, d = [];
                i.forEach(function(e) {
                    c(e) === n ? r = !0 : d.push(e);
                });
                var u = !1;
                return r || (d.unshift(l(e)), d.length > 2e3 && (d = d.slice(0, 2e3), u = !0)), 
                s(t, d) ? (u && setTimeout(function() {
                    o("收藏上限 2000 条，已移除最早的收藏");
                }, 300), !r) : null;
            },
            clear: function(n) {
                s("fav" === n ? t : e, []);
            },
            remove: function(n, i) {
                var o = {};
                i.forEach(function(e) {
                    o[e] = 1;
                });
                var r = "fav" === n ? t : e;
                s(r, a(r).filter(function(e) {
                    return !o[c(e)];
                }));
            },
            teen: function() {
                try {
                    return "0" !== localStorage.getItem(n);
                } catch (e) {
                    return !0;
                }
            },
            teenSaved: function() {
                try {
                    return null !== localStorage.getItem(n);
                } catch (e) {
                    return !1;
                }
            },
            setTeen: function(e) {
                try {
                    localStorage.setItem(n, e ? "1" : "0");
                } catch (e) {}
            },
            muted: function() {
                try {
                    return "1" === localStorage.getItem(i);
                } catch (e) {
                    return !1;
                }
            },
            setMuted: function(e) {
                try {
                    localStorage.setItem(i, e ? "1" : "0");
                } catch (e) {}
            },
            syncFav: function(e) {
                var n = c(e), i = a(t), o = !1, r = [];
                i.forEach(function(t) {
                    c(t) === n ? (o = !0, r.push(l(e))) : r.push(t);
                }), o && s(t, r);
            }
        };
    }();
    function Ue(e) {
        var t = e.opts && e.opts.fav;
        t && t.id && Be.pushHistory({
            plat: t.plat,
            id: t.id,
            name: t.name,
            pname: t.pname,
            cover: t.cover,
            ep: e.opts.ep || 1
        });
    }
    function je(e) {
        return '<div class="cover">' + (e.cover ? '<img loading="lazy" referrerpolicy="no-referrer" data-np="' + d(String(e.name || "剧").slice(0, 1)) + '" src="' + d(S(e.cover, e.ref)) + '" alt="">' : '<span class="nopic">' + d(String(e.name || "剧").slice(0, 1)) + "</span>") + (e.badge ? '<span class="badge">' + d(e.badge) + "</span>" : "") + (e.eps ? '<span class="eps">' + d(e.eps) + "</span>" : "") + '</div><div class="cname">' + d(e.name) + "</div>";
    }
    function De(e, t, n, i, o) {
        i = i || 24;
        var a = document.createElement("div");
        a.className = o || "grid grid2", e.innerHTML = "", e.appendChild(a);
        var r = 0, s = null;
        function c() {
            s && s.parentNode && s.remove();
            for (var o = r; o < Math.min(r + i, t.length); o++) a.appendChild(n(t[o]));
            (r += i) < t.length && ((s = document.createElement("div")).className = "spin", 
            s.innerHTML = "<b></b>继续加载 " + (t.length - r) + " 条…", e.appendChild(s), d.observe(s));
        }
        var l = e.closest ? e.closest(".pbody") : null, d = new IntersectionObserver(function(e) {
            e.forEach(function(e) {
                e.isIntersecting && c();
            });
        }, {
            root: l,
            rootMargin: "200px"
        });
        return c(), {
            destroy: function() {
                d.disconnect();
            },
            append: function(e) {
                d.disconnect(), s && s.parentNode && s.remove(), e.forEach(function(e) {
                    a.appendChild(n(e));
                }), r = Number.MAX_SAFE_INTEGER;
            }
        };
    }
    var ze = "jk.feed.v1", Ye = 40, Je = {
        items: [],
        active: 0,
        scroll: 0
    }, Xe = 0;
    function Ve() {
        Xe && (clearTimeout(Xe), Xe = 0);
        try {
            if (!Je.items || !Je.items.length) return;
            localStorage.setItem(ze, JSON.stringify({
                at: Date.now(),
                active: Je.active || 0,
                scroll: Je.scroll || 0,
                items: Je.items.slice(-Ye)
            }));
        } catch (e) {}
    }
    function We() {
        Xe || (Xe = setTimeout(Ve, 800));
    }
    function Ke() {
        Xe && (clearTimeout(Xe), Xe = 0);
        try {
            localStorage.removeItem(ze);
        } catch (e) {}
    }
    function Qe() {
        try {
            var e = localStorage.getItem(ze);
            if (!e) return null;
            var t = JSON.parse(e);
            return t && t.items && t.items.length ? Date.now() - (t.at || 0) > 72e5 ? null : t : null;
        } catch (e) {
            return null;
        }
    }
    var $e = !1, Ge = {
        slides: [],
        raw: [],
        active: 0
    };
    function Ze() {
        var e = document.createElement("div");
        e.className = "page";
        var t = document.createElement("div");
        t.className = "feed", e.appendChild(t), V(t, {
            onCommit: function() {
                N(T());
            }
        });
        var n = Ge.slides, i = Ge.raw;
        Je.items = i;
        var a = -1, r = !1, s = !1, c = null, l = 0;
        function u() {
            s || c || n.length || ((c = document.createElement("section")).className = "slide boot", 
            c.innerHTML = '<div class="bootbox"><div class="btip">正在随机挑选短剧…</div>' + E(6) + "</div>", 
            t.appendChild(c), r && h(!0));
        }
        function v() {
            l && (clearTimeout(l), l = 0), h(!1), c && c.parentNode && (c.remove(), c = null);
        }
        n.length || (l = setTimeout(u, 500));
        var f = 0, p = 0;
        function h(e) {
            p && (clearInterval(p), p = 0), e && c && (f = Date.now(), p = setInterval(function() {
                if (!c) return clearInterval(p), void (p = 0);
                var e = "正在随机挑选短剧…（已等待 " + Math.round((Date.now() - f) / 1e3) + "s）", t = c.querySelector(".btip");
                if (t) t.textContent = e; else {
                    var n = c.querySelector(".spin");
                    n && (n.innerHTML = "<b></b>" + e);
                }
            }, 1e3));
        }
        function m(e) {
            h(!1), c || u(), c && (c.innerHTML = '<div class="empty">' + d(e) + '<br><button class="epbtn" type="button" style="margin-top:14px">重新加载</button></div>', 
            c.querySelector(".epbtn").addEventListener("click", function() {
                c.innerHTML = '<div class="spin" style="color:#9a9aa8"><b></b>正在随机挑选短剧…</div>', 
                y(6);
            }));
        }
        function g(e) {
            x(e.plat, e.drama_id, e.cover);
            var o = function() {
                location.hash = "#/series?plat=" + encodeURIComponent(e.plat) + "&id=" + encodeURIComponent(e.drama_id) + "&ep=1";
            }, a = new Ee({
                feed: !0,
                cover: e.cover ? S(e.cover) : "",
                title: e.drama_name || "",
                badge: e.plat_name || "短剧",
                onTitle: o,
                desc: e.desc || "",
                tags: [],
                fav: {
                    plat: e.plat,
                    id: e.drama_id,
                    name: e.drama_name,
                    cover: e.cover,
                    pname: e.plat_name
                },
                ep: e.episode_no,
                btn: {
                    cap: !0,
                    play: !0,
                    text: "观看完整短剧" + (e.total ? " · 共" + e.total + "集" : "") + " · 当前第" + (e.episode_no || 1) + "集",
                    onClick: function(e) {
                        e.stopPropagation(), o();
                    }
                },
                onFail: function(e) {
                    e.err = 0, e.loaded = !1, e.play();
                },
                onSwipe: function(e) {
                    var i = n.indexOf(a), o = i + e;
                    if (!(i < 0 || o < 0 || o >= n.length)) {
                        var r = n[o];
                        r.loadNow(), W(t, r.el, e, function() {
                            N(T());
                        });
                    }
                }
            });
            return a.setSource(e.play, e.m3u8), n.push(a), i.push(e), We(), t.appendChild(a.el), 
            M.observe(a.el), a;
        }
        function y(e) {
            r || (r = !0, c && h(!0), b("/feed?n=" + (e || 6) + "&blk=1" + (Be.teen() ? "&teen=1" : ""), {
                timeout: w
            }).then(function(e) {
                if (!s) {
                    var t = e.items || [];
                    if (t.length) {
                        v(), L(), t.forEach(g);
                        for (var i = n.length - t.length, r = i; r < Math.min(i + 2, n.length); r++) n[r].loadNow();
                        a < 0 && N(0);
                    } else n.length ? o("没有取到新的短剧，稍后再试") : m("暂时没能取到可播放的短剧");
                }
            }).catch(function(e) {
                var t = e && e.message ? e.message : String(e);
                n.length ? o("加载失败：" + t) : m(t);
            }).then(function() {
                r = !1;
            }));
        }
        function k() {
            n.length && (Ge.scroll = t.scrollTop, Ge.active = T(), Je.active = Ge.active, Je.scroll = Ge.scroll, 
            We());
        }
        function T() {
            return K(n.map(function(e) {
                return e.el;
            }), t.scrollTop);
        }
        var C = 0;
        t.addEventListener("scroll", function() {
            C || (C = setTimeout(function() {
                C = 0, k(), H();
            }, 150));
        }, {
            passive: !0
        });
        var M = new IntersectionObserver(function(e) {
            if (!ke) {
                var n = t.__silk;
                n && (n.animating || n.dragging) || e.some(function(e) {
                    return e.isIntersecting && e.intersectionRatio >= .6;
                }) && (k(), Ge.active !== a ? N(Ge.active) : H());
            }
        }, {
            root: t,
            threshold: [ .6 ]
        }), q = 24;
        function H() {
            if (ke && t.contains(ke.el)) {
                if (ke.userPaused || ke.err) return;
                if (ke.video && !ke.video.paused) return;
                ke.play(!0);
            } else if (!(a < 0)) {
                var e = n[a];
                !e || e.userPaused || e.err || e.video && !e.video.paused || e.play(!0);
            }
        }
        function N(e) {
            if (!s) if (e !== a) {
                a = e, n.forEach(function(t, n) {
                    Math.abs(n - e) > 2 ? (t.release(), t.freeCover()) : (t.loadNow(), t.restoreCover()), 
                    t.reset(), n !== e && t.pause();
                }), function() {
                    if (!(n.length <= q || a < 12)) {
                        var e = n.length - q;
                        if (!(e <= 0 || a < e)) {
                            for (var o = 0, r = 0; r < e; r++) o += n[r].el.offsetHeight || t.clientHeight, 
                            n[r].dispose(), n[r].el.remove();
                            var s = document.createElement("div");
                            s.className = "slide spacer", s.style.height = o + "px", t.insertBefore(s, n[e].el), 
                            n.splice(0, e), i.splice(0, e), a -= e, Ge.active = a, Je.active = a, We(), window.__dbg && console.log("[trim] 回收 " + e + " 条，剩余 " + n.length);
                        }
                    }
                }(), e = Math.max(0, Math.min(a, n.length - 1)), a = e, Ge.active = e;
                var o = n[e];
                o && (o.err && (o.err = 0, o.src = "", o.loaded = !1), o.el.classList.remove("paused", "error"), 
                o.loadNow(), o.play(!0), Ie(o.el), ke && Y(o), n.length > 3 && e >= n.length - 3 && y(6));
            } else H();
        }
        var _, I, A, R = !1;
        if (!n.length) {
            var P = Qe();
            P && P.items && P.items.length && (P.items.forEach(function(e) {
                g(e);
            }), Ge.scroll = P.scroll || 0, Ge.active = Math.max(0, Math.min(P.active || 0, n.length - 1)), 
            Je.active = Ge.active, Je.scroll = Ge.scroll, R = !0, window.__dbg && console.log("[cache] 本地缓存秒开 " + n.length + " 条，第 " + (Ge.active + 1) + " 条"));
        }
        n.length ? (n.forEach(function(e) {
            t.appendChild(e.el), M.observe(e.el);
        }), _ = Ge.scroll || 0, I = 0, A = !1, function e() {
            if (!s && n.length && !A) {
                if (Math.abs(t.scrollTop - _) > 2) {
                    var i = t.style.scrollSnapType;
                    t.style.scrollSnapType = "none", t.scrollTop = _, requestAnimationFrame(function() {
                        t.style.scrollSnapType = i || "";
                    });
                }
                Math.abs(t.scrollTop - _) > 2 && ++I < 12 ? requestAnimationFrame(e) : (A = !0, 
                window.__dbg && console.log("[restore] want=" + _ + " got=" + t.scrollTop + " idx=" + T() + " saved=" + Ge.active + " tries=" + I), 
                N(T()));
            }
        }(), v(), L(), R && setTimeout(function() {
            s || y(6);
        }, 500)) : y(8), this.el = e, this.onOnline = function() {
            s || r || n.length || (c && (c.innerHTML = '<div class="spin" style="color:#9a9aa8"><b></b>正在随机挑选短剧…</div>'), 
            y(8));
        }, this.destroy = function() {
            s = !0, l && (clearTimeout(l), l = 0), h(!1), M.disconnect(), C && (clearTimeout(C), 
            C = 0);
            var e = Math.max(0, Math.min(Ge.active || 0, n.length - 1));
            n.forEach(function(t, n) {
                t.pause(), Math.abs(n - e) > 1 && t.release();
            }), Je.active = e, Je.scroll = Ge.scroll || 0, Ve();
        };
    }
    function et(e, t, n) {
        var i = document.createElement("div");
        i.className = "page";
        var a = document.createElement("div");
        a.className = "feed", i.appendChild(a), V(a, {
            onCommit: function() {
                var e = K(p, a.scrollTop);
                e >= 0 && e < s.length && D(e);
            }
        });
        var r = null, s = [], c = -1, l = Object.create(null), u = [], v = !1, f = !1, p = [], h = 4, m = 0, g = 30, y = document.createElement("div");
        y.className = "mask";
        var w = document.createElement("div");
        function E() {
            y.classList.remove("on"), w.classList.remove("on");
        }
        w.className = "drawer", w.innerHTML = '<div class="dhd"><div class="dcov"></div><div class="dinfo"><b class="dname"></b><span class="dsub"></span></div><button type="button" class="dclose" aria-label="关闭">&times;</button></div><div class="dtabs" hidden><button type="button" class="dtab" data-t="info">简介</button><button type="button" class="dtab on" data-t="eps">选集</button><button type="button" class="dtab" data-t="ser">系列剧</button></div><div class="dbody"><div class="dpane" data-p="info" hidden><div class="idesc"></div></div><div class="dpane" data-p="eps"><div class="drange" hidden></div><div class="eplist"></div></div><div class="dpane" data-p="ser" hidden><div class="slist"></div></div></div><button type="button" class="favbtn"></button>', 
        function() {
            for (var e = 0; e < arguments.length; e++) O.push(arguments[e]);
            U();
        }(y, w);
        var L = Z(function() {
            return w.classList.contains("on") ? (E(), !0) : !(!ke && !j() || (He(), 0));
        });
        function k(e) {
            w.querySelectorAll(".dtab").forEach(function(t) {
                t.classList.toggle("on", t.dataset.t === e);
            }), w.querySelectorAll(".dpane").forEach(function(t) {
                t.hidden = t.dataset.p !== e;
            });
        }
        y.addEventListener("click", E), w.querySelector(".dclose").addEventListener("click", E), 
        w.querySelectorAll(".dtab").forEach(function(e) {
            e.addEventListener("click", function() {
                k(e.dataset.t);
            });
        });
        var T = w.querySelector(".favbtn");
        function C() {
            return {
                plat: e,
                id: t,
                name: r && r.name,
                cover: r && r.cover,
                pname: r && r.plat_name
            };
        }
        function M() {
            var e = Be.isFav(C());
            T.textContent = e ? "已收藏 · 可在「我的」查看" : "收藏", T.classList.toggle("on", e);
        }
        function H(e) {
            w.querySelector(".drange").querySelectorAll(".rg").forEach(function(t) {
                t.classList.toggle("on", Number(t.dataset.r) === e);
            });
            var t = w.querySelector(".eplist");
            t.innerHTML = "";
            for (var n = e * g, i = Math.min(n + g, r.episodes.length), o = n; o < i; o++) {
                var a = document.createElement("div");
                a.className = "epi", a.dataset.no = String(o + 1), a.textContent = String(o + 1), 
                a.title = r.episodes[o] && r.episodes[o].name || "第" + (o + 1) + "集", a.addEventListener("click", function() {
                    E(), z(Number(this.dataset.no) - 1);
                }), t.appendChild(a);
            }
            var s = t.querySelector('.epi[data-no="' + (c + 1) + '"]');
            s && s.classList.add("on");
        }
        function N(e) {
            if (r) {
                U();
                var t = w.querySelector(".dcov");
                r.cover ? t.innerHTML = '<img alt="" data-np="' + d(String(r.name || "剧").slice(0, 1)) + '" src="' + d(S(r.cover)).replace(/"/g, "%22") + '">' : t.innerHTML = "", 
                w.querySelector(".dname").textContent = r.name || "", w.querySelector(".dsub").textContent = "第" + (c + 1) + "集 · 全" + r.episodes.length + "集" + (r.remarks ? " · " + r.remarks : ""), 
                function() {
                    var e = w.querySelector(".idesc");
                    if (e && r) {
                        var t = [ [ "剧名", r.name || "" ], [ "平台", r.plat_name || "" ], [ "集数", "共" + (r.episodes ? r.episodes.length : r.total || 0) + "集" ], [ "状态", r.remarks || "连载中" ] ];
                        e.innerHTML = '<div class="imeta">' + t.map(function(e) {
                            return '<div class="irow"><span>' + d(e[0]) + "</span><b>" + d(e[1]) + "</b></div>";
                        }).join("") + '</div><div class="itxt">' + d(r.desc || "暂无简介") + "</div>";
                    }
                }(), w.querySelector(".dtabs").hidden = !1, w.querySelector('.dtab[data-t="ser"]').hidden = !u.length, 
                k(e || "eps"), function() {
                    var e = w.querySelector(".drange");
                    e.innerHTML = "";
                    var t = Math.ceil(r.episodes.length / g);
                    if (t <= 1) e.hidden = !0; else {
                        e.hidden = !1;
                        for (var n = 0; n < t; n++) {
                            var i = document.createElement("button");
                            i.type = "button", i.className = "rg", i.dataset.r = String(n), i.textContent = n * g + 1 + "-" + Math.min((n + 1) * g, r.episodes.length), 
                            i.addEventListener("click", function() {
                                H(Number(this.dataset.r));
                            }), e.appendChild(i);
                        }
                    }
                }(), H(Math.floor(c / g)), M(), y.classList.add("on"), w.classList.add("on");
            }
        }
        function _(e) {
            return '<div class="vtop">' + ((t = (t = {
                back: !0,
                close: !0
            }) || {}).back ? '<button type="button" class="bk">&#8249;</button>' : "") + '<div class="tt">' + d("第" + (e + 1) + "集" || "") + "</div>" + (t.sel ? '<button type="button" class="sel">选集</button>' : "") + (t.close ? '<button type="button" class="vclose" aria-label="关闭"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button>' : "") + "</div>";
            var t;
        }
        T.addEventListener("click", function(e) {
            e.stopPropagation();
            var t = Be.toggleFav(C());
            if (null !== t) {
                try {
                    i.querySelectorAll(".vside .fav").forEach(function(e) {
                        e.classList.toggle("on", t);
                    });
                } catch (e) {}
                if (t) {
                    var n = s[c];
                    n && Ue(n);
                }
                M(), o(t ? "已收藏，可在「我的」里查看" : "已取消收藏");
            } else M();
        });
        var I = 0;
        function A() {
            !v && r && r.name && b("/seasons?plat=" + encodeURIComponent(e) + "&id=" + encodeURIComponent(t) + "&name=" + encodeURIComponent(r.name)).then(function(t) {
                if (!f) {
                    var n = t && t.list || [], i = n.filter(function(e) {
                        return !e.current;
                    });
                    v = !0, i.length && (u = n, function(t) {
                        var n = w.querySelector(".slist");
                        n.innerHTML = "", t.forEach(function(t) {
                            var i = document.createElement("div");
                            i.className = "sitem" + (t.current ? " on" : "");
                            var a = document.createElement("div");
                            a.className = "scov", t.cover && (a.style.backgroundImage = 'url("' + S(t.cover).replace(/"/g, "%22") + '")');
                            var r = document.createElement("div");
                            r.className = "sinfo";
                            var s = document.createElement("b");
                            s.textContent = t.name || "";
                            var c = document.createElement("span");
                            if (c.textContent = (t.label || "") + (t.remarks ? " · " + t.remarks : ""), r.appendChild(s), 
                            r.appendChild(c), i.appendChild(a), i.appendChild(r), t.current) {
                                var l = document.createElement("em");
                                l.textContent = "正在看", i.appendChild(l);
                            }
                            i.addEventListener("click", function() {
                                E(), t.current ? o("正在看这一部") : location.hash = "#/series?plat=" + encodeURIComponent(t.plat || e) + "&id=" + encodeURIComponent(t.id) + "&ep=1";
                            }), n.appendChild(i);
                        });
                    }(n));
                }
            }).catch(function() {
                ++I < 2 ? (v = !1, setTimeout(A, 2500)) : v = !0;
            });
        }
        function R(n) {
            if (s[n]) return s[n];
            if (n < 0 || n >= s.length) return null;
            var i = p[n] || null, d = new Ee({
                cover: r.cover ? S(r.cover) : "",
                before: _(n),
                title: "《" + r.name + "》 第" + (n + 1) + "集",
                desc: r.desc || "",
                badge: r.plat_name,
                tags: [],
                immerse: !0,
                fav: {
                    plat: e,
                    id: t,
                    name: r.name,
                    cover: r.cover,
                    pname: r.plat_name
                },
                ep: n + 1,
                btn: {
                    cap: !0,
                    fs: !0,
                    text: "选集 · 共" + m + "集 · 当前第" + (n + 1) + "集",
                    onClick: function(e) {
                        e.stopPropagation(), N("eps");
                    }
                },
                onBack: function() {
                    history.back();
                },
                onNeedSrc: function(e) {
                    F(n);
                },
                onEnded: function() {
                    !function(e) {
                        f || (e + 1 < s.length ? z(e + 1) : (o("已经是最后一集了"), w.classList.contains("on") || N("eps")));
                    }(n);
                },
                onSwipe: function(e) {
                    !function(e) {
                        if (!f) {
                            var t = -1;
                            if (ke) for (var n = 0; n < p.length; n++) if (p[n] === ke.el) {
                                t = n;
                                break;
                            }
                            if (t < 0) for (var i = 0; i < s.length; i++) if (s[i] && s[i].el && s[i].el.classList.contains("rotfs")) {
                                t = i;
                                break;
                            }
                            t < 0 && (t = c), z(t + e);
                        }
                    }(e);
                },
                onFail: function(e) {
                    l[n + 1] = !1, F(n);
                }
            });
            return d.el.dataset.idx = n, i && i.parentNode ? i.parentNode.replaceChild(d.el, i) : a.appendChild(d.el), 
            p[n] = d.el, B.observe(d.el), s[n] = d, d;
        }
        function P(e) {
            var t = s[e];
            if (t) {
                t.dispose();
                var n = document.createElement("section");
                n.className = "slide stub", n.dataset.idx = e, r && r.cover && (n.style.backgroundImage = 'url("' + S(r.cover).replace(/"/g, "%22") + '")', 
                n.style.backgroundSize = "contain", n.style.backgroundRepeat = "no-repeat", n.style.backgroundPosition = "center"), 
                n.style.backgroundColor = "#000", t.el.parentNode ? t.el.parentNode.replaceChild(n, t.el) : a.appendChild(n), 
                p[e] = n, B.observe(n), s[e] = null;
            }
        }
        function F(n) {
            if (!f) {
                var i = s[n];
                if (i && !i.src) {
                    var a = n + 1;
                    l[a] || (l[a] = !0, b("/episode?plat=" + encodeURIComponent(e) + "&id=" + encodeURIComponent(t) + "&ep=" + a).then(function(e) {
                        !f && s[n] && s[n].el.isConnected && (s[n].load(e.play, e.m3u8), n === c && s[n].play());
                    }).catch(function(e) {
                        s[n] && !f && s[n].fail(), o("第" + a + "集解析失败");
                    }).then(function() {
                        l[a] = !1;
                    }));
                }
            }
        }
        var B = new IntersectionObserver(function(e) {
            if (!ke) {
                var t = a.__silk;
                t && (t.animating || t.dragging) || e.forEach(function(e) {
                    if (e.isIntersecting && !(e.intersectionRatio < .6)) {
                        var t = e.target.dataset ? Number(e.target.dataset.idx) : -1;
                        t >= 0 && t < s.length && D(t);
                    }
                });
            }
        }, {
            root: a,
            threshold: [ .6 ]
        });
        function D(n) {
            if (!f && n !== c) {
                c = n, R(n), R(n + 1), R(n - 1);
                for (var i = 0; i < s.length; i++) {
                    var o = s[i];
                    o && (Math.abs(i - n) > h ? P(i) : (Math.abs(i - n) > 1 && o.release(), o.reset(), 
                    i !== n && o.pause()));
                }
                var a = s[n];
                a.err && (a.err = 0, a.src = "", a.loaded = !1), a.el.classList.remove("paused", "error"), 
                a.src ? a.play(!0) : F(n), Ue(a), F(n + 1), F(n - 1), history.replaceState(null, "", "#/series?plat=" + encodeURIComponent(e) + "&id=" + encodeURIComponent(t) + "&ep=" + (n + 1)), 
                Ie(a.el), ke && Y(a);
            }
        }
        function z(e, t) {
            if (!(e < 0 || e >= s.length)) {
                R(e);
                var n = p[e];
                if (t) {
                    var i = n && n.classList && n.classList.contains("rotfs") ? a.scrollTop + (e - c) * (a.clientHeight || n.offsetHeight || 0) : n ? n.offsetTop : 0;
                    return a.scrollTop = i, void setTimeout(function() {
                        D(e);
                    }, 30);
                }
                W(a, n, e - c, function() {
                    D(e);
                });
            }
        }
        function J() {
            b("/series?plat=" + encodeURIComponent(e) + "&id=" + encodeURIComponent(t)).then(function(i) {
                if (!f) {
                    var o = q(e, t);
                    o ? i.cover = o : i.cover && x(e, t, i.cover), r = i, function() {
                        a.innerHTML = "";
                        var e = r.episodes || [];
                        if (e.length) {
                            m = r.total || e.length;
                            var t = e.length;
                            s = new Array(t).fill(null), p = [];
                            for (var i = 0; i < t; i++) {
                                var o = document.createElement("section");
                                o.className = "slide stub", o.dataset.idx = i, r.cover && (o.style.backgroundImage = 'url("' + S(r.cover).replace(/"/g, "%22") + '")', 
                                o.style.backgroundSize = "contain", o.style.backgroundRepeat = "no-repeat", o.style.backgroundPosition = "center"), 
                                o.style.backgroundColor = "#000", a.appendChild(o), p.push(o), B.observe(o);
                            }
                            z(Math.max(0, Math.min(n - 1, t - 1)), !0);
                        } else a.innerHTML = '<div class="empty">这部剧暂时没有可播放的集数</div>';
                    }(), r.episodes && r.episodes.length && A();
                }
            }).catch(function(e) {
                if (!f) {
                    a.innerHTML = '<div class="empty">' + d(e.message) + '<br><button class="epbtn retry" type="button" style="margin-top:14px">重试</button></div>';
                    var t = a.querySelector(".retry");
                    t && t.addEventListener("click", J);
                }
            });
        }
        this.el = i, this.isSeries = !0, this.destroy = function() {
            f = !0, B.disconnect(), ee(L), s.forEach(function(e, t) {
                e && e.dispose ? e.dispose() : p[t] && p[t].parentNode && p[t].remove();
            }), function() {
                for (var e = 0; e < arguments.length; e++) {
                    var t = O.indexOf(arguments[e]);
                    t >= 0 && O.splice(t, 1);
                }
            }(y, w), y.remove(), w.remove();
        }, this.onOnline = function() {
            if (!f) if (r) {
                var e = s[c];
                e && e.err && (e.err = 0, e.src = "", e.loaded = !1, e.play());
            } else J();
        }, J();
    }
    var tt = {
        plat: "",
        cat: "",
        plats: null,
        list: null,
        key: "",
        scroll: 0,
        pticket: 1,
        q: "",
        slist: null,
        sscroll: 0,
        splat: "",
        lastQ: "",
        unions: null,
        ucat: "",
        ulist: null,
        ukey: "",
        uplats: null,
        uticket: 1,
        uwrap: !1,
        feed: null,
        fticket: 1
    };
    function nt() {
        var e = document.createElement("div");
        e.className = "page", e.innerHTML = '<div class="sbox"><select class="psel" aria-label="搜索范围"><option value="">聚合</option></select><input type="search" placeholder="搜短剧名 / 关键字" autocomplete="off"><button type="button" class="go">搜索</button></div><div class="cfilter"><div class="catsbar"><button type="button" class="utog" hidden aria-label="展开分类"></button><div class="chips cats"></div></div></div><div class="pbody"><div class="sres-hd" hidden></div><div class="result"></div></div>';
        var t = e.querySelector(".psel"), n = e.querySelector(".cats"), i = e.querySelector(".utog"), a = e.querySelector(".result"), r = e.querySelector(".pbody"), s = e.querySelector(".cfilter"), c = e.querySelector(".sres-hd"), l = e.querySelector(".sbox input");
        l.addEventListener("input", function() {
            !l.value && L && ve();
        }), l.addEventListener("search", function() {
            !l.value && L && ve();
        }), i.addEventListener("click", function(e) {
            e.stopPropagation(), tt.uwrap = !tt.uwrap, I();
        });
        var u = [], v = [], f = null, p = H("plat") || tt.plat || "", h = H("cat") || tt.cat || "", m = H("ucat") || tt.ucat || "", g = null, y = null, L = !1, k = !1, T = "";
        function S() {
            requestAnimationFrame(function() {
                try {
                    r.scrollTop = tt.scroll || 0;
                } catch (e) {}
            });
        }
        function C(e) {
            var t = u.find(function(t) {
                return t.key === e;
            });
            return t ? t.name : "";
        }
        function M() {
            var e = !p;
            s.style.display = L ? "none" : "", l.placeholder = e ? "搜短剧名 / 关键字（全部平台）" : "搜 " + (C(p) || "该平台") + " 里的短剧";
        }
        function q(e, t) {
            if (e && t) {
                var n = t.getBoundingClientRect(), i = e.getBoundingClientRect();
                if (!(n.left >= i.left + 4 && n.right <= i.right - 4)) {
                    var o = t.offsetLeft - e.clientWidth / 2 + t.offsetWidth / 2;
                    e.scrollTo ? e.scrollTo({
                        left: Math.max(0, o),
                        behavior: "smooth"
                    }) : e.scrollLeft = Math.max(0, o);
                }
            }
        }
        function N(e) {
            var t = Be.lastEp(e), n = t > 1 ? t : 1;
            location.hash = "#/series?plat=" + encodeURIComponent(e.plat) + "&id=" + encodeURIComponent(e.id) + "&ep=" + n, 
            t > 1 && o("上次看到第" + t + "集，已续播");
        }
        function _() {
            if (tt.unions && tt.unions.length) return g = tt.unions, void I();
            b("/unions" + (Be.teen() ? "?teen=1" : "")).then(function(e) {
                tt.unions = e.unions || [], g = tt.unions, I();
            }).catch(function() {
                g = [], tt.unions = [];
            });
        }
        function I() {
            if (!p && !L && g) {
                n.innerHTML = "";
                var e = null, t = !!tt.uwrap;
                n.parentNode.classList.toggle("wrap", t), n.classList.toggle("wrap", t), i.hidden = !1, 
                i.classList.toggle("on2", t), i.title = t ? "收起成一行" : "换行显示全部分类", i.setAttribute("aria-label", i.title), 
                i.innerHTML = t ? '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="1.9" y="6.9" width="12.2" height="2.2" rx="1.1"/></svg>' : '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><rect x="1.9" y="2.9" width="4.8" height="4.2" rx="1"/><rect x="9.3" y="2.9" width="4.8" height="4.2" rx="1"/><rect x="1.9" y="8.9" width="4.8" height="4.2" rx="1"/><rect x="9.3" y="8.9" width="4.8" height="4.2" rx="1"/></svg>', 
                o("推荐", 0, !m, "随机混合各平台内容").addEventListener("click", function() {
                    (m || tt.uwrap) && (tt.uwrap = !1, m = "", y = null, j(), D(), I(), Y());
                }), g.forEach(function(e) {
                    var t = e.name === m;
                    o(e.name, e.n, t, "来自 " + e.n + " 个平台：" + (e.plats || []).map(function(e) {
                        return e.name;
                    }).join("、")).addEventListener("click", function() {
                        t && !tt.uwrap || (tt.uwrap = !1, m = e.name, y = null, j(), D(), I(), X(1));
                    });
                }), n.style.display = "", t || q(n, e);
            }
            function o(t, i, o, a) {
                var r = document.createElement("button");
                return r.type = "button", r.className = "chip ucat" + (o ? " on" : ""), r.title = a || "", 
                r.innerHTML = d(t) + (i > 1 ? " <i>" + i + "</i>" : ""), n.appendChild(r), o && (e = r), 
                r;
            }
        }
        function A() {
            c && (c.hidden = !0, c.innerHTML = "");
        }
        function R(e) {
            e && e.length ? (c.innerHTML = '<span class="k">「' + d(m) + "」· 来自 " + e.length + " 个平台：" + d(e.join("、")) + "</span>", 
            c.hidden = !1) : A();
        }
        function P() {
            var e = u.find(function(e) {
                return e.key === p;
            }) || u[0];
            p = e.key, A(), i.hidden = !0, n.classList.remove("wrap"), n.parentNode.classList.remove("wrap"), 
            n.innerHTML = "";
            var t = e.cats || [];
            "" === h && t.length && (h = t[0].id);
            var o = null;
            t.forEach(function(e) {
                var t = document.createElement("button");
                t.className = "chip" + (e.id === h ? " on" : ""), t.textContent = e.name, e.id === h && (o = t), 
                t.addEventListener("click", function() {
                    e.id !== h && (h = e.id, j(), D(), P(), W(1));
                }), n.appendChild(t);
            }), n.style.display = t.length ? "" : "none", q(n, o);
        }
        function F(e) {
            f && f.destroy && f.destroy(), a.innerHTML = "", e.length ? f = De(a, e, function(e) {
                x(e.plat, e.id, e.cover);
                var t = document.createElement("div");
                return t.className = "citem", t.innerHTML = je({
                    cover: e.cover,
                    ref: "",
                    badge: e.plat_name,
                    eps: e.remarks,
                    name: e.name
                }), t.addEventListener("click", function() {
                    N(e);
                }), t;
            }, 30, "grid") : a.innerHTML = '<div class="empty">这个分类暂时没有内容</div>';
        }
        function O(e, t) {
            f && f.destroy && f.destroy(), a.innerHTML = "", c.hidden = !0, e.length ? (c.innerHTML = '<span class="k">「' + d(t) + "」" + (p ? "在「" + d(C(p)) + "」" : "（聚合）") + "共 " + e.length + ' 条</span><span class="bk2">返回剧场</span>', 
            c.hidden = !1, c.querySelector(".bk2").addEventListener("click", function() {
                ve();
            }), f = De(a, e, function(e) {
                x(e.plat, e.id, e.cover);
                var t = document.createElement("div");
                return t.className = "citem", t.innerHTML = je({
                    cover: e.cover,
                    ref: "",
                    badge: e.plat_name,
                    eps: e.remarks,
                    name: e.name
                }), t.addEventListener("click", function() {
                    N(e);
                }), t;
            }, 30, "grid")) : a.innerHTML = '<div class="empty">没有找到相关短剧</div>';
        }
        function B() {
            return p + "|" + h;
        }
        function U() {
            return "U|" + m;
        }
        function j() {
            tt.plat = p, tt.cat = h, p || (tt.ucat = m);
        }
        function D() {
            tt.scroll = 0, re = !1;
            try {
                r.scrollTop = 0;
            } catch (e) {}
        }
        function z(e) {
            return "/mix?n=" + (e || 12) + (Be.teen() ? "&teen=1" : "");
        }
        function Y() {
            L = !1, A();
            var e = ++V;
            if (tt.feed && tt.feed.length) return v = tt.feed, T = "FEED", ne = tt.fticket || 1, 
            F(v), Q(), void S();
            ne = 1, a.innerHTML = E(9), oe.hidden = !0, b(z(12), {
                timeout: w
            }).then(function(t) {
                e === V && (v = t.list || [], T = "FEED", tt.feed = v, tt.fticket = ne, v.length ? (F(v), 
                Q()) : K());
            }).catch(function(t) {
                if (e === V) {
                    a.innerHTML = '<div class="empty">' + d(t && t.message ? t.message : "拉取失败") + '<br><button class="epbtn retry" type="button" style="margin-top:14px">重试</button></div>';
                    var n = a.querySelector(".retry");
                    n && n.addEventListener("click", function() {
                        Y();
                    });
                }
            });
        }
        function J(e) {
            return "/union?cat=" + encodeURIComponent(m) + "&page=" + (e || 1) + (Be.teen() ? "&teen=1" : "");
        }
        function X(e) {
            if (m) {
                L = !1, ne = e || 1;
                var t = ++V, n = U();
                if (tt.ulist && tt.ukey === n) return v = tt.ulist, T = n, ne = tt.uticket || 1, 
                R(y = tt.uplats), F(v), Q(), void S();
                a.innerHTML = E(9), oe.hidden = !0, c.hidden = !0, b(J(ne), {
                    timeout: 6e4
                }).then(function(e) {
                    t === V && (v = e.list || [], y = e.plat_names || [], T = n, tt.ucat = m, tt.ukey = n, 
                    tt.ulist = v, tt.uplats = y, tt.uticket = ne, R(y), v.length ? (F(v), Q()) : K());
                }).catch(function(e) {
                    if (t === V) {
                        a.innerHTML = '<div class="empty">' + d(e && e.message ? e.message : "拉取失败") + '<br><button class="epbtn retry" type="button" style="margin-top:14px">重试</button></div>';
                        var n = a.querySelector(".retry");
                        n && n.addEventListener("click", function() {
                            X(ne);
                        });
                    }
                });
            } else Y();
        }
        var V = 0;
        function W(e) {
            ne = e || 1, A();
            var t = ++V, n = B();
            if (tt.list && tt.key === n) return v = tt.list, T = n, ne = tt.pticket || 1, F(v), 
            Q(), void S();
            a.innerHTML = E(9), oe.hidden = !0, b("/list?plat=" + encodeURIComponent(p) + "&cat=" + encodeURIComponent(h) + "&page=" + ne).then(function(e) {
                t === V && (v = e.list || [], T = B(), j(), tt.key = B(), tt.list = v, tt.pticket = ne, 
                v.length ? (F(v), Q()) : K());
            }).catch(function(e) {
                if (t === V) {
                    a.innerHTML = '<div class="empty">' + d(e.message) + '<br><button class="epbtn retry" type="button" style="margin-top:14px">重试</button></div>';
                    var n = a.querySelector(".retry");
                    n && n.addEventListener("click", function() {
                        W(ne);
                    });
                }
            });
        }
        function K() {
            var e = p ? "这个分类暂时没有内容" : m ? "「" + m + "」这几个平台暂时没有内容" : "聚推暂时没有内容";
            a.innerHTML = '<div class="empty">' + d(e) + '<br><button class="epbtn retry" type="button" style="margin-top:14px">重试</button></div>', 
            oe && (oe.hidden = !0);
            var t = a.querySelector(".retry");
            t && t.addEventListener("click", function() {
                p ? W(ne) : m ? X(ne) : Y();
            });
        }
        function Q() {
            ie = v.length >= 12, $();
        }
        function $() {
            oe.hidden = L || !ie, oe.classList.toggle("ghost", !oe.hidden && !p), G || (ae.textContent = "加载更多");
        }
        var G = !1;
        function te(e) {
            G || L || (p ? u.length && (G = !0, $(), b("/list?plat=" + encodeURIComponent(p) + "&cat=" + encodeURIComponent(h) + "&page=" + e).then(function(t) {
                var n = t.list || [], i = {};
                v.forEach(function(e) {
                    i[e.id] = 1;
                });
                var a = n.filter(function(e) {
                    return e.id && !i[e.id];
                });
                if (!a.length) return ie = !1, $(), void o("没有更多内容了");
                v = v.concat(a), ne = e, tt.list = v, tt.key = B(), tt.pticket = ne, f && f.append ? f.append(a) : F(v), 
                ie = !0, $();
            }).catch(function(e) {
                ae.textContent = "加载失败，点此重试", o(e && e.message ? e.message : "加载失败");
            }).then(function() {
                G = !1, $();
            })) : m ? function(e) {
                G || (G = !0, $(), b(J(e), {
                    timeout: 6e4
                }).then(function(t) {
                    var n = t.list || [], i = {};
                    v.forEach(function(e) {
                        i[e.id] = 1;
                    });
                    var a = n.filter(function(e) {
                        return e.id && !i[e.id];
                    });
                    if (!a.length) return ie = !1, $(), void o("这个分类暂时没有更多了");
                    v = v.concat(a), ne = e, tt.ukey = U(), tt.ulist = v, tt.uticket = ne, f && f.append ? f.append(a) : F(v), 
                    ie = !0, $();
                }).catch(function(e) {
                    ae.textContent = "加载失败，点此重试", o(e && e.message ? e.message : "加载失败");
                }).then(function() {
                    G = !1, $();
                }));
            }(e) : G || (G = !0, $(), b(z(12), {
                timeout: w
            }).then(function(e) {
                var t = e.list || [], n = {};
                v.forEach(function(e) {
                    n[e.id] = 1;
                });
                var i = t.filter(function(e) {
                    return e.id && !n[e.id];
                });
                if (!i.length) return ie = !1, $(), void o("聚推暂时没有更多了");
                v = v.concat(i), tt.feed = v, f && f.append ? f.append(i) : F(v), ie = !0, $();
            }).catch(function(e) {
                ae.textContent = "加载失败，点此重试", o(e && e.message ? e.message : "加载失败");
            }).then(function() {
                G = !1, $();
            })));
        }
        var ne = 1, ie = !1, oe = document.createElement("div");
        oe.className = "morewrap", oe.hidden = !0, oe.innerHTML = '<button class="more" type="button">加载更多</button>', 
        r.appendChild(oe);
        var ae = oe.querySelector(".more");
        ae.addEventListener("click", function() {
            te(ne + 1);
        });
        var re = !1;
        function se() {
            ie && !L && !G && re && (r.scrollHeight <= r.clientHeight + 40 || r.scrollTop + r.clientHeight < r.scrollHeight - 300 || te(ne + 1));
        }
        r.addEventListener("scroll", function() {
            r.scrollTop > 8 && (re = !0), se();
        }, {
            passive: !0
        });
        var ce = new IntersectionObserver(function(e) {
            e.forEach(function(e) {
                e.isIntersecting && se();
            });
        }, {
            root: r,
            rootMargin: "300px"
        });
        function le(e) {
            u = e || [], t.innerHTML = '<option value="">聚合</option>', u.forEach(function(e) {
                var n = document.createElement("option");
                n.value = e.key, n.textContent = e.name, t.appendChild(n);
            }), p && !u.some(function(e) {
                return e.key === p;
            }) && (p = ""), t.value = p, j(), M(), k = !0, p ? P() : (_(), I()), L || (p ? W(1) : m ? X(1) : Y());
        }
        function de() {
            k || (tt.plats && tt.plats.length ? le(tt.plats) : b("/platforms" + (Be.teen() ? "?teen=1" : "")).then(function(e) {
                tt.plats = e.platforms || [], le(tt.plats);
            }).catch(function() {
                tt.plats = tt.plats || [], le(tt.plats);
            }));
        }
        ce.observe(oe), t.addEventListener("change", function() {
            p = t.value, h = "", tt.cat = "", tt.list = null, tt.key = "", p ? (m = "", y = null) : m = tt.ucat || "", 
            j(), D(), M(), L ? l.value.trim() ? fe(l.value) : ve() : p ? (P(), W(1)) : (g ? I() : _(), 
            m ? X(1) : Y());
        });
        var ue = 0;
        function ve() {
            l.value = "", L = !1, tt.lastQ = tt.q, tt.q = "", tt.sscroll = 0, c.hidden = !0, 
            c.innerHTML = "", M();
            try {
                history.replaceState(null, "", "#/cats");
            } catch (e) {}
            if (k) return v.length && T === (p ? B() : m ? U() : "FEED") ? (m && R(y), F(v), 
            Q(), void S()) : void (p ? W(1) : m ? X(1) : Y());
            de();
        }
        function fe(e, t) {
            if (e = (e || "").trim()) {
                var n = tt.q;
                if (tt.splat !== p && (tt.slist = null, tt.splat = p), function(e) {
                    L = !0, tt.q = e, s.style.display = "none", oe.hidden = !0, c.hidden = !0;
                    try {
                        history.replaceState(null, "", "#/cats?q=" + encodeURIComponent(e));
                    } catch (e) {}
                }(e), tt.slist && tt.splat === p && (n === e || tt.lastQ === e)) return O(tt.slist, e), 
                void S();
                var i = ++ue;
                a.innerHTML = '<div class="spin"><b></b>' + (p ? "正在检索「" + d(C(p)) + "」…" : "正在检索全部平台…") + "</div>", 
                b("/search?wd=" + encodeURIComponent(e) + "&page=1" + (p ? "&plat=" + encodeURIComponent(p) : "") + (Be.teen() ? "&teen=1" : "")).then(function(t) {
                    if (i === ue && L) {
                        var n = t.list || [];
                        tt.q = e, tt.slist = n, O(n, e);
                    }
                }).catch(function(e) {
                    i === ue && L && (c.hidden = !0, a.innerHTML = '<div class="empty">' + d(e && e.message ? e.message : String(e)) + "</div>");
                });
            } else ve();
        }
        var pe = e.querySelector(".sbox .go");
        pe && pe.addEventListener("click", function() {
            fe(l.value);
        }), l.addEventListener("keydown", function(e) {
            "Enter" === e.key && fe(l.value);
        });
        var he = H("q") || tt.q || "";
        he ? (l.value = he, fe(he), de()) : (L = !1, de());
        var me = Z(function() {
            return !!L && (ve(), !0);
        });
        this.el = e, this.onOnline = function() {
            !L && a.querySelector(".empty") && (p ? W(ne) : m ? X(ne) : Y());
        }, this.destroy = function() {
            r && (L ? tt.sscroll = r.scrollTop || 0 : tt.scroll = r.scrollTop || 0), ee(me);
            try {
                ce.disconnect();
            } catch (e) {}
            f && f.destroy && f.destroy();
        };
    }
    function it(e) {
        try {
            return fetch("/web/api/teen?on=" + (e ? 1 : 0), {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json"
                },
                body: JSON.stringify({
                    on: e ? 1 : 0
                })
            }).then(function(e) {
                return e.ok ? e.json() : null;
            }).then(function(e) {
                return !(!e || 200 !== e.code);
            }).catch(function() {
                return !1;
            });
        } catch (e) {
            return Promise.resolve(!1);
        }
    }
    function ot() {
        var e = document.createElement("div");
        e.className = "page", e.innerHTML = '<div class="phead"><h1>我的</h1></div><div class="pbody"><label class="teenbox"><span class="ttxt">青少年模式</span><span class="tsw"><input type="checkbox" class="teenck"><i></i></span></label><div class="mtabs"><button type="button" class="mtab on" data-t="history">播放历史</button><button type="button" class="mtab" data-t="fav">我的收藏</button><span class="act mclear">清空</span></div><div class="mselbar" hidden><span class="mcount">已选 0 条</span><button class="mbtn" type="button" data-a="invert">反选</button><button class="mbtn danger" type="button" data-a="del">删除选中</button><button class="mbtn" type="button" data-a="exit">取消</button></div><div class="mres hist"></div><div class="mres favs" hidden></div></div>';
        var t = e.querySelector(".hist"), n = e.querySelector(".favs"), i = e.querySelector(".mclear"), a = e.querySelector(".mselbar"), r = e.querySelector(".mcount"), s = e.querySelector(".teenck"), c = "history";
        {
            function E(e) {
                var t, n, i = [ 1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298 ], o = unescape(encodeURIComponent(String(e))), a = o.length, r = 1 + (a + 8 >> 6), s = new Array(16 * r);
                for (t = 0; t < 16 * r; t++) s[t] = 0;
                for (t = 0; t < a; t++) s[t >> 2] |= (255 & o.charCodeAt(t)) << 24 - t % 4 * 8;
                s[a >> 2] |= 128 << 24 - a % 4 * 8, s[16 * r - 1] = 8 * a;
                for (var c = [ 1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225 ], l = 0; l < r; l++) {
                    var d = s.slice(16 * l, 16 * l + 16);
                    for (n = 16; n < 64; n++) {
                        var u = d[n - 15], v = d[n - 2], f = (u >>> 7 | u << 25) ^ (u >>> 18 | u << 14) ^ u >>> 3, p = (v >>> 17 | v << 15) ^ (v >>> 19 | v << 13) ^ v >>> 10;
                        d[n] = d[n - 16] + f + d[n - 7] + p >>> 0;
                    }
                    var h = c[0], m = c[1], g = c[2], y = c[3], b = c[4], w = c[5], E = c[6], L = c[7];
                    for (n = 0; n < 64; n++) {
                        var k = L + ((b >>> 6 | b << 26) ^ (b >>> 11 | b << 21) ^ (b >>> 25 | b << 7)) + (b & w ^ ~b & E) + i[n] + d[n] >>> 0, T = h & m ^ h & g ^ m & g;
                        L = E, E = w, w = b, b = y + k >>> 0, y = g, g = m, m = h, h = k + (((h >>> 2 | h << 30) ^ (h >>> 13 | h << 19) ^ (h >>> 22 | h << 10)) + T >>> 0) >>> 0;
                    }
                    c = [ c[0] + h >>> 0, c[1] + m >>> 0, c[2] + g >>> 0, c[3] + y >>> 0, c[4] + b >>> 0, c[5] + w >>> 0, c[6] + E >>> 0, c[7] + L >>> 0 ];
                }
                var S = "";
                for (t = 0; t < 8; t++) S += ("0000000" + (c[t] >>> 0).toString(16)).slice(-8);
                return S;
            }
            function k(e) {
                it(e).then(function(t) {
                    if (!t) return s.checked = !e, void o("青少年模式切换失败");
                    Be.setTeen(e), T(e);
                });
            }
            function T(e) {
                o(e ? "青少年模式已开启" : "青少年模式已关闭：显示全部平台");
                try {
                    Ge.slides.forEach(function(e) {
                        e.dispose && e.dispose();
                    });
                } catch (e) {}
                if (Ge.slides = [], Ge.raw = [], Ge.active = 0, Ge.scroll = 0, Je.items = [], Je.active = 0, 
                Je.scroll = 0, Ke(), tt.plats = null, tt.list = null, tt.slist = null, tt.plat = "", 
                tt.cat = "", tt.feed = null, tt.ulist = null, tt.unions = null, tt.ukey = "", tt.key = "", 
                tt.lastQ = "", at && at.isSeries) try {
                    location.hash = "#/cats";
                } catch (e) {}
            }
            s.checked = Be.teen(), s.addEventListener("change", function() {
                s.checked ? k(!0) : k(!1);
            });
        }
        var l = !1, f = {};
        function p(e) {
            return (e.plat || "") + "|" + (e.id || "");
        }
        function h() {
            e.querySelectorAll(".citem").forEach(function(e) {
                e.classList.toggle("sel", !!f[e.dataset.k]);
            }), r.textContent = "已选 " + function() {
                var e = 0;
                for (var t in f) f[t] && e++;
                return e;
            }() + " 条";
        }
        function m(t) {
            l = !!t, a.hidden = !l, a.style.display = l ? "" : "none", i.style.display = l ? "none" : "", 
            e.classList.toggle("selmode", l), l || (f = {}), h();
        }
        function g(e) {
            l = !0, (f = {})[e] = !0, m(!0);
        }
        function y(i) {
            c = "fav" === i ? "fav" : "history", e.querySelectorAll(".mtab").forEach(function(e) {
                e.classList.toggle("on", e.dataset.t === c);
            }), t.hidden = "history" !== c, n.hidden = "fav" !== c, m(!1);
        }
        function b(e, t, n) {
            if (e.innerHTML = "", t.length) {
                var i = document.createElement("div");
                i.className = "grid", t.forEach(function(e) {
                    i.appendChild(function(e) {
                        if (!e.cover) {
                            var t = q(e.plat, e.id);
                            t && (e.cover = t, Be.fillCover(c, p(e), t));
                        }
                        var n = document.createElement("div");
                        n.className = "citem", n.dataset.k = p(e), n.innerHTML = je({
                            cover: e.cover,
                            ref: "",
                            badge: e.pname || "",
                            eps: e.ep ? "看到第" + e.ep + "集" : "",
                            name: e.name
                        }) + '<span class="tick"></span>';
                        var i = 0, o = !1;
                        function a(e) {
                            Date.now(), o = !1, clearTimeout(i), i = setTimeout(function() {
                                if (o = !0, g(n.dataset.k), navigator.vibrate) try {
                                    navigator.vibrate(15);
                                } catch (e) {}
                            }, 500);
                        }
                        function r() {
                            clearTimeout(i);
                        }
                        return n.addEventListener("touchstart", a, {
                            passive: !0
                        }), n.addEventListener("touchmove", r, {
                            passive: !0
                        }), n.addEventListener("touchend", r), n.addEventListener("touchcancel", r), n.addEventListener("mousedown", a), 
                        n.addEventListener("mouseup", r), n.addEventListener("mouseleave", r), n.addEventListener("contextmenu", function(e) {
                            e.preventDefault(), g(n.dataset.k);
                        }), n.addEventListener("click", function() {
                            if (o) o = !1; else {
                                if (l) {
                                    var t = n.dataset.k;
                                    return f[t] ? delete f[t] : f[t] = !0, void h();
                                }
                                !function(e) {
                                    location.hash = "#/series?plat=" + encodeURIComponent(e.plat) + "&id=" + encodeURIComponent(e.id) + "&ep=" + (e.ep || 1);
                                }(e);
                            }
                        }), n;
                    }(e));
                }), e.appendChild(i);
            } else e.innerHTML = '<div class="mempty">' + d(n) + "</div>";
        }
        function w() {
            b(t, Be.history(), "还没有播放记录，去剧场挑一部剧点进去看几集吧"), b(n, Be.favs(), "还没有收藏，播放页点右侧的「追剧」就能收藏"), 
            h();
        }
        a.addEventListener("click", function(e) {
            var t = e.target.closest(".mbtn");
            if (t) {
                var n = t.dataset.a, i = "fav" === c ? Be.favs() : Be.history();
                if ("exit" !== n) {
                    if ("invert" === n) {
                        var a = {};
                        return i.forEach(function(e) {
                            var t = p(e);
                            f[t] || (a[t] = !0);
                        }), f = a, void h();
                    }
                    if ("del" === n) {
                        var r = [];
                        for (var s in f) f[s] && r.push(s);
                        if (!r.length) return void o("还没有选中任何内容");
                        v({
                            title: "删除选中的 " + r.length + " 条记录？",
                            tip: "删除后无法恢复。",
                            okText: "删除",
                            cancelText: "取消",
                            danger: !0
                        }).then(function(e) {
                            e && (Be.remove(c, r), m(!1), w(), o("已删除 " + r.length + " 条"));
                        });
                    }
                } else m(!1);
            }
        }), e.querySelectorAll(".mtab").forEach(function(e) {
            e.addEventListener("click", function() {
                y(e.dataset.t);
            });
        }), i.addEventListener("click", function() {
            var e = c, t = "fav" === e, n = t ? Be.favs() : Be.history();
            n.length ? v({
                title: t ? "清空全部收藏？" : "清空全部播放历史？",
                tip: "共 " + n.length + " 条，清空后无法恢复。",
                okText: t ? "清空收藏" : "清空历史",
                cancelText: "再想想",
                danger: !0
            }).then(function(t) {
                t && (Be.clear(e), w(), o("已清空"));
            }) : o(t ? "收藏还是空的" : "还没有播放记录");
        }), y("history"), w(), this.el = e, this.refresh = w;
    }
    var at = null;
    function rt() {
        var e = document.activeElement;
        if (e && /^(INPUT|TEXTAREA)$/.test(e.tagName || "")) {
            var t = e.getBoundingClientRect(), n = window.visualViewport, i = (n ? n.height + n.offsetTop : window.innerHeight) - 12;
            if (!(t.bottom <= i)) {
                var o = Math.min(t.bottom - i + 10, 260), a = function(e) {
                    for (var t = e.parentElement; t; t = t.parentElement) {
                        var n = getComputedStyle(t);
                        if (/(auto|scroll)/.test(n.overflowY) && t.scrollHeight > t.clientHeight + 2) return t;
                    }
                    return null;
                }(e);
                a ? a.scrollTop += o : window.scrollBy(0, o);
            }
        }
    }
    function st(n, i) {
        try {
            ae();
        } catch (e) {}
        at && at.destroy && at.destroy();
        try {
            ke = null, xe(), ye(), P() && le(), Se && l ? he() : ve(), Se = !1, pe(!1), qe();
        } catch (e) {}
        e.innerHTML = "", e.appendChild(n.el), at = n, t.classList.remove("nobar"), t.classList.toggle("hide", !i), 
        document.querySelectorAll("#tabbar .tab").forEach(function(e) {
            e.classList.toggle("on", e.dataset.tab === i);
        }), setTimeout(L, 80), setTimeout(k, 400);
    }
    function ct() {
        var e = (location.hash.slice(1) || "/feed").split("?")[0];
        if ("/series" !== e) {
            if ("/cats" === e || "/search" === e) return window.__lastList = location.hash, 
            void st(new nt, "cats");
            if ("/mine" === e) return window.__lastList = location.hash, void st(new ot, "mine");
            window.__lastList = location.hash, st(new Ze, "feed");
        } else st(new et(H("plat"), H("id"), Number(H("ep") || 1)));
    }
    if (document.addEventListener("focusin", function(e) {
        var t = e.target;
        t && /^(INPUT|TEXTAREA)$/.test(t.tagName || "") && setTimeout(rt, 320);
    }), window.visualViewport && window.visualViewport.addEventListener("resize", rt), 
    t.addEventListener("click", function(e) {
        var t = e.target.closest(".tab");
        t && (location.hash = "#/" + t.dataset.tab);
    }), window.addEventListener("hashchange", ct), location.hash || (location.hash = "#/feed"), 
    ct(), Be.teenSaved()) {
        var lt = Be.teen();
        it(lt).then(function(e) {
            if (!e && !lt) {
                Be.setTeen(!0);
                try {
                    Ge.slides.forEach(function(e) {
                        e.dispose && e.dispose();
                    });
                } catch (e) {}
                Ge.slides = [], Ge.raw = [], Ge.active = 0, Ge.scroll = 0, Je.items = [], Je.active = 0, 
                Je.scroll = 0, Ke();
            }
        });
    }
    setTimeout(function() {
        $e || ($e = !0, Ge.slides.length || Qe() || b("/feed?n=8&blk=1&warm=1" + (Be.teen() ? "&teen=1" : ""), {
            timeout: w
        }).then(function(e) {
            var t = e && e.items || [];
            if (t.length && !Ge.slides.length) try {
                localStorage.setItem(ze, JSON.stringify({
                    at: Date.now(),
                    active: 0,
                    scroll: 0,
                    items: t
                })), window.__dbg && console.log("[cache] 预热写入 " + t.length + " 条");
            } catch (e) {}
        }).catch(function() {}));
    }, 1200), a && [ 1200, 3e3, 6e3 ].forEach(function(e) {
        setTimeout(function() {
            var e = re;
            e && !e.userPaused && e.video && e.video.paused && !e.video.ended && e.play(!0);
        }, e);
    });
}();
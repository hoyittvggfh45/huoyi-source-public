(function() {
    "use strict";
    var MODES = [ {
        k: "duanju",
        n: "短剧"
    }, {
        k: "manhua",
        n: "漫画"
    }, {
        k: "music",
        n: "音乐"
    }, {
        k: "ting",
        n: "听书"
    } ];
    var ICONS = {
        duanju: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="4.5" width="19" height="13" rx="3"/><path d="M9.6 8.6l5 3.4-5 3.4z" fill="currentColor" stroke="none"/><path d="M8 21h8"/></svg>',
        manhua: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="4.5" y="2.8" width="15" height="18.4" rx="2.6"/><path d="M8.5 7.5h7M8.5 11.5h7M8.5 15.5h4"/></svg>',
        music: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 17.5V5.2l9.5-1.9v12.3"/><circle cx="7" cy="17.8" r="2.5"/><circle cx="16.5" cy="15.9" r="2.5"/></svg>',
        ting: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 12.5a7.5 7.5 0 0 1 15 0"/><rect x="2.8" y="12.5" width="4.4" height="6.4" rx="2.2"/><rect x="16.8" y="12.5" width="4.4" height="6.4" rx="2.2"/></svg>'
    };
    var ACCENT = {
        duanju: "#ff2b54",
        manhua: "#ff4d6d",
        music: "#7c6cff",
        ting: "#f96942"
    };
    var CSS = [ ".jdd-mode-btn{flex:0 0 auto;width:34px;height:34px;border:1px solid rgba(255,255,255,.12);", "border-radius:11px;display:grid;place-items:center;cursor:pointer;color:#fff;", "background:linear-gradient(135deg,var(--jdd-accent,#f96942),var(--jdd-accent-2,#ffb03a));", "box-shadow:0 3px 12px var(--jdd-soft,rgba(249,105,66,.3));padding:0;transition:transform .12s,box-shadow .2s}", ".jdd-mode-btn:active{transform:scale(.93)}", ".jdd-mode-btn.jdd-plain{border:0;background:none;box-shadow:none}", ".jdd-mode-btn svg{width:17px;height:17px}", ".jdd-menu{position:fixed;z-index:3000;min-width:148px;padding:6px;border-radius:14px;", "background:rgba(22,23,30,.96);border:1px solid rgba(255,255,255,.09);", "-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);", "box-shadow:0 14px 40px rgba(0,0,0,.5);animation:jddIn .16s ease-out}", "@keyframes jddIn{from{opacity:0;transform:translateY(-6px) scale(.97)}to{opacity:1;transform:none}}", ".jdd-item{display:flex;align-items:center;gap:9px;width:100%;height:40px;padding:0 11px;", "border:0;border-radius:10px;background:transparent;color:#c9cdd8;font:inherit;", "font-size:13.5px;font-weight:600;cursor:pointer;text-align:left;transition:background .15s,color .15s}", ".jdd-item svg{width:16px;height:16px;flex:0 0 auto;opacity:.85}", ".jdd-item:hover{background:rgba(255,255,255,.06);color:#fff}", ".jdd-item.on{color:#fff;background:var(--jdd-item-bg,rgba(249,105,66,.18))}", ".jdd-item .jdd-check{margin-left:auto;font-size:12px;font-weight:800;color:var(--jdd-accent,#f96942)}", ".jdd-item.off{opacity:.4;pointer-events:none}", ".jdd-mask{position:fixed;inset:0;z-index:2999;background:transparent}" ].join("");
    var styleInjected = false;
    function injectStyle() {
        if (styleInjected) return;
        styleInjected = true;
        var s = document.createElement("style");
        s.id = "jdd-bridge-style";
        s.textContent = CSS;
        document.head.appendChild(s);
    }
    function esc(s) {
        return String(s == null ? "" : s).replace(/[&<>"']/g, function(c) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            }[c];
        });
    }
    function closeMenus(root) {
        root.querySelectorAll(".jdd-menu,.jdd-mask").forEach(function(el) {
            el.remove();
        });
    }
    function buildMenu(btn, cur) {
        var root = btn.ownerDocument.body;
        closeMenus(root);
        var mask = document.createElement("div");
        mask.className = "jdd-mask";
        var menu = document.createElement("div");
        menu.className = "jdd-menu";
        var acc = ACCENT[cur] || "#f96942";
        menu.style.setProperty("--jdd-accent", acc);
        menu.style.setProperty("--jdd-item-bg", hexSoft(acc));
        var rect = btn.getBoundingClientRect();
        var html = "";
        for (var i = 0; i < MODES.length; i++) {
            var m = MODES[i];
            html += '<button type="button" class="jdd-item' + (m.k === cur ? " on" : "") + '" data-k="' + m.k + '">' + ICONS[m.k] + "<span>" + esc(m.n) + "</span>" + (m.k === cur ? '<span class="jdd-check">✓</span>' : "") + "</button>";
        }
        menu.innerHTML = html;
        root.appendChild(mask);
        root.appendChild(menu);
        var mw = menu.offsetWidth;
        var left = Math.min(Math.max(8, rect.left), window.innerWidth - mw - 8);
        var top = rect.bottom + 8;
        if (top + menu.offsetHeight > window.innerHeight - 8) top = Math.max(8, rect.top - menu.offsetHeight - 8);
        menu.style.left = left + "px";
        menu.style.top = top + "px";
        mask.addEventListener("click", function() {
            closeMenus(root);
        }, {
            once: true
        });
        menu.addEventListener("click", function(e) {
            var t = e.target;
            while (t && t !== menu && !(t.getAttribute && t.getAttribute("data-k"))) t = t.parentNode;
            if (!t || t === menu) return;
            var k = t.getAttribute("data-k");
            if (!k || k === cur) {
                closeMenus(root);
                return;
            }
            closeMenus(root);
            switchMode(k);
        });
    }
    function hexSoft(hex) {
        var n = parseInt(hex.slice(1), 16);
        return "rgba(" + (n >> 16 & 255) + "," + (n >> 8 & 255) + "," + (n & 255) + ",.2)";
    }
    function switchMode(k) {
        fetch("/__jdd/switch?json=1&m=" + encodeURIComponent(k), {
            cache: "no-store"
        }).then(function(r) {
            return r.json();
        }).then(function(r) {
            if (r && r.code === 200) {
                try { (window.top || window).localStorage.setItem("jk_last_mode", k); } catch (e) {}
                location.href = "/__jdd/frame/" + encodeURIComponent(k) + "/?t=" + Date.now();
            } else {
                alert(r && r.msg || "模式切换失败");
            }
        }).catch(function() {
            alert("模式切换失败，请重试");
        });
    }
    var mountSeq = 0;
    function mount(opts) {
        opts = opts || {};
        var doc = opts.doc || document;
        var anchor = doc.querySelector(opts.anchor);
        if (!anchor) return;
        var cur = opts.mode || "ting";
        var exist = anchor.parentNode.querySelector(".jdd-mode-btn");
        if (exist) return;
        injectStyle();
        var btn = doc.createElement("button");
        btn.type = "button";
        mountSeq += 1;
        btn.id = "jdd-mode-btn-" + mountSeq;
        btn.className = "jdd-mode-btn";
        btn.title = "切换模式";
        btn.setAttribute("aria-label", "切换模式");
        btn.setAttribute("data-mode", cur);
        if (opts.plain) btn.classList.add("jdd-plain");
        var acc = ACCENT[cur] || "#f96942";
        btn.style.setProperty("--jdd-accent", acc);
        btn.style.setProperty("--jdd-accent-2", ACCENT[MODES[(MODES.map(function(m) {
            return m.k;
        }).indexOf(cur) + 1) % 4].k] || "#ffb03a");
        btn.style.setProperty("--jdd-soft", hexSoft(acc));
        btn.innerHTML = ICONS[cur] || ICONS.ting;
        btn.addEventListener("click", function(e) {
            e.stopPropagation();
            var root = btn.ownerDocument.body;
            if (root.querySelector(".jdd-menu")) {
                closeMenus(root);
                return;
            }
            buildMenu(btn, cur);
        });
        anchor.parentNode.insertBefore(btn, anchor);
    }
    function bind(opts) {
        opts = opts || {};
        var doc = opts.doc || document;
        var target = doc.querySelector(opts.target);
        if (!target) return;
        var cur = opts.mode || "music";
        injectStyle();
        target.addEventListener("click", function(e) {
            e.stopPropagation();
            var root = target.ownerDocument.body;
            if (root.querySelector(".jdd-menu")) {
                closeMenus(root);
                return;
            }
            buildMenu(target, cur);
        });
    }
    window.JddBridge = {
        mount: mount,
        bind: bind,
        icons: ICONS,
        modes: MODES
    };
})();
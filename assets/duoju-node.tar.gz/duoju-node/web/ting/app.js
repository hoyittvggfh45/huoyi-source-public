(function() {
    "use strict";
    var SPEEDS = [ 0.75, 1, 1.25, 1.5, 2, 3 ];
    var HOT_KEYWORDS = [ "斗破苍穹", "盗墓笔记", "鬼吹灯", "庆余年", "三体", "雪中悍刀行", "凡人修仙传", "仙逆", "遮天", "甄嬛传", "何以笙箫默", "步步惊心" ];
    var CH_PER_PAGE = 50;
    var ICONS = {
        mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
        books: '<path d="M4 5h6v14H4zM12 5h4v14h-4z"/><path d="M18 6l2.2.6-2.8 12.3-2-1"/>',
        tv: '<rect x="3" y="6.5" width="18" height="13" rx="2"/><path d="M8 3l4 3 4-3"/>',
        flame: '<path d="M12 3c1.2 3 5 5.2 5 9a5 5 0 0 1-10 0c0-2 .9-3.6 2-5.2.5 1.4 1.3 2.2 2.3 2.7C10.8 7.5 11 5.2 12 3z"/>',
        broadcast: '<circle cx="12" cy="12" r="2"/><path d="M7.8 16.2a6 6 0 0 1 0-8.4M16.2 7.8a6 6 0 0 1 0 8.4M4.9 19.1a10 10 0 0 1 0-14.2M19.1 4.9a10 10 0 0 1 0 14.2"/>',
        cloud: '<path d="M6.8 18a4.3 4.3 0 0 1-.4-8.6A6 6 0 0 1 18 9.6a3.7 3.7 0 0 1-.8 7.4z"/>',
        headphones: '<path d="M4 14a8 8 0 0 1 16 0"/><rect x="3" y="14" width="4.4" height="6" rx="1.6"/><rect x="16.6" y="14" width="4.4" height="6" rx="1.6"/>',
        mountain: '<path d="M3 19L10 6l4 7 2-3.4L21 19z"/>',
        bookopen: '<path d="M12 6c-2-1.6-5-2.2-8-2.2v14.4c3 0 6 .6 8 2.2 2-1.6 5-2.2 8-2.2V3.8c-3 0-6 .6-8 2.2z"/><path d="M12 6v14.4"/>',
        book: '<path d="M4 19V5a2 2 0 0 1 2-2h13v14H6a2 2 0 0 0-2 2zm0 0a2 2 0 0 0 2 2h13"/>',
        radio: '<rect x="3" y="9" width="18" height="11" rx="2"/><path d="M7 9L17 4"/><circle cx="8.5" cy="14.5" r="2.4"/><path d="M15 13h3M15 16.5h3"/>',
        bus: '<rect x="4" y="4" width="16" height="13" rx="2"/><path d="M4 10h16"/><circle cx="8" cy="19.4" r="1.5"/><circle cx="16" cy="19.4" r="1.5"/><path d="M8 14h.01M16 14h.01"/>',
        bird: '<path d="M20 5.5c-1.8-.4-3.2.3-4 1.6C14.8 9.4 12 13.5 7.5 14c-1.8.2-3.4-.4-4.3-1.4.2 3.9 3.2 7.9 8.3 7.9 5.3 0 8.7-4.1 8.7-9.5 0-2-.1-3.9-.2-5.5z"/>',
        music: '<path d="M9 18V5l10-2v13"/><circle cx="6.5" cy="18" r="2.4"/><circle cx="16.5" cy="16" r="2.4"/>',
        tomato: '<circle cx="12" cy="14" r="7"/><path d="M12 7c0-2.2 1.2-3.4 3.2-3.4-.6 2-1.6 3.1-3.2 3.4zm0 0C10.2 5 8.2 4.8 6.6 5.6 8 6.9 10 7.2 12 7z"/>',
        play: '<path d="M7.5 4.5l12 7.5-12 7.5z" fill="currentColor" stroke="none"/>',
        pause: '<rect x="6.5" y="4.5" width="4" height="15" rx="1" fill="currentColor" stroke="none"/><rect x="13.5" y="4.5" width="4" height="15" rx="1" fill="currentColor" stroke="none"/>',
        close: '<path d="M6 6l12 12M18 6L6 18"/>',
        star: '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.9L12 17l-5.2 2.7 1-5.9-4.3-4.1 5.9-.9z"/>',
        starfill: '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.9L12 17l-5.2 2.7 1-5.9-4.3-4.1 5.9-.9z" fill="currentColor" stroke="none"/>',
        timer: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 13.5l3.2-3.2M9.5 2h5"/>',
        bookmark: '<path d="M6 3h12a1 1 0 0 1 1 1v17l-7-4.2L5 21V4a1 1 0 0 1 1-1z"/><path d="M12 8v6M9 11h6"/>',
        search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
        neutral: '<circle cx="12" cy="12" r="9"/><path d="M8.5 9.8h.01M15.5 9.8h.01M8.5 15.2c1 1 2.1 1.5 3.5 1.5s2.5-.5 3.5-1.5"/>'
    };
    function icon(name, size) {
        var s = size || 16;
        return '<svg viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || ICONS.headphones) + "</svg>";
    }
    var PLAT_ICONS = {
        kw: "mic",
        bookan: "books",
        bili: "tv",
        podcast: "mic",
        yuntu: "cloud",
        ty: "headphones",
        xm: "mountain",
        syfm: "bookopen",
        tsw: "book",
        i275: "radio",
        faloo: "bird",
        tyfm: "music",
        ytba: "radio",
        leting: "bookopen",
        qdysw: "bookopen"
    };
    function platIcon(key, size) {
        return icon(PLAT_ICONS[key] || "headphones", size || 13);
    }
    var state = {
        plats: [],
        plat: "",
        cats: [],
        cat: "",
        page: 1,
        cards: [],
        hasMore: true,
        loading: false,
        sPage: 1,
        sWd: "",
        sCards: [],
        sHasMore: true,
        libTab: "hist",
        enabled: {},
        searchOn: {}
    };
    var player = {
        chapters: [],
        idx: -1,
        chPage: 1,
        chDesc: false,
        sheetDesc: false,
        bookName: "",
        bookId: "",
        plat: "",
        pic: "",
        author: "",
        speed: 1.0
    };
    var jkWake = (function() {
        var lock = null, want = false;
        function acquire() {
            if (!want || lock || document.hidden || !navigator.wakeLock) return;
            try {
                navigator.wakeLock.request("screen").then(function(l) {
                    if (!want) {
                        try {
                            l.release();
                        } catch (e) {}
                        return;
                    }
                    lock = l;
                    l.addEventListener("release", function() {
                        if (lock === l) lock = null;
                    });
                }).catch(function() {});
            } catch (e) {}
        }
        function on() {
            want = true;
            acquire();
        }
        function off() {
            want = false;
            if (lock) {
                try {
                    lock.release();
                } catch (e) {}
                lock = null;
            }
        }
        document.addEventListener("visibilitychange", function() {
            if (document.hidden) {
                if (lock) {
                    try {
                        lock.release();
                    } catch (e) {}
                    lock = null;
                }
            } else acquire();
        });
        return {
            on: on,
            off: off
        };
    })();
    var $ = function(id) {
        return document.getElementById(id);
    };
    function syncMediaSession() {
        if (!("mediaSession" in navigator)) return;
        try {
            var ch = player.chapters[player.idx];
            if (window.MediaMetadata) navigator.mediaSession.metadata = new window.MediaMetadata({
                title: ch && ch.name ? ch.name : player.bookName || "听书",
                artist: player.bookName + (player.author ? " · " + player.author : ""),
                album: platName(player.plat),
                artwork: player.pic ? [ {
                    src: imgProxy(player.pic),
                    sizes: "512x512",
                    type: "image/jpeg"
                } ] : []
            });
            navigator.mediaSession.setActionHandler("play", function() {
                audio.play().catch(function() {});
            });
            navigator.mediaSession.setActionHandler("pause", function() {
                player.wantPlay = false;
                audio.pause();
            });
            navigator.mediaSession.setActionHandler("previoustrack", function() {
                playOffset(-1);
            });
            navigator.mediaSession.setActionHandler("nexttrack", function() {
                playOffset(1);
            });
        } catch (e) {}
    }
    var toastTimer = null;
    function toast(msg) {
        var t = $("toast");
        t.textContent = msg;
        t.classList.add("show");
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function() {
            t.classList.remove("show");
        }, 2600);
    }
    function esc(s) {
        return String(s == null ? "" : s).replace(/[&<>"]/g, function(c) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;"
            }[c];
        });
    }
    function fmtTime(s) {
        if (!isFinite(s) || s < 0) s = 0;
        var m = Math.floor(s / 60), sec = Math.floor(s % 60);
        return (m < 10 ? "0" : "") + m + ":" + (sec < 10 ? "0" : "") + sec;
    }
    function imgProxy(url) {
        if (!url) return "";
        return "/media/img?u=" + encodeURIComponent(url);
    }
    function api(path, params) {
        var q = new URLSearchParams(params).toString();
        return fetch(path + (q ? "?" + q : "")).then(function(r) {
            return r.json().then(function(j) {
                if (j.code !== 200) throw new Error(j.msg || "HTTP " + r.status);
                return j.data;
            });
        });
    }
    function loadJSON(key, def) {
        try {
            return JSON.parse(localStorage.getItem(key) || "null") || def;
        } catch (e) {
            return def;
        }
    }
    function saveJSON(key, v) {
        try {
            localStorage.setItem(key, JSON.stringify(v));
        } catch (e) {}
    }
    var HIST_KEY = "dt_hist_v1", FAV_KEY = "dt_fav_v1";
    var ON_KEY = "dt_plat_on_v1", SEARCH_ON_KEY = "dt_search_on_v1", SPD_KEY = "dt_speed_v1";
    var LAST_PLAT_KEY = "dt_last_plat_v1";
    function getHist() {
        return loadJSON(HIST_KEY, []);
    }
    function getFav() {
        return loadJSON(FAV_KEY, []);
    }
    function favHas(plat, id) {
        return getFav().some(function(f) {
            return f.plat === plat && f.id === id;
        });
    }
    function pushHistory(item) {
        var list = getHist().filter(function(h) {
            return !(h.plat === item.plat && h.id === item.id);
        });
        list.unshift(item);
        if (list.length > 80) list = list.slice(0, 80);
        saveJSON(HIST_KEY, list);
    }
    function platName(key) {
        for (var i = 0; i < state.plats.length; i++) if (state.plats[i].key === key) return state.plats[i].name;
        return key;
    }
    function isEnabled(key) {
        return state.enabled[key] !== false;
    }
    function isSearchOn(key) {
        return state.searchOn[key] !== false;
    }
    function enabledCount() {
        var n = 0;
        state.plats.forEach(function(p) {
            if (isEnabled(p.key)) n++;
        });
        return n;
    }
    function searchOnCount() {
        var n = 0;
        state.plats.forEach(function(p) {
            if (isSearchOn(p.key)) n++;
        });
        return n;
    }
    function searchPlats() {
        var keys = state.plats.filter(function(p) {
            return isSearchOn(p.key);
        }).map(function(p) {
            return p.key;
        });
        return keys.length === state.plats.length ? "" : keys.join(",");
    }
    function loadEnabled() {
        var saved = loadJSON(ON_KEY, {});
        state.enabled = {};
        state.plats.forEach(function(p) {
            state.enabled[p.key] = saved[p.key] !== false;
        });
        var savedS = loadJSON(SEARCH_ON_KEY, {});
        state.searchOn = {};
        state.plats.forEach(function(p) {
            state.searchOn[p.key] = savedS[p.key] !== false;
        });
    }
    var tabbar = $("tabbar");
    tabbar.addEventListener("click", function(e) {
        var t = e.target.closest(".tab");
        if (!t) return;
        switchTab(t.dataset.page);
    });
    function switchTab(name) {
        $("detail").hidden = true;
        closeSheets();
        document.querySelectorAll(".page").forEach(function(p) {
            p.classList.toggle("on", p.id === "page-" + name);
        });
        tabbar.querySelectorAll(".tab").forEach(function(t) {
            t.classList.toggle("on", t.dataset.page === name);
        });
        if (name === "library") {
            state.libTab = "hist";
            document.querySelectorAll(".lib-tab").forEach(function(x) {
                x.classList.toggle("on", x.dataset.libtab === "hist");
            });
            renderLibrary();
        }
        if (name === "plugins") renderPlugins();
        if (name === "search") showSearchHome();
        window.scrollTo(0, 0);
    }
    function rowHTML(h, asRow) {
        var stat;
        if (h.eps) {
            stat = h.ep ? "第 " + h.ep + " / " + h.eps + " 集" : "共 " + h.eps + " 集";
        } else {
            stat = h.ep ? "第 " + h.ep + " 集" : "";
        }
        var ico = platIcon(h.plat, 12);
        var meta = esc(h.author || "") + (h.author ? " · " : "") + ico + " " + esc(platName(h.plat));
        var img = h.pic ? '<img loading="lazy" src="' + imgProxy(h.pic) + '" alt="" onload="this.classList.add(\'loaded\')" onerror="this.classList.add(\'loaded\')">' : "";
        if (asRow) {
            return '<div class="lrow" data-plat="' + esc(h.plat) + '" data-id="' + esc(h.id) + '">' + '<div class="cover">' + img + (stat ? '<div class="remark">' + esc(stat) + "</div>" : "") + "</div>" + '<div class="info">' + '<div class="name">' + esc(h.name) + "</div>" + '<div class="author">' + meta + "</div>" + (stat ? '<div class="stat">' + esc(stat) + "</div>" : "") + "</div>" + '<div class="ops">' + '<button class="lrow-play" data-play="1" title="播放">' + icon("play", 15) + "</button>" + '<button class="lrow-del" data-del="1" title="移除">' + icon("close", 13) + "</button>" + "</div>" + "</div>";
        }
        return '<div class="lcard" data-plat="' + esc(h.plat) + '" data-id="' + esc(h.id) + '">' + '<div class="cover">' + img + (stat ? '<div class="remark">' + esc(stat) + "</div>" : "") + '<button class="lcard-play" data-play="1" title="播放">' + icon("play", 15) + "</button>" + '<button class="lcard-del" data-del="1" title="移除">' + icon("close", 13) + "</button>" + "</div>" + '<div class="shelf-board"></div>' + '<div class="name">' + esc(h.name) + "</div>" + '<div class="author">' + meta + "</div>" + "</div>";
    }
    function renderLibrary() {
        var el = $("lib-list");
        var asRow = state.libTab === "hist";
        var list = asRow ? getHist() : getFav();
        el.classList.toggle("as-rows", asRow);
        el.innerHTML = list.map(function(h) {
            return rowHTML(h, asRow);
        }).join("");
        $("lib-empty").hidden = list.length > 0;
    }
    document.querySelectorAll(".lib-tab").forEach(function(t) {
        t.addEventListener("click", function() {
            document.querySelectorAll(".lib-tab").forEach(function(x) {
                x.classList.remove("on");
            });
            t.classList.add("on");
            state.libTab = t.dataset.libtab;
            renderLibrary();
        });
    });
    $("lib-list").addEventListener("click", function(e) {
        var row = e.target.closest(".lcard,.lrow");
        if (!row) return;
        var plat = row.dataset.plat, id = row.dataset.id;
        if (e.target.closest("[data-del]")) {
            var key = state.libTab === "hist" ? HIST_KEY : FAV_KEY;
            saveJSON(key, loadJSON(key, []).filter(function(h) {
                return !(h.plat === plat && h.id === id);
            }));
            renderLibrary();
            return;
        }
        if (e.target.closest("[data-play]")) {
            openDetail(id, plat, true);
            return;
        }
        openDetail(id, plat, false);
    });
    $("plat-picker").addEventListener("click", function() {
        var list = state.plats.filter(function(p) {
            return isEnabled(p.key);
        });
        $("plat-sheet-list").innerHTML = list.map(function(p) {
            return '<button class="plat-item' + (p.key === state.plat ? " on" : "") + '" data-plat="' + esc(p.key) + '">' + '<span class="pi">' + platIcon(p.key, 18) + "</span>" + esc(p.name) + "</button>";
        }).join("");
        openSheet("plat-sheet");
    });
    $("plat-sheet-list").addEventListener("click", function(e) {
        var b = e.target.closest("[data-plat]");
        if (!b) return;
        closeSheets();
        if (b.dataset.plat !== state.plat) {
            state.plat = b.dataset.plat;
            $("plat-name").textContent = platName(state.plat);
            saveJSON(LAST_PLAT_KEY, state.plat);
            switchPlat(state.plat);
        }
    });
    function renderCatbar() {
        $("catbar").innerHTML = state.cats.map(function(c) {
            return '<button class="chip' + (c.id === state.cat ? " active" : "") + '" data-cat="' + esc(c.id) + '">' + esc(c.name) + "</button>";
        }).join("");
    }
    $("catbar").addEventListener("click", function(e) {
        var b = e.target.closest("[data-cat]");
        if (!b || b.dataset.cat === state.cat) return;
        state.cat = b.dataset.cat;
        state.page = 1;
        renderCatbar();
        loadList(true);
    });
    $("refresh-btn").addEventListener("click", function() {
        var btn = $("refresh-btn");
        btn.classList.add("spin");
        state.page = 1;
        loadList(true);
        setTimeout(function() {
            btn.classList.remove("spin");
        }, 900);
    });
    function switchPlat(key) {
        state.cat = "";
        state.page = 1;
        state.cards = [];
        showSkeleton(12);
        api("/api/cats", {
            plat: key
        }).then(function(d) {
            state.cats = d.cats || [];
            state.cat = state.cats.length ? state.cats[0].id : "";
            renderCatbar();
            loadList(true);
        }).catch(function(e) {
            toast("分类获取失败: " + e.message);
            $("grid").innerHTML = "";
            $("empty").hidden = false;
        });
    }
    function showSkeleton(n) {
        var html = "";
        for (var i = 0; i < n; i++) {
            html += '<div class="card skel"><div class="cover"></div><div class="name">····</div><div class="author">···</div></div>';
        }
        $("grid").innerHTML = html;
        $("empty").hidden = true;
        $("more-btn").hidden = true;
    }
    function cardHTML(c, fallbackPlat) {
        var platKey = c.vod_plat || fallbackPlat || state.plat;
        var badge = c.vod_plat ? '<div class="src-badge">' + esc(platName(platKey)) + "</div>" : "";
        var pic = c.vod_pic || "";
        return '<div class="card" data-id="' + esc(c.vod_id) + '" data-plat="' + esc(platKey) + '">' + '<div class="cover">' + (pic ? '<img loading="lazy" src="' + imgProxy(pic) + '" alt="" onload="this.classList.add(\'loaded\')" onerror="this.classList.add(\'loaded\')">' : "") + badge + (c.vod_remarks ? '<div class="remark">' + esc(c.vod_remarks) + "</div>" : "") + "</div>" + '<div class="name">' + esc(c.vod_name) + "</div>" + (c.vod_director ? '<div class="author">' + esc(c.vod_director) + "</div>" : "") + "</div>";
    }
    function filterEnabled(cards) {
        return cards.filter(function(c) {
            return !c.vod_plat || isSearchOn(c.vod_plat);
        });
    }
    function renderGrid(el, moreBtn, cards, hasMore, reset, fallbackPlat) {
        var html = cards.map(function(c) {
            return cardHTML(c, fallbackPlat);
        }).join("");
        if (reset) el.innerHTML = html; else el.insertAdjacentHTML("beforeend", html);
        $("empty").hidden = el.id !== "grid" || cards.length > 0 || !reset;
        moreBtn.hidden = !hasMore;
    }
    function loadList(reset) {
        if (state.loading) return;
        state.loading = true;
        if (reset) showSkeleton(12);
        api("/api/category", {
            plat: state.plat,
            cat: state.cat,
            page: state.page
        }).then(function(d) {
            var list = d.list || [];
            state.cards = reset ? list : state.cards.concat(list);
            state.hasMore = list.length > 0;
            renderGrid($("grid"), $("more-btn"), state.cards, state.hasMore, reset, state.plat);
        }).catch(function(e) {
            if (reset) {
                $("grid").innerHTML = "";
                $("empty").hidden = false;
            }
            toast("加载失败: " + e.message);
        }).finally(function() {
            state.loading = false;
        });
    }
    $("more-btn").addEventListener("click", function() {
        state.page += 1;
        loadList(false);
    });
    window.addEventListener("scroll", function() {
        if (!$("detail").hidden || !$("fplayer").hidden) return;
        if (!$("page-discover").classList.contains("on")) return;
        if ($("more-btn").hidden || state.loading) return;
        if (window.innerHeight + window.scrollY >= document.body.scrollHeight - 500) {
            state.page += 1;
            loadList(false);
        }
    }, {
        passive: true
    });
    document.addEventListener("click", function(e) {
        var card = e.target.closest(".card");
        if (!card || card.classList.contains("skel")) return;
        openDetail(card.dataset.id, card.dataset.plat || state.plat, false);
    });
    function renderHot() {
        if ($("hot-grid").childElementCount) return;
        $("hot-grid").innerHTML = HOT_KEYWORDS.map(function(k) {
            return '<button class="hot-tag" data-k="' + esc(k) + '">' + esc(k) + "</button>";
        }).join("");
    }
    function showSearchHome() {
        renderHot();
        $("hot").hidden = false;
        $("s-grid").innerHTML = "";
        $("s-empty").hidden = true;
        $("s-more").hidden = true;
    }
    $("hot-grid").addEventListener("click", function(e) {
        var b = e.target.closest("[data-k]");
        if (!b) return;
        $("search-input").value = b.dataset.k;
        doSearch();
    });
    function doSearch() {
        var wd = $("search-input").value.trim();
        if (!wd) return;
        state.sWd = wd;
        state.sPage = 1;
        $("hot").hidden = true;
        $("s-grid").innerHTML = "";
        $("search-clear").hidden = false;
        $("s-empty").hidden = true;
        for (var i = 0; i < 9; i++) {
            $("s-grid").insertAdjacentHTML("beforeend", '<div class="card skel"><div class="cover"></div><div class="name">····</div><div class="author">···</div></div>');
        }
        var q = {
            wd: wd,
            page: 1
        }, plats = searchPlats();
        if (plats) q.plats = plats;
        api("/api/search", q).then(function(d) {
            var list = filterEnabled(d.list || []);
            state.sCards = list;
            state.sHasMore = (d.list || []).length >= 10;
            $("s-grid").innerHTML = list.map(function(c) {
                return cardHTML(c, "");
            }).join("");
            $("s-empty").hidden = list.length > 0;
            $("s-empty-txt").textContent = "「" + wd + "」没有找到结果";
            $("s-more").hidden = !state.sHasMore;
            if (list.length) toast("已搜索 " + (d.platforms ? d.platforms.length : 0) + " 个启用的源");
        }).catch(function(e) {
            $("s-grid").innerHTML = "";
            $("s-empty").hidden = false;
            $("s-empty-txt").textContent = "搜索失败: " + e.message;
        });
    }
    $("search-btn").addEventListener("click", doSearch);
    $("search-input").addEventListener("keydown", function(e) {
        if (e.key === "Enter") doSearch();
    });
    $("search-clear").addEventListener("click", function() {
        $("search-input").value = "";
        $("search-clear").hidden = true;
        showSearchHome();
    });
    $("s-more").addEventListener("click", function() {
        if (!state.sWd || state.sHasMore === false) return;
        state.sPage += 1;
        var page = state.sPage;
        var q = {
            wd: state.sWd,
            page: page
        }, plats = searchPlats();
        if (plats) q.plats = plats;
        api("/api/search", q).then(function(d) {
            var list = filterEnabled(d.list || []);
            state.sHasMore = (d.list || []).length >= 10;
            $("s-grid").insertAdjacentHTML("beforeend", list.map(function(c) {
                return cardHTML(c, "");
            }).join(""));
            $("s-more").hidden = !state.sHasMore;
            if (!list.length) toast("没有更多了");
        });
    });
    function renderPlugins() {
        var on = enabledCount(), onS = searchOnCount(), total = state.plats.length;
        $("plug-sub").textContent = "听书源（发现 " + on + " / " + total + " · 搜索 " + onS + " / " + total + " 已启用）";
        $("plug-list").innerHTML = state.plats.map(function(p) {
            return '<div class="prow">' + '<div class="prow-avatar">' + platIcon(p.key, 20) + "</div>" + '<div class="prow-meta"><div class="prow-name">' + esc(p.name) + "</div>" + '<div class="prow-sub">听书 · 发现 + 搜索</div></div>' + '<div class="prow-switches">' + '<label class="switch" title="发现开关（发现页与平台选择器）">' + '<input type="checkbox" data-toggle="' + esc(p.key) + '"' + (isEnabled(p.key) ? " checked" : "") + '><span class="knob"></span></label>' + '<label class="switch" title="搜索开关（关闭后聚合搜索跳过该源）">' + '<input type="checkbox" data-search="' + esc(p.key) + '"' + (isSearchOn(p.key) ? " checked" : "") + '><span class="knob"></span></label>' + "</div>" + "</div>";
        }).join("");
    }
    $("plug-list").addEventListener("change", function(e) {
        var t = e.target.closest("[data-toggle]");
        if (t) {
            var key = t.dataset.toggle;
            state.enabled[key] = t.checked;
            saveJSON(ON_KEY, state.enabled);
            renderPlugins();
            if (!isEnabled(state.plat)) {
                var first = state.plats.filter(function(p) {
                    return isEnabled(p.key);
                })[0];
                if (first) {
                    state.plat = first.key;
                    $("plat-name").textContent = platName(state.plat);
                    saveJSON(LAST_PLAT_KEY, state.plat);
                    switchPlat(state.plat);
                }
            }
            if (!t.checked) toast(platName(key) + " 发现已停用（不影响已有播放）");
            return;
        }
        var s = e.target.closest("[data-search]");
        if (s) {
            var skey = s.dataset.search;
            state.searchOn[skey] = s.checked;
            saveJSON(SEARCH_ON_KEY, state.searchOn);
            renderPlugins();
            toast(platName(skey) + (s.checked ? " 已加入聚合搜索" : " 搜索已停用"));
        }
    });
    $("set-clear-hist").addEventListener("click", function() {
        saveJSON(HIST_KEY, []);
        toast("播放历史已清除");
        if ($("page-library").classList.contains("on")) renderLibrary();
    });
    $("set-clear-fav").addEventListener("click", function() {
        saveJSON(FAV_KEY, []);
        toast("收藏已清除");
        if ($("page-library").classList.contains("on")) renderLibrary();
    });
    $("set-enable-all").addEventListener("click", function() {
        state.plats.forEach(function(p) {
            state.enabled[p.key] = true;
            state.searchOn[p.key] = true;
        });
        saveJSON(ON_KEY, state.enabled);
        saveJSON(SEARCH_ON_KEY, state.searchOn);
        renderPlugins();
        toast("已恢复全部听书源");
    });
    function teenDesc(on) {
        return on ? "已开启 · 成人内容源已拦截" : "已关闭 · 成人内容源已显示";
    }
    function loadTeenState() {
        fetch("/web/api/teen", { cache: "no-store" }).then(function(r) {
            return r.json();
        }).then(function(j) {
            var on = !!(j.data && j.data.teen);
            $("teen-switch").checked = on;
            $("teen-desc").textContent = teenDesc(on);
        }).catch(function() {
            $("teen-desc").textContent = "状态获取失败";
        });
    }
    $("teen-switch").addEventListener("change", function() {
        var on = $("teen-switch").checked;
        fetch("/web/api/teen", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: on ? "enable" : "disable" })
        }).then(function(r) {
            return r.json();
        }).then(function(j) {
            if (j.code !== 200) throw new Error(j.msg || "设置失败");
            var now = !!(j.data && j.data.teen);
            $("teen-switch").checked = now;
            $("teen-desc").textContent = teenDesc(now);
            toast(j.msg || (now ? "青少年模式已开启" : "青少年模式已关闭"));
        }).catch(function(e) {
            $("teen-switch").checked = !on;
            toast("设置失败: " + e.message);
        });
    });
    function openSheet(id) {
        $("sheet-mask").hidden = false;
        $(id).hidden = false;
    }
    function closeSheets() {
        $("sheet-mask").hidden = true;
        $("ch-sheet").hidden = true;
        $("plat-sheet").hidden = true;
    }
    $("sheet-mask").addEventListener("click", closeSheets);
    function lastKey() {
        return "dt_last:" + player.plat + ":" + player.bookId;
    }
    function openDetail(id, plat, autoplay) {
        if (plat) player.plat = plat;
        var detailEl = $("detail");
        detailEl.hidden = false;
        detailEl.scrollTop = 0;
        $("detail-name").textContent = "加载中…";
        $("detail-pic").removeAttribute("src");
        $("detail-bg").removeAttribute("src");
        $("ch-count").textContent = "章节";
        $("chlist").innerHTML = '<div class="skel" style="height:280px;border-radius:12px"></div>';
        $("ch-filter").hidden = true;
        $("ch-pager").hidden = true;
        $("detail-resume").hidden = true;
        var playBtn0 = $("detail-play");
        playBtn0.innerHTML = icon("play", 14) + " 播放";
        playBtn0.onclick = null;
        $("detail-desc").classList.remove("open");
        var favBtn = $("detail-fav");
        favBtn.innerHTML = icon("star", 19);
        favBtn.classList.remove("on");
        api("/api/detail", {
            plat: player.plat,
            id: id
        }).then(function(d) {
            player.chapters = d.chapters || [];
            player.chPage = 1;
            player.idx = -1;
            player.bookName = d.vod_name || "";
            player.bookId = d.vod_id || id;
            player.pic = d.vod_pic || "";
            player.author = d.vod_director || "";
            $("detail-pic").src = imgProxy(d.vod_pic || "");
            $("detail-bg").src = imgProxy(d.vod_pic || "");
            $("detail-name").textContent = d.vod_name || "";
            $("detail-author").textContent = d.vod_director ? "播讲：" + d.vod_director : platName(player.plat);
            $("detail-remarks").textContent = d.vod_remarks || "";
            $("detail-desc").textContent = d.vod_content || "";
            if ((d.vod_content || "").length > 90) {
                var oldTg = detailEl.querySelector(".detail-desc-toggle");
                if (oldTg) oldTg.remove();
                var tg = document.createElement("button");
                tg.className = "detail-desc-toggle";
                tg.textContent = "展开全部 ▾";
                tg.onclick = function() {
                    var open = $("detail-desc").classList.toggle("open");
                    tg.textContent = open ? "收起 ▴" : "展开全部 ▾";
                };
                $("detail-desc").after(tg);
            } else {
                var oldTg2 = detailEl.querySelector(".detail-desc-toggle");
                if (oldTg2) oldTg2.remove();
            }
            syncFavBtn();
            renderChapters();
            var last = loadJSON(lastKey(), null);
            var canResume = last && player.chapters[last.i];
            var playBtn = $("detail-play");
            $("detail-resume").hidden = true;
            if (canResume) {
                playBtn.innerHTML = icon("play", 14) + " 继续播放 " + (last.i + 1) + "/" + player.chapters.length;
                playBtn.onclick = function() {
                    playChapter(last.i, last.t || 0);
                };
            } else {
                playBtn.innerHTML = icon("play", 14) + " 播放";
                playBtn.onclick = function() {
                    playChapter(0, 0);
                };
            }
            pushHistory({
                plat: player.plat,
                id: player.bookId,
                name: player.bookName,
                pic: player.pic,
                author: player.author,
                eps: player.chapters.length,
                ep: 0,
                ts: Date.now()
            });
            if (autoplay) {
                if (canResume) playChapter(last.i, last.t || 0); else if (player.chapters.length) playChapter(0, 0);
            }
        }).catch(function(e) {
            $("detail-name").textContent = "详情加载失败";
            $("chlist").innerHTML = "";
            toast(e.message);
        });
    }
    $("detail-back").addEventListener("click", function() {
        $("detail").hidden = true;
    });
    function syncFavBtn() {
        var on = favHas(player.plat, player.bookId);
        var b = $("detail-fav");
        b.innerHTML = icon(on ? "starfill" : "star", 19);
        b.classList.toggle("on", on);
    }
    $("detail-fav").addEventListener("click", function() {
        var list = getFav();
        var i = list.findIndex(function(f) {
            return f.plat === player.plat && f.id === player.bookId;
        });
        if (i >= 0) {
            list.splice(i, 1);
            toast("已取消收藏");
        } else {
            list.unshift({
                plat: player.plat,
                id: player.bookId,
                name: player.bookName,
                pic: player.pic,
                author: player.author,
                eps: player.chapters.length,
                ep: 0
            });
            if (list.length > 200) list = list.slice(0, 200);
            toast("已加入书架收藏");
        }
        saveJSON(FAV_KEY, list);
        syncFavBtn();
    });
    function chapterHTML(ch, realIdx) {
        var cur = realIdx === player.idx ? '<span class="cur">' + icon("pause", 12) + " 播放中</span>" : "";
        return '<button class="chbtn' + (realIdx === player.idx ? " playing" : "") + '" data-i="' + realIdx + '"><span class="ch-no">' + (realIdx + 1) + "</span>" + esc(ch.name) + cur + "</button>";
    }
    function renderChapters() {
        var list = player.chapters;
        var kw = ($("ch-filter").value || "").trim().toLowerCase();
        var pages = Math.max(1, Math.ceil(list.length / CH_PER_PAGE));
        if (player.chPage < 1) player.chPage = 1;
        if (player.chPage > pages) player.chPage = pages;
        var view;
        if (kw) {
            view = list.filter(function(c, i) {
                return c.name.toLowerCase().indexOf(kw) >= 0 || String(i + 1) === kw;
            });
            if (player.chDesc) view = view.slice().reverse();
            $("ch-pager").hidden = true;
            $("ch-count").textContent = "章节（匹配 " + view.length + "）";
            $("chlist").innerHTML = view.map(function(ch) {
                return chapterHTML(ch, list.indexOf(ch));
            }).join("");
            return;
        }
        var start = (player.chPage - 1) * CH_PER_PAGE;
        if (player.chDesc) {
            var origStart = list.length - player.chPage * CH_PER_PAGE;
            if (origStart < 0) origStart = 0;
            view = list.slice(origStart, origStart + CH_PER_PAGE).slice().reverse();
        } else {
            view = list.slice(start, start + CH_PER_PAGE);
        }
        $("ch-count").textContent = "章节（" + list.length + "）";
        $("ch-filter").hidden = list.length < 30;
        $("ch-pager").hidden = pages <= 1;
        $("ch-pageinfo").textContent = "第 " + player.chPage + " / " + pages + " 页";
        $("chlist").innerHTML = view.map(function(ch, k) {
            return chapterHTML(ch, list.indexOf(ch));
        }).join("");
    }
    function bindSort(btnId, getPlayerFlag, setPlayerFlag, rerender) {
        $(btnId).addEventListener("click", function() {
            setPlayerFlag(!getPlayerFlag());
            $(btnId).textContent = getPlayerFlag() ? "倒序" : "正序";
            rerender();
            $("chlist").scrollTop = 0;
        });
    }
    bindSort("ch-sort", function() {
        return player.chDesc;
    }, function(v) {
        player.chDesc = v;
        player.chPage = 1;
    }, renderChapters);
    $("ch-filter").addEventListener("input", renderChapters);
    $("ch-prev").addEventListener("click", function() {
        if (player.chPage > 1) {
            player.chPage--;
            renderChapters();
            $("chlist").scrollTop = 0;
        }
    });
    $("ch-next").addEventListener("click", function() {
        var pages = Math.max(1, Math.ceil(player.chapters.length / CH_PER_PAGE));
        if (player.chPage < pages) {
            player.chPage++;
            renderChapters();
            $("chlist").scrollTop = 0;
        }
    });
    $("ch-jump").addEventListener("change", function() {
        var n = parseInt($("ch-jump").value, 10);
        $("ch-jump").value = "";
        if (!n || n < 1) return;
        if (n > player.chapters.length) n = player.chapters.length;
        player.chPage = player.chDesc ? Math.ceil((player.chapters.length - n + 1) / CH_PER_PAGE) : Math.ceil(n / CH_PER_PAGE);
        renderChapters();
        $("chlist").scrollTop = 0;
        setTimeout(function() {
            var el = $("chlist").querySelector('.chbtn[data-i="' + (n - 1) + '"]');
            if (el) {
                el.scrollIntoView({
                    block: "center",
                    behavior: "smooth"
                });
                el.classList.add("flash");
                setTimeout(function() {
                    el.classList.remove("flash");
                }, 1200);
            }
        }, 80);
    });
    $("ch-jump").addEventListener("keydown", function(e) {
        if (e.key === "Enter") $("ch-jump").blur();
    });
    $("chlist").addEventListener("click", function(e) {
        var btn = e.target.closest(".chbtn");
        if (!btn) return;
        playChapter(parseInt(btn.dataset.i, 10), 0);
    });
    var audio = $("audio");
    function saveProgress(t) {
        if (player.idx < 0) return;
        try {
            localStorage.setItem(lastKey(), JSON.stringify({
                i: player.idx,
                t: Math.floor(t || audio.currentTime || 0)
            }));
        } catch (e) {}
    }
    function detachHls() {
        if (player.hls) {
            try {
                player.hls.destroy();
            } catch (e) {}
            player.hls = null;
        }
        var el = $("audio");
        if (el) {
            el.removeAttribute("src");
            try {
                el.load();
            } catch (e) {}
        }
    }

    function playChapter(i, seekTo) {
        if (!player.chapters[i]) return;
        var ch = player.chapters[i];
        player.idx = i;
        player.wantPlay = true;
        syncMediaSession();
        $("fplayer").hidden = false;
        $("fp-name").textContent = ch.name;
        $("fp-book").textContent = player.bookName + (player.author ? " · " + player.author : "");
        $("fp-source").textContent = platName(player.plat);
        $("fp-cover").src = imgProxy(player.pic || "");
        $("fp-bg").src = imgProxy(player.pic || "");
        $("fp-toggle").innerHTML = icon("pause", 24);
        $("mini").hidden = false;
        $("mini-title").textContent = ch.name;
        $("mini-sub").textContent = player.bookName;
        $("mini-pic").src = imgProxy(player.pic || "");
        $("mini-toggle").innerHTML = icon("pause", 17);
        syncFpFav();
        audio.src = "";
        pushHistory({
            plat: player.plat,
            id: player.bookId,
            name: player.bookName,
            pic: player.pic,
            author: player.author,
            eps: player.chapters.length,
            ep: i + 1,
            ts: Date.now()
        });
        var dpb = $("detail-play");
        if (!$("detail").hidden && dpb.onclick) {
            dpb.innerHTML = icon("play", 14) + " 继续播放 " + (i + 1) + "/" + player.chapters.length;
            dpb.onclick = function() {
                playChapter(i, 0);
            };
        }
        api("/api/play", {
            plat: player.plat,
            url: ch.url
        }).then(function(d) {
            if (player.idx !== i) return;
            var resume = seekTo || 0;
            detachHls();
            var src = d.url || d.src;
            if (window.Hls && Hls.isSupported() && /\.m3u8($|\?)/.test(src)) {
                var h = new Hls({
                    enableWorker: true
                });
                h.loadSource(src);
                h.attachMedia(audio);
                h.on(Hls.Events.MANIFEST_PARSED, function() {
                    audio.playbackRate = player.speed;
                    if (resume > 5) audio.currentTime = resume;
                    audio.play().catch(function() {});
                });
                h.on(Hls.Events.ERROR, function(ev, data) {
                    if (data.fatal) toast("播放解析失败: 流异常");
                });
                player.hls = h;
            } else {
                audio.src = src;
                audio.playbackRate = player.speed;
                var seekOnce = function() {
                    audio.removeEventListener("loadedmetadata", seekOnce);
                    if (resume > 5 && resume < audio.duration - 10) audio.currentTime = resume;
                    audio.play().catch(function() {});
                };
                audio.addEventListener("loadedmetadata", seekOnce);
            }
        }).catch(function(e) {
            toast("播放解析失败: " + e.message);
            $("fp-toggle").innerHTML = icon("play", 24);
            $("mini-toggle").innerHTML = icon("play", 17);
        });
        renderChapters();
    }
    function playOffset(delta) {
        var next = player.idx + delta;
        if (next < 0 || next >= player.chapters.length) return;
        playChapter(next, 0);
    }
    $("fp-toggle").addEventListener("click", togglePlay);
    $("mini-toggle").addEventListener("click", function(e) {
        e.stopPropagation();
        togglePlay();
    });
    function togglePlay() {
        if (!audio.src) {
            if (player.idx >= 0) playChapter(player.idx, 0);
            return;
        }
        if (audio.paused) {
            player.wantPlay = true;
            audio.play().catch(function() {});
        } else {
            player.wantPlay = false;
            audio.pause();
        }
    }
    audio.addEventListener("play", function() {
        jkWake.on();
        syncMediaSession();
        try {
            navigator.mediaSession.playbackState = "playing";
        } catch (e) {}
        $("fp-toggle").innerHTML = icon("pause", 24);
        $("mini-toggle").innerHTML = icon("pause", 17);
    });
    audio.addEventListener("pause", function() {
        jkWake.off();
        try {
            navigator.mediaSession.playbackState = "paused";
        } catch (e) {}
        $("fp-toggle").innerHTML = icon("play", 24);
        $("mini-toggle").innerHTML = icon("play", 17);
        saveProgress();
    });
    document.addEventListener("visibilitychange", function() {
        if (document.hidden || !player.wantPlay || !audio.paused || !audio.src) return;
        audio.play().catch(function() {});
    });
    audio.addEventListener("ended", function() {
        saveProgress(0);
        if (player.idx + 1 < player.chapters.length) playChapter(player.idx + 1, 0); else toast("本专辑播完啦");
    });
    var lastSave = 0;
    audio.addEventListener("timeupdate", function() {
        var cur = audio.currentTime, dur = audio.duration || 0;
        $("fp-cur").textContent = fmtTime(cur);
        $("fp-dur").textContent = fmtTime(dur);
        if (dur) {
            var pct = cur / dur * 100;
            $("fp-fill").style.width = pct + "%";
            $("fp-rest").style.left = pct + "%";
            $("fp-knob").style.left = pct + "%";
            $("mini-line").style.width = pct + "%";
        }
        var now = Date.now();
        if (now - lastSave > 5000) {
            lastSave = now;
            saveProgress();
        }
    });
    (function() {
        var bar = $("fp-bar");
        var dragging = false;
        function seekTo(x) {
            if (!audio.duration) return;
            var rect = bar.getBoundingClientRect();
            var pct = Math.min(Math.max((x - rect.left) / rect.width, 0), 1);
            audio.currentTime = pct * audio.duration;
            $("fp-fill").style.width = pct * 100 + "%";
            $("fp-rest").style.left = pct * 100 + "%";
            $("fp-knob").style.left = pct * 100 + "%";
        }
        bar.addEventListener("pointerdown", function(e) {
            if (!audio.duration) return;
            dragging = true;
            bar.setPointerCapture(e.pointerId);
            seekTo(e.clientX);
        });
        bar.addEventListener("pointermove", function(e) {
            if (dragging) seekTo(e.clientX);
        });
        bar.addEventListener("pointerup", function() {
            dragging = false;
        });
    })();
    $("fp-prev").addEventListener("click", function() {
        playOffset(-1);
    });
    $("fp-next").addEventListener("click", function() {
        playOffset(1);
    });
    $("mini-next").addEventListener("click", function(e) {
        e.stopPropagation();
        playOffset(1);
    });
    $("fp-back10").addEventListener("click", function() {
        if (audio.duration) audio.currentTime = Math.max(0, audio.currentTime - 10);
    });
    $("fp-fwd10").addEventListener("click", function() {
        if (audio.duration) audio.currentTime = Math.min(audio.duration - 1, audio.currentTime + 10);
    });
    $("fp-collapse").addEventListener("click", function() {
        $("fplayer").hidden = true;
    });
    $("mini-open").addEventListener("click", function() {
        if (player.idx >= 0) $("fplayer").hidden = false; else if (player.bookId) openDetail(player.bookId, player.plat, false);
    });
    $("fp-list").addEventListener("click", function() {
        $("sheet-count").textContent = "共 " + player.chapters.length + " 集";
        $("sheet-filter").hidden = player.chapters.length < 30;
        renderSheetChapters("");
        openSheet("ch-sheet");
    });
    function renderSheetChapters(kw) {
        var list = player.chapters;
        var view = list;
        if (kw) {
            view = list.filter(function(c, i) {
                return c.name.toLowerCase().indexOf(kw) >= 0 || String(i + 1) === kw;
            });
        }
        if (player.sheetDesc) view = view.slice().reverse();
        $("sheet-chlist").innerHTML = view.map(function(ch) {
            return chapterHTML(ch, list.indexOf(ch));
        }).join("") || '<div class="empty" style="padding:40px 0">无匹配章节</div>';
    }
    bindSort("sheet-sort", function() {
        return player.sheetDesc;
    }, function(v) {
        player.sheetDesc = v;
    }, function() {
        renderSheetChapters(($("sheet-filter").value || "").trim().toLowerCase());
    });
    $("sheet-filter").addEventListener("input", function() {
        renderSheetChapters(($("sheet-filter").value || "").trim().toLowerCase());
    });
    $("sheet-chlist").addEventListener("click", function(e) {
        var btn = e.target.closest(".chbtn");
        if (!btn) return;
        closeSheets();
        playChapter(parseInt(btn.dataset.i, 10), 0);
    });
    function renderSpeedChips() {
        $("speed-chips").innerHTML = SPEEDS.map(function(s) {
            return '<button data-s="' + s + '"' + (s === player.speed ? ' class="on"' : "") + ">" + s + "x</button>";
        }).join("");
        $("fp-speed-val").textContent = player.speed.toFixed(player.speed === Math.floor(player.speed) ? 1 : 2).replace(/0$/, "") + "x";
    }
    $("fp-speed").addEventListener("click", function() {
        $("fp-speed-panel").hidden = !$("fp-speed-panel").hidden;
    });
    $("speed-chips").addEventListener("click", function(e) {
        var b = e.target.closest("[data-s]");
        if (!b) return;
        player.speed = parseFloat(b.dataset.s);
        audio.playbackRate = player.speed;
        saveJSON(SPD_KEY, player.speed);
        renderSpeedChips();
        setTimeout(function() {
            $("fp-speed-panel").hidden = true;
        }, 250);
    });
    function syncFpFav() {
        var on = favHas(player.plat, player.bookId);
        var b = $("fp-fav");
        if (!b) return;
        b.innerHTML = on ? icon("bookmark", 14) + " 已加入书架" : icon("bookmark", 14) + " 加入书架";
        b.classList.toggle("on", on);
    }
    function toggleFavFromPlayer() {
        var list = getFav();
        var i = list.findIndex(function(f) {
            return f.plat === player.plat && f.id === player.bookId;
        });
        if (i >= 0) {
            list.splice(i, 1);
            toast("已移出书架");
        } else {
            if (!player.bookId) {
                toast("暂无播放中的书籍");
                return;
            }
            list.unshift({
                plat: player.plat,
                id: player.bookId,
                name: player.bookName,
                pic: player.pic,
                author: player.author,
                eps: player.chapters.length,
                ep: player.idx >= 0 ? player.idx + 1 : 0
            });
            if (list.length > 200) list = list.slice(0, 200);
            toast("已加入书架");
        }
        saveJSON(FAV_KEY, list);
        syncFpFav();
        if ($("page-library").classList.contains("on")) renderLibrary();
    }
    $("fp-fav").addEventListener("click", toggleFavFromPlayer);
    document.addEventListener("keydown", function(e) {
        if (e.target.tagName === "INPUT") return;
        if (e.code === "Space" && !$("fplayer").hidden) {
            e.preventDefault();
            togglePlay();
        }
        if (e.code === "ArrowRight" && !$("fplayer").hidden) playOffset(1);
        if (e.code === "ArrowLeft" && !$("fplayer").hidden) playOffset(-1);
        if (e.code === "Escape") {
            if (!$("fplayer").hidden) $("fplayer").hidden = true; else if (!$("detail").hidden) $("detail").hidden = true; else closeSheets();
        }
    });
    renderSpeedChips();
    loadTeenState();
    api("/api/platform").then(function(d) {
        state.plats = d.platforms || [];
        if (!state.plats.length) throw new Error("无可用平台");
        $("search-input").placeholder = "聚合搜索 " + state.plats.length + " 个平台";
        $("set-about").textContent = "多聚听书 · " + state.plats.length + " 源聚合";
        loadEnabled();
        var savedSpeed = parseFloat(loadJSON(SPD_KEY, 1));
        if (SPEEDS.indexOf(savedSpeed) >= 0) {
            player.speed = savedSpeed;
            renderSpeedChips();
        }
        var savedPlat = loadJSON(LAST_PLAT_KEY, "");
        var pick = state.plats.filter(function(p) {
            return p.key === savedPlat && isEnabled(p.key);
        })[0];
        if (!pick) pick = state.plats.filter(function(p) {
            return isEnabled(p.key);
        })[0] || state.plats[0];
        state.plat = pick.key;
        $("plat-name").textContent = platName(state.plat);
        saveJSON(LAST_PLAT_KEY, state.plat);
        switchTab("discover");
        switchPlat(state.plat);
    }).catch(function(e) {
        $("grid").innerHTML = "";
        $("empty").hidden = false;
        $("empty").querySelector(".empty-txt").textContent = "初始化失败: " + e.message;
    });
})();
"use strict";

const $ = s => document.querySelector(s);

const $$ = s => Array.from(document.querySelectorAll(s));

const state = {
    platforms: [],
    sourceStatus: {},
    plat: "",
    cat: "",
    page: 1,
    cats: [],
    mode: "grid",
    hasMore: false,
    searchMode: false,
    wd: "",
    searchPlat: "",
    teen: true,
    detail: null,
    chSort: "asc",
    chCols: 3,
    chQuery: "",
    chPage: 1,
    reader: null,
    shelfUpdates: {}
};

const store = {
    get(key, def) {
        try {
            const v = localStorage.getItem("dm_" + key);
            return v ? JSON.parse(v) : def;
        } catch (e) {
            return def;
        }
    },
    set(key, val) {
        try {
            localStorage.setItem("dm_" + key, JSON.stringify(val));
        } catch (e) {}
    },
    del(key) {
        try {
            localStorage.removeItem("dm_" + key);
        } catch (e) {}
    }
};

const prefs = {
    theme: store.get("theme", "dark"),
    accent: store.get("accent", "rose"),
    rdMode: store.get("rdMode", "webtoon"),
    rdDir: store.get("rdDir", "ltr"),
    tapTurn: store.get("tapTurn", true),
    gap: store.get("gap", "none"),
    bright: store.get("bright", 100),
    scope: store.get("scope", "agg")
};

const GAP_PX = {
    none: "0px",
    sm: "4px",
    lg: "12px"
};

const T2S_PAIRS = "們们東东車车馬马鳥鸟門门問问間间開开关關关閉闭見见貝贝頁页風风飛飞書书畫画學学習习樂乐氣气質质點点" + "愛爱戀恋嬰婴兒儿孫孙寶宝實实寬宽寫写對对專专業业丽丽麗亿億萬万與与龍龙鳳凤岡冈島岛嶋屿灣湾港" + "戰战環环現现國国圖图團团園圆圍围壇坛場场處处聲声響响務务動动態态強强獨独難难雞鸡語语說说話话讀读試试詩诗詞词議议談谈請请謝谢識识譯译護护變变讓让證证評评計计訊讯記记訪访設设" + "經经結结給给統统緒绪網网線线紅红練练級级純纯紀纪紙纸張张繼續续編编緣缘總总縮缩藝艺節节華华薦荐蘭兰藏藥药蠻蛮術术機机構构標标樣样橋桥權权歡欢歲岁錢钱銀银鐵铁鋼钢錄录鑒鉴長长閃闪聞闻闇暗" + "陰阴陽阳隊队階阶際际隨随隱隐雙双雜杂雲云電电餘余館馆養养餐饅馒馬达区医历协华单卖南博双发变台只是够梦奥妈妇学宁审岁帮广" + "废当录彻径征忆忧怀态惊愿报担拟拥拦拨择换损据摆摄敌断无旧昼显晓术样核楼横残毁毕气汉汇汤沧沟没沥沦浅泞泥济浦浩浪涛涨烧烫烦烛爷牍献猎猫玛环现琴琼画疯盖盘省矿码础" + "礼祢纬练组绅细织终绑绒绕绘绚络绝统继绩续维绵掷摊撑击摇摸斗时枪枫柜柠档栋检殃殿毕氏浊浓渔渗温湾湿溃滚满滤滥滨滩滴灵灶炮点炼烁烂烟热焕焰狮猕猴";

const T2S = (() => {
    const m = {};
    for (let i = 0; i + 1 < T2S_PAIRS.length; i += 2) m[T2S_PAIRS[i]] = T2S_PAIRS[i + 1];
    return m;
})();

function normalizeQuery(s) {
    let out = "";
    for (const ch of String(s || "")) {
        const code = ch.codePointAt(0);
        if (code >= 0xFF01 && code <= 0xFF5E) {
            out += String.fromCharCode(code - 0xFEE0);
            continue;
        }
        out += T2S[ch] || ch;
    }
    return out.trim();
}

async function api(path) {
    const resp = await fetch(path);
    const json = await resp.json().catch(() => ({}));
    if (!resp.ok || json.code !== undefined && json.code !== 200) throw new Error(json.msg || "HTTP " + resp.status);
    return json.data;
}

async function apiPost(path, body) {
    const resp = await fetch(path, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(body || {})
    });
    const json = await resp.json().catch(() => ({}));
    if (!resp.ok || json.code !== undefined && json.code !== 200) throw new Error(json.msg || "HTTP " + resp.status);
    return json.data;
}

const apiPlatforms = () => api("/api/platform");

const apiCats = plat => api("/api/cats?plat=" + encodeURIComponent(plat)).then(d => d.cats || []);

const apiList = (plat, cat, page) => api(`/api/category?plat=${encodeURIComponent(plat)}&cat=${encodeURIComponent(cat)}&page=${page}`);

const apiSearch = (wd, page, plat) => api(`/api/search?wd=${encodeURIComponent(wd)}&page=${page}` + (plat ? `&plat=${encodeURIComponent(plat)}` : ""));

const apiDetail = (plat, id) => api(`/api/detail?plat=${encodeURIComponent(plat)}&id=${encodeURIComponent(id)}`);

const apiPlay = (plat, url, warm, cid, ch) => api(`/api/play?plat=${encodeURIComponent(plat)}&url=${encodeURIComponent(url)}` + (warm ? `&warm=${warm}` : "") + (cid != null && ch >= 0 ? `&cid=${encodeURIComponent(cid)}&ch=${ch}` : ""));

function imgProxy(u) {
    if (!u) return "";
    if (u.includes("/media/img?")) {
        try {
            const x = new URL(u, location.origin);
            return x.pathname + x.search;
        } catch (e) {
            return u;
        }
    }
    return "media/img?u=" + encodeURIComponent(u);
}

function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[c]));
}

function escAttr(s) {
    return esc(s).replace(/`/g, "&#96;");
}

let toastTimer = 0;

function toast(msg, ms) {
    const t = $("#toast");
    t.textContent = msg;
    t.classList.remove("hidden");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.add("hidden"), ms || 2000);
}

function platName(key) {
    const p = state.platforms.find(x => x.key === key);
    return p ? p.name : key || "";
}

function platMeta(key) {
    return state.platforms.find(x => x.key === key) || {};
}

function applyPrefs() {
    const root = document.documentElement;
    root.dataset.theme = prefs.theme;
    root.dataset.accent = prefs.accent;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = prefs.theme === "light" ? "#f5f6f8" : prefs.theme === "amoled" ? "#000000" : "#12141a";
    $$("#theme-seg .seg-btn").forEach(b => b.classList.toggle("active", b.dataset.theme === prefs.theme));
    $$("#accent-seg .seg-btn").forEach(b => b.classList.toggle("active", b.dataset.accent === prefs.accent));
    $$("#rdmode-seg .seg-btn").forEach(b => b.classList.toggle("active", b.dataset.rd === prefs.rdMode));
    $$("#rddir-seg .seg-btn").forEach(b => b.classList.toggle("active", b.dataset.dir === prefs.rdDir));
    $$("#rdgap-seg .seg-btn").forEach(b => b.classList.toggle("active", b.dataset.gap === prefs.gap));
    $$("#scope-seg .seg-btn").forEach(b => b.classList.toggle("active", b.dataset.scope === prefs.scope));
    $("#tap-turn").checked = !!prefs.tapTurn;
    document.documentElement.style.setProperty("--rd-gap", GAP_PX[prefs.gap] || "0px");
}

let sheetOnClose = null;

let sheetPushed = false;

let ignorePop = 0;

function openSheet(title, buildBody, onClose) {
    $("#sheet-title").textContent = title;
    const body = $("#sheet-body");
    body.innerHTML = "";
    buildBody(body);
    $("#sheet-mask").classList.remove("hidden");
    $("#sheet").classList.remove("hidden");
    sheetOnClose = onClose || null;
    if (!sheetPushed) {
        sheetPushed = true;
        history.pushState({
            v: "sheet"
        }, "");
    }
}

function closeSheet(fromPop) {
    $("#sheet").classList.add("hidden");
    $("#sheet-mask").classList.add("hidden");
    const f = sheetOnClose;
    sheetOnClose = null;
    if (sheetPushed) {
        sheetPushed = false;
        if (!fromPop) {
            ignorePop++;
            history.back();
        }
    }
    if (f) f();
}

$("#sheet-close").addEventListener("click", closeSheet);

$("#sheet-mask").addEventListener("click", closeSheet);

let currentView = "discover";

const viewScroll = {};

function switchView(name) {
    if (currentView === name) return;
    const prev = $("#view-" + currentView);
    if (prev) viewScroll[currentView] = prev.scrollTop;
    currentView = name;
    $$(".view").forEach(v => v.classList.remove("active"));
    const el = $("#view-" + name);
    el.classList.add("active");
    $$("#tabbar .tab").forEach(t => t.classList.toggle("active", t.dataset.view === name));
    $("#search-box").classList.toggle("hidden", name !== "discover");
    el.scrollTop = viewScroll[name] || 0;
    if (name === "shelf") renderShelf();
    if (name === "history") renderHistory();
    if (name === "settings") {
        refreshTeenUI();
        refreshCacheUI();
    }
}

$$("#tabbar .tab").forEach(t => t.addEventListener("click", () => switchView(t.dataset.view)));

$("#detail-back").addEventListener("click", () => history.back());

function renderPlatSheet(body) {
    state.platforms.forEach(p => {
        const st = state.sourceStatus[p.key];
        const cls = st ? st.ok ? "" : " err" : " na";
        const btn = document.createElement("button");
        btn.className = "source-item" + (p.key === state.plat ? " active" : "");
        btn.dataset.plat = p.key;
        btn.innerHTML = `<span class="dot${cls}"></span><span>${esc(p.name)}</span>`;
        btn.addEventListener("click", () => {
            const changed = p.key !== state.plat;
            const wasSearch = state.searchMode;
            resetToDiscover();
            if (changed || wasSearch) selectPlat(p.key);
        });
        body.appendChild(btn);
    });
}

function resetToDiscover() {
    let back = 0;
    if (sheetPushed) {
        closeSheet(true);
        back++;
    }
    if (state.reader) {
        closeReader();
        back++;
    }
    if (currentView === "detail") {
        state.detail = null;
        back++;
    }
    if (back > 0) {
        ignorePop += back;
        history.go(-back);
    }
    exitSearch();
    switchView("discover");
    $("#view-discover").scrollTop = 0;
}

$(".plat-trigger").addEventListener("click", e => {
    e.stopPropagation();
    openSheet("选择漫画源", renderPlatSheet);
});

function updatePlatLabel() {
    const name = platName(state.plat) || "多聚漫画";
    $$(".plat-current").forEach(el => {
        el.textContent = name;
    });
}

async function loadPlatforms() {
    try {
        const data = await apiPlatforms();
        state.platforms = data.platforms || [];
        state.teen = !!data.teen;
        state.sourceStatus = {};
        (data.status || []).forEach(s => {
            state.sourceStatus[s.key] = s;
        });
        updatePlatLabel();
        const saved = store.get("plat", "");
        const pick = state.platforms.find(p => p.key === saved);
        if (!state.plat && pick) selectPlat(pick.key, true); else if (!state.plat && state.platforms.length) selectPlat(state.platforms[0].key, true);
    } catch (e) {
        $("#list").innerHTML = '<div class="hint">加载源失败：' + esc(e.message) + "</div>";
    }
}

async function selectPlat(key, first) {
    state.plat = key;
    state.cat = "";
    state.page = 1;
    store.set("plat", key);
    updatePlatLabel();
    try {
        state.cats = await apiCats(key);
        renderCatBar();
        loadList(first);
    } catch (e) {
        $("#list").innerHTML = '<div class="hint">' + esc(e.message) + "</div>";
        $("#pager").classList.add("hidden");
    }
}

function renderCatBar() {
    const bar = $("#cat-bar");
    bar.innerHTML = state.cats.map(c => `<button class="cat-chip${String(c.id) === String(state.cat) ? " active" : ""}" data-id="${escAttr(String(c.id))}">${esc(c.name)}</button>`).join("");
    bar.querySelectorAll(".cat-chip").forEach(c => c.addEventListener("click", () => {
        state.cat = c.dataset.id;
        state.page = 1;
        renderCatBar();
        loadList();
        $("#view-discover").scrollTop = 0;
    }));
}

function coverBox(pic, remarks) {
    const img = pic ? `<img loading="lazy" decoding="async" src="${escAttr(imgProxy(pic))}" onerror="this.style.display='none';this.parentNode.classList.add('img-err')">` : "";
    return `<div class="cover${pic ? "" : " img-err"}">${img}${remarks ? `<span class="badge-remarks">${esc(remarks)}</span>` : ""}</div>`;
}

function cardHTML(c, defaultPlat) {
    const plat = c.vod_plat || defaultPlat || "";
    if (c.vod_id === "__teen__") {
        return `<div class="card teen-card" data-teen="1">${coverBox("", "")}\n      <div class="name">🔒 青少年模式已隐藏</div><div class="sub">去设置解锁</div></div>`;
    }
    const name = esc(c.vod_name || "未知");
    const remarks = c.vod_remarks || "";
    const platTag = plat && state.searchMode ? `<span class="plat-tag">${esc(platName(plat))}</span>` : "";
    const info = `<div class="info"><div class="name">${name}</div>${remarks ? `<div class="sub">${esc(remarks)}</div>` : ""}${platTag}</div>`;
    const head = `<div class="name">${name}</div><div class="sub">${esc(c.vod_director || platName(plat))}</div>${platTag}`;
    return `<div class="card" data-plat="${escAttr(plat)}" data-id="${escAttr(String(c.vod_id))}">\n    ${coverBox(c.vod_pic, remarks)}${state.mode === "list" ? info : head}</div>`;
}

function skeletonHTML(n) {
    let h = "";
    for (let i = 0; i < n; i++) h += '<div><div class="sk cover"></div><div class="sk line"></div><div class="sk line" style="width:60%"></div></div>';
    return h;
}

function bindCards(box) {
    box.querySelectorAll(".card").forEach(card => card.addEventListener("click", () => {
        if (card.dataset.teen) {
            switchView("settings");
            return;
        }
        openDetail(card.dataset.plat, card.dataset.id);
    }));
}

async function loadList(firstLoad) {
    const box = $("#list");
    if (!firstLoad) box.innerHTML = skeletonHTML(12);
    const page = state.page;
    $("#pager").classList.remove("hidden");
    $("#page-now").textContent = page;
    $("#page-prev").disabled = page <= 1;
    try {
        const data = state.searchMode ? await apiSearch(state.wd, page, state.searchPlat) : await apiList(state.plat, state.cat || "", page);
        const list = data.list || [];
        state.hasMore = !!data.hasMore;
        box.className = "card-grid" + (state.mode === "list" ? " mode-list" : "");
        if (!list.length) {
            box.innerHTML = '<div class="hint">没有更多内容了</div>';
            $("#pager").classList.add("hidden");
        } else {
            box.innerHTML = list.map(c => cardHTML(c, state.searchMode ? "" : state.plat)).join("");
        }
        bindCards(box);
        const paged = state.searchMode ? platMeta(state.searchPlat || state.plat).searchPaged !== false : platMeta(state.plat).listPaged !== false;
        const pagerEl = $("#pager");
        if (!list.length || !paged) {
            pagerEl.classList.add("hidden");
        } else {
            pagerEl.classList.remove("hidden");
            $("#page-next").disabled = !state.hasMore;
        }
        const meta = $("#result-meta");
        if (state.searchMode) {
            const slow = (data.timeout || []).length;
            meta.textContent = `「${state.wd}」· ${state.searchPlat ? platName(state.searchPlat) : "聚合"} · ${list.length} 条` + (slow ? ` · ${slow} 源超时` : "");
        } else {
            meta.textContent = `${platName(state.plat)} · 第 ${page} 页 · ${list.length} 条`;
        }
    } catch (e) {
        box.innerHTML = `<div class="hint">加载失败：${esc(e.message)}<div class="retry"><button class="ghost-btn" onclick="window.__retryList()">重试</button></div></div>`;
        $("#pager").classList.add("hidden");
    }
}

window.__retryList = () => loadList();

$("#page-prev").addEventListener("click", () => {
    if (state.page > 1) {
        state.page--;
        loadList();
        $("#view-discover").scrollTop = 0;
    }
});

$("#page-next").addEventListener("click", () => {
    if (!state.hasMore) return;
    state.page++;
    loadList();
    $("#view-discover").scrollTop = 0;
});

$$("#mode-seg .seg-btn").forEach(b => b.addEventListener("click", () => {
    state.mode = b.dataset.mode;
    $$("#mode-seg .seg-btn").forEach(x => x.classList.toggle("active", x === b));
    store.set("mode", state.mode);
    loadList();
}));

$("#view-discover").addEventListener("scroll", () => {
    $("#to-top").classList.toggle("hidden", $("#view-discover").scrollTop < 400);
});

$("#to-top").addEventListener("click", () => {
    $("#view-discover").scrollTop = 0;
});

const searchInput = $("#search-input");

searchInput.addEventListener("focus", showRecentSearch);

searchInput.addEventListener("input", () => {
    $("#search-clear").classList.toggle("hidden", !searchInput.value);
    if (!searchInput.value) showRecentSearch(); else $("#recent-search").classList.add("hidden");
});

searchInput.addEventListener("keydown", e => {
    if (e.key === "Enter") {
        e.preventDefault();
        doSearch();
        searchInput.blur();
    }
});

document.addEventListener("click", e => {
    if (!e.target.closest("#search-box") && !e.target.closest("#recent-search")) $("#recent-search").classList.add("hidden");
});

function showRecentSearch() {
    const rec = store.get("recentWd", []);
    const box = $("#recent-search");
    if (!rec.length) {
        box.classList.add("hidden");
        return;
    }
    box.innerHTML = '<div class="recent-title">最近搜索</div>' + rec.map(w => `<button class="recent-item" data-wd="${escAttr(w)}">${esc(w)}</button>`).join("");
    box.classList.remove("hidden");
    box.querySelectorAll(".recent-item").forEach(b => b.addEventListener("click", () => {
        searchInput.value = b.dataset.wd;
        doSearch();
    }));
}

function exitSearch() {
    state.searchMode = false;
    state.wd = "";
    state.searchPlat = "";
    searchInput.value = "";
    $("#search-clear").classList.add("hidden");
    $("#recent-search").classList.add("hidden");
}

function doSearch() {
    const raw = searchInput.value.trim();
    if (!raw) return;
    const wd = normalizeQuery(raw);
    state.searchMode = true;
    state.wd = wd;
    state.page = 1;
    state.searchPlat = prefs.scope === "single" ? state.plat : "";
    const rec = store.get("recentWd", []).filter(w => w !== raw);
    rec.unshift(raw);
    store.set("recentWd", rec.slice(0, 6));
    $("#recent-search").classList.add("hidden");
    if (currentView !== "discover") switchView("discover");
    $("#view-discover").scrollTop = 0;
    loadList();
}

$("#search-clear").addEventListener("click", () => {
    searchInput.value = "";
    $("#search-clear").classList.add("hidden");
    if (state.searchMode) {
        exitSearch();
        state.page = 1;
        loadList();
    }
    searchInput.focus();
});

const progKey = (plat, id) => plat + "|" + id;

const allProg = () => store.get("prog", {});

function getProg(plat, id) {
    return allProg()[progKey(plat, id)] || null;
}

function setProg(plat, id, entry) {
    const all = allProg();
    all[progKey(plat, id)] = Object.assign({
        plat: plat,
        id: id
    }, entry, {
        t: Date.now()
    });
    const keys = Object.keys(all);
    if (keys.length > 100) {
        keys.sort((a, b) => (all[a].t || 0) - (all[b].t || 0));
        keys.slice(0, keys.length - 100).forEach(k => delete all[k]);
    }
    store.set("prog", all);
}

const favList = () => store.get("fav", []);

function isFav(plat, id) {
    return favList().some(x => x.plat === plat && x.id === id);
}

function toggleFav(plat, id, name, pic) {
    let list = favList();
    if (isFav(plat, id)) {
        list = list.filter(x => !(x.plat === plat && x.id === id));
        toast("已移出书架");
    } else {
        list.unshift({
            plat: plat,
            id: id,
            name: name,
            pic: pic,
            t: Date.now()
        });
        toast("已加入书架");
    }
    store.set("fav", list.slice(0, 200));
    return isFav(plat, id);
}

function historyList() {
    return Object.values(allProg()).filter(x => x.name).sort((a, b) => (b.t || 0) - (a.t || 0));
}

function progLabel(p) {
    const ch = p.chName || "第 " + ((p.ch || 0) + 1) + " 话";
    const total = p.total || 0;
    if (total > 1 && typeof p.page === "number") return `读到 ${ch} · ${Math.round((p.page + 1) / total * 100)}%`;
    return "读到 " + ch;
}

async function openDetail(plat, id) {
    state.detailFrom = currentView === "detail" ? state.detailFrom || "discover" : currentView;
    history.pushState({
        v: "detail"
    }, "");
    switchView("detail");
    $("#detail-body").innerHTML = '<div class="hint">加载中…</div>';
    $("#detail-fav").classList.add("hidden");
    try {
        const d = await apiDetail(plat, id);
        state.detail = Object.assign({}, d, {
            plat: plat
        });
        if (d.vod_id === "__teen__") {
            renderTeenDetail();
            return;
        }
        renderDetail();
    } catch (e) {
        $("#detail-body").innerHTML = '<div class="hint">' + esc(e.message) + "</div>";
    }
}

function renderTeenDetail() {
    $("#detail-fav").classList.add("hidden");
    $("#detail-body").innerHTML = `<div class="detail-head"><div class="detail-cover">🔒</div>\n    <div class="detail-meta"><div class="detail-name">青少年模式已隐藏</div>\n    <div class="detail-tags">成人内容 · 需解锁后查看</div></div></div>`;
}

function updateDetailFav() {
    const d = state.detail;
    const btn = $("#detail-fav");
    if (!d || d.vod_id === "__teen__") {
        btn.classList.add("hidden");
        return;
    }
    const fav = isFav(d.plat, d.vod_id);
    btn.classList.remove("hidden");
    btn.textContent = fav ? "✓ 收藏" : "＋ 收藏";
    btn.classList.toggle("faved", fav);
}

$("#detail-fav").addEventListener("click", () => {
    const d = state.detail;
    if (!d) return;
    toggleFav(d.plat, d.vod_id, d.vod_name, d.vod_pic);
    updateDetailFav();
});

function renderDetail() {
    const d = state.detail;
    const chapters = d.chapters || [];
    const total = chapters.length;
    const prog = getProg(d.plat, d.vod_id);
    const resumeCh = prog ? Math.min(prog.ch || 0, Math.max(0, total - 1)) : 0;
    const resumeTxt = prog ? `继续阅读（${esc(progLabel(prog))}）` : "开始阅读";
    const cols = state.chCols || 3;
    state.chQuery = "";
    state.chPage = 1;
    $("#detail-body").innerHTML = `\n    <div class="detail-head">\n      <div class="detail-cover${d.vod_pic ? "" : " img-err"}">${d.vod_pic ? `<img src="${escAttr(imgProxy(d.vod_pic))}" onerror="this.style.display='none';this.parentNode.classList.add('img-err')">` : ""}</div>\n      <div class="detail-meta">\n        <div class="detail-name">${esc(d.vod_name || "未知")}</div>\n        <div class="detail-tags">${esc([ d.vod_class, d.vod_director, d.vod_remarks ].filter(Boolean).join(" · "))}</div>\n        ${d.adult ? '<div class="detail-adult">⚠️ 成人内容</div>' : ""}\n        <div class="detail-actions">\n          <button class="accent-btn" id="btn-read">${resumeTxt}</button>\n        </div>\n      </div>\n    </div>\n    <div class="detail-desc" id="detail-desc">${esc(d.vod_content || "暂无简介")}</div>\n    <div class="chap-toolbar">\n      <div class="chap-count">章节（${total}）</div>\n      <div class="head-actions">\n        <input class="chap-search" id="chap-search" type="search" placeholder="搜索章节…" autocomplete="off">\n        <button class="ghost-btn" id="btn-chcols" title="切换每行列数">▦ ${cols} 列</button>\n        <div class="seg" id="chap-sort">\n          <button class="seg-btn${state.chSort === "asc" ? " active" : ""}" data-s="asc">正序</button>\n          <button class="seg-btn${state.chSort === "desc" ? " active" : ""}" data-s="desc">倒序</button>\n        </div>\n      </div>\n    </div>\n    <div class="chap-pager" id="chap-pager" style="display:none"></div>\n    <div class="chapter-list" data-cols="${cols}"></div>`;
    $("#detail-desc").addEventListener("click", function() {
        this.classList.toggle("expanded");
    });
    $("#btn-read").addEventListener("click", () => openReader(resumeCh, prog ? prog.page || 0 : 0));
    updateDetailFav();
    $("#btn-chcols").addEventListener("click", function() {
        state.chCols = state.chCols % 4 + 1;
        store.set("chCols", state.chCols);
        this.textContent = `▦ ${state.chCols} 列`;
        const listEl = $("#detail-body .chapter-list");
        if (listEl) listEl.dataset.cols = state.chCols;
    });
    $$("#chap-sort .seg-btn").forEach(b => b.addEventListener("click", () => {
        state.chSort = b.dataset.s;
        $$("#chap-sort .seg-btn").forEach(x => x.classList.toggle("active", x === b));
        state.chPage = 1;
        renderChapterList();
    }));
    const searchEl = $("#chap-search");
    searchEl.addEventListener("input", () => {
        state.chQuery = searchEl.value;
        state.chPage = 1;
        renderChapterList();
    });
    renderChapterList();
}

const CHAP_PAGE_SIZE = 100;

function chapterVisibleIdxs() {
    const chapters = (state.detail || {}).chapters || [];
    const q = (state.chQuery || "").trim().toLowerCase();
    let idxs = chapters.map((ch, i) => i);
    if (q) idxs = idxs.filter(i => (chapters[i].name || "第 " + (i + 1) + " 话").toLowerCase().includes(q));
    if (state.chSort === "desc") idxs.reverse();
    return idxs;
}

function renderChapterList() {
    const d = state.detail;
    if (!d) return;
    const chapters = d.chapters || [];
    const prog = getProg(d.plat, d.vod_id);
    const readCh = prog ? prog.ch || 0 : -1;
    const idxs = chapterVisibleIdxs();
    const pages = Math.max(1, Math.ceil(idxs.length / CHAP_PAGE_SIZE));
    if (state.chPage > pages) state.chPage = pages;
    if (state.chPage < 1) state.chPage = 1;
    const slice = idxs.slice((state.chPage - 1) * CHAP_PAGE_SIZE, state.chPage * CHAP_PAGE_SIZE);
    const listEl = $("#detail-body .chapter-list");
    if (!listEl) return;
    listEl.innerHTML = slice.map(i => `<div class="chapter${i === readCh ? " read" : ""}" data-i="${i}">${esc(chapters[i].name || "第 " + (i + 1) + " 话")}</div>`).join("");
    listEl.querySelectorAll(".chapter").forEach(ch => ch.addEventListener("click", () => {
        const i = +ch.dataset.i;
        const chData = chapters[i];
        if (!chData) return;
        if (chData.url === "teen://unlock") {
            switchView("settings");
            return;
        }
        openReader(i);
    }));
    const pager = $("#chap-pager");
    if (!pager) return;
    if (pages > 1) {
        pager.style.display = "";
        let btns = "";
        const start = Math.max(1, state.chPage - 2), end = Math.min(pages, start + 4);
        if (state.chPage > 1) btns += `<button class="ghost-btn pg-btn" data-p="${state.chPage - 1}">‹</button>`;
        for (let p = start; p <= end; p++) btns += `<button class="ghost-btn pg-btn${p === state.chPage ? " active" : ""}" data-p="${p}">${p}</button>`;
        if (state.chPage < pages) btns += `<button class="ghost-btn pg-btn" data-p="${state.chPage + 1}">›</button>`;
        pager.innerHTML = btns;
        pager.querySelectorAll(".pg-btn").forEach(b => b.addEventListener("click", () => {
            state.chPage = +b.dataset.p;
            renderChapterList();
            const tb = $("#detail-body .chap-toolbar");
            if (tb) tb.scrollIntoView({ behavior: "smooth", block: "start" });
        }));
    } else {
        pager.style.display = "none";
        pager.innerHTML = "";
    }
    const q = (state.chQuery || "").trim();
    const cnt = $("#detail-body .chap-count");
    if (cnt) cnt.textContent = q ? `章节（${idxs.length}/${chapters.length}）` : `章节（${chapters.length}）`;
}

let wakeLock = null;

const R = {
    pageRatio: 1.45,
    seeded: false,
    io: null,
    ioEnd: null,
    saveTimer: 0,
    prefetched: -1
};

const MAX_CHAIN_PAGES = 1500;

async function requestWakeLock() {
    try {
        if ("wakeLock" in navigator) wakeLock = await navigator.wakeLock.request("screen");
    } catch (e) {}
}

function releaseWakeLock() {
    try {
        if (wakeLock) {
            wakeLock.release();
            wakeLock = null;
        }
    } catch (e) {}
}

async function enterReaderFullscreen() {
    try {
        const el = document.documentElement;
        if (!document.fullscreenElement && el.requestFullscreen) await el.requestFullscreen();
    } catch (e) {}
}

function exitReaderFullscreen() {
    try {
        if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen();
    } catch (e) {}
}

document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && state.reader) requestWakeLock();
});

async function openReader(idx, startPage) {
    const d = state.detail;
    const chapters = d.chapters || [];
    if (!chapters.length) {
        toast("暂无章节");
        return;
    }
    idx = Math.max(0, Math.min(idx, chapters.length - 1));
    history.pushState({
        v: "reader"
    }, "");
    const prog = getProg(d.plat, d.vod_id);
    state.reader = {
        idx: idx,
        chapters: chapters,
        pics: [],
        page: 0,
        mode: prefs.rdMode,
        dir: prefs.rdDir,
        plat: d.plat,
        id: d.vod_id,
        name: d.vod_name,
        pic: d.vod_pic,
        startPage: startPage || 0,
        startPct: prog && prog.total && prog.ch === idx ? (prog.page + 1) / prog.total : 0,
        prefetched: -1,
        segIdx: [ idx ],
        segBase: [ 0 ],
        segLen: [ 0 ],
        appending: false
    };
    $("#reader").classList.remove("hidden");
    $("#reader").classList.remove("bars-hidden");
    $("#reader-mode").textContent = prefs.rdMode === "webtoon" ? "长条" : "翻页";
    $("#reader-fav").textContent = isFav(d.plat, d.vod_id) ? "★" : "☆";
    applyBright(prefs.bright);
    applyGap();
    requestWakeLock();
    enterReaderFullscreen();
    await loadChapter();
}

async function loadChapter() {
    const r = state.reader;
    const loading = $("#reader-loading");
    loading.classList.remove("hidden");
    $("#reader-loading-txt").textContent = "解析章节图片…";
    const ch = r.chapters[r.idx];
    $("#reader-title").textContent = `${r.name} · ${ch.name || ""}`;
    updateReaderBtns();
    let data = null;
    try {
        data = await apiPlay(r.plat, ch.url, 0, r.id, r.idx);
    } catch (e) {
        loading.classList.add("hidden");
        $("#reader-body").innerHTML = `<div class="hint">加载失败：${esc(e.message)}</div>`;
        return;
    }
    if (data.teen) {
        loading.classList.add("hidden");
        $("#reader-body").innerHTML = '<div class="hint">🔒 青少年模式已隐藏该内容</div>';
        return;
    }
    r.pics = data.pics || [];
    if (!r.pics.length) {
        loading.classList.add("hidden");
        $("#reader-body").innerHTML = '<div class="hint">本章无图片</div>';
        return;
    }
    r.segIdx = [ r.idx ];
    r.segBase = [ 0 ];
    r.segLen = [ r.pics.length ];
    r.appending = false;
    $("#reader-loading-txt").textContent = `共 ${r.pics.length} 页`;
    const start = resumePage();
    renderReader(start);
    loading.classList.add("hidden");
    updateReaderUI();
    saveProgress();
}

function resumePage() {
    const r = state.reader;
    if (r.startPct && !r.startPage) return Math.min(Math.round(r.startPct * r.pics.length) - 1, r.pics.length - 1);
    return Math.min(r.startPage || 0, r.pics.length - 1);
}

function renderReader(startPage) {
    const r = state.reader;
    const body = $("#reader-body");
    body.className = r.mode;
    if (r.mode === "webtoon") buildWebtoon(startPage); else buildPaged(startPage);
}

function updateReaderBtns() {
    const r = state.reader;
    if (!r) return;
    $("#prev-ch").disabled = r.idx <= 0;
    $("#next-ch").disabled = r.idx >= r.chapters.length - 1;
    $("#reader-mode").textContent = r.mode === "webtoon" ? "长条" : "翻页";
}

function updateReaderUI() {
    const r = state.reader;
    if (!r) return;
    const p = chapterProgress(r.page);
    const slider = $("#page-slider");
    slider.max = p.len;
    slider.value = p.local + 1;
    $("#reader-pos").textContent = `${p.local + 1}/${p.len}`;
    updateReaderBtns();
}

function buildWebtoon(startPage) {
    const r = state.reader;
    const body = $("#reader-body");
    const pb = (R.pageRatio * 100).toFixed(2) + "%";
    body.innerHTML = r.pics.map((_, i) => `<div class="pg-wrap" data-i="${i}" style="--pg-ar:${pb}">` + `<span class="pg-ph">${i + 1} / ${r.pics.length}</span>` + `<img class="pg" data-i="${i}" alt="第${i + 1}页" decoding="async"></div>`).join("");
    R.seeded = false;
    if (R.io) R.io.disconnect();
    const wraps = Array.from(body.querySelectorAll(".pg-wrap"));
    R.io = new IntersectionObserver(entries => {
        entries.forEach(en => {
            const i = +en.target.dataset.i;
            if (en.isIntersecting) loadPageImg(i); else {
                const rb = en.rootBounds;
                if (!rb) return;
                const far = en.boundingClientRect.top - rb.bottom > 2600 || rb.top - en.boundingClientRect.bottom > 2600;
                if (far) releasePageImg(i);
            }
        });
    }, {
        root: body,
        rootMargin: "1400px 0px 1400px 0px",
        threshold: 0
    });
    wraps.forEach(w => R.io.observe(w));
    body.onscroll = onWebtoonScroll;
    body.onpointerdown = null;
    body.onpointerup = null;
    attachSentinel();
    if (startPage > 0 && wraps[startPage]) {
        jumpToPage(startPage);
    } else {
        body.scrollTop = 0;
    }
    requestAnimationFrame(() => {
        for (let i = 0; i < Math.min(r.pics.length, 3); i++) loadPageImg(i);
        onWebtoonScroll();
    });
}

function attachSentinel() {
    const body = $("#reader-body");
    if (!body) return;
    let s = $("#ch-sentinel");
    if (!s) {
        s = document.createElement("div");
        s.id = "ch-sentinel";
        s.className = "ch-sentinel";
        s.innerHTML = '<span class="cs-txt">正在接下一话…</span>';
    }
    body.appendChild(s);
    if (R.ioEnd) R.ioEnd.disconnect();
    R.ioEnd = new IntersectionObserver(es => {
        if (es.some(e => e.isIntersecting)) appendNextChapter();
    }, {
        root: body,
        rootMargin: "2400px 0px 2400px 0px",
        threshold: 0
    });
    R.ioEnd.observe(s);
}

async function appendNextChapter() {
    const r = state.reader;
    if (!r || r.mode !== "webtoon" || r.appending) return;
    if (r.pics.length >= MAX_CHAIN_PAGES) return;
    const last = r.segIdx[r.segIdx.length - 1];
    if (last == null || last >= r.chapters.length - 1) return;
    r.appending = true;
    const s = $("#ch-sentinel");
    if (s) s.classList.add("loading");
    try {
        const data = await apiPlay(r.plat, r.chapters[last + 1].url, 3, r.id, last + 1);
        if (state.reader !== r) return;
        const pics = data && !data.teen && data.pics ? data.pics : [];
        if (!pics.length) return;
        appendSegment(last + 1, pics);
    } catch (e) {} finally {
        if (state.reader === r) {
            r.appending = false;
            if (s) s.classList.remove("loading");
            attachSentinel();
        }
    }
}

function appendSegment(idx, pics) {
    const r = state.reader;
    const body = $("#reader-body");
    const sentinel = $("#ch-sentinel");
    const base = r.pics.length;
    const pb = (R.pageRatio * 100).toFixed(2) + "%";
    r.segIdx.push(idx);
    r.segBase.push(base);
    r.segLen.push(pics.length);
    r.pics = r.pics.concat(pics);
    const frag = document.createDocumentFragment();
    pics.forEach((_, j) => {
        const gi = base + j;
        const w = document.createElement("div");
        w.className = "pg-wrap";
        w.dataset.i = String(gi);
        w.style.setProperty("--pg-ar", pb);
        w.innerHTML = `<span class="pg-ph">${gi + 1} / ${r.pics.length}</span>` + `<img class="pg" data-i="${gi}" alt="第${gi + 1}页" decoding="async">`;
        frag.appendChild(w);
    });
    body.insertBefore(frag, sentinel);
    if (R.io) body.querySelectorAll(".pg-wrap").forEach(w => R.io.observe(w));
    body.querySelectorAll(".pg-ph").forEach((el, i) => {
        el.textContent = i + 1 + " / " + r.pics.length;
    });
    loadPageImg(base);
    loadPageImg(base + 1);
    updateReaderUI();
}

function loadPageImg(i) {
    const r = state.reader;
    const wrap = $('#reader-body .pg-wrap[data-i="' + i + '"]');
    if (!wrap) return;
    const img = wrap.querySelector("img");
    if (img.dataset.loaded === "1") return;
    img.dataset.loaded = "1";
    img.onload = () => {
        wrap.classList.add("loaded");
        const ratio = img.naturalHeight / img.naturalWidth;
        if (ratio > 0.2 && ratio < 20) {
            if (!R.seeded) {
                R.seeded = true;
                R.pageRatio = ratio;
            }
            setPageRatio(i, ratio);
        }
    };
    img.onerror = () => {
        img.dataset.loaded = "";
        wrap.classList.remove("loaded");
        img.removeAttribute("src");
        if (!img.dataset.retried) {
            img.dataset.retried = "1";
            setTimeout(() => {
                if (state.reader && state.reader.idx === r.idx) {
                    delete img.dataset.retried;
                    loadPageImg(i);
                }
            }, 1600);
        }
    };
    img.src = imgProxy(r.pics[i]);
}

function releasePageImg(i) {
    const wrap = $('#reader-body .pg-wrap[data-i="' + i + '"]');
    if (!wrap) return;
    const img = wrap.querySelector("img");
    if (img && img.dataset.loaded === "1") {
        img.removeAttribute("src");
        img.dataset.loaded = "";
        wrap.classList.remove("loaded");
    }
}

function setPageRatio(i, ratio) {
    const body = $("#reader-body");
    if (!body || !body.classList.contains("webtoon")) return;
    const wrap = body.querySelector('.pg-wrap[data-i="' + i + '"]');
    if (!wrap) return;
    const anchor = body.querySelector('.pg-wrap[data-i="' + (state.reader ? state.reader.page : 0) + '"]');
    const before = anchor ? anchor.getBoundingClientRect().top : 0;
    wrap.style.setProperty("--pg-ar", (ratio * 100).toFixed(2) + "%");
    if (anchor && anchor !== wrap && wrap.compareDocumentPosition(anchor) & Node.DOCUMENT_POSITION_FOLLOWING) {
        body.scrollTop += anchor.getBoundingClientRect().top - before;
    }
}

function jumpToPage(n) {
    const body = $("#reader-body");
    const wrap = body.querySelector('.pg-wrap[data-i="' + n + '"]');
    if (!wrap) return;
    body.scrollTop = wrap.offsetTop;
    loadPageImg(n);
    if (n + 1 < state.reader.pics.length) loadPageImg(n + 1);
}

function onWebtoonScroll() {
    const r = state.reader;
    if (!r || r.mode !== "webtoon" || !r.pics.length) return;
    const body = $("#reader-body");
    const wraps = body.querySelectorAll(".pg-wrap");
    const cursor = body.scrollTop + body.clientHeight * 0.4;
    let cur = 0;
    for (let i = 0; i < wraps.length; i++) {
        if (wraps[i].offsetTop <= cursor) cur = i; else break;
    }
    if (cur !== r.page) {
        r.page = cur;
        const p = chapterProgress(cur);
        $("#page-slider").max = p.len;
        $("#page-slider").value = p.local + 1;
        $("#reader-pos").textContent = `${p.local + 1}/${p.len}`;
    }
    const ci = chapterOfPage(cur);
    if (ci !== r.idx) {
        r.idx = ci;
        syncChapterTitle();
        updateReaderBtns();
    }
    scheduleSave();
}

function segmentOf(page) {
    const r = state.reader;
    for (let k = r.segBase.length - 1; k >= 0; k--) {
        if (page >= r.segBase[k]) return k;
    }
    return 0;
}

function chapterOfPage(page) {
    const r = state.reader;
    const k = segmentOf(page);
    return r.segIdx[k] != null ? r.segIdx[k] : r.idx;
}

function chapterProgress(page) {
    const r = state.reader;
    const k = segmentOf(page);
    const base = r.segBase[k] || 0;
    const len = r.segLen[k] || r.pics.length || 1;
    return {
        base: base,
        len: len,
        local: Math.max(0, page - base)
    };
}

function syncChapterTitle() {
    const r = state.reader;
    if (!r) return;
    const ch = r.chapters[r.idx] || {};
    $("#reader-title").textContent = `${r.name} · ${ch.name || ""}`;
}

function maybePrefetchNext() {
    const r = state.reader;
    if (!r) return;
    if (r.mode !== "paged") return;
    if (r.page < r.pics.length - 3) return;
    if (r.idx >= r.chapters.length - 1) return;
    if (r.prefetched === r.idx + 1) return;
    r.prefetched = r.idx + 1;
    apiPlay(r.plat, r.chapters[r.idx + 1].url, 3, r.id, r.idx + 1).catch(() => {});
}

function buildPaged(startPage) {
    const r = state.reader;
    r.page = Math.min(startPage || 0, r.pics.length - 1);
    showPaged(r.page);
    bindPagedEvents();
}

function showPaged(n) {
    const r = state.reader;
    n = Math.max(0, Math.min(n, r.pics.length - 1));
    r.page = n;
    const body = $("#reader-body");
    body.innerHTML = `<img src="${escAttr(imgProxy(r.pics[n]))}" alt="第${n + 1}页" decoding="async">`;
    [ n + 1, n - 1 ].forEach(j => {
        if (r.pics[j]) {
            const pre = new Image;
            pre.src = imgProxy(r.pics[j]);
        }
    });
    const p = chapterProgress(n);
    $("#page-slider").max = p.len;
    $("#page-slider").value = p.local + 1;
    $("#reader-pos").textContent = `${p.local + 1}/${p.len}`;
    scheduleSave();
    maybePrefetchNext();
}

function bindPagedEvents() {
    const body = $("#reader-body");
    let sx = 0, sy = 0, st = 0, lastTap = 0, zoomed = false;
    body.onpointerdown = e => {
        sx = e.clientX;
        sy = e.clientY;
        st = Date.now();
    };
    body.onpointerup = e => {
        const dx = e.clientX - sx, dy = e.clientY - sy;
        const dt = Date.now() - st;
        if (Math.abs(dx) > 46 && Math.abs(dx) > Math.abs(dy)) {
            const forward = state.reader.dir === "rtl" ? dx > 0 : dx < 0;
            turnPage(forward ? 1 : -1);
            return;
        }
        if (dt < 300 && Math.abs(dx) < 10 && Math.abs(dy) < 10) {
            const now = Date.now();
            if (now - lastTap < 350) {
                lastTap = 0;
                zoomed = !zoomed;
                const img = body.querySelector("img");
                if (img) {
                    img.style.transform = zoomed ? "scale(2.2)" : "";
                    if (zoomed) {
                        const rect = body.getBoundingClientRect();
                        img.style.transformOrigin = `${e.clientX - rect.left}px ${e.clientY - rect.top}px`;
                    }
                }
                return;
            }
            lastTap = now;
            const w = body.clientWidth;
            if (prefs.tapTurn) {
                const x = e.clientX - body.getBoundingClientRect().left;
                if (x > w * 0.35 && x < w * 0.65) {
                    toggleBars();
                    return;
                }
                const forward = state.reader.dir === "rtl" ? x < w * 0.35 : x > w * 0.65;
                turnPage(forward ? 1 : -1);
            } else toggleBars();
        }
    };
}

function turnPage(delta) {
    const r = state.reader;
    if (!r || r.mode !== "paged") return;
    const next = r.page + delta;
    if (next < 0) {
        prevChapter();
        return;
    }
    if (next >= r.pics.length) {
        nextChapter();
        return;
    }
    showPaged(next);
}

function toggleBars() {
    $("#reader").classList.toggle("bars-hidden");
}

$("#reader-body").addEventListener("click", e => {
    const r = state.reader;
    if (!r || r.mode !== "webtoon") return;
    if (e.target.tagName === "IMG") toggleBars();
});

$("#page-slider").addEventListener("input", e => {
    const r = state.reader;
    if (!r || !r.pics.length) return;
    const n = parseInt(e.target.value, 10) - 1;
    if (r.mode === "paged") showPaged(chapterProgress(r.page).base + n); else {
        jumpToPage(chapterProgress(r.page).base + n);
        onWebtoonScroll();
    }
});

$("#page-slider").addEventListener("change", saveProgress);

function applyBright(v) {
    prefs.bright = Math.max(30, Math.min(100, v | 0));
    $("#reader-dim").style.opacity = String((100 - prefs.bright) / 100);
    $("#bright-slider").value = prefs.bright;
    $("#bright-slider-val").textContent = prefs.bright + "%";
}

function applyGap() {
    document.documentElement.style.setProperty("--rd-gap", GAP_PX[prefs.gap] || "0px");
}

$("#reader-bright").addEventListener("click", () => $("#reader-bright-panel").classList.toggle("hidden"));

$("#bright-slider").addEventListener("input", e => {
    applyBright(+e.target.value);
    store.set("bright", prefs.bright);
});

$("#reader-mode").addEventListener("click", () => {
    const r = state.reader;
    if (!r) return;
    r.mode = r.mode === "webtoon" ? "paged" : "webtoon";
    updateReaderBtns();
    stopReaderObservers();
    $("#reader-body").innerHTML = "";
    $("#reader-body").onscroll = null;
    renderReader(r.page);
    updateReaderUI();
});

$("#reader-fav").addEventListener("click", () => {
    const r = state.reader;
    if (!r) return;
    const now = toggleFav(r.plat, r.id, r.name, r.pic);
    $("#reader-fav").textContent = now ? "★" : "☆";
    $("#reader-fav").classList.toggle("faved", now);
});

function prevChapter() {
    const r = state.reader;
    if (r && r.idx > 0) gotoChapter(r.idx - 1);
}

function nextChapter() {
    const r = state.reader;
    if (r && r.idx < r.chapters.length - 1) gotoChapter(r.idx + 1);
}

function gotoChapter(n) {
    const r = state.reader;
    if (!r || n < 0 || n >= r.chapters.length) return;
    const k = r.segIdx.indexOf(n);
    if (k >= 0) {
        r.idx = n;
        syncChapterTitle();
        updateReaderBtns();
        if (r.mode === "webtoon") {
            jumpToPage(r.segBase[k]);
            onWebtoonScroll();
        } else showPaged(r.segBase[k]);
        return;
    }
    openReaderAt(n);
}

$("#prev-ch").addEventListener("click", prevChapter);

$("#next-ch").addEventListener("click", nextChapter);

async function openReaderAt(idx) {
    const r = state.reader;
    saveProgress();
    stopReaderObservers();
    r.idx = idx;
    r.pics = [];
    r.page = 0;
    r.startPage = 0;
    r.startPct = 0;
    r.segIdx = [ idx ];
    r.segBase = [ 0 ];
    r.segLen = [ 0 ];
    r.appending = false;
    $("#reader-body").innerHTML = "";
    $("#reader-body").onscroll = null;
    await loadChapter();
}

function stopReaderObservers() {
    if (R.io) {
        R.io.disconnect();
        R.io = null;
    }
    if (R.ioEnd) {
        R.ioEnd.disconnect();
        R.ioEnd = null;
    }
}

function scheduleSave() {
    clearTimeout(R.saveTimer);
    R.saveTimer = setTimeout(saveProgress, 1200);
}

function saveProgress() {
    const r = state.reader;
    if (!r || !r.pics.length) return;
    const k = segmentOf(r.page);
    const chIdx = r.segIdx[k] != null ? r.segIdx[k] : r.idx;
    const ch = r.chapters[chIdx] || {};
    setProg(r.plat, r.id, {
        ch: chIdx,
        page: r.page - r.segBase[k],
        total: r.segLen[k] || r.pics.length,
        name: r.name,
        pic: r.pic,
        chName: ch.name || ""
    });
}

function closeReader() {
    saveProgress();
    releaseWakeLock();
    exitReaderFullscreen();
    stopReaderObservers();
    clearTimeout(R.saveTimer);
    const body = $("#reader-body");
    body.innerHTML = "";
    body.onscroll = null;
    body.onpointerdown = null;
    body.onpointerup = null;
    state.reader = null;
    $("#reader-bright-panel").classList.add("hidden");
    $("#reader").classList.add("hidden");
    refreshDetailIfOpen();
}

$("#reader-back").addEventListener("click", () => history.back());

function refreshDetailIfOpen() {
    if (currentView === "detail" && state.detail) renderDetail();
}

function shelfItemHTML(x) {
    const p = getProg(x.plat, x.id);
    const pct = p && p.total ? Math.min(100, Math.round(((p.page || 0) + 1) / p.total * 100)) : 0;
    const upd = state.shelfUpdates[x.plat + "|" + x.id];
    const badge = upd && upd.hasUpdate ? `<span class="upd-badge">更新 · ${upd.total} 话</span>` : "";
    return `<div class="shelf-item" data-plat="${escAttr(x.plat)}" data-id="${escAttr(String(x.id))}">\n    ${coverBox(x.pic, "")}\n    <div class="info">\n      <div class="name">${esc(x.name || "未知")}</div>\n      <div class="meta">${p ? esc(progLabel(p)) + " · " : ""}${esc(platName(x.plat))}</div>\n      ${pct ? `<div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>` : ""}\n    </div>\n    ${badge}\n  </div>`;
}

function renderShelf() {
    const list = favList();
    const box = $("#shelf-list");
    if (!list.length) {
        box.innerHTML = '<div class="hint">书架空空，去发现页收藏几部吧</div>';
        return;
    }
    box.innerHTML = list.map(shelfCardHTML).join("");
    bindShelf(box);
}

function shelfCardHTML(x) {
    const upd = state.shelfUpdates[x.plat + "|" + x.id];
    const dot = upd && upd.hasUpdate ? '<span class="upd-dot"></span>' : "";
    return `<div class="shelf-card" data-plat="${escAttr(x.plat)}" data-id="${escAttr(String(x.id))}">\n    ${coverBox(x.pic, "")}${dot}\n    <button class="remove" data-remove="1">✕</button>\n    <div class="name">${esc(x.name || "未知")}</div>\n  </div>`;
}

function renderHistory() {
    const list = historyList();
    const box = $("#history-list");
    if (!list.length) {
        box.innerHTML = '<div class="hint">暂无阅读记录</div>';
        return;
    }
    box.innerHTML = list.map(shelfItemHTML).join("");
    bindShelf(box);
}

function bindShelf(box) {
    box.querySelectorAll(".shelf-item, .shelf-card").forEach(el => el.addEventListener("click", e => {
        e.stopPropagation();
        if (e.target.dataset.remove !== undefined) {
            store.set("fav", favList().filter(x => !(x.plat === el.dataset.plat && x.id === el.dataset.id)));
            renderShelf();
            return;
        }
        openDetail(el.dataset.plat, el.dataset.id);
    }));
}

$("#shelf-clear").addEventListener("click", () => {
    store.set("fav", []);
    state.shelfUpdates = {};
    renderShelf();
});

$("#history-clear").addEventListener("click", () => {
    store.del("prog");
    renderHistory();
});

$("#shelf-check").addEventListener("click", async () => {
    const list = favList();
    if (!list.length) {
        toast("书架是空的");
        return;
    }
    toast("正在检查更新…");
    const items = list.slice(0, 200).map(x => {
        const p = getProg(x.plat, x.id);
        return {
            plat: x.plat,
            id: x.id,
            ch: p && typeof p.ch === "number" ? p.ch : -1
        };
    });
    try {
        const data = await apiPost("/api/checkupdate", {
            items: items
        });
        let n = 0;
        state.shelfUpdates = {};
        (data.results || []).forEach(r => {
            if (r.ok) state.shelfUpdates[r.plat + "|" + r.id] = r;
            if (r.hasUpdate) n++;
        });
        renderShelf();
        toast(n ? `${n} 部有新章节` : "暂无更新");
    } catch (e) {
        toast("检查失败：" + e.message);
    }
});

$$("#theme-seg .seg-btn").forEach(b => b.addEventListener("click", () => {
    prefs.theme = b.dataset.theme;
    store.set("theme", prefs.theme);
    applyPrefs();
}));

$$("#accent-seg .seg-btn").forEach(b => b.addEventListener("click", () => {
    prefs.accent = b.dataset.accent;
    store.set("accent", prefs.accent);
    applyPrefs();
}));

$$("#rdmode-seg .seg-btn").forEach(b => b.addEventListener("click", () => {
    prefs.rdMode = b.dataset.rd;
    store.set("rdMode", prefs.rdMode);
    applyPrefs();
}));

$$("#rddir-seg .seg-btn").forEach(b => b.addEventListener("click", () => {
    prefs.rdDir = b.dataset.dir;
    store.set("rdDir", prefs.rdDir);
    applyPrefs();
}));

$$("#rdgap-seg .seg-btn").forEach(b => b.addEventListener("click", () => {
    prefs.gap = b.dataset.gap;
    store.set("gap", prefs.gap);
    applyPrefs();
    if (state.reader) {
        if (state.reader.mode === "webtoon") onWebtoonScroll();
    }
}));

$$("#scope-seg .seg-btn").forEach(b => b.addEventListener("click", () => {
    prefs.scope = b.dataset.scope;
    store.set("scope", prefs.scope);
    applyPrefs();
    toast(prefs.scope === "single" ? "搜索范围：仅当前源" : "搜索范围：聚合全源");
}));

$("#tap-turn").addEventListener("change", e => {
    prefs.tapTurn = e.target.checked;
    store.set("tapTurn", prefs.tapTurn);
});

async function refreshCacheUI() {
    try {
        const c = await api("/api/cache");
        const mb = n => (n / 1048576).toFixed(1);
        const rate = c.hits + c.misses > 0 ? Math.round(c.hits / (c.hits + c.misses) * 100) : 0;
        $("#cache-desc").textContent = `${mb(c.bytes)} MB / ${mb(c.budget)} MB · ${c.entries} 张 · 命中率 ${rate}%` + (c.pruned ? ` · 已清理旧章节 ${c.pruned} 张` : "");
    } catch (e) {
        $("#cache-desc").textContent = "读取失败";
    }
}

$("#cache-clear").addEventListener("click", async () => {
    try {
        await apiPost("/api/cache", {});
        toast("图片缓存已清空");
        refreshCacheUI();
    } catch (e) {
        toast("清理失败：" + e.message);
    }
});

async function refreshTeenUI() {
    try {
        const s = await api("/web/api/teen");
        state.teen = !!s.enabled;
        $("#teen-switch").checked = state.teen;
        $("#teen-desc").textContent = state.teen ? s.blocked > 0 ? `已开启 · 已拦截 ${s.blocked} 个成人源（服务端）` : "已开启 · 成人源已在服务端拦截" : "已关闭 · 成人源已显示";
    } catch (e) {}
}

function applyTeenState(res) {
    state.teen = !!res.enabled;
    refreshTeenUI();
    state.plat = "";
    state.page = 1;
    loadPlatforms();
}

$("#teen-switch").addEventListener("change", async e => {
    const on = e.target.checked;
    try {
        applyTeenState(await apiPost("/web/api/teen", {
            action: on ? "enable" : "disable"
        }));
        toast(on ? "青少年模式已开启" : "青少年模式已关闭");
    } catch (err) {
        e.target.checked = !on;
        toast(err.message);
    }
});

window.addEventListener("popstate", () => {
    if (ignorePop > 0) {
        ignorePop--;
        return;
    }
    if (!$("#sheet").classList.contains("hidden")) {
        closeSheet(true);
        return;
    }
    if (state.reader) {
        closeReader();
        return;
    }
    if (currentView === "detail") {
        switchView(state.detailFrom || "discover");
        state.detail = null;
        return;
    }
    if (currentView !== "discover") switchView("discover");
});

window.addEventListener("beforeunload", () => {
    if (state.reader) saveProgress();
});

(async function boot() {
    applyPrefs();
    state.mode = store.get("mode", "grid");
    state.chCols = store.get("chCols", 3);
    $$("#mode-seg .seg-btn").forEach(b => b.classList.toggle("active", b.dataset.mode === state.mode));
    refreshTeenUI();
    await loadPlatforms();
})();
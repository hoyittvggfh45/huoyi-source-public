

import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { fileURLToPath } from 'node:url';
import { Aggregator } from './src/agg.js';
import { DuanjuServer } from './src/duanju/index.js';
import { setFeedTTL, warmFeed, flushFeed } from './src/duanju/web.js';
import { setPath as setTeenPath } from './src/teenhub.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));


const args = process.argv.slice(2);
function argValue(names, fallback) {
  for (let i = 0; i < args.length; i++) {
    for (const n of names) {
      if (args[i] === n && i + 1 < args.length) return args[i + 1];
      if (args[i].startsWith(n + '=')) return args[i].slice(n.length + 1);
    }
  }
  return fallback;
}
const hasFlag = (...names) => args.some((a) => names.includes(a));

let port = parseInt(argValue(['-p', '--port', '-port'], '5689'), 10) || 5689;
let bind = argValue(['--bind', '-bind'], '127.0.0.1');
if (hasFlag('--lan', '-lan')) bind = '0.0.0.0';
const dataFlag = argValue(['--data', '-data'], '');
const mode = argValue(['--mode', '-mode'], '');
const noMusic = hasFlag('--nomusic', '-nomusic');


function resolveDataDir(flagValue) {
  const v = String(flagValue || '').trim();
  if (v) return path.resolve(v);
  return path.join(__dirname, 'jdd-data');
}
const dataDir = resolveDataDir(dataFlag);
fs.mkdirSync(dataDir, { recursive: true });
setTeenPath(path.join(dataDir, 'teen.txt'));


function listenFree(host, start, tries) {
  return new Promise((resolve, reject) => {
    const attempt = (i) => {
      if (i >= tries) return reject(new Error(`端口 ${start} 起 ${tries} 个都不可用`));
      const p = start + i;
      const server = net.createServer();
      server.once('error', () => attempt(i + 1));
      server.listen(p, host, () => {
        const addr = server.address();
        server.close(() => resolve({ port: addr.port }));
      });
    };
    attempt(0);
  });
}

function writePortFile(dir, realPort) {
  const p = path.join(dir, 'port.txt');
  try {
    fs.writeFileSync(p + '.tmp', String(realPort));
    fs.renameSync(p + '.tmp', p);
  } catch {}
}


const main = await listenFree(bind, port, 60);
const mainPort = main.port;
writePortFile(dataDir, mainPort);
console.log(`[jk] port=${mainPort}`);

const modes = [];


let duanjuSrv = null;
try {
  const { setDataDir: setDuanjuDataDir } = await import('./src/duanju/index.js');
  const { BrowserClient } = await import('./src/core/client.js');
  setDuanjuDataDir(path.join(dataDir, 'duanju'));
  duanjuSrv = new DuanjuServer(new BrowserClient());
  modes.push({ key: 'duanju', name: '短剧', desc: '多平台短剧聚合', app: duanjuSrv.app, ready: true });
  setFeedTTL(6 * 3600 * 1000);
  warmFeed().catch(() => {});
} catch (err) {
  console.error('短剧模块初始化失败:', err.message);
}


try {
  const { ManhuaServer } = await import('./src/manhua/index.js').catch(() => ({}));
  if (ManhuaServer) {
    const msrv = new ManhuaServer({ dataDir: path.join(dataDir, 'manhua') });
    modes.push({ key: 'manhua', name: '漫画', desc: '多源漫画阅读', app: msrv.app, ready: true });
  }
} catch (err) {
  console.error('漫画模块初始化失败:', err.message);
}
try {
  const { TingServer } = await import('./src/ting/index.js').catch(() => ({}));
  if (TingServer) {
    const tsrv = new TingServer({ dataDir: path.join(dataDir, 'ting') });
    modes.push({ key: 'ting', name: '听书', desc: '有声书与播客', app: tsrv.app, ready: true });
  }
} catch (err) {
  console.error('听书模块初始化失败:', err.message);
}
try {
  const { MusicServer } = await import('./src/music/index.js').catch(() => ({}));
  if (MusicServer && !noMusic) {
    const msvc = new MusicServer({ dataDir: path.join(dataDir, 'music') });
    modes.push({ key: 'music', name: '音乐', desc: '六源音乐播放', app: msvc.app, ready: !!msvc.ready });
  }
} catch (err) {
  console.error('音乐模块初始化失败:', err.message);
}
if (!modes.find((m) => m.key === 'music')) {
  modes.push({ key: 'music', name: '音乐', desc: '六源音乐播放', app: null, ready: false });
}

const agg = new Aggregator(modes, mode, path.join(dataDir, 'super'), { webDir: path.join(__dirname, 'web') });
const server = http.createServer(agg.Handler());
server.keepAliveTimeout = 65000;
server.requestTimeout = 0;

server.listen(mainPort, bind, () => {
  printBanner();
});

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

process.on('unhandledRejection', (err) => {
  console.error('[jk] 未处理的异步错误:', err && err.stack ? err.stack : err);
});
process.on('uncaughtException', (err) => {
  console.error('[jk] 未捕获异常:', err && err.stack ? err.stack : err);
});
function shutdown() {
  console.log('聚多多已停止');
  try { flushFeed(); } catch {}
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}

function printBanner() {
  console.log('聚多多聚合后台启动 (Node.js)');
  console.log(`  网页端: http://127.0.0.1:${mainPort}/`);
  console.log(`  数据目录: ${dataDir}`);
  console.log(`  当前模式: ${agg.active}`);
  console.log('  模式切换: 模式图标下拉（短剧 / 漫画 / 音乐 / 听书）');
  console.log('  规则入口: /api/duanju/* /api/manhua/* /api/ting/* /api/music/*');
  if (bind === '0.0.0.0') {
    for (const ip of lanAddresses()) {
      console.log(`  局域网可访问: http://${ip}:${mainPort}/`);
    }
  }
}

function lanAddresses() {
  const out = [];
  for (const ifaces of Object.values(os.networkInterfaces())) {
    for (const info of ifaces || []) {
      if (info.internal || info.family !== 'IPv4') continue;
      out.push(info.address);
    }
  }
  const score = (s) => (s.startsWith('192.168.') ? 0 : s.startsWith('10.') ? 1 : s.startsWith('172.') ? 2 : 3);
  return out.sort((a, b) => score(a) - score(b));
}

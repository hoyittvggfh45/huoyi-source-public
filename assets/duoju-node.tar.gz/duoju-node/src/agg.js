


import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { writeJSON } from './core/util.js';

export const Version = '1.0.0';

const modeRank = { duanju: 0, manhua: 1, music: 2, ting: 3 };

export class Aggregator {
  constructor(modes, active, dataDir, opts = {}) {
    this.modes = [...modes].sort((a, b) => (modeRank[a.key] ?? 99) - (modeRank[b.key] ?? 99));
    this.dataDir = dataDir;
    this.webDir = opts.webDir || path.join(process.cwd(), 'web');
    this.active = '';
    
    const saved = this.loadActive();
    const pref = (active && this.has(active) && this.ready(active)) ? active
      : (saved && this.has(saved) && this.ready(saved)) ? saved
        : (active || saved || this.firstReady());
    this.active = this.has(pref) && this.ready(pref) ? pref : this.firstReady();
  }

  has(key) { return this.modes.some((m) => m.key === key); }
  ready(key) { const m = this.modes.find((x) => x.key === key); return !!m && !!m.ready; }
  base(key) { const m = this.modes.find((x) => x.key === key); return m ? m.base : ''; }
  name(key) { const m = this.modes.find((x) => x.key === key); return m ? m.name : key; }
  firstReady() {
    for (const m of this.modes) if (m.ready) return m.key;
    return this.modes[0] ? this.modes[0].key : '';
  }

  activePath() { return this.dataDir ? path.join(this.dataDir, 'super', 'active.txt') : ''; }

  loadActive() {
    const p = this.activePath();
    if (!p) return '';
    try { return fs.readFileSync(p, 'utf8').trim(); } catch { return ''; }
  }

  saveActive(key) {
    const p = this.activePath();
    if (!p) return;
    try {
      fs.mkdirSync(path.dirname(p), { recursive: true });
      const tmp = p + '.tmp';
      fs.writeFileSync(tmp, key);
      fs.renameSync(tmp, p);
    } catch {}
  }

  setReady(key, ready) {
    const m = this.modes.find((x) => x.key === key);
    if (m) m.ready = ready;
    if (!ready && this.active === key) {
      this.active = this.firstReady();
      if (this.active) this.saveActive(this.active);
    }
  }

  setActive(key) {
    if (!this.has(key) || !this.ready(key)) return false;
    this.active = key;
    this.saveActive(key);
    return true;
  }

  modesJSON() {
    return this.modes.map((m) => ({ k: m.key, n: m.name, d: m.desc, ok: !!m.ready }));
  }

  insideFrame(req) {
    const referer = String(req.headers.referer || '');
    if (referer.includes('/__jdd/frame/')) return true;
    return String(req.headers['sec-fetch-dest'] || '').toLowerCase() === 'iframe';
  }

  
  dispatch(req, res, next, moduleApp, { from = '', to = '', ext = '' } = {}) {
    if (!req.headers['x-jdd-external']) {
      req.headers['x-jdd-external'] = `http://${req.headers.host || '127.0.0.1'}${ext}`;
    }
    const origURL = req.url;
    if (from && req.url.startsWith(from)) {
      req.url = to + req.url.slice(from.length);
      if (req.url === '') req.url = '/';
    }
    moduleApp(req, res, () => {
      req.url = origURL;
      next();
    });
  }

  Handler() {
    const app = express();
    app.disable('x-powered-by');

    
    app.get('/__jdd/hello', (req, res) => {
      writeJSON(res, { app: 'duoju-super', name: '聚多多', version: Version, active: this.active, pid: process.pid, ok: true });
    });
    app.get('/__jdd/state', (req, res) => {
      writeJSON(res, { code: 200, active: this.active, activeName: this.name(this.active), modes: this.modesJSON() });
    });
    app.all('/__jdd/switch', (req, res) => {
      const q = req.query;
      const key = String(q.m || q.mode || '').trim();
      const ok = this.setActive(key);
      const wantsJSON = q.json !== undefined || String(req.headers.accept || '').toLowerCase().includes('application/json');
      if (wantsJSON) {
        const payload = { code: ok ? 200 : 400, active: this.active, activeName: this.name(this.active), modes: this.modesJSON() };
        if (!ok) { payload.msg = '模式不可用: ' + key; return writeJSON(res, payload, 400); }
        return writeJSON(res, payload);
      }
      if (!ok) {
        return writeJSON(res, { code: 400, msg: '模式不可用: ' + key, active: this.active, modes: this.modesJSON() }, 400);
      }
      let target = '/';
      const next = String(q.r || '').trim();
      if (next.startsWith('/')) target = next;
      res.redirect(302, target);
    });
    app.get('/__jdd/bridge.js', (req, res) => {
      res.setHeader('Content-Type', 'text/javascript; charset=utf-8');
      res.sendFile(path.join(this.webDir, 'bridge.js'), (err) => { if (err && !res.headersSent) res.status(404).end(); });
    });
    const serveShell = (req, res) => {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Cache-Control', 'no-store');
      res.setHeader('X-Frame-Options', 'SAMEORIGIN');
      res.sendFile(path.join(this.webDir, 'shell.html'), (err) => {
        if (err && !res.headersSent) { res.status(500); res.send('shell not found'); }
      });
    };
    app.get('/__jdd/shell', serveShell);
    app.get('/__jdd/frame', (req, res) => this.handleFrame(req, res));
    app.get('/__jdd/frame/*', (req, res) => this.handleFrame(req, res));
    app.all('/__jdd/*', (req, res) => res.status(404).end('404 page not found'));

    
    const modeOf = (key) => this.modes.find((m) => m.key === key);
    const usable = (m) => m && m.app && m.ready;
    const frameBase = '/__jdd/frame';

    app.all('*', (req, res, next) => {
      const p = req.path;
      
      for (const m of this.modes) {
        if (m.key === 'music' || !usable(m)) continue;
        const from1 = `/api/${m.key}/api`;
        if (p === from1 || p.startsWith(from1 + '/')) {
          return this.dispatch(req, res, next, m.app, { from: from1, to: '/api', ext: `/m/${m.key}` });
        }
      }
      
      for (const m of this.modes) {
        if (m.key === 'music' || !usable(m)) continue;
        const from2 = `/api/${m.key}`;
        if (p === from2 || p.startsWith(from2 + '/')) {
          return this.dispatch(req, res, next, m.app, { from: from2, to: '', ext: `/m/${m.key}` });
        }
      }
      
      for (const m of this.modes) {
        if (m.key === 'music' || !usable(m)) continue;
        const pre = `/m/${m.key}/media`;
        if (p === pre || p.startsWith(pre + '/')) {
          return this.dispatch(req, res, next, m.app, { from: `/m/${m.key}`, to: '', ext: `/m/${m.key}` });
        }
      }
      
      
      const ting = modeOf('ting');
      if (usable(ting) && (p === '/media/audio' || p.startsWith('/media/audio/') || p === '/media/img' || p.startsWith('/media/img/'))) {
        return this.dispatch(req, res, next, ting.app, {});
      }
      
      const music = modeOf('music');
      if (usable(music)) {
        const musicPaths = ['/api/music', '/api/source', '/api/config', '/api/logs', '/api/shutdown', '/Script.html', '/api-debug.html', '/music'];
        if (musicPaths.some((pre) => p === pre || p.startsWith(pre + '/'))) {
          return this.dispatch(req, res, next, music.app, {});
        }
      }
      
      if ((p === '/' || p === '/index.html') && !this.insideFrame(req)) {
        return serveShell(req, res);
      }
      const active = modeOf(this.active);
      if (usable(active)) {
        return this.dispatch(req, res, next, active.app, {});
      }
      writeJSON(res, { code: 503, msg: '聚多多无可用的模式模块' }, 503);
    });

    
    return app;
  }

  handleFrame(req, res) {
    const rest = req.path.replace(/^\/__jdd\/frame\/?/, '');
    let key = rest ? rest.split('/')[0] : '';
    let scoped = false;
    if (key && this.has(key) && this.ready(key)) {
      scoped = true;
      this.setActive(key);
    } else {
      key = this.active;
    }
    const m = this.modes.find((x) => x.key === key);
    if (!m || !m.app || !m.ready) {
      return res.status(503).send('聚多多无可用的模式模块');
    }
    
    if (req.path === '/' && !String(req.headers.accept || '').includes('text/html')) {
      req.headers.accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
    }
    const from = scoped ? `/__jdd/frame/${key}` : '/__jdd/frame';
    
    const sub = express();
    sub.use((req2, res2, n2) => this.dispatch(req2, res2, n2, m.app, { from, to: '', ext: from }));
    sub(req, res, () => res.status(404).end());
  }
}

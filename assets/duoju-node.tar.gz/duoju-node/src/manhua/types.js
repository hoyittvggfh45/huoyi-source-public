

export function Card(f = {}) {
  const out = {
    vod_id: f.id ?? '',
    vod_name: f.name ?? '',
    vod_pic: f.pic ?? '',
    vod_remarks: f.remarks ?? '',
    vod_class: f.cat ?? '',
  };
  if (f.author) out.vod_director = f.author;
  if (f.desc) out.vod_content = f.desc;
  if (f.plat) out.vod_plat = f.plat;
  return out;
}

export function Cat(id, name) {
  return { id: id ?? '', name: name ?? '' };
}

export function Chapter(no, name, url) {
  return { no: no ?? 0, name: name ?? '', url: url ?? '' };
}


export function BookDetail(f = {}) {
  const out = {
    vod_id: f.id ?? '',
    vod_name: f.name ?? '',
    vod_pic: f.pic ?? '',
    vod_content: f.desc ?? '',
    vod_class: f.tag ?? '',
    vod_remarks: f.remarks ?? '',
    vod_director: f.author ?? '',
    chapters: (f.chapters || []).map((c) => Chapter(c.no, c.name, c.url)),
    chapter_count: f.count ?? f.chapters?.length ?? 0,
  };
  if (f.adult) out.adult = true;
  return out;
}


export function ComicPlay(f = {}) {
  const out = { pics: f.pics || [] };
  if (f.referer) out.referer = f.referer;
  if (f.ua) out.ua = f.ua;
  if (f.direct) out.direct = true;
  if (f.decrypt) out.decrypt = f.decrypt;
  if (f.local) out.local = f.local;
  return out;
}


export function Platform(f = {}) {
  const out = {
    key: f.key ?? '',
    name: f.name ?? '',
  };
  if (f.desc) out.desc = f.desc;
  if (f.adult) out.adult = true;
  out.listPaged = !!f.listPaged;
  out.searchPaged = !!f.searchPaged;
  return out;
}

export default { Card, Cat, Chapter, BookDetail, ComicPlay, Platform };

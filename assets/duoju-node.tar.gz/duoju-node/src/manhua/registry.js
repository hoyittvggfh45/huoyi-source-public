
import { encodeQuery } from './core/http.js';

const providerRegistry = new Map(); 
const providerOrder = [];

export function registerProvider(p) {
  const k = p.key();
  if (providerRegistry.has(k)) return;
  providerRegistry.set(k, p);
  providerOrder.push(k);
}

export function provider(key) {
  return providerRegistry.get(String(key || '').toLowerCase().trim()) || null;
}

export function providers() {
  const out = [];
  for (const k of providerOrder) {
    const p = providerRegistry.get(k);
    if (p) out.push(p);
  }
  return out;
}


export function platformList() {
  const all = providers();
  const out = [];
  for (const p of all) {
    let listPaged = true;
    let searchPaged = true;
    if (typeof p.listPaged === 'function') listPaged = !!p.listPaged();
    if (typeof p.searchPaged === 'function') searchPaged = !!p.searchPaged();
    out.push({
      key: p.key(),
      name: p.name(),
      desc: p.desc() || '',
      adult: !!p.adult(),
      listPaged,
      searchPaged,
    });
  }
  return out;
}

export function catOrDefault(p, cat) {
  const c = String(cat || '').trim();
  if (c !== '' && c !== 'undefined') return c;
  const cats = p.cats ? p.cats() : [];
  if (cats.length > 0) return cats[0].id;
  return '';
}



export function proxyPicsURL(mediaBase, ap, ref, scope) {
  const out = [];
  for (const pic of ap.pics || []) {
    const q = { u: pic };
    if (ap.referer) q.ref = ap.referer;
    if (ap.ua) q.ua = ap.ua;
    if (scope) q.s = scope;
    if (ap.decrypt) q.d = ap.decrypt;
    if (ap.direct) q.np = '1';
    out.push(`${mediaBase}/media/img?${encodeQuery(q)}`);
  }
  return out;
}

export default {
  registerProvider,
  provider,
  providers,
  platformList,
  catOrDefault,
  proxyPicsURL,
};

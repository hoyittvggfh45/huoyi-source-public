
import path from 'node:path';
import fs from 'node:fs';

export const AppVersion = '2.2.2';

let dataDir = '';

export function setDataDir(dir) {
  dataDir = dir;
  if (dataDir) {
    try {
      fs.mkdirSync(dataDir, { recursive: true });
    } catch {
      
    }
  }
}

export function getDataDir() {
  return dataDir;
}


export function filepath(name) {
  if (!dataDir) return name;
  return path.join(dataDir, name);
}


export function readDataFile(name) {
  if (!dataDir) return '';
  try {
    return fs.readFileSync(filepath(name), 'utf8');
  } catch {
    return '';
  }
}


export function writeDataFile(name, content) {
  if (!dataDir) return false;
  const full = filepath(name);
  try {
    fs.mkdirSync(path.dirname(full), { recursive: true });
    const tmp = full + '.tmp';
    fs.writeFileSync(tmp, content, 'utf8');
    fs.renameSync(tmp, full);
    return true;
  } catch {
    return false;
  }
}









import zlib from 'node:zlib';
import crypto from 'node:crypto';
import { md5hex } from './http.js';




export function jmScrambleRows(pid, fn) {
  if (pid < 220980) return 0;
  if (pid < 268850) return 10;
  let x = 10;
  if (pid >= 421926) x = 8;
  const hx = md5hex(String(pid) + fn);
  return (hx.charCodeAt(hx.length - 1) % x) * 2 + 2;
}




export function detectContentType(buf) {
  const b = buf;
  if (!b || b.length < 8) return 'application/octet-stream';
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg';
  if (
    b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 &&
    b[4] === 0x0d && b[5] === 0x0a && b[6] === 0x1a && b[7] === 0x0a
  ) return 'image/png';
  if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) return 'image/gif';
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
      b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return 'image/webp';
  if (b[0] === 0x42 && b[1] === 0x4d) return 'image/bmp';
  if (b[0] === 0x00 && b[1] === 0x00 && b[2] === 0x01 && b[3] === 0x00) return 'image/x-icon';
  return 'application/octet-stream';
}




const PNG_SIG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

function paeth(a, b, c) {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  if (pa <= pb && pa <= pc) return a;
  if (pb <= pc) return b;
  return c;
}


export function decodePNG(buf) {
  if (buf.length < 8 || !buf.subarray(0, 8).equals(PNG_SIG)) throw new Error('not png');
  let off = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 8;
  let colorType = 6;
  let interlace = 0;
  let palette = null;
  let trns = null;
  const idat = [];
  while (off + 8 <= buf.length) {
    const len = buf.readUInt32BE(off);
    const type = buf.toString('ascii', off + 4, off + 8);
    const data = buf.subarray(off + 8, off + 8 + len);
    off += 12 + len;
    if (type === 'IHDR') {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
      const compression = data[10];
      const filter = data[11];
      interlace = data[12];
      if (compression !== 0 || filter !== 0) throw new Error('bad png');
    } else if (type === 'PLTE') {
      palette = Buffer.from(data);
    } else if (type === 'tRNS') {
      trns = Buffer.from(data);
    } else if (type === 'IDAT') {
      idat.push(data);
    } else if (type === 'IEND') {
      break;
    }
  }
  if (!width || !height) throw new Error('png missing IHDR');
  const channels = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[colorType];
  if (!channels) throw new Error(`bad png colorType ${colorType}`);
  const supportedDepth = { 0: [1, 2, 4, 8, 16], 2: [8, 16], 3: [1, 2, 4, 8], 4: [8, 16], 6: [8, 16] }[colorType];
  if (!supportedDepth.includes(bitDepth)) throw new Error(`unsupported png bitDepth ${bitDepth} colorType ${colorType}`);
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const out = Buffer.alloc(width * height * 4);

  const unpackRow = null; 
  void unpackRow;

  const processScanline = (line, prevLine, passWidth, bpp) => {
    const ftype = line[0];
    const d = line.subarray(1);
    for (let i = 0; i < d.length; i++) {
      const a = i >= bpp ? d[i - bpp] : 0;
      const b = prevLine ? prevLine[i] : 0;
      const c = prevLine && i >= bpp ? prevLine[i - bpp] : 0;
      switch (ftype) {
        case 0: break;
        case 1: d[i] = (d[i] + a) & 0xff; break;
        case 2: d[i] = (d[i] + b) & 0xff; break;
        case 3: d[i] = (d[i] + ((a + b) >> 1)) & 0xff; break;
        case 4: d[i] = (d[i] + paeth(a, b, c)) & 0xff; break;
        default: throw new Error(`bad png filter ${ftype}`);
      }
    }
    return d;
  };

  const pxToRGBA = (px, dstIdx) => {
    
    if (colorType === 6) {
      out[dstIdx] = px[0]; out[dstIdx + 1] = px[1]; out[dstIdx + 2] = px[2]; out[dstIdx + 3] = px[3];
    } else if (colorType === 2) {
      out[dstIdx] = px[0]; out[dstIdx + 1] = px[1]; out[dstIdx + 2] = px[2]; out[dstIdx + 3] = 255;
    } else if (colorType === 4) {
      out[dstIdx] = px[0]; out[dstIdx + 1] = px[0]; out[dstIdx + 2] = px[0]; out[dstIdx + 3] = px[1];
    } else if (colorType === 0) {
      out[dstIdx] = px[0]; out[dstIdx + 1] = px[0]; out[dstIdx + 2] = px[0]; out[dstIdx + 3] = 255;
    } else if (colorType === 3) {
      const idx = px[0];
      if (palette && idx * 3 + 2 < palette.length) {
        out[dstIdx] = palette[idx * 3];
        out[dstIdx + 1] = palette[idx * 3 + 1];
        out[dstIdx + 2] = palette[idx * 3 + 2];
      }
      out[dstIdx + 3] = trns && idx < trns.length ? trns[idx] : 255;
    }
  };

  const scaleSample = (v) => {
    if (bitDepth === 16) return v >>> 8; 
    if (bitDepth === 8) return v;
    const max = (1 << bitDepth) - 1;
    return Math.round((v * 255) / max);
  };

  const emitPixel = (lineData, pxIndex, dstX, dstY) => {
    const dstIdx = (dstY * width + dstX) * 4;
    if (colorType === 3) {
      
      const bitPos = pxIndex * bitDepth;
      const byte = lineData[bitPos >> 3];
      const shift = 8 - bitDepth - (bitPos & 7);
      const v = (byte >> shift) & ((1 << bitDepth) - 1);
      pxToRGBA([v], dstIdx);
    } else if (bitDepth === 16) {
      const base = pxIndex * channels * 2;
      const px = [];
      for (let c = 0; c < channels; c++) px.push(lineData[base + c * 2]);
      pxToRGBA(px, dstIdx);
    } else {
      const base = pxIndex * channels;
      const px = [];
      for (let c = 0; c < channels; c++) px.push(scaleSample(lineData[base + c]));
      pxToRGBA(px, dstIdx);
    }
  };

  const decodePass = (dataOff, passW, passH, x0, y0, dx, dy) => {
    if (passW <= 0 || passH <= 0) return dataOff;
    const bitsPerPx = channels * bitDepth;
    const rowStride = 1 + Math.ceil((passW * bitsPerPx) / 8);
    let prev = null;
    let off = dataOff;
    for (let py = 0; py < passH; py++) {
      if (off + rowStride > raw.length) throw new Error('png truncated');
      const line = Buffer.from(raw.subarray(off, off + rowStride));
      off += rowStride;
      const d = processScanline(line, prev, passW, Math.max(1, Math.floor((channels * bitDepth + 7) / 8)));
      prev = d;
      for (let px = 0; px < passW; px++) {
        emitPixel(d, px, x0 + px * dx, y0 + py * dy);
      }
    }
    return off;
  };

  if (interlace === 0) {
    decodePass(0, width, height, 0, 0, 1, 1);
  } else if (interlace === 1) {
    const passes = [
      [0, 0, 8, 8], [4, 0, 8, 8], [0, 4, 8, 8], [2, 0, 4, 4], [0, 2, 4, 4], [1, 0, 2, 2], [0, 1, 2, 2],
    ];
    let off = 0;
    for (const [x0, y0, dx, dy] of passes) {
      const passW = Math.ceil((width - x0) / dx);
      const passH = Math.ceil((height - y0) / dy);
      off = decodePass(off, passW, passH, x0, y0, dx, dy);
    }
  } else {
    throw new Error(`bad png interlace ${interlace}`);
  }
  return { width, height, rgba: out };
}




const crcTable = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

export function encodePNG(rgba, width, height) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; 
  ihdr[9] = 6; 
  ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const stride = width * 4;
  const rawRows = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y++) {
    rawRows[y * (stride + 1)] = 0; 
    rgba.copy(rawRows, y * (stride + 1) + 1, y * stride, (y + 1) * stride);
  }
  const idat = zlib.deflateSync(rawRows, { level: 6 });
  return Buffer.concat([
    PNG_SIG,
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', idat),
    pngChunk('IEND', Buffer.alloc(0)),
  ]);
}




class BitReader {
  constructor(data, pos) {
    this.data = data;
    this.pos = pos;
    this.bitBuf = 0;
    this.bitCnt = 0;
  }
  readBit() {
    if (this.bitCnt === 0) {
      let b = this.data[this.pos++];
      if (b === 0xff) {
        const n = this.data[this.pos];
        if (n === 0x00) this.pos++;
        else if (n >= 0xd0 && n <= 0xd7) {
          
          this.pos++;
          b = this.data[this.pos++];
        } else {
          throw new Error('jpeg: unexpected marker in entropy data');
        }
      }
      this.bitBuf = b;
      this.bitCnt = 8;
    }
    this.bitCnt--;
    return (this.bitBuf >> this.bitCnt) & 1;
  }
  align() { this.bitCnt = 0; }
}

class HuffTable {
  constructor(bits, vals) {
    this.maxcode = new Int32Array(17);
    this.mincode = new Int32Array(17);
    this.valptr = new Int32Array(17);
    this.values = vals;
    let code = 0;
    let k = 0;
    for (let l = 1; l <= 16; l++) {
      this.valptr[l] = k;
      this.mincode[l] = code;
      code += bits[l - 1];
      k += bits[l - 1];
      this.maxcode[l] = code - 1;
      code <<= 1;
    }
  }
  decode(br) {
    let code = br.readBit();
    let l = 1;
    while (l <= 16 && code > this.maxcode[l]) {
      code = (code << 1) | br.readBit();
      l++;
    }
    if (l > 16) throw new Error('jpeg: bad huffman code');
    return this.values[this.valptr[l] + code - this.mincode[l]];
  }
}

function extend(v, t) {
  return v < 1 << (t - 1) ? v - (1 << t) + 1 : v;
}

export function decodeJPEG(buf) {
  if (buf.length < 4 || buf[0] !== 0xff || buf[1] !== 0xd8) throw new Error('not jpeg');
  let pos = 2;
  let width = 0;
  let height = 0;
  let progressive = false;
  let ri = 0; 
  const quant = {}; 
  const huffDC = {};
  const huffAC = {};
  let frame = null; 
  let scan = null;
  while (pos + 4 <= buf.length) {
    if (buf[pos] !== 0xff) { pos++; continue; }
    let marker = buf[pos + 1];
    while (marker === 0xff && pos + 2 < buf.length) { pos++; marker = buf[pos + 1]; }
    pos += 2;
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
    if (marker === 0xd9) break; 
    const segLen = (buf[pos] << 8) | buf[pos + 1];
    if (marker === 0xdb) { 
      let p = pos + 2;
      const end = pos + 2 + segLen - 2;
      while (p < end) {
        const pq = buf[p] >> 4;
        const tq = buf[p] & 0x0f;
        p++;
        const t = new Int32Array(64);
        for (let i = 0; i < 64; i++) {
          if (pq) { t[i] = (buf[p] << 8) | buf[p + 1]; p += 2; }
          else { t[i] = buf[p++]; }
        }
        quant[tq] = t;
      }
      pos += segLen;
    } else if (marker === 0xc0 || marker === 0xc1) { 
      height = (buf[pos + 5] << 8) | buf[pos + 6];
      width = (buf[pos + 7] << 8) | buf[pos + 8];
      const nc = buf[pos + 9];
      const comps = [];
      let p = pos + 10;
      for (let i = 0; i < nc; i++) {
        comps.push({ id: buf[p], h: buf[p + 1] >> 4, v: buf[p + 1] & 0x0f, tq: buf[p + 2], td: 0, ta: 0 });
        p += 3;
      }
      frame = { comps, width, height };
      pos += segLen;
    } else if (marker === 0xc2) {
      progressive = true;
      throw new Error('jpeg: progressive not supported');
    } else if (marker === 0xc4) { 
      let p = pos + 2;
      const end = pos + 2 + segLen - 2;
      while (p < end) {
        const tc = buf[p] >> 4;
        const th = buf[p] & 0x0f;
        p++;
        const bits = new Array(16);
        let total = 0;
        for (let i = 0; i < 16; i++) { bits[i] = buf[p++]; total += bits[i]; }
        const vals = new Uint8Array(total);
        for (let i = 0; i < total; i++) vals[i] = buf[p++];
        if (tc === 0) huffDC[th] = new HuffTable(bits, vals);
        else huffAC[th] = new HuffTable(bits, vals);
      }
      pos += segLen;
    } else if (marker === 0xdd) { 
      ri = (buf[pos + 4] << 8) | buf[pos + 5];
      pos += segLen;
    } else if (marker === 0xda) { 
      const ns = buf[pos + 2];
      const comps = [];
      let p = pos + 3;
      for (let i = 0; i < ns; i++) {
        const cs = buf[p];
        const td = buf[p + 1] >> 4;
        const ta = buf[p + 1] & 0x0f;
        const comp = frame.comps.find((c) => c.id === cs);
        if (comp) { comp.td = td; comp.ta = ta; comps.push(comp); }
        p += 2;
      }
      const ss = buf[p]; const se = buf[p + 1]; const ahl = buf[p + 2];
      scan = { comps, ss, se, ah: ahl >> 4, al: ahl & 0x0f, ri };
      pos += segLen;
      break;
    } else {
      pos += segLen;
    }
  }
  if (!frame || !scan) throw new Error('jpeg: missing SOF/SOS');
  if (progressive) throw new Error('jpeg: progressive not supported');

  const hMax = Math.max(...frame.comps.map((c) => c.h));
  const vMax = Math.max(...frame.comps.map((c) => c.v));
  const mcuW = hMax * 8;
  const mcuH = vMax * 8;
  const mcusX = Math.ceil(width / mcuW);
  const mcusY = Math.ceil(height / mcuH);
  const planes = new Map();
  for (const c of frame.comps) {
    planes.set(c.id, {
      data: new Float32Array(Math.ceil((width * c.h) / hMax / 8) * 8 * Math.ceil((height * c.v) / vMax / 8) * 8),
      stride: Math.ceil((width * c.h) / hMax / 8) * 8,
      rows: Math.ceil((height * c.v) / vMax / 8) * 8,
      q: quant[c.tq],
    });
  }

  const ZIGZAG = null;
  void ZIGZAG;

  
  const ZZ = new Int32Array([
    0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5,
    12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28,
    35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51,
    58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63,
  ]);
  void ZIGZAG;

  const idct8 = (block, out, outOff, outStride) => {
    const tmp = new Float32Array(64);
    for (let i = 0; i < 8; i++) {
      for (let j = 0; j < 8; j++) {
        let s = 0;
        for (let k = 0; k < 8; k++) {
          s += block[i * 8 + k] * COS_TABLE[j * 8 + k];
        }
        tmp[i * 8 + j] = s;
      }
    }
    for (let j = 0; j < 8; j++) {
      for (let i = 0; i < 8; i++) {
        let s = 0;
        for (let k = 0; k < 8; k++) {
          s += tmp[k * 8 + j] * COS_TABLE[i * 8 + k];
        }
        out[outOff + i * outStride + j] = s / 4;
      }
    }
  };

  const COS_TABLE = new Float32Array(64);
  for (let x = 0; x < 8; x++) {
    for (let u = 0; u < 8; u++) {
      COS_TABLE[x * 8 + u] = (u === 0 ? Math.SQRT1_2 : 1) * Math.cos(((2 * x + 1) * u * Math.PI) / 16) / 2;
    }
  }

  let br = new BitReader(buf, pos);
  const dcPred = new Map();
  let rstNo = 0;
  let mcusSinceRst = 0;
  const RESTART_INTERVAL = scan.ri || 0;

  const decodeBlock = (comp, plane, bx, by) => {
    const block = new Float32Array(64);
    const td = huffDC[comp.td];
    const ta = huffAC[comp.ta];
    if (!td || !ta) throw new Error('jpeg: missing huffman table');
    const t = td.decode(br);
    let diff = 0;
    if (t) diff = extend(readBits(br, t), t);
    const predKey = comp.id;
    const pred = (dcPred.get(predKey) || 0) + diff;
    dcPred.set(predKey, pred);
    block[0] = pred * plane.q[0];
    let k = 1;
    while (k < 64) {
      const rs = ta.decode(br);
      const r = rs >> 4;
      const s = rs & 0x0f;
      if (s === 0) {
        if (r !== 15) break;
        k += 16;
      } else {
        k += r;
        if (k > 63) break;
        const v = extend(readBits(br, s), s) * plane.q[k];
        block[ZZ[k]] = v;
        k++;
      }
    }
    
    const outOff = by * plane.stride + bx;
    idct8(block, plane.data, outOff, plane.stride);
  };

  function readBits(br_, n) {
    let v = 0;
    for (let i = 0; i < n; i++) v = (v << 1) | br_.readBit();
    return v;
  }

  for (let my = 0; my < mcusY; my++) {
    for (let mx = 0; mx < mcusX; mx++) {
      if (RESTART_INTERVAL && mcusSinceRst === RESTART_INTERVAL) {
        br.align();
        
        let p = br.pos;
        while (p + 1 < buf.length) {
          if (buf[p] === 0xff && buf[p + 1] === 0xff) { p++; continue; }
          if (buf[p] === 0xff && buf[p + 1] >= 0xd0 && buf[p + 1] <= 0xd7) { p += 2; break; }
          if (buf[p] === 0xff && buf[p + 1] !== 0x00) break;
          p++;
        }
        br = new BitReader(buf, p);
        for (const k of dcPred.keys()) dcPred.set(k, 0);
        mcusSinceRst = 0;
        rstNo = (rstNo + 1) & 7;
      }
      for (const comp of scan.comps) {
        const plane = planes.get(comp.id);
        const bw = Math.ceil((mcuW * comp.h) / hMax / 8);
        const bh = Math.ceil((mcuH * comp.v) / vMax / 8);
        for (let by = 0; by < bh; by++) {
          for (let bx = 0; bx < bw; bx++) {
            decodeBlock(comp, plane, (mx * bw + bx) * 8, (my * bh + by) * 8);
          }
        }
      }
      mcusSinceRst++;
    }
  }

  
  const out = Buffer.alloc(width * height * 4);
  const yPlane = frame.comps.length === 1 ? planes.get(frame.comps[0].id) : planes.get(frame.comps[0].id);
  const cbPlane = planes.get(frame.comps[1]?.id);
  const crPlane = planes.get(frame.comps[2]?.id);
  const yH = frame.comps[0].h / hMax;
  const yV = frame.comps[0].v / vMax;
  const cbH = cbPlane ? frame.comps[1].h / hMax : 1;
  const cbV = cbPlane ? frame.comps[1].v / vMax : 1;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const yi = Math.min(yPlane.rows - 1, Math.floor(y * yV)) * yPlane.stride + Math.min(yPlane.stride - 1, Math.floor(x * yH));
      const Y = yPlane.data[yi] + 128;
      let R; let G; let B;
      if (cbPlane && crPlane) {
        const ci = Math.min(cbPlane.rows - 1, Math.floor(y * cbV)) * cbPlane.stride + Math.min(cbPlane.stride - 1, Math.floor(x * cbH));
        const Cb = cbPlane.data[ci];
        const Cr = crPlane.data[ci];
        R = Y + 1.402 * Cr;
        G = Y - 0.344136 * Cb - 0.714136 * Cr;
        B = Y + 1.772 * Cb;
      } else {
        R = G = B = Y;
      }
      const o = (y * width + x) * 4;
      out[o] = clamp255(Math.round(R));
      out[o + 1] = clamp255(Math.round(G));
      out[o + 2] = clamp255(Math.round(B));
      out[o + 3] = 255;
    }
  }
  return { width, height, rgba: out };
}

function clamp255(v) {
  return v < 0 ? 0 : v > 255 ? 255 : v;
}


export function decodeImage(data) {
  const ct = detectContentType(data);
  if (ct === 'image/png') return decodePNG(data);
  if (ct === 'image/jpeg') return decodeJPEG(data);
  throw new Error(`unsupported image type: ${ct}`);
}




export function descrambleJM(data, target) {
  let u;
  try {
    u = new URL(target);
  } catch {
    return data;
  }
  const segs = u.pathname.split('/');
  let pidStr = '';
  let fn = '';
  for (let i = 0; i < segs.length; i++) {
    if (segs[i] === 'photos' && i + 2 < segs.length) {
      pidStr = segs[i + 1];
      fn = segs[i + 2];
      break;
    }
  }
  if (!pidStr || !fn) return data;
  let ext = '';
  const dot = fn.lastIndexOf('.');
  if (dot >= 0) {
    ext = fn.slice(dot + 1).toLowerCase();
    fn = fn.slice(0, dot);
  }
  const pid = parseInt(pidStr, 10);
  if (!Number.isFinite(pid) || ext === 'gif') return data;
  const n = jmScrambleRows(pid, fn);
  if (n <= 0) return data;
  let img;
  try {
    img = decodeImage(data);
  } catch {
    return data;
  }
  const w = img.width;
  const h = img.height;
  if (w < 4 || h < 4 || h < n * 4) return data;
  const over = h % n;
  const move = Math.floor(h / n);
  const src = img.rgba;
  const dst = Buffer.alloc(w * h * 4);
  for (let ii = 0; ii < n; ii++) {
    let m2 = move;
    let ys = h - move * (ii + 1) - over;
    let yd = move * ii;
    if (ii === 0) {
      m2 += over;
    } else {
      yd += over;
    }
    if (ys < 0) ys = 0;
    if (ys + m2 > h) m2 = h - ys;
    if (yd < 0) yd = 0;
    if (yd + m2 > h) m2 = h - yd;
    if (m2 <= 0) continue;
    for (let row = 0; row < m2; row++) {
      src.copy(
        dst,
        (yd + row) * w * 4,
        (ys + row) * w * 4,
        (ys + row + 1) * w * 4,
      );
    }
  }
  try {
    if (ext === 'png') {
      return encodePNG(dst, w, h);
    }
    return encodeJPEG(dst, w, h, 90);
  } catch {
    return data;
  }
}

export default {
  jmScrambleRows,
  descrambleJM,
  detectContentType,
  decodeImage,
  decodePNG,
  encodePNG,
  decodeJPEG,
  encodeJPEG,
};




const STD_Q_LUMA = [
  16, 11, 10, 16, 24, 40, 51, 61,
  12, 12, 14, 19, 26, 58, 60, 55,
  14, 13, 16, 24, 40, 57, 69, 56,
  14, 17, 22, 29, 51, 87, 80, 62,
  18, 22, 37, 56, 68, 109, 103, 77,
  24, 35, 55, 64, 81, 104, 113, 92,
  49, 64, 78, 87, 103, 121, 120, 101,
  72, 92, 95, 98, 112, 100, 103, 99,
];
const STD_Q_CHROMA = [
  17, 18, 24, 47, 99, 99, 99, 99,
  18, 21, 26, 66, 99, 99, 99, 99,
  24, 26, 56, 99, 99, 99, 99, 99,
  47, 66, 99, 99, 99, 99, 99, 99,
  99, 99, 99, 99, 99, 99, 99, 99,
  99, 99, 99, 99, 99, 99, 99, 99,
  99, 99, 99, 99, 99, 99, 99, 99,
  99, 99, 99, 99, 99, 99, 99, 99,
];
const DC_LUMA_BITS = [0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0];
const DC_LUMA_VALS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
const DC_CHROMA_BITS = [0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0];
const DC_CHROMA_VALS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
const AC_LUMA_BITS = [0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 0x7d];
const AC_LUMA_VALS = [
  0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06, 0x13, 0x51, 0x61, 0x07,
  0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xa1, 0x08, 0x23, 0x42, 0xb1, 0xc1, 0x15, 0x52, 0xd1, 0xf0,
  0x24, 0x33, 0x62, 0x72, 0x82, 0x09, 0x0a, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x25, 0x26, 0x27, 0x28,
  0x29, 0x2a, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49,
  0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69,
  0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
  0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7,
  0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5,
  0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xe1, 0xe2,
  0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8,
  0xf9, 0xfa,
];
const AC_CHROMA_BITS = [0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 0x77];
const AC_CHROMA_VALS = [
  0x00, 0x01, 0x02, 0x03, 0x11, 0x04, 0x05, 0x21, 0x31, 0x06, 0x12, 0x41, 0x51, 0x07, 0x61, 0x71,
  0x13, 0x22, 0x32, 0x81, 0x08, 0x14, 0x42, 0x91, 0xa1, 0xb1, 0xc1, 0x09, 0x23, 0x33, 0x52, 0xf0,
  0x15, 0x62, 0x72, 0xd1, 0x0a, 0x16, 0x24, 0x34, 0xe1, 0x25, 0xf1, 0x17, 0x18, 0x19, 0x1a, 0x26,
  0x27, 0x28, 0x29, 0x2a, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48,
  0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68,
  0x69, 0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
  0x88, 0x89, 0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5,
  0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3,
  0xc4, 0xc5, 0xc6, 0xc7, 0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda,
  0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8,
  0xf9, 0xfa,
];

function buildEncodeTable(bits, vals) {
  const codes = new Map(); 
  let code = 0;
  let k = 0;
  for (let l = 1; l <= 16; l++) {
    for (let i = 0; i < bits[l - 1]; i++) {
      codes.set(vals[k], { code, len: l });
      code++;
      k++;
    }
    code <<= 1;
  }
  return codes;
}

function scaleQuantTable(base, quality) {
  let q = quality;
  if (q < 1) q = 1;
  if (q > 100) q = 100;
  const scale = q < 50 ? 5000 / q : 200 - 2 * q;
  const out = new Int32Array(64);
  for (let i = 0; i < 64; i++) {
    let v = Math.floor((base[i] * scale + 50) / 100);
    if (v < 1) v = 1;
    if (v > 255) v = 255;
    out[i] = v;
  }
  return out;
}

class BitWriter {
  constructor() {
    this.bytes = [];
    this.cur = 0;
    this.n = 0;
  }
  write(code, len) {
    for (let i = len - 1; i >= 0; i--) {
      this.cur = (this.cur << 1) | ((code >>> i) & 1);
      this.n++;
      if (this.n === 8) {
        this.bytes.push(this.cur);
        if (this.cur === 0xff) this.bytes.push(0x00);
        this.cur = 0;
        this.n = 0;
      }
    }
  }
  flush() {
    while (this.n !== 0) this.write(1, 1);
    return Buffer.from(this.bytes);
  }
}

const COS_FDCT = new Float32Array(64);
for (let x = 0; x < 8; x++) {
  for (let u = 0; u < 8; u++) {
    COS_FDCT[x * 8 + u] = (u === 0 ? Math.SQRT1_2 : 1) * Math.cos(((2 * x + 1) * u * Math.PI) / 16) / 2;
  }
}

function fdct8(block) {
  const tmp = new Float32Array(64);
  for (let i = 0; i < 8; i++) {
    for (let u = 0; u < 8; u++) {
      let s = 0;
      for (let x = 0; x < 8; x++) s += block[i * 8 + x] * COS_FDCT[x * 8 + u];
      tmp[i * 8 + u] = s;
    }
  }
  const out = new Float32Array(64);
  for (let u = 0; u < 8; u++) {
    for (let v = 0; v < 8; v++) {
      let s = 0;
      for (let j = 0; j < 8; j++) s += tmp[j * 8 + u] * COS_FDCT[j * 8 + v];
      out[v * 8 + u] = s / 4;
    }
  }
  return out;
}

const ZZ_ORDER = [
  0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5,
  12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28,
  35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51,
  58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63,
];

function bitSize(v) {
  let t = Math.abs(v);
  let n = 0;
  while (t) { t >>= 1; n++; }
  return n;
}

export function encodeJPEG(rgba, width, height, quality = 90) {
  const qL = scaleQuantTable(STD_Q_LUMA, quality);
  const qC = scaleQuantTable(STD_Q_CHROMA, quality);
  const dcL = buildEncodeTable(DC_LUMA_BITS, DC_LUMA_VALS);
  const acL = buildEncodeTable(AC_LUMA_BITS, AC_LUMA_VALS);
  const dcC = buildEncodeTable(DC_CHROMA_BITS, DC_CHROMA_VALS);
  const acC = buildEncodeTable(AC_CHROMA_BITS, AC_CHROMA_VALS);

  
  const cw = Math.ceil(width / 2);
  const ch = Math.ceil(height / 2);
  const Y = new Float32Array(width * height);
  const CbAccum = new Float64Array(cw * ch);
  const CrAccum = new Float64Array(cw * ch);
  const CbCount = new Int32Array(cw * ch);
  const Cb = new Float32Array(cw * ch);
  const Cr = new Float32Array(cw * ch);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const o = (y * width + x) * 4;
      const r = rgba[o]; const g = rgba[o + 1]; const b = rgba[o + 2];
      Y[y * width + x] = 0.299 * r + 0.587 * g + 0.114 * b - 128;
      const cy = Math.floor(y / 2) * cw + Math.floor(x / 2);
      CbAccum[cy] += -0.168736 * r - 0.331264 * g + 0.5 * b;
      CrAccum[cy] += 0.5 * r - 0.418688 * g - 0.081312 * b;
      CbCount[cy] += 1;
    }
  }
  
  for (let i = 0; i < CbAccum.length; i++) {
    if (CbCount[i]) {
      Cb[i] = CbAccum[i] / CbCount[i];
      Cr[i] = CrAccum[i] / CbCount[i];
    }
  }

  const head = [];
  head.push(Buffer.from([0xff, 0xd8])); 
  
  const app0 = Buffer.from([
    0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x02, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00,
  ]);
  const app0Len = Buffer.alloc(2);
  app0Len.writeUInt16BE(app0.length, 0);
  head.push(Buffer.from([0xff, 0xe0]), app0Len, app0);
  
  for (const [id, q] of [[0, qL], [1, qC]]) {
    const dqt = Buffer.alloc(65);
    dqt[0] = id;
    for (let i = 0; i < 64; i++) dqt[i + 1] = q[i];
    const l = Buffer.alloc(2);
    l.writeUInt16BE(dqt.length + 2, 0);
    head.push(Buffer.from([0xff, 0xdb]), l, dqt);
  }
  
  const sof = Buffer.alloc(17);
  sof[0] = 8; 
  sof.writeUInt16BE(height, 1);
  sof.writeUInt16BE(width, 3);
  sof[5] = 3;
  sof[6] = 1; sof[7] = 0x22; sof[8] = 0; 
  sof[9] = 2; sof[10] = 0x11; sof[11] = 1; 
  sof[12] = 3; sof[13] = 0x11; sof[14] = 1; 
  const sofLen = Buffer.alloc(2);
  sofLen.writeUInt16BE(sof.length + 2, 0);
  head.push(Buffer.from([0xff, 0xc0]), sofLen, sof);
  
  const dhtSeg = (tc, th, bits, vals) => {
    const d = Buffer.alloc(1 + 16 + vals.length);
    d[0] = (tc << 4) | th;
    for (let i = 0; i < 16; i++) d[i + 1] = bits[i];
    for (let i = 0; i < vals.length; i++) d[i + 17] = vals[i];
    const l = Buffer.alloc(2);
    l.writeUInt16BE(d.length + 2, 0);
    return Buffer.concat([Buffer.from([0xff, 0xc4]), l, d]);
  };
  head.push(
    dhtSeg(0, 0, DC_LUMA_BITS, DC_LUMA_VALS),
    dhtSeg(1, 0, AC_LUMA_BITS, AC_LUMA_VALS),
    dhtSeg(0, 1, DC_CHROMA_BITS, DC_CHROMA_VALS),
    dhtSeg(1, 1, AC_CHROMA_BITS, AC_CHROMA_VALS),
  );
  
  const sos = Buffer.from([0x03, 0x01, 0x00, 0x02, 0x11, 0x03, 0x11, 0x00, 0x3f, 0x00]);
  const sosLen = Buffer.alloc(2);
  sosLen.writeUInt16BE(sos.length + 2, 0);
  head.push(Buffer.from([0xff, 0xda]), sosLen, sos);

  const bw = new BitWriter();
  const encodeBlock = (src, srcStride, ox, oy, qtab, dcTab, acTab, dcPredKey) => {
    const block = new Float32Array(64);
    for (let y = 0; y < 8; y++) {
      for (let x = 0; x < 8; x++) {
        const sx = Math.min(ox + x, width - 1);
        const sy = Math.min(oy + y, height - 1);
        block[y * 8 + x] = src[sy * srcStride + sx];
      }
    }
    const freq = fdct8(block);
    const quant = new Int32Array(64);
    for (let i = 0; i < 64; i++) {
      const zz = ZZ_ORDER[i];
      const v = freq[zz] / qtab[zz];
      quant[i] = Math.round(v);
    }
    
    const dc = quant[0];
    const diff = dc - (dcPred.get(dcPredKey) || 0);
    dcPred.set(dcPredKey, dc);
    const cat = bitSize(diff);
    const dce = dcTab.get(cat);
    bw.write(dce.code, dce.len);
    if (cat) {
      let v = diff;
      if (v < 0) v -= 1;
      bw.write(v & ((1 << cat) - 1), cat);
    }
    
    let run = 0;
    for (let i = 1; i < 64; i++) {
      const v = quant[i];
      if (v === 0) { run++; continue; }
      while (run > 15) {
        const zrl = acTab.get(0xf0);
        bw.write(zrl.code, zrl.len);
        run -= 16;
      }
      const catA = bitSize(v);
      const sym = (run << 4) | catA;
      const ace = acTab.get(sym);
      bw.write(ace.code, ace.len);
      let vv = v;
      if (vv < 0) vv -= 1;
      bw.write(vv & ((1 << catA) - 1), catA);
      run = 0;
    }
    if (run > 0) {
      const eob = acTab.get(0x00);
      bw.write(eob.code, eob.len);
    }
  };

  const dcPred = new Map();
  const mcusX = Math.ceil(width / 16);
  const mcusY = Math.ceil(height / 16);
  for (let my = 0; my < mcusY; my++) {
    for (let mx = 0; mx < mcusX; mx++) {
      encodeBlock(Y, width, mx * 16, my * 16, qL, dcL, acL, 'Y');
      for (const [plane, stride, q, dc, ac, key] of [
        [Cb, cw, qC, dcC, acC, 'Cb'],
        [Cr, cw, qC, dcC, acC, 'Cr'],
      ]) {
        encodeBlock(plane, stride, mx * 8, my * 8, q, dc, ac, key);
      }
    }
  }

  const body = bw.flush();
  return Buffer.concat([...head, body, Buffer.from([0xff, 0xd9])]);
}

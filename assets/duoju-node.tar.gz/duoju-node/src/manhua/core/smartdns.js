






import dns from 'node:dns';

export const SMART_DNS_OK_TTL = 3 * 60 * 1000;
export const SMART_DNS_BAD_TTL = 30 * 1000;
export const SMART_DNS_QUERY = 1500;
export const SMART_MAX_IPS = 8;

export const smartUpstreams = ['223.5.5.5', '119.29.29.29', '114.114.114.114'];

const smartDNSCache = new Map(); 

export function isIPv4(s) {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(s);
  if (!m) return false;
  return m.slice(1).every((x) => parseInt(x, 10) <= 255);
}

export function mergeIPs(dst, src) {
  const seen = new Set();
  const out = [];
  for (const ip of [...(dst || []), ...(src || [])]) {
    const s = String(ip || '').trim();
    if (!s || seen.has(s)) continue;
    seen.add(s);
    out.push(s);
  }
  
  const v4 = out.filter((ip) => isIPv4(ip));
  const v6 = out.filter((ip) => !isIPv4(ip));
  const merged = [...v4, ...v6];
  return merged.slice(0, SMART_MAX_IPS);
}

async function resolveVia(servers, host, timeoutMs = SMART_DNS_QUERY) {
  const resolver = new dns.Resolver({ timeout: Math.min(timeoutMs, 2000), tries: 2 });
  try {
    resolver.setServers(servers);
    const t = new Promise((resolve) => setTimeout(() => resolve(null), timeoutMs));
    const lookup = Promise.allSettled([resolver.resolve4(host), resolver.resolve6(host)]).then((rs) =>
      rs.flatMap((r) => (r.status === 'fulfilled' ? r.value : [])),
    );
    const addrs = await Promise.race([lookup, t]);
    return addrs || [];
  } catch {
    return [];
  } finally {
    try { resolver.cancel(); } catch {  }
  }
}


export async function aggregateResolve(host, timeoutMs = SMART_DNS_QUERY) {
  const results = await Promise.all(smartUpstreams.map((srv) => resolveVia([srv], host, timeoutMs)));
  let out = [];
  for (const ips of results) out = mergeIPs(out, ips);
  return out;
}


export async function smartLookup(host) {
  const key = String(host || '').toLowerCase().trim();
  if (!key) return [];
  const cached = smartDNSCache.get(key);
  if (cached && Date.now() < cached.expire) return cached.ips;

  const sys = await resolveVia(dns.getServers?.() || [], key);
  if (sys.length > 0) {
    smartDNSCache.set(key, { ips: sys, expire: Date.now() + SMART_DNS_OK_TTL });
    
    aggregateResolve(key)
      .then((agg) => {
        if (agg.length > sys.length) {
          smartDNSCache.set(key, { ips: agg, expire: Date.now() + SMART_DNS_OK_TTL });
        }
      })
      .catch(() => {});
    return sys;
  }
  const agg = await aggregateResolve(key);
  smartDNSCache.set(key, { ips: agg, expire: Date.now() + (agg.length > 0 ? SMART_DNS_OK_TTL : SMART_DNS_BAD_TTL) });
  return agg;
}

export default { smartLookup, aggregateResolve, mergeIPs, smartUpstreams };


export const IMG_CACHE_BUDGET = 64 * 1024 * 1024;

export class ImgCache {
  constructor(budget = IMG_CACHE_BUDGET) {
    this.items = new Map(); 
    this.budget = budget > 0 ? budget : IMG_CACHE_BUDGET;
    this.used = 0;
    this.inflight = new Map(); 
    this.hits = 0;
    this.misses = 0;
    this.pruned = 0;
  }

  get(key) {
    const it = this.items.get(key);
    if (!it) return null;
    
    this.items.delete(key);
    this.items.set(key, it);
    return it;
  }

  store(key, ct, scope, data) {
    const existing = this.items.get(key);
    if (existing) {
      this.used += data.length - existing.data.length;
      existing.ct = ct;
      existing.data = data;
      if (scope) existing.scope = scope;
      this.items.delete(key);
      this.items.set(key, existing);
    } else {
      this.items.set(key, { key, ct, scope, data });
      this.used += data.length;
    }
    while (this.used > this.budget) {
      const oldestKey = this.items.keys().next().value;
      if (oldestKey === undefined) break;
      const oldest = this.items.get(oldestKey);
      this.items.delete(oldestKey);
      this.used -= oldest.data.length;
    }
  }

  clear() {
    this.items.clear();
    this.used = 0;
  }

  async getOrLoad(key, scope, fetchFn) {
    const it = this.items.get(key);
    if (it) {
      if (scope && it.scope !== scope) it.scope = scope;
      
      this.items.delete(key);
      this.items.set(key, it);
      this.hits++;
      return { data: it.data, ct: it.ct };
    }
    if (this.inflight.has(key)) {
      return this.inflight.get(key);
    }
    this.misses++;
    const call = (async () => {
      try {
        const { data, ct } = await fetchFn();
        this.inflight.delete(key);
        if (data && data.length > 0) {
          this.store(key, ct, scope, data);
        }
        return { data, ct };
      } catch (err) {
        this.inflight.delete(key);
        throw err;
      }
    })();
    this.inflight.set(key, call);
    return call;
  }

  retainScopes(...scopes) {
    const keep = new Set();
    for (const s of scopes) {
      if (s) keep.add(s);
    }
    if (keep.size === 0) return 0;
    let n = 0;
    for (const [key, it] of [...this.items.entries()]) {
      if (!it.scope || keep.has(it.scope)) continue;
      this.items.delete(key);
      this.used -= it.data.length;
      n++;
    }
    this.pruned += n;
    return n;
  }

  stats() {
    return {
      entries: this.items.size,
      bytes: this.used,
      budget: this.budget,
      hits: this.hits,
      misses: this.misses,
      inflight: this.inflight.size,
      pruned: this.pruned,
    };
  }
}

export default { ImgCache, IMG_CACHE_BUDGET };








const MAX_PER_HOST = 4;
const MIN_INTERVAL_MS = 120;

const state = new Map(); 

function stateFor(host) {
  let st = state.get(host);
  if (!st) {
    st = { running: 0, last: 0, queue: [] };
    state.set(host, st);
  }
  return st;
}

function hostOf(urlLike) {
  try {
    return new URL(urlLike).hostname.toLowerCase();
  } catch {
    return String(urlLike || '').toLowerCase();
  }
}





export async function acquire(urlLike) {
  const host = hostOf(urlLike);
  const st = stateFor(host);

  return new Promise((resolve) => {
    const tryStart = () => {
      if (st.running < MAX_PER_HOST) {
        const wait = MIN_INTERVAL_MS - (Date.now() - st.last);
        if (wait > 0) {
          st.queue.push({ start: false, resolve });
          
          setTimeout(() => {
            const idx = st.queue.findIndex((q) => q.resolve === resolve && q.start === false);
            if (idx >= 0) {
              const item = st.queue[idx];
              if (st.running < MAX_PER_HOST) {
                st.queue.splice(idx, 1);
                st.running++;
                st.last = Date.now();
                resolve(releaseFor(st));
              }
            }
          }, Math.max(wait, 1));
        } else {
          st.running++;
          st.last = Date.now();
          resolve(releaseFor(st));
        }
        return true;
      }
      return false;
    };

    if (!tryStart()) {
      st.queue.push({ start: true, resolve });
    }
  });
}

function releaseFor(st) {
  let released = false;
  return () => {
    if (released) return;
    released = true;
    st.running--;
    pump(st);
  };
}

function pump(st) {
  while (st.running < MAX_PER_HOST && st.queue.length > 0) {
    const idx = st.queue.findIndex((q) => Date.now() - st.last >= MIN_INTERVAL_MS);
    if (idx < 0) {
      const delay = MIN_INTERVAL_MS - (Date.now() - st.last);
      setTimeout(() => pump(st), Math.max(delay, 1));
      return;
    }
    const item = st.queue[idx];
    st.queue.splice(idx, 1);
    st.running++;
    st.last = Date.now();
    item.resolve(releaseFor(st));
  }
}


export async function runLimited(urlLike, fn) {
  const release = await acquire(urlLike);
  try {
    return await fn();
  } finally {
    release();
  }
}

export default { acquire, runLimited, MAX_PER_HOST, MIN_INTERVAL_MS };

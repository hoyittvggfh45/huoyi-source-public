
import * as cheerio from 'cheerio';

const namedEntities = {
  amp: '&',
  lt: '<',
  gt: '>',
  quot: '"',
  apos: "'",
  nbsp: ' ',
  hellip: '…',
  mdash: '—',
  ndash: '–',
  lsquo: '‘',
  rsquo: '’',
  ldquo: '“',
  rdquo: '”',
  middot: '·',
  bull: '•',
  deg: '°',
  times: '×',
  divide: '÷',
  copy: '©',
  reg: '®',
  trade: '™',
  laquo: '«',
  raquo: '»',
  eacute: 'é',
  agrave: 'à',
  ccedil: 'ç',
  uuml: 'ü',
  ouml: 'ö',
  auml: 'ä',
  szlig: 'ß',
  yacute: 'ý',
  iexcl: '¡',
  cent: '¢',
  pound: '£',
  euro: '€',
  yen: '¥',
  sect: '§',
  para: '¶',
  frac12: '½',
  frac14: '¼',
  frac34: '¾',
  sup2: '²',
  sup3: '³',
  micro: 'µ',
  plusmn: '±',
  ne: '≠',
  le: '≤',
  ge: '≥',
  larr: '←',
  rarr: '→',
  uarr: '↑',
  darr: '↓',
  harr: '↔',
  crarr: '↵',
  alpha: 'α',
  beta: 'β',
  gamma: 'γ',
  delta: 'δ',
  epsilon: 'ε',
  pi: 'π',
  sigma: 'σ',
  omega: 'ω',
  infin: '∞',
  asymp: '≈',
  equiv: '≡',
};

const numericEntityRe = /&#(x?[0-9a-fA-F]+);/g;
const namedEntityRe = /&([a-zA-Z][a-zA-Z0-9]*);/g;

function decodeNumeric(body) {
  return body.replace(numericEntityRe, (all, num) => {
    try {
      let cp;
      if (num[0] === 'x' || num[0] === 'X') cp = parseInt(num.slice(1), 16);
      else cp = parseInt(num, 10);
      if (!Number.isFinite(cp) || cp < 0 || cp > 0x10ffff) return all;
      if (cp >= 0xd800 && cp <= 0xdfff) return '\uFFFD';
      return String.fromCodePoint(cp);
    } catch {
      return all;
    }
  });
}

function decodeNamed(body) {
  return body.replace(namedEntityRe, (all, name) => {
    const lower = name.toLowerCase();
    if (Object.prototype.hasOwnProperty.call(namedEntities, lower)) {
      return namedEntities[lower];
    }
    return all;
  });
}


export function unescapeHTML(s) {
  if (!s) return '';
  return decodeNamed(decodeNumeric(String(s)));
}


export function escapeHTML(s) {
  if (!s) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/'/g, '&#39;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&#34;');
}


export function collapseSpace(s) {
  if (!s) return '';
  return String(s).replace(/\s+/g, ' ').trim();
}


export function stripTags(s) {
  if (!s) return '';
  return collapseSpace(String(s).replace(/<[^>]*>/g, ' '));
}


export function absURL(base, href) {
  if (!href) return '';
  const h = String(href).trim();
  if (!h) return '';
  try {
    return new URL(h, base).toString();
  } catch {
    return '';
  }
}


export function textSel($, sel) {
  const t = $(sel).first().text();
  return collapseSpace(t);
}


export function attrSel($, sel, name) {
  const v = $(sel).first().attr(name);
  return v ? String(v).trim() : '';
}


export function attrOf($el, name) {
  const v = $el.attr ? $el.attr(name) : undefined;
  return v ? String(v).trim() : '';
}


export function htmlText(s) {
  if (!s) return '';
  return collapseSpace(unescapeHTML(String(s).replace(/<[^>]*>/gis, ' ')));
}



export function firstGroup(re, s) {
  if (!s) return '';
  const src = String(s);
  let rx = re;
  if (re.global || re.sticky) {
    rx = new RegExp(re.source, re.flags.replace(/[gy]/g, ''));
  }
  const m = rx.exec(src);
  if (m && m.length > 1) return m[1] || '';
  return '';
}


export function loadHTML(html) {
  return cheerio.load(html || '');
}

export default {
  unescapeHTML,
  escapeHTML,
  collapseSpace,
  stripTags,
  absURL,
  textSel,
  attrSel,
  attrOf,
  loadHTML,
  htmlText,
  firstGroup,
};

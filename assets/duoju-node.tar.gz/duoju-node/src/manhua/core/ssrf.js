
import dns from 'node:dns';

const SSRF_CACHE_TTL = 5 * 60 * 1000;
const SSRF_FLAKY_TTL = 20 * 1000;
const SSRF_LOOKUP_WAIT = 1200;

const ssrfCache = new Map(); 



function parseIPv4(s) {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(s);
  if (!m) return null;
  const parts = [m[1], m[2], m[3], m[4]].map((x) => parseInt(x, 10));
  if (parts.some((x) => x > 255)) return null;
  return parts;
}


function expandIPv6(s) {
  if (!s.includes(':')) return null;
  let str = s;
  
  const pct = str.indexOf('%');
  if (pct >= 0) str = str.slice(0, pct);
  
  let v4 = null;
  const lastColon = str.lastIndexOf(':');
  const tail = str.slice(lastColon + 1);
  if (tail.includes('.')) {
    v4 = parseIPv4(tail);
    if (!v4) return null;
    const hi = ((v4[0] << 8) | v4[1]).toString(16);
    const lo = ((v4[2] << 8) | v4[3]).toString(16);
    str = str.slice(0, lastColon + 1) + hi + ':' + lo;
  }
  const doubleColon = str.includes('::');
  if (doubleColon && str.indexOf('::') !== str.lastIndexOf('::')) return null;
  let head = str;
  let tailParts = [];
  if (doubleColon) {
    const [a, b] = str.split('::');
    head = a;
    tailParts = b ? b.split(':').filter((x) => x !== '') : [];
  }
  const headParts = head ? head.split(':').filter((x) => x !== '') : [];
  const missing = 8 - headParts.length - tailParts.length;
  if (missing < 0) return null;
  const groups = doubleColon
    ? [...headParts, ...Array(missing).fill('0'), ...tailParts]
    : headParts;
  if (groups.length !== 8) return null;
  const out = [];
  for (const g of groups) {
    if (!/^[0-9a-fA-F]{1,4}$/.test(g)) return null;
    out.push(parseInt(g, 16));
  }
  return out;
}

function ipv6MappedV4(groups) {
  
  const allZero = groups.slice(0, 5).every((g) => g === 0);
  if (allZero && (groups[5] === 0xffff || groups[5] === 0)) {
    return [(groups[6] >> 8) & 0xff, groups[6] & 0xff, (groups[7] >> 8) & 0xff, groups[7] & 0xff];
  }
  return null;
}


export function ssrfIPOK(v4parts, groups6) {
  if (v4parts) {
    const [a, b] = v4parts;
    if (a === 127) return false; 
    if (a === 10) return false; 
    if (a === 172 && b >= 16 && b < 32) return false; 
    if (a === 192 && b === 168) return false; 
    if (a === 169 && b === 254) return false; 
    if (a === 224) return false; 
    if (a === 0) return false; 
    if (a === 100 && b >= 64 && b < 128) return false; 
    return true;
  }
  if (groups6) {
    const hi = groups6[0];
    const lo = groups6[1];
    if (hi === 0 && groups6.slice(1).every((g) => g === 0)) return false; 
    if (hi === 0 && lo === 1 && groups6.slice(2).every((g) => g === 0)) return false; 
    if ((hi & 0xfe00) === 0xfe00) return false; 
    if ((hi & 0xff00) === 0xff00) return false; 
    if ((hi & 0xfe00) === 0xfc00) return false; 
    if (hi === 0 && lo === 0 && groups6[2] === 0 && groups6[3] === 0 && groups6[4] === 0) {
      
      const v4 = ipv6MappedV4(groups6);
      if (v4) return ssrfIPOK(v4, null);
      return false;
    }
    const v4 = ipv6MappedV4(groups6);
    if (v4) return ssrfIPOK(v4, null);
    return true;
  }
  return false;
}

function ssrfIPOKStr(ip) {
  if (ip.includes(':')) {
    const groups = expandIPv6(ip);
    if (!groups) return false;
    const v4 = ipv6MappedV4(groups);
    if (v4) return ssrfIPOK(v4, null);
    return ssrfIPOK(null, groups);
  }
  const v4 = parseIPv4(ip);
  if (!v4) return false;
  return ssrfIPOK(v4, null);
}



async function ssrfCheckHost(host) {
  if (parseIPv4(host)) {
    return [ssrfIPOKStr(host), false];
  }
  if (host.includes(':') && expandIPv6(host)) {
    return [ssrfIPOKStr(host), false];
  }
  
  const resolver = new dns.Resolver();
  let ips = [];
  try {
    const timer = new Promise((resolve) => setTimeout(() => resolve([]), SSRF_LOOKUP_WAIT));
    const lookup = Promise.allSettled([dns.promises.resolve4(host), dns.promises.resolve6(host)]).then(
      (rs) => rs.flatMap((r) => (r.status === 'fulfilled' ? r.value : [])),
    );
    ips = await Promise.race([lookup, timer]);
  } catch {
    ips = [];
  } finally {
    try { resolver.close(); } catch {}
  }
  if (!ips || ips.length === 0) {
    
    try {
      const recs = await Promise.race([
        dns.promises.resolve(host),
        new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), SSRF_LOOKUP_WAIT)),
      ]);
      ips = recs || [];
    } catch {
      return [false, true];
    }
    if (!ips || ips.length === 0) return [false, true];
  }
  for (const ip of ips) {
    if (!ssrfIPOKStr(String(ip))) {
      return [false, false];
    }
  }
  return [true, false];
}


export async function ssrfTargetAllowed(target) {
  let u;
  try {
    u = new URL(target);
  } catch {
    return false;
  }
  let host = String(u.hostname || '').toLowerCase();
  if (host.endsWith('.')) host = host.slice(0, -1);
  host = host.replace(/^\[|\]$/g, '');
  if (!host) return false;
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal')) {
    return false;
  }
  const cached = ssrfCache.get(host);
  if (cached) {
    const ttl = cached.transient ? SSRF_FLAKY_TTL : SSRF_CACHE_TTL;
    if (Date.now() - cached.at < ttl) return cached.allowed;
  }
  const [allowed, transient] = await ssrfCheckHost(host);
  if (ssrfCache.size > 2048) ssrfCache.clear();
  ssrfCache.set(host, { allowed, transient, at: Date.now() });
  return allowed;
}

export default { ssrfTargetAllowed, ssrfIPOK };

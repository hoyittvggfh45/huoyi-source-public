





import crypto from 'node:crypto';
import * as hostlimit from './hostlimit.js';

export const defaultUA =
  'Mozilla/5.0 (Linux; Android 13; M2012K11AC) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

let upstream = null;


export function setUpstreamClient(client) {
  upstream = client;
}

export function getUpstreamClient() {
  if (!upstream) {
    
    
    import('../../core/client.js').then(({ BrowserClient }) => {
      if (!upstream) upstream = new BrowserClient({ profile: 'chrome120' });
    });
  }
  return upstream;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class UpstreamStatusError extends Error {
  constructor(code) {
    super(`upstream status ${code}`);
    this.code = code;
  }
}



async function upstreamRaw(api, build) {
  const client = getUpstreamClient();
  if (!client) throw new Error('upstream client unavailable');
  let lastErr = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    if (attempt > 0) await sleep(400);
    const release = await hostlimit.acquire(api);
    try {
      const b = build();
      const resp = await client.do(b.method || 'GET', api, b.headers || {}, {
        body: b.body,
        noBrowserHeaders: true,
        withoutCookieJar: true,
        timeoutMs: b.timeoutMs,
      });
      if (resp.status >= 500) {
        try { await resp.buffer(); } catch {  }
        lastErr = new UpstreamStatusError(resp.status);
        continue;
      }
      const buf = await resp.buffer();
      return { resp, buf, status: resp.status, respHeaders: resp.headers || {} };
    } catch (err) {
      lastErr = err;
    } finally {
      release();
    }
  }
  throw lastErr || new Error('upstream failed');
}




export async function upstreamRequest(api, opts = {}) {
  const { resp, buf, status, respHeaders } = await upstreamRaw(api, () => opts);
  void resp;
  return { status, buf, respHeaders };
}


export async function httpGet(api, headers = {}, timeoutMs = 20000) {
  const h = { 'User-Agent': defaultUA, ...headers };
  const { status, buf } = await upstreamRaw(api, () => ({
    method: 'GET',
    headers: h,
    timeoutMs,
  }));
  if (status < 200 || status >= 300) {
    const err = new Error('EOF');
    err.status = status;
    throw err;
  }
  return buf.toString('utf8');
}

export async function httpGetJSON(api, headers = {}, timeoutMs = 20000) {
  return httpGet(api, headers, timeoutMs);
}

export async function httpPost(api, body, contentType, headers = {}, timeoutMs = 20000) {
  const h = { 'User-Agent': defaultUA, 'Content-Type': contentType, ...headers };
  const { status, buf } = await upstreamRaw(api, () => ({
    method: 'POST',
    body: body || '',
    headers: h,
    timeoutMs,
  }));
  if (status < 200 || status >= 300) {
    const err = new Error('EOF');
    err.status = status;
    throw err;
  }
  return buf.toString('utf8');
}

export async function httpPostJSON(api, body, headers = {}, timeoutMs = 20000) {
  return httpPost(api, typeof body === 'string' ? body : JSON.stringify(body), 'application/json', headers, timeoutMs);
}

export async function httpPostForm(api, form, headers = {}, timeoutMs = 20000) {
  return httpPost(api, typeof form === 'string' ? form : encodeQuery(form), 'application/x-www-form-urlencoded', headers, timeoutMs);
}


export async function httpGetBytes(api, headers = {}, timeoutMs = 20000) {
  const h = { 'User-Agent': defaultUA, ...headers };
  const { status, buf } = await upstreamRaw(api, () => ({
    method: 'GET',
    headers: h,
    timeoutMs,
  }));
  if (status < 200 || status >= 300) {
    const err = new Error('EOF');
    err.status = status;
    throw err;
  }
  return buf;
}



export function newUUIDv4() {
  const b = crypto.randomBytes(16);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const hex = b.toString('hex');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

export function md5hex(s) {
  return crypto.createHash('md5').update(String(s), 'utf8').digest('hex');
}


export function encode(s) {
  return encodeURIComponent(String(s ?? '')).replace(/%20/g, '+');
}


export function encodeQuery(obj) {
  const parts = [];
  for (const k of Object.keys(obj ?? {}).sort()) {
    const v = obj[k];
    if (v === undefined || v === null) continue;
    parts.push(`${encode(k)}=${encode(v)}`);
  }
  return parts.join('&');
}

export function atoiDefault(s, def) {
  const t = String(s ?? '').trim();
  if (t === '') return def;
  let n = 0;
  for (const ch of t) {
    if (ch < '0' || ch > '9') return def;
    n = n * 10 + (ch.charCodeAt(0) - 48);
    if (n > 1_000_000_000) return def;
  }
  if (n <= 0) return def;
  return n;
}

export function firstNonEmpty(...vals) {
  for (const v of vals) {
    if (v != null && String(v).trim() !== '') return String(v).trim();
  }
  return '';
}


export function jsonIDString(v) {
  if (v == null) return '';
  if (typeof v === 'string') return v.trim();
  if (typeof v === 'number') {
    if (Number.isFinite(v)) return String(Math.trunc(v));
    return String(v);
  }
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (typeof v === 'bigint') return String(v);
  const s = String(v).trim();
  if (s && !/[eE]/.test(s)) {
    const f = Number(s);
    if (Number.isFinite(f)) return String(Math.trunc(f));
  }
  return s;
}

export default {
  defaultUA,
  setUpstreamClient,
  getUpstreamClient,
  upstreamRequest,
  httpGet,
  httpGetJSON,
  httpPost,
  httpPostJSON,
  httpPostForm,
  httpGetBytes,
  newUUIDv4,
  md5hex,
  encode,
  atoiDefault,
  firstNonEmpty,
  jsonIDString,
};

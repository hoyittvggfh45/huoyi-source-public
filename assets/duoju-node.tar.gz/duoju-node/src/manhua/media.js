
import { BrowserClient } from '../core/client.js';
import { ImgCache } from './core/imgcache.js';
import { ssrfTargetAllowed } from './core/ssrf.js';
import { upstreamRequest, defaultUA, firstNonEmpty } from './core/http.js';
import { descrambleJM, detectContentType } from './core/imgdescramble.js';
import crypto from 'node:crypto';

const HOP_HEADERS = new Set([
  'connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization',
  'te', 'trailer', 'transfer-encoding', 'upgrade', 'host',
]);

export function normalizeMediaURL(raw) {
  const t = String(raw || '').trim();
  if (t.startsWith('//')) return 'https:' + t;
  return t;
}


export function decryptAesCbcImage(b) {
  const key = Buffer.from('my2ecret782ecret', 'utf8');
  if (!b || b.length === 0 || b.length % 16 !== 0) {
    throw new Error(`密文长度非块对齐: ${b ? b.length : 0}`);
  }
  const decipher = crypto.createDecipheriv('aes-128-cbc', key, key);
  decipher.setAutoPadding(false);
  const out = Buffer.concat([decipher.update(b), decipher.final()]);
  const pad = out[out.length - 1];
  if (pad > 0 && pad <= 16 && pad <= out.length) {
    let ok = true;
    for (let i = out.length - pad; i < out.length; i++) {
      if (out[i] !== pad) { ok = false; break; }
    }
    if (ok) return out.subarray(0, out.length - pad);
  }
  return out;
}


export { detectContentType };

export class MediaProxy {
  constructor() {
    this.imgCache = new ImgCache();
    
    this.streamClient = new BrowserClient({ profile: 'chrome120' });
  }

  
  async handleAudio(req, res) {
    const q = req.query || {};
    const target = normalizeMediaURL(q.u);
    if (!target) {
      res.status(400).type('text/plain; charset=utf-8').send('missing u');
      return;
    }
    let scheme = '';
    try { scheme = new URL(target).protocol.replace(':', ''); } catch { scheme = ''; }
    if (scheme !== 'http' && scheme !== 'https') {
      res.status(400).type('text/plain; charset=utf-8').send('bad url');
      return;
    }
    if (!(await ssrfTargetAllowed(target))) {
      res.status(403).type('text/plain; charset=utf-8').send('forbidden target');
      return;
    }
    const headers = {
      'User-Agent': firstNonEmpty(q.ua, defaultUA),
      Accept: '*/*',
      'Icy-MetaData': '1',
    };
    if (q.ref) headers.Referer = q.ref;
    if (req.headers.range) headers.Range = req.headers.range;

    let resp;
    try {
      resp = await this.streamClient.do('GET', target, headers, { media: true, timeoutMs: 30 * 60 * 1000 });
    } catch (err) {
      res.status(502).type('text/plain; charset=utf-8').send('upstream error: ' + (err && err.message ? err.message : err));
      return;
    }
    
    for (const [k, v] of Object.entries(resp.headers || {})) {
      if (HOP_HEADERS.has(k.toLowerCase())) continue;
      if (v == null) continue;
      try { res.setHeader(k, v); } catch {  }
    }
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Accept-Ranges', 'bytes');
    res.status(resp.status);
    if (resp.stream) {
      resp.stream.pipe(res);
      resp.stream.on('error', () => {
        try { res.destroy(); } catch {  }
      });
      res.on('close', () => {
        try { resp.stream.destroy?.(); } catch {  }
      });
    } else {
      const buf = await resp.buffer();
      res.send(buf);
    }
  }

  
  async handleImg(req, res) {
    const q = req.query || {};
    const target = normalizeMediaURL(q.u);
    if (!target) {
      res.status(400).type('text/plain; charset=utf-8').send('missing u');
      return;
    }
    let scheme = '';
    try { scheme = new URL(target).protocol.replace(':', ''); } catch { scheme = ''; }
    if (scheme !== 'http' && scheme !== 'https') {
      res.status(400).type('text/plain; charset=utf-8').send('bad url');
      return;
    }
    if (!(await ssrfTargetAllowed(target))) {
      res.status(403).type('text/plain; charset=utf-8').send('forbidden target');
      return;
    }
    const ref = q.ref || '';
    const ua = q.ua || '';
    const dec = q.d || '';
    const noProxy = q.np === '1';
    const cacheKey = `${target}|${dec}|${q.np || ''}`;
    let data;
    let ct;
    try {
      const r = await this.imgCache.getOrLoad(cacheKey, q.s || '', async () => {
        return this.loadAndProcess(target, ref, ua, noProxy, dec);
      });
      data = r.data;
      ct = r.ct;
    } catch (err) {
      res.status(502).type('text/plain; charset=utf-8').send('upstream error: ' + (err && err.message ? err.message : err));
      return;
    }
    res.setHeader('Content-Type', ct);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'public, max-age=21600');
    res.status(200).send(data);
  }

  async loadAndProcess(target, ref, ua, noProxy, dec) {
    const { buf, ct: ct2 } = await this.fetchImage(target, ref, ua, noProxy);
    let b = buf;
    if (dec === 'aescbc') {
      const b2 = decryptAesCbcImage(b);
      return { data: b2, ct: detectContentType(b2) };
    }
    if (dec === 'jm') {
      const b2 = descrambleJM(b, target);
      return { data: b2, ct: detectContentType(b2) };
    }
    return { data: b, ct: ct2 };
  }

  async fetchImage(target, ref, ua, noProxy) {
    let u;
    try {
      u = new URL(target);
    } catch {
      throw new Error('bad url');
    }
    const headers = {
      'User-Agent': firstNonEmpty(ua, defaultUA),
      Accept: 'image/avif,image/webp,image/png,image/jpeg,image/*',
    };
    if (ref) headers.Referer = ref;
    else if (u.host) headers.Referer = `${u.protocol}//${u.host}/`;

    const { status, buf, respHeaders } = await upstreamRequest(target, {
      method: 'GET',
      headers,
      timeoutMs: 18000,
    });
    if (status < 200 || status >= 300) {
      throw new Error(`HTTP ${status}`);
    }
    let b = buf;
    if (b.length > 8 * 1024 * 1024) b = b.subarray(0, 8 * 1024 * 1024);
    if (b.length === 0) throw new Error('空响应');
    let ct = String(respHeaders['content-type'] || '');
    if (!ct.startsWith('image/')) {
      ct = detectContentType(b);
    }
    return { buf: b, ct };
  }

  warm(proxyURLs, n) {
    if (n <= 0) return;
    if (n > proxyURLs.length) n = proxyURLs.length;
    let running = 0;
    const queue = [];
    for (const raw of proxyURLs.slice(0, n)) {
      let u;
      try { u = new URL(raw, 'http://placeholder.local'); } catch { continue; }
      const q = u.searchParams;
      const target = normalizeMediaURL(q.get('u'));
      if (!target) continue;
      queue.push({
        target,
        ref: q.get('ref') || '',
        ua: q.get('ua') || '',
        scope: q.get('s') || '',
        dec: q.get('d') || '',
        np: q.get('np') || '',
      });
    }
    const runNext = () => {
      if (running >= 3) return;
      const item = queue.shift();
      if (!item) return;
      running++;
      this.imgCache
        .getOrLoad(`${item.target}|${item.dec}|${item.np}`, item.scope, () =>
          this.loadAndProcess(item.target, item.ref, item.ua, item.np === '1', item.dec))
        .catch(() => {})
        .finally(() => {
          running--;
          runNext();
        });
    };
    runNext();
    runNext();
    runNext();
  }
}

export default { MediaProxy, normalizeMediaURL };

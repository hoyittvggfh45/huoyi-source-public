
import { httpGet, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay } from '../types.js';

const HOST = 'https://cn.bzmanga.com';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const CDN = 'https://s2.bzcdn.net';

function headers(ref) {
  if (!ref) ref = `${HOST}/`;
  return { 'User-Agent': UA, Referer: ref };
}

const CATS = [
  ['/classify', '全部'],
  ['/list/new/', '最新上架'],
  ['/classify?region=cn', '国漫'],
  ['/classify?region=jp', '日漫'],
  ['/classify?region=en', '欧美'],
  ['/classify?state=serial', '连载中'],
  ['/classify?state=pub', '已完结'],
  ['/classify?type=dushi', '都市'],
  ['/classify?type=mouxian', '冒险'],
  ['/classify?type=rexie', '热血'],
  ['/classify?type=aiqing', '爱情'],
  ['/classify?type=lianai', '恋爱'],
  ['/classify?type=danmei', '耽美'],
  ['/classify?type=wuxia', '武侠'],
  ['/classify?type=gedou', '格斗'],
  ['/classify?type=kehuan', '科幻'],
  ['/classify?type=mohuan', '魔幻'],
  ['/classify?type=zhentan', '侦探'],
  ['/classify?type=tuili', '推理'],
  ['/classify?type=xuanhuan', '玄幻'],
  ['/classify?type=richang', '日常'],
  ['/classify?type=shenghuo', '生活'],
  ['/classify?type=gaoxiao', '搞笑'],
  ['/classify?type=xiaoyuan', '校园'],
  ['/classify?type=qihuan', '奇幻'],
].map(([id, name]) => ({ id, name }));

const reBzmhCard = /(<a\s[^>]*class="[^"]*comics-card__poster[^"]*"[^>]*>.*?<\/a>)/gis;
const reBzmhID = /href="\/comic\/([^"]+)"/;
const reBzmhName = /(?:title|aria-label)="([^"]*)"/;
const reBzmhCover = /src="(https?:\/\/[^"?]+\.(?:jpg|jpeg|png|webp))/;
const reBzmhTag = /<span[^>]*class="[^"]*\btab\b[^"]*"[^>]*>([^<]*)</gis;
const reBzmhOGName = /<meta[^>]*og:novel:book_name"[^>]*content="([^"]*)"/is;
const reBzmhOGAuth = /<meta[^>]*og:novel:author"[^>]*content="([^"]*)"/is;
const reBzmhOGStat = /<meta[^>]*og:novel:status"[^>]*content="([^"]*)"/is;
const reBzmhOGCat = /<meta[^>]*og:novel:category"[^>]*content="([^"]*)"/is;
const reBzmhOGImg = /<meta[^>]*property="og:image"[^>]*content="([^"]*)"/is;
const reBzmhDesc = /class="comics-detail__desc[^"]*"[^>]*>([\s\S]{0,600}?)<\/p>/is;
const reBzmhChap = /href="\/user\/page_direct\?comic_id=([^&"]+)&(?:amp;)?section_slot=(\d+)&(?:amp;)?chapter_slot=(\d+)"[^>]*>[\s\S]{0,240}?<span[^>]*>([^<]*)<\/span>/gis;
const reBzmhPic = /data-src="(https?:\/\/[^"]+\/scomic\/[^"]+)"/gis;

function coverURL(slug, raw) {
  const i = raw.indexOf('/cover/');
  if (i >= 0) return CDN + raw.slice(i);
  return `${CDN}/cover/${slug}.jpg`;
}

function cards(page) {
  const out = [];
  const seen = new Set();
  for (const m of [...page.matchAll(reBzmhCard)]) {
    const blk = m[1];
    const idm = blk.match(reBzmhID);
    if (!idm) continue;
    const id = idm[1].trim().replace(/^\/+|\/+$/g, '');
    const name = firstGroup(reBzmhName, blk).trim();
    if (!id || !name || seen.has(id) || /[{}]/.test(id)) continue;
    const tags = [];
    const seenTag = new Set();
    for (const t of [...blk.matchAll(reBzmhTag)]) {
      const v = htmlText(t[1]);
      if (!v || seenTag.has(v)) continue;
      seenTag.add(v);
      tags.push(v);
    }
    seen.add(id);
    out.push(Card({
      id, name,
      pic: coverURL(id, firstGroup(reBzmhCover, blk)),
      remarks: tags.join(' '),
      plat: 'bzmh',
    }));
  }
  return out;
}

function pageURL(cat, page) {
  if (page < 1) page = 1;
  const u = HOST + cat;
  return u.includes('?') ? `${u}&page=${page}` : `${u}?page=${page}`;
}

export class ProviderBzmh {
  key() { return 'bzmh'; }
  name() { return '包子漫画'; }
  desc() { return 'cn.bzmanga.com AMP 源，直连可用'; }
  adult() { return false; }

  cats() { return CATS; }

  listPaged() { return true; }
  searchPaged() { return false; }

  async list(cat, page) {
    if (!String(cat || '').trim()) cat = CATS[0].id;
    const body = await httpGet(pageURL(cat, page), headers(''), 20000);
    const cs = cards(body);
    return { cards: cs, hasMore: cs.length >= 10 };
  }

  async search(wd, page) {
    if (page > 1) return { cards: [] };
    const body = await httpGet(`${HOST}/search?q=${encode(String(wd || '').trim())}`, headers(''), 20000);
    return { cards: cards(body), hasMore: false };
  }

  async detail(id) {
    const slug = String(id || '').trim().replace(/^\/+|\/+$/g, '');
    if (!slug) throw new Error('bzmh: 空漫画 id');
    const page = await httpGet(`${HOST}/comic/${encode(slug)}`, headers(''), 25000);
    const name = htmlText(firstGroup(reBzmhOGName, page));
    if (!name) throw new Error(`bzmh: 详情解析失败 ${slug}`);

    const slotSet = new Map(); 
    const nameSet = new Map();
    for (const m of [...page.matchAll(reBzmhChap)]) {
      const sec = parseInt(m[2], 10) || 0;
      const idx = parseInt(m[3], 10) || 0;
      const nm = htmlText(m[4]);
      if (slotSet.has(idx)) continue;
      slotSet.set(idx, { sec, idx });
      nameSet.set(idx, nm);
    }
    const keys = [...slotSet.keys()].sort((a, b) => a - b);

    const chapters = [];
    keys.forEach((k, i) => {
      const s = slotSet.get(k);
      let nm = nameSet.get(k);
      if (!nm) nm = `第${i + 1}话`;
      chapters.push({ no: i + 1, name: nm, url: `${slug}|${s.sec}|${s.idx}` });
    });

    let remarks = htmlText(firstGroup(reBzmhOGStat, page));
    remarks = remarks ? `${remarks} · ${chapters.length} 话` : `${chapters.length} 话`;
    return BookDetail({
      id: slug,
      name,
      pic: coverURL(slug, firstGroup(reBzmhOGImg, page)),
      desc: htmlText(firstGroup(reBzmhDesc, page)),
      tag: htmlText(firstGroup(reBzmhOGCat, page)),
      remarks,
      author: htmlText(firstGroup(reBzmhOGAuth, page)),
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const parts = String(ref || '').trim().split('|');
    if (parts.length !== 3 || !parts[0]) {
      throw new Error(`bzmh: 非法章节凭证 ${ref}`);
    }
    const [slug, sec, idx] = parts;
    const chapURL = `${HOST}/comic/chapter/${encode(slug)}/${sec}_${idx}.html`;
    const page = await httpGet(chapURL, headers(`${HOST}/comic/${encode(slug)}`), 40000);
    const pics = [];
    const seen = new Set();
    for (const m of [...page.matchAll(reBzmhPic)]) {
      const u = m[1].trim();
      if (!u || seen.has(u)) continue;
      seen.add(u);
      pics.push(u);
    }
    if (pics.length === 0) throw new Error('bzmh: 章节无图片');
    return ComicPlay({ pics, referer: chapURL, ua: UA });
  }
}

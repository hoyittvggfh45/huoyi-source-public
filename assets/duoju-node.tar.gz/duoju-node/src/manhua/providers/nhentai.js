
import { httpGet } from '../core/http.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const nhAPI = 'https://nhentai.net/api/v2';
const nhUA = 'Breeze-plugin-nhentai/0.1.0';

function nhHeaders() {
  return {
    'User-Agent': nhUA,
    Accept: 'application/json',
    Referer: 'https://nhentai.net/',
  };
}


function nhStr(v) {
  if (v == null) return '';
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v).trim();
  return '';
}

let nhImgBase = 'https://i3.nhentai.net';
let nhThumbB64 = 'https://t3.nhentai.net';
let nhCDNOnce = false;

async function nhInitCDN() {
  if (nhCDNOnce) return;
  nhCDNOnce = true;
  let body = '';
  try {
    body = await httpGet(`${nhAPI}/cdn`, nhHeaders(), 20000);
  } catch {
    return;
  }
  let cdn = null;
  try {
    cdn = JSON.parse(body);
  } catch {
    return;
  }
  if (Array.isArray(cdn?.image_servers) && cdn.image_servers.length > 0) {
    nhImgBase = String(cdn.image_servers[0]).replace(/\/+$/, '');
  }
  if (Array.isArray(cdn?.thumb_servers) && cdn.thumb_servers.length > 0) {
    nhThumbB64 = String(cdn.thumb_servers[0]).replace(/\/+$/, '');
  }
}

function nhGalleryTitle(g) {
  const t = g?.title;
  if (t && typeof t === 'object') {
    if (t.pretty) return t.pretty;
    if (t.english) return t.english;
    if (t.japanese) return t.japanese;
  }
  if (g?.pretty_title) return g.pretty_title;
  if (g?.english_title) return g.english_title;
  return g?.japanese_title ?? '';
}

function nhTagNames(tags, typ, limit) {
  const out = [];
  for (const t of Array.isArray(tags) ? tags : []) {
    if (t?.type === typ && t?.name) {
      out.push(String(t.name));
      if (out.length >= limit) break;
    }
  }
  return out.join(' ');
}

export class ProviderNhentai {
  key() { return 'nhentai'; }
  name() { return 'nhentai'; }
  adult() { return true; }
  desc() { return 'nhentai.net：API v2 JSON，分类为热门榜与语言过滤'; }

  cats() {
    return [
      { id: 'r:date', name: '最新' },
      { id: 'r:popular', name: '热门' },
      { id: 'r:popular-today', name: '今日热门' },
      { id: 'r:popular-week', name: '本周热门' },
      { id: 'r:popular-month', name: '本月热门' },
      { id: 'l:chinese', name: '中文' },
      { id: 'l:japanese', name: '日语' },
      { id: 'l:english', name: '英语' },
    ];
  }

  async nhCards(url, page) {
    await nhInitCDN();
    const body = await httpGet(url, nhHeaders(), 20000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('nhentai: JSON 解析失败');
    }
    const result = Array.isArray(resp?.result) ? resp.result : [];
    const cards = [];
    for (const g of result) {
      const name = nhGalleryTitle(g);
      if (!name) continue;
      let pic = '';
      if (g?.cover?.path) {
        pic = `${nhThumbB64}/${String(g.cover.path).replace(/^\//, '')}`;
      } else if (nhStr(g?.thumbnail)) {
        pic = `${nhThumbB64}/${nhStr(g.thumbnail).replace(/^\//, '')}`;
      }
      cards.push(Card({
        id: String(g?.id ?? ''),
        name,
        pic,
        remarks: `${parseInt(g?.num_pages ?? 0, 10) || 0}页`,
        cat: nhTagNames(g?.tags, 'tag', 3),
      }));
    }
    let hasMore = (parseInt(resp?.num_pages ?? 0, 10) || 0) > page;
    if (result.length === 0) hasMore = false;
    return { cards, hasMore };
  }

  async list(cat, page) {
    cat = String(cat ?? '');
    let sort = 'date';
    let lang = '';
    if (cat.length > 2 && cat[1] === ':') {
      sort = cat.slice(2);
      lang = cat.slice(2);
      if (cat[0] === 'r') {
        lang = '';
      } else {
        sort = 'date';
      }
    }
    let q = 'all';
    if (lang) q = 'language:' + lang;
    const url = `${nhAPI}/search?query=${q}&page=${page}&sort=${sort}`;
    return this.nhCards(url, page);
  }

  async search(wd, page) {
    const url = `${nhAPI}/search?query=${encodeURIComponent(String(wd ?? '')).replace(/%20/g, '+')}&page=${page}`;
    return this.nhCards(url, page);
  }

  nhCoverPic(g) {
    if (g?.cover?.path) return `${nhThumbB64}/${String(g.cover.path).replace(/^\//, '')}`;
    const t = nhStr(g?.thumbnail);
    if (t) return `${nhThumbB64}/${t.replace(/^\//, '')}`;
    return '';
  }

  async detail(id) {
    await nhInitCDN();
    const body = await httpGet(`${nhAPI}/galleries/${id}`, nhHeaders(), 20000);
    let g = null;
    try {
      g = JSON.parse(body);
    } catch {
      throw new Error('nhentai: JSON 解析失败');
    }
    const name = nhGalleryTitle(g);
    const pic = this.nhCoverPic(g);
    const pages = [];
    if (Array.isArray(g?.pages) && g.pages.length > 0) {
      pages.push(Chapter(1, '本篇', String(g?.id ?? '')));
    }
    const descParts = [];
    const c = nhTagNames(g?.tags, 'parody', 3);
    if (c) descParts.push('Parody: ' + c);
    const a = nhTagNames(g?.tags, 'artist', 3);
    if (a) descParts.push('Artist: ' + a);
    const ch = nhTagNames(g?.tags, 'character', 5);
    if (ch) descParts.push('Characters: ' + ch);
    const favs = parseInt(g?.num_favorites ?? 0, 10) || 0;
    if (favs > 0) descParts.push(`收藏 ${favs}`);
    return BookDetail({
      id: String(g?.id ?? ''),
      name,
      pic,
      desc: descParts.join('\n'),
      tag: [nhTagNames(g?.tags, 'category', 1), nhTagNames(g?.tags, 'tag', 6), nhTagNames(g?.tags, 'language', 2)].join(' '),
      remarks: `${parseInt(g?.num_pages ?? 0, 10) || 0}页`,
      author: nhTagNames(g?.tags, 'artist', 3),
      chapters: pages,
      count: pages.length,
      adult: true,
    });
  }

  async pics(ref) {
    await nhInitCDN();
    const id = String(ref ?? '').trim();
    if (!id) throw new Error(`nhentai: 无效引用 "${ref}"`);
    const body = await httpGet(`${nhAPI}/galleries/${id}`, nhHeaders(), 20000);
    let g = null;
    try {
      g = JSON.parse(body);
    } catch {
      throw new Error('nhentai: JSON 解析失败');
    }
    const pics = [];
    for (const pg of Array.isArray(g?.pages) ? g.pages : []) {
      if (!pg?.path) continue;
      pics.push(`${nhImgBase}/${String(pg.path).replace(/^\//, '')}`);
    }
    if (pics.length === 0) throw new Error('nhentai: 章节无图片');
    return ComicPlay({ pics, referer: 'https://nhentai.net/', ua: nhUA });
  }
}

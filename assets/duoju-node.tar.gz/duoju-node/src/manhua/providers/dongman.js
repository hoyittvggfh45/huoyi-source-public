
import { httpGet, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay } from '../types.js';

const HOST = 'https://www.dongmanmanhua.cn';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';

const CATS = [
  ['LOVE', '恋爱'], ['COMEDY', '搞笑'], ['FANTASY', '奇幻'], ['SUSPENSE', '悬疑'],
  ['CAMPUS', '校园'], ['HEALING', '治愈'], ['BOY', '少年'], ['METROPOLIS', '都市'],
  ['INSPIRATIONAL', '励志'],
].map(([id, name]) => ({ id, name }));

function headers(ref) {
  const h = { 'User-Agent': UA, 'Accept-Language': 'zh-CN,zh;q=0.9' };
  if (ref) h.Referer = ref;
  return h;
}

const reDmCard = /<li[^>]*id="title_li_(\d+)"[^>]*>([\s\S]*?)<\/li>/gis;
const reDmCardHref = /href="[^"]*?\/(([A-Z]+)\/([^/"]+))\/list\?title_no=(\d+)"/i;
const reDmCardNo = /\/episodeList\?titleNo=(\d+)/i;
const reDmGenreSpan = /<span[^>]*class="genre[^"]*"[^>]*>([\s\S]*?)<\/span>/is;
const reDmSubj = /<p[^>]*class="subj"[^>]*>([\s\S]*?)<\/p>/is;
const reDmAuthor = /<p[^>]*class="author"[^>]*>([\s\S]*?)<\/p>/is;
const reDmImg = /<img[^>]+src="([^"]+)"/i;
const reDmOgProp = /<meta\s+property="og:(title|description|image)"\s+content="([^"]*)"/gi;
const reDmListUl = /<ul[^>]*id="_listUl"[^>]*>([\s\S]*?)<\/ul>/is;
const reDmLi = /<li[^>]*>([\s\S]*?)<\/li>/gis;
const reDmViewer = /href="([^"]*?viewer\?title_no=(\d+)&episode_no=(\d+))"/i;
const reDmChapSubj = /<span[^>]*class="subj"[^>]*>\s*<span>([\s\S]*?)<\/span>/is;
const reDmImageList = /<div[^>]*id="_imageList"[^>]*>([\s\S]*?)<\/div>\s*<\/div>/is;
const reDmDataURL = /data-url="([^"]+)"/gi;
const reDmCanonical = /<link[^>]*rel="canonical"[^>]*href="([^"]*)"/i;
const reDmPageNum = /[?&]page=(\d+)/gi;


let dmCache = null;
let dmCachedAt = 0;
const DM_STALE = 20 * 60 * 1000;

function abs(href) {
  href = String(href || '').trim();
  if (href.startsWith('//')) return 'https:' + href;
  if (href.startsWith('/')) return HOST + href;
  return href;
}

function genreID(name) {
  const n = String(name || '').trim();
  if (!n) return '';
  for (const c of CATS) {
    if (c.name.toLowerCase() === n.toLowerCase()) return c.id;
  }
  return n.toUpperCase();
}

function parseCards(page) {
  const out = [];
  const seen = new Set();
  for (const m of [...page.matchAll(reDmCard)]) {
    const block = m[2];
    let id = '';
    const h = block.match(reDmCardHref);
    if (h) {
      id = h[2].toUpperCase() + '/' + h[3] + '/' + h[4];
    } else {
      const h2 = block.match(reDmCardNo);
      if (h2) id = h2[1];
      else id = m[1].trim();
    }
    let key = id;
    const li = key.lastIndexOf('/');
    if (li >= 0) key = key.slice(li + 1);
    if (seen.has(key)) continue;
    const name = htmlText(firstGroup(reDmSubj, block));
    if (!name) continue;
    seen.add(key);
    const genreCN = htmlText(firstGroup(reDmGenreSpan, block));
    let catID = '';
    if (id.includes('/')) catID = id.split('/')[0];
    else catID = genreID(genreCN);
    out.push(Card({
      id,
      name,
      pic: firstGroup(reDmImg, block),
      author: htmlText(firstGroup(reDmAuthor, block)),
      remarks: '',
      cat: catID,
      plat: 'dongman',
    }));
  }
  return out;
}

async function genreCards() {
  if (dmCache && Date.now() - dmCachedAt < DM_STALE) return [...dmCache];
  let body;
  try {
    body = await httpGet(`${HOST}/genre`, headers(`${HOST}/`), 30000);
  } catch (err) {
    if (dmCache) return [...dmCache];
    throw err;
  }
  const cs = parseCards(body);
  if (cs.length === 0) throw new Error('dongman: 解析为空');
  dmCache = cs;
  dmCachedAt = Date.now();
  return [...cs];
}

function chaptersOf(body) {
  const out = [];
  let block = '';
  const m = body.match(reDmListUl);
  if (m) block = m[1];
  const seen = new Set();
  for (const li of [...block.matchAll(reDmLi)]) {
    const vm = li[1].match(reDmViewer);
    if (!vm) continue;
    if (seen.has(vm[3])) continue;
    seen.add(vm[3]);
    const no = parseInt(vm[3], 10) || 0;
    out.push({ no, name: htmlText(firstGroup(reDmChapSubj, li[1])), href: abs(vm[1]) });
  }
  return out;
}

async function resolve(id) {
  id = String(id || '').trim().replace(/^\/+|\/+$/g, '');
  const parts = id.split('/');
  if (parts.length >= 3) {
    return [parts.slice(0, parts.length - 1).join('/'), parts[parts.length - 1]];
  }
  let no = parts[0];
  const u = `${HOST}/episodeList?titleNo=${encode(no)}`;
  const body = await httpGet(u, headers(`${HOST}/`), 30000);
  const can = body.match(reDmCanonical);
  if (!can) throw new Error(`dongman: 无法确定作品路径 ${no}`);
  const pu = new URL(can[1].replace('http://', 'https://'));
  let p = pu.pathname.replace(/^\/+|\/+$/g, '');
  const li = p.indexOf('/list');
  if (li > 0) p = p.slice(0, li);
  const pp = p.split('/');
  if (pp.length < 2) throw new Error(`dongman: 作品路径解析失败 ${no}`);
  let path = p;
  if (/^\d+$/.test(pp[pp.length - 1])) path = pp.slice(0, pp.length - 1).join('/');
  const q = pu.searchParams.get('title_no');
  if (q) no = q;
  return [path, no];
}

function pageURL(path, no, page) {
  return `${HOST}/${path}/list?title_no=${no}&page=${page}`;
}

export class ProviderDongman {
  key() { return 'dongman'; }
  name() { return '咚漫'; }
  adult() { return false; }
  desc() {
    return '咚漫：Naver Webtoon 中国分站，韩国条漫/恋爱/悬疑/奇幻，服务端渲染直取，图片无防盗链';
  }

  cats() { return CATS; }

  listPaged() { return true; }
  searchPaged() { return false; }

  async list(cat, page) {
    let all = await genreCards();
    const key = String(cat || '').trim().toUpperCase();
    if (key && key !== 'ALL') {
      all = all.filter((c) => String(c.vod_class || '').toLowerCase() === key.toLowerCase());
    }
    const size = 30;
    if (page < 1) page = 1;
    const start = (page - 1) * size;
    if (start >= all.length) return { cards: [], hasMore: false };
    let end = start + size;
    let hasMore = false;
    if (end < all.length) hasMore = true;
    else end = all.length;
    return { cards: all.slice(start, end), hasMore };
  }

  async search(wd, page) {
    wd = String(wd || '').trim();
    if (!wd || page > 1) return { cards: [] };
    const u = `${HOST}/search?keyword=${encode(wd)}`;
    const body = await httpGet(u, headers(`${HOST}/`), 20000);
    return { cards: parseCards(body), hasMore: false };
  }

  async detail(id) {
    const [path, no] = await resolve(id);
    const fullID = `${path}/${no}`;
    const first = await httpGet(pageURL(path, no, 1), headers(`${HOST}/`), 30000);
    const book = { id: fullID, name: '', pic: '', desc: '', tag: '', remarks: '', author: '', chapters: [], count: 0 };
    for (const m of [...first.matchAll(reDmOgProp)]) {
      const prop = m[1].toLowerCase();
      if (prop === 'title') book.name = htmlText(m[2].trim().split('_')[0]);
      else if (prop === 'description') book.desc = htmlText(m[2]);
      else if (prop === 'image') book.pic = m[2].trim();
    }
    let all = chaptersOf(first);
    let total = 0;
    for (const c of all) if (c.no > total) total = c.no;
    let pages = 1;
    for (const m of [...first.matchAll(reDmPageNum)]) {
      const n = parseInt(m[1], 10);
      if (Number.isFinite(n) && n > pages) pages = n;
    }
    const est = Math.ceil((total + 9) / 10);
    if (est > pages) pages = est;
    if (pages > 40) pages = 40;
    if (pages > 1) {
      const jobs = [];
      for (let pg = 2; pg <= pages; pg++) jobs.push(pg);
      const CONC = 6;
      let idx = 0;
      const worker = async () => {
        for (;;) {
          const i = idx++;
          if (i >= jobs.length) return;
          const pg = jobs[i];
          try {
            const body = await httpGet(pageURL(path, no, pg), headers(`${HOST}/`), 30000);
            all = all.concat(chaptersOf(body));
          } catch {  }
        }
      };
      await Promise.all(Array.from({ length: Math.min(CONC, jobs.length) }, worker));
    }
    const seenNo = new Set();
    const uniq = [];
    for (const c of all) {
      if (c.no <= 0 || seenNo.has(c.no)) continue;
      seenNo.add(c.no);
      uniq.push(c);
    }
    uniq.sort((a, b) => a.no - b.no);
    book.chapters = uniq.map((c) => ({ no: c.no, name: c.name || `第 ${c.no} 话`, url: c.href }));
    book.count = book.chapters.length;
    if (book.chapters.length > 0) {
      book.remarks = '更新至 ' + book.chapters[book.chapters.length - 1].name;
    }
    const genre0 = path.split('/')[0];
    for (const c of CATS) {
      if (c.id.toLowerCase() === genre0.toLowerCase()) book.tag = c.name;
    }
    return BookDetail(book);
  }

  async pics(ref) {
    const u = abs(ref);
    const body = await httpGet(u, headers(`${HOST}/`), 30000);
    let imageList = '';
    const m = body.match(reDmImageList);
    if (m) imageList = m[1];
    if (!imageList) imageList = body;
    const out = [];
    const seen = new Set();
    for (const dm of [...imageList.matchAll(reDmDataURL)]) {
      const p = dm[1].trim();
      if (!p || seen.has(p)) continue;
      seen.add(p);
      out.push(p);
    }
    if (out.length === 0) throw new Error('dongman: 解析为空');
    return ComicPlay({ pics: out, referer: `${HOST}/`, ua: UA });
  }
}

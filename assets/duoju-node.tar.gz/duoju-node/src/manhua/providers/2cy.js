
import { httpGet, httpPostForm, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay } from '../types.js';

const HOST = 'https://2cycomic.com';
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_3 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13E230 Safari/601.1';
const PIC_BATCH = 10;

function headers(ref) {
  if (!ref) ref = `${HOST}/`;
  return { 'User-Agent': UA, Referer: ref };
}

const CATS = [
  '全部', '冒险', '热血', '奇幻', '都市', '悬疑', '搞笑', '恋爱', '爱情', '古风',
  '穿越', '校园', '科幻', '治愈', '美食', '格斗', '剧情', '历史', '战争', '侦探',
  '神鬼', '生活', '职场', '竞技', '萌系', '励志', '欢乐向', '异世界', '轻小说', '长条',
  '大女主', '霸总', '耽美', '百合', '纯爱', '後宫', '韩漫', '伪娘', '性转换', '节操',
].map((n) => ({ id: n, name: n }));

const reCyCard = /<li[^>]*class="[^"]*comic-item[^"]*"[^>]*>([\s\S]*?)<\/li>/gis;
const reCyLink = /<a[^>]*href="(\/book\/\d+\/)"[^>]*title="([^"]*)"/is;
const reCyImg = /<img[^>]*class="[^"]*\bimg\b[^"]*"[^>]*src="([^"]+)"/is;
const reCyImg2 = /<img[^>]*src="([^"]+)"/is;
const reCyDesc = /class="[^"]*(?:chapter|subtitle|desc)[^"]*"[^>]*>([^<]*)</is;

const reCyOGName = /<meta[^>]*property="og:novel:book_name"[^>]*content="([^"]*)"/is;
const reCyOGImg = /<meta[^>]*property="og:image"[^>]*content="([^"]*)"/is;
const reCyOGDesc = /<meta[^>]*property="og:description"[^>]*content="([^"]*)"/is;
const reCyOGAuth = /<meta[^>]*property="og:novel:author"[^>]*content="([^"]*)"/is;
const reCyOGStat = /<meta[^>]*property="og:novel:status"[^>]*content="([^"]*)"/is;
const reCyChapA = /<a[^>]*href="\/chapter\/(\d+)\/(\d+)\.html"[^>]*>([\s\S]*?)<\/a>/gis;
const reCyPicCnt = /picCount\s*:\s*(\d+)/;

function allMatches(re, s) {
  return [...String(s).matchAll(re)];
}

function parseCards(page) {
  const out = [];
  const seen = new Set();
  for (const m of allMatches(reCyCard, page)) {
    const blk = m[1];
    const lm = blk.match(reCyLink);
    if (!lm) continue;
    const id = lm[1].replace(/^\/book\//, '').replace(/\//g, '').trim();
    const name = lm[2].split(',')[0].trim();
    if (!id || !name || seen.has(id)) continue;
    seen.add(id);
    let pic = firstGroup(reCyImg, blk);
    if (!pic) pic = firstGroup(reCyImg2, blk);
    out.push(Card({ id, name, pic, remarks: htmlText(firstGroup(reCyDesc, blk)), plat: '2cy' }));
  }
  return out;
}


function pathEscape(s) {
  return encodeURIComponent(s).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
}

export class Provider2cy {
  key() { return '2cy'; }
  name() { return '次元漫画'; }
  desc() { return '2cycomic.com HTML + 分批取图接口'; }
  adult() { return false; }

  cats() { return CATS; }

  listPaged() { return true; }
  searchPaged() { return false; }

  
  async fetchCards(u, attempts = 4) {
    let cards = [];
    for (let i = 0; i < attempts; i++) {
      const body = await httpGet(u, headers(''), 15000);
      cards = parseCards(body);
      if (cards.length > 0) return cards;
    }
    return cards;
  }

  async list(cat, page) {
    if (!String(cat || '').trim()) cat = '全部';
    if (page < 1) page = 1;
    const u = `${HOST}/booklists/9/${pathEscape(cat)}/3/${page}.html`;
    const cards = await this.fetchCards(u);
    return { cards, hasMore: cards.length >= 10 };
  }

  async search(wd, page) {
    if (page > 1) return { cards: [] };
    const u = `${HOST}/search?searchkey=${encode(wd)}`;
    return { cards: await this.fetchCards(u), hasMore: false };
  }

  async detail(id) {
    id = String(id || '').trim();
    const u = `${HOST}/book/${encode(id)}/`;
    const page = await httpGet(u, headers(''), 20000);
    const name = firstGroup(reCyOGName, page);
    if (!name) throw new Error('2cy: 详情解析失败');
    const chapters = [];
    const seen = new Set();
    for (const m of allMatches(reCyChapA, page)) {
      const [, bookID, chID, raw] = m;
      if (!chID || seen.has(chID)) continue;
      const chName = htmlText(raw);
      if (!chName) continue;
      seen.add(chID);
      chapters.push({ no: chapters.length + 1, name: chName, url: `${bookID}|${chID}` });
    }
    let remarks = firstGroup(reCyOGStat, page).trim();
    remarks = remarks ? `${remarks} · ${chapters.length} 话` : `${chapters.length} 话`;
    return BookDetail({
      id,
      name: name.replace(/漫画$/, ''),
      pic: firstGroup(reCyOGImg, page),
      desc: firstGroup(reCyOGDesc, page),
      tag: '漫画',
      remarks,
      author: firstGroup(reCyOGAuth, page),
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const parts = String(ref || '').trim().split('|');
    if (parts.length !== 2 || !parts[0] || !parts[1]) {
      throw new Error(`2cy: 非法章节凭证 ${ref}`);
    }
    const [bookID, chID] = parts;
    const chapURL = `${HOST}/chapter/${encode(bookID)}/${encode(chID)}.html`;

    let total = 0;
    try {
      const page = await httpGet(chapURL, headers(''), 15000);
      const m = page.match(reCyPicCnt);
      if (m) total = parseInt(m[1], 10) || 0;
    } catch {  }

    const pics = [];
    for (let offset = 0; offset < 5000; offset += PIC_BATCH) {
      if (total > 0 && offset >= total) break;
      const form = `id=${encode(chID)}&aid=${encode(bookID)}&offset=${offset}&limit=${PIC_BATCH}`;
      const hdrs = headers(chapURL);
      hdrs['X-Requested-With'] = 'XMLHttpRequest';
      let body;
      try {
        body = await httpPostForm(`${HOST}/api/comic/read/pics`, form, hdrs, 15000);
      } catch {
        break;
      }
      let resp;
      try {
        resp = JSON.parse(body);
      } catch {
        break;
      }
      const batch = (resp.data && resp.data.pic) || [];
      for (const it of batch) {
        const v = String(it.pic || '').trim();
        if (v) pics.push(v);
      }
      if (batch.length < PIC_BATCH) break;
    }
    if (pics.length === 0) throw new Error('2cy: 章节无图片');
    return ComicPlay({ pics, referer: chapURL, ua: UA });
  }
}

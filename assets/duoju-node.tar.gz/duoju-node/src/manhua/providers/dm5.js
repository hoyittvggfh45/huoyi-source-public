
import { httpGet, httpPostForm, encode, firstNonEmpty } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay } from '../types.js';



const reDM5Pack = /eval\(function\(p,a,c,k,e,d\)\{[\s\S]*?\}\('(.*?)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'(.*?)'\s*\.split\('\|'\)/s;

function dm5Digit(x) {
  if (x > 35) return String.fromCharCode(x + 29);
  const alphabet = '0123456789abcdefghijklmnopqrstuvwxyz';
  if (x < 0 || x >= alphabet.length) return '';
  return alphabet[x];
}

function dm5BaseN(c, a) {
  if (c < a) return dm5Digit(c % a);
  return dm5BaseN(Math.floor(c / a), a) + dm5Digit(c % a);
}

function quoteMeta(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function dm5Unpack(src) {
  const m = src.match(reDM5Pack);
  if (!m) return '';
  const payload = m[1].replace(/\\'/g, "'").replace(/\\\\/g, '\\');
  const a = parseInt(m[2], 10) || 0;
  const c = parseInt(m[3], 10) || 0;
  const words = m[4].split('|');
  let out = payload;
  for (let i = c - 1; i >= 0; i--) {
    if (i >= words.length || words[i] === '') continue;
    const re = new RegExp(`\\b${quoteMeta(dm5BaseN(i, a))}\\b`, 'g');
    out = out.replace(re, words[i]);
  }
  return out;
}



const reDM5CardID = /href="\/manhua(\d+)\//;
const reDM5CardImg = /<img[^>]*\bsrc="(https?:\/\/[^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"/is;
const reDM5CardTitle = /title="([^"]{1,80})"/is;
const reDM5CardA = /<a[^>]*href="\/manhua\d+\/"[^>]*>([\s\S]{0,200}?)<\/a>/is;
const reDM5CardClass = /class="[^"]*title[^"]*"[^>]*>\s*<a[^>]*>([\s\S]{0,200}?)<\/a>/is;

function dm5Blocks(page, marker) {
  const out = [];
  let idx = 0;
  for (;;) {
    const i = page.indexOf(marker, idx);
    if (i < 0) break;
    const start = i;
    const next = start + marker.length;
    let end = page.length;
    const j = page.indexOf(marker, next);
    if (j >= 0) end = j;
    out.push(page.slice(start, end));
    idx = next;
  }
  return out;
}

function dm5CardsFromBlocks(blocks, plat) {
  const out = [];
  const seen = new Set();
  for (const blk of blocks) {
    const m = blk.match(reDM5CardID);
    if (!m) continue;
    const id = m[1];
    if (!id || seen.has(id)) continue;
    const pic = firstGroup(reDM5CardImg, blk);
    if (!pic) continue;
    let name = htmlText(firstGroup(reDM5CardTitle, blk));
    if (!name) name = htmlText(firstGroup(reDM5CardA, blk));
    if (!name) name = htmlText(firstGroup(reDM5CardClass, blk));
    if (!name) continue;
    seen.add(id);
    out.push(Card({ id, name, pic, plat }));
  }
  return out;
}

function dm5PageURL(base, page) {
  if (page <= 1) return base;
  base = base.replace(/\/$/, '');
  return `${base}-p${page}/`;
}

const KKK_UA = 'Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

function dm5Headers(ref, host) {
  if (!ref) ref = `${host}/`;
  return { 'User-Agent': KKK_UA, Referer: ref };
}



const KKK_HOST = 'https://www.1kkk.com';

const KKK_CATS = [
  ['/manhua-new/', '最近更新'],
  ['/manhua-rank/', '排行榜'],
  ['/manhua-completed/', '已完结'],
  ['/manhua-rexue/', '热血'],
  ['/manhua-maoxian/', '冒险'],
  ['/manhua-gaoxiao/', '搞笑'],
  ['/manhua-shounen/', '少年'],
  ['/manhua-shoujo/', '少女'],
  ['/manhua-jpkr/', '日韩'],
  ['/manhua-original/', '原创'],
].map(([id, name]) => ({ id, name }));

const reKkkName = /class="detail-main-info-title"[^>]*>([\s\S]*?)<\/p>/is;
const reKkkAuthor = /class="detail-main-info-author"[^>]*>作者[：:][\s\S]{0,120}?<a[^>]*>([^<]*)</is;
const reKkkStatus = /class="detail-list-title-1"[^>]*>([^<]*)</is;
const reKkkDesc = /class="detail-desc"[^>]*>([\s\S]*?)<\/p>/is;
const reKkkChap = /<a[^>]*href="\/ch(\d+)-(\d+)\/"[^>]*class="chapteritem"[^>]*>([\s\S]*?)<\/a>/gis;
const reKkkChap2 = /<a[^>]*class="chapteritem"[^>]*href="\/ch(\d+)-(\d+)\/"[^>]*>([\s\S]*?)<\/a>/gis;
const reKkkChapOther = /<a[^>]*href="\/(other\d+)\/"[^>]*class="chapteritem"[^>]*>([\s\S]*?)<\/a>/gis;
const reKkkChapOther2 = /<a[^>]*class="chapteritem"[^>]*href="\/(other\d+)\/"[^>]*>([\s\S]*?)<\/a>/gis;
const reKkkCover = /<img[^>]*src="(https?:\/\/[^"]*cdndm5[^"]*)"/gis;
const reKkkNewImgs = /newImgs\s*=\s*\[(.*?)\]/s;
const reQuotedSingle = /'([^']+)'/g;

export class Provider1kkk {
  key() { return '1kkk'; }
  name() { return '极速漫画'; }
  desc() { return '1kkk.com 移动版（图链内联，DM5 图床）'; }
  adult() { return false; }

  cats() { return KKK_CATS; }

  listPaged() { return true; }
  searchPaged() { return false; }

  async list(cat, page) {
    if (!String(cat || '').trim() || !String(cat).startsWith('/manhua')) cat = '/manhua-new/';
    if (page < 1) page = 1;
    const body = await httpGet(KKK_HOST + dm5PageURL(cat, page), dm5Headers('', KKK_HOST), 20000);
    const cs = dm5CardsFromBlocks(dm5Blocks(body, '<li>'), '1kkk');
    return { cards: cs, hasMore: cs.length >= 12 };
  }

  async search(wd, page) {
    if (page > 1) return { cards: [] };
    const u = `${KKK_HOST}/search?title=${encode(String(wd || '').trim())}`;
    const body = await httpGet(u, dm5Headers(`${KKK_HOST}/`, KKK_HOST), 20000);
    return { cards: dm5CardsFromBlocks(dm5Blocks(body, '<div class="book-list-cover">'), '1kkk'), hasMore: false };
  }

  async detail(id) {
    id = String(id || '').trim();
    const u = `${KKK_HOST}/manhua${encode(id)}/`;
    const page = await httpGet(u, dm5Headers('', KKK_HOST), 25000);
    const name = htmlText(firstGroup(reKkkName, page));
    if (!name) throw new Error('1kkk: 详情解析失败');
    const chapters = [];
    const seen = new Set();
    const addChap = (ref, nm) => {
      nm = htmlText(nm);
      if (!ref || !nm || seen.has(ref)) return;
      seen.add(ref);
      chapters.push({ no: chapters.length + 1, name: nm, url: ref });
    };
    for (const re of [reKkkChap, reKkkChap2]) {
      for (const m of [...page.matchAll(re)]) addChap(`ch${m[1]}-${m[2]}`, m[3]);
      if (chapters.length > 0) break;
    }
    if (chapters.length === 0) {
      for (const re of [reKkkChapOther, reKkkChapOther2]) {
        for (const m of [...page.matchAll(re)]) addChap(m[1], m[2]);
        if (chapters.length > 0) break;
      }
    }
    chapters.reverse();
    chapters.forEach((c, i) => { c.no = i + 1; });
    let remarks = htmlText(firstGroup(reKkkStatus, page));
    remarks = remarks ? `${remarks} · ${chapters.length} 话` : `${chapters.length} 话`;

    let pic = '';
    for (const m of [...page.matchAll(reKkkCover)]) {
      if (m[1].includes(`/${id}/`) || m[1].includes(`/${id}_`)) {
        pic = m[1];
        break;
      }
    }
    if (!pic) pic = firstGroup(reKkkCover, page);
    return BookDetail({
      id, name, pic,
      desc: htmlText(firstGroup(reKkkDesc, page)),
      tag: '漫画',
      remarks,
      author: htmlText(firstGroup(reKkkAuthor, page)),
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const path = String(ref || '').trim().replace(/^\/+|\/+$/g, '');
    if (!path) throw new Error(`1kkk: 非法章节凭证 ${ref}`);
    const chapURL = `${KKK_HOST}/${path}/`;
    const page = await httpGet(chapURL, dm5Headers('', KKK_HOST), 40000);
    const up = dm5Unpack(page);
    const arr = firstGroup(reKkkNewImgs, up);
    if (!arr) throw new Error('1kkk: 章节无图片');
    const pics = [];
    const seen = new Set();
    for (const m of [...arr.matchAll(/'(https?:\/\/[^']+)'/g)]) {
      const v = m[1].replace(/&amp;/g, '&');
      if (!v || seen.has(v)) continue;
      seen.add(v);
      pics.push(v);
    }
    if (pics.length === 0) throw new Error('1kkk: 章节无图片');
    return ComicPlay({ pics, referer: chapURL, ua: KKK_UA });
  }
}



const GMH_HOST = 'https://www.gmanhua.com';

const GMH_CATS = [
  ['/manhua-new/', '最近更新'],
  ['/manhua-updated/', '连载中'],
  ['/manhua-completed/', '已完结'],
  ['/manhua-shaonianrexue/', '少年热血'],
  ['/manhua-shaonvaiqing/', '少女爱情'],
  ['/manhua-wuxiagedou/', '武侠格斗'],
  ['/manhua-kehuanmohuan/', '科幻魔幻'],
  ['/manhua-baoxiaoxiju/', '爆笑喜剧'],
  ['/manhua-zhentantuili/', '侦探推理'],
  ['/manhua-jingjitiyu/', '竞技体育'],
  ['/manhua-china/', '中国'],
  ['/manhua-jpkr/', '日韩'],
  ['/manhua-hktw/', '港台'],
  ['/manhua-euus/', '欧美'],
  ['/top/', '排行榜'],
].map(([id, name]) => ({ id, name }));

const reGmhName = /<h1>\s*<a[^>]*title="([^"]*)"/is;
const reGmhDesc = /<meta[^>]*name="Description"[^>]*content="([^"]*)"/is;
const reGmhDesc2 = /<meta[^>]*content="([^"]*)"[^>]*name="Description"/is;
const reGmhAuthor = /作者[：:]\s*<a[^>]*>([^<]*)</is;
const reGmhStatus = /状态[：:]\s*(连载中|已完结)/is;
const reGmhChap = /<a[^>]*class="tg"[^>]*href="\/((?:ch|other|vol)\d+[-\d]*)\/"[^>]*>([\s\S]*?)<\/a>/gis;
const reGmhChap2 = /<a[^>]*href="\/((?:ch|other|vol)\d+[-\d]*)\/"[^>]*>\s*([^<]{1,60}?)\s*</is;
const reGmhCover = /<img[^>]*src="(https?:\/\/[^"]*cdndm5[^"]*)"/is;
const reGmhGuid = /var\s+guidkey\s*=\s*([\s\S]*?);/s;
const reGmhCID = /DM5_CID\s*=\s*(\d+)/;
const reGmhPix = /pix\s*=\s*"([^"]*)"/;
const reGmhPvalue = /pvalue\s*=\s*\[(.*?)\]/s;
const reGmhSuffix = /pvalue\[i\]\s*=\s*pix\s*\+\s*pvalue\[i\]\s*\+\s*'([^']*)'/;
const reQuotedDouble = /"([^"]+)"/g;

export class ProviderGmanhua {
  key() { return 'gmanhua'; }
  name() { return 'G漫画'; }
  desc() { return 'gmanhua.com（PC 版 + chapterimagefun 换图，DM5 图床）'; }
  adult() { return false; }

  cats() { return GMH_CATS; }

  listPaged() { return true; }
  searchPaged() { return false; }

  async list(cat, page) {
    if (!String(cat || '').trim() || (!String(cat).startsWith('/manhua') && cat !== '/top/')) cat = '/manhua-new/';
    if (page < 1) page = 1;
    const body = await httpGet(GMH_HOST + dm5PageURL(cat, page), dm5Headers('', GMH_HOST), 20000);
    const cs = dm5CardsFromBlocks(dm5Blocks(body, '<p class="cover">'), 'gmanhua');
    return { cards: cs, hasMore: cs.length >= 12 };
  }

  async search(wd, page) {
    if (page > 1) return { cards: [] };
    const u = `${GMH_HOST}/search?title=${encode(String(wd || '').trim())}`;
    const body = await httpGet(u, dm5Headers(`${GMH_HOST}/`, GMH_HOST), 20000);
    return { cards: dm5CardsFromBlocks(dm5Blocks(body, '<div class="ssnrk">'), 'gmanhua'), hasMore: false };
  }

  async detail(id) {
    id = String(id || '').trim();
    const u = `${GMH_HOST}/manhua${encode(id)}/`;
    const page = await httpGet(u, dm5Headers('', GMH_HOST), 25000);
    const name = htmlText(firstGroup(reGmhName, page));
    if (!name) throw new Error('gmanhua: 详情解析失败');
    const chapters = [];
    const seen = new Set();
    for (const m of [...page.matchAll(reGmhChap)]) {
      const key = m[1];
      const chName = htmlText(m[2]);
      if (!key || !chName || seen.has(key)) continue;
      seen.add(key);
      chapters.push({ no: 0, name: chName, url: key });
    }
    if (chapters.length === 0) {
      for (const m of [...page.matchAll(reGmhChap2)]) {
        const key = m[1];
        const chName = htmlText(m[2]);
        if (!key || !chName || seen.has(key)) continue;
        seen.add(key);
        chapters.push({ no: 0, name: chName, url: key });
      }
    }
    chapters.reverse();
    chapters.forEach((c, i) => { c.no = i + 1; });
    let desc = firstNonEmpty(firstGroup(reGmhDesc, page), firstGroup(reGmhDesc2, page));
    const di = desc.indexOf('简介：');
    if (di >= 0) desc = desc.slice(di + '简介：'.length);
    desc = desc.trim();
    let remarks = htmlText(firstGroup(reGmhStatus, page));
    remarks = remarks ? `${remarks} · ${chapters.length} 话` : `${chapters.length} 话`;
    return BookDetail({
      id, name,
      pic: firstGroup(reGmhCover, page),
      desc, tag: '漫画', remarks,
      author: htmlText(firstGroup(reGmhAuthor, page)),
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const path = String(ref || '').trim().replace(/^\/+|\/+$/g, '');
    if (!path) throw new Error(`gmanhua: 非法章节凭证 ${ref}`);
    const chapURL = `${GMH_HOST}/${path}/`;
    const page = await httpGet(chapURL, dm5Headers('', GMH_HOST), 40000);
    const up = dm5Unpack(page);

    let key = '';
    const km = up.match(reGmhGuid);
    if (km) {
      for (const q of [...km[1].matchAll(reQuotedSingle)]) key += q[1];
    }
    const cid = firstGroup(reGmhCID, page);
    if (!key || !cid) throw new Error('gmanhua: 章节凭证解析失败');
    const form = `cid=${encode(cid)}&page=1&key=${encode(key)}&showcount=64`;
    const hdrs = dm5Headers(chapURL, GMH_HOST);
    hdrs['X-Requested-With'] = 'XMLHttpRequest';
    const body = await httpPostForm(`${GMH_HOST}/chapterimagefun.ashx`, form, hdrs, 20000);
    const uin = dm5Unpack(body);
    const pix = firstGroup(reGmhPix, uin);
    const arr = firstGroup(reGmhPvalue, uin);
    const suffix = firstGroup(reGmhSuffix, uin);
    if (!pix || !arr) throw new Error('gmanhua: 章节无图片');
    const pics = [];
    const seen = new Set();
    for (const m of [...arr.matchAll(reQuotedDouble)]) {
      const v = pix + m[1] + suffix;
      if (seen.has(v)) continue;
      seen.add(v);
      pics.push(v);
    }
    if (pics.length === 0) throw new Error('gmanhua: 章节无图片');
    return ComicPlay({ pics, referer: chapURL, ua: KKK_UA });
  }
}

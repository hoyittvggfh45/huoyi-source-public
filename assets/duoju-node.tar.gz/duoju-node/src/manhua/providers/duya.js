
import { httpGet, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay } from '../types.js';

const HOST = 'https://www.duya.cc';
const UA = 'Mozilla/5.0 (Linux; Android 8.1.0; JKM-AL00b) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.126 MQQBrowser/6.2 TBS/044807 Mobile Safari/537.36';

function headers(ref) {
  if (!ref) ref = `${HOST}/`;
  return { 'User-Agent': UA, Referer: ref };
}

const CATS = [
  ['home', '首页推荐', '/'],
  ['top0', '阅读总榜', '/top.html?type=0'],
  ['top1', '最新上新', '/top.html?type=1'],
  ['top2', '最新更新', '/top.html?type=2'],
  ['top3', '日阅读榜', '/top.html?type=3'],
  ['top4', '周阅读榜', '/top.html?type=4'],
];

const reDyJpItem = /<li[^>]*class="comic-item-jp"[^>]*>([\s\S]*?)<\/li>/gis;
const reDyJpHref = /<a[^>]*href="(\/comic\/[A-Za-z0-9]+\/)"/is;
const reDyJpDes = /<p[^>]*class="comic-des"[^>]*>([\s\S]*?)<\/p>/is;
const reDyJpIntro = /<p[^>]*class="comic-name"[^>]*>([\s\S]*?)<\/p>/is;
const reDyStyleU = /url\(\s*['"]?([^'")]+)['"]?\s*\)/is;
const reDyNItem = /<a[^>]*href="(\/comic\/[A-Za-z0-9]+\/)"[^>]*>([\s\S]*?)<\/a>/gis;
const reDyNTit = /class="[^"]*nmain_cl_tit[^"]*"[^>]*>([\s\S]*?)<\/div>/is;
const reDyNAuth = /class="[^"]*nmain_cl_author[^"]*"[^>]*>([\s\S]*?)<\/div>/is;
const reDyNNewc = /class="[^"]*nmain_cl_newc[^"]*"[^>]*>([\s\S]*?)<\/div>/is;
const reDyDataS = /<img[^>]*data-src="([^"]+)"/is;
const reDyOGName = /<meta[^>]*property="og:novel:book_name"[^>]*content="([^"]*)"/is;
const reDyOGName2 = /<meta[^>]*content="([^"]*)"[^>]*property="og:novel:book_name"/is;
const reDyOGImg = /<meta[^>]*property="og:image"[^>]*content="([^"]*)"/is;
const reDyOGDesc = /<meta[^>]*property="og:description"[^>]*content="([^"]*)"/is;
const reDyOGAuth = /<meta[^>]*property="og:novel:author"[^>]*content="([^"]*)"/is;
const reDyChapBox = /<ul[^>]*id="ncp3_ul"[^>]*>([\s\S]*?)<\/ul>/is;
const reDyChapLi = /<a[^>]*href="(\/comic\/[A-Za-z0-9]+\/\d+\.html)"[^>]*>([\s\S]*?)<\/a>/gis;
const reDyTitDiv = /class="[^"]*ncp3li_title[^"]*"[^>]*>([\s\S]*?)<\/div>/is;
const reDyLazyImg = /<img[^>]*class="[^"]*lazy[^"]*"[^>]*data-original="([^"]+)"/gis;

function slug(href) {
  return String(href || '').replace(/^\/comic\//, '').replace(/^\/+|\/+$/g, '');
}

function parseJp(page) {
  const out = [];
  for (const m of [...page.matchAll(reDyJpItem)]) {
    const blk = m[1];
    const id = slug(firstGroup(reDyJpHref, blk));
    const name = htmlText(firstGroup(reDyJpDes, blk));
    if (!id || !name) continue;
    let pic = firstGroup(reDyDataS, blk);
    if (!pic) pic = firstGroup(reDyStyleU, blk);
    out.push(Card({
      id, name, pic,
      remarks: htmlText(firstGroup(reDyJpIntro, blk)),
      plat: 'duya',
    }));
  }
  return out;
}

function parseList(page) {
  const out = [];
  const seen = new Set();
  for (const m of [...page.matchAll(reDyNItem)]) {
    const id = slug(m[1]);
    const blk = m[2];
    if (!id || seen.has(id)) continue;
    const name = htmlText(firstGroup(reDyNTit, blk));
    if (!name) continue;
    seen.add(id);
    out.push(Card({
      id, name,
      pic: firstGroup(reDyDataS, blk),
      author: htmlText(firstGroup(reDyNAuth, blk)).replace(/^作者：/, '').trim(),
      remarks: htmlText(firstGroup(reDyNNewc, blk)).replace(/^更新至：/, '').trim(),
      plat: 'duya',
    }));
  }
  return out;
}

export class ProviderDuya {
  key() { return 'duya'; }
  name() { return '毒牙漫画'; }
  desc() { return 'duya.cc HTML（仅直连可用）'; }
  adult() { return false; }

  cats() { return CATS.map(([id, name]) => ({ id, name })); }

  listPaged() { return false; }
  searchPaged() { return false; }

  async list(cat) {
    let path = '/';
    for (const [id, , p] of CATS) {
      if (id === cat) { path = p; break; }
    }
    const body = await httpGet(HOST + path, headers(''), 15000);
    let cs = parseJp(body);
    if (cs.length === 0) cs = parseList(body);
    return { cards: cs, hasMore: false };
  }

  async search(wd, page) {
    if (page > 1) return { cards: [] };
    const u = `${HOST}/c3d?searchkey=${encode(wd)}`;
    const body = await httpGet(u, headers(''), 15000);
    let cs = parseList(body);
    if (cs.length === 0) cs = parseJp(body);
    return { cards: cs, hasMore: false };
  }

  async detail(id) {
    const u = `${HOST}/comic/${encode(id)}/`;
    const page = await httpGet(u, headers(''), 15000);
    let name = firstGroup(reDyOGName, page);
    if (!name) name = firstGroup(reDyOGName2, page);
    if (!name) throw new Error('duya: 详情解析失败');

    const box = firstGroup(reDyChapBox, page);
    const chapters = [];
    const seen = new Set();
    for (const m of [...box.matchAll(reDyChapLi)]) {
      const href = m[1];
      if (seen.has(href)) continue;
      let chName = htmlText(firstGroup(reDyTitDiv, m[2]));
      if (!chName) chName = htmlText(m[2]);
      if (!chName) continue;
      seen.add(href);
      chapters.push({ no: 0, name: chName, url: HOST + href });
    }
    chapters.forEach((c, i) => { c.no = i + 1; });
    return BookDetail({
      id,
      name: name.replace(/漫画$/, ''),
      pic: firstGroup(reDyOGImg, page),
      desc: firstGroup(reDyOGDesc, page),
      tag: '漫画',
      remarks: `${chapters.length} 话`,
      author: firstGroup(reDyOGAuth, page),
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    let u = String(ref || '').trim();
    if (!u.startsWith('http')) u = HOST + u;
    const page = await httpGet(u, headers(u), 20000);
    const out = [];
    const seen = new Set();
    for (const m of [...page.matchAll(reDyLazyImg)]) {
      const v = m[1].trim();
      if (!v || seen.has(v)) continue;
      seen.add(v);
      out.push(v);
    }
    if (out.length === 0) throw new Error('duya: 章节无图片');
    return ComicPlay({ pics: out, referer: u, ua: UA });
  }
}

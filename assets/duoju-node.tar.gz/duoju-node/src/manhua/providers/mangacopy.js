
import { httpGet, encode } from '../core/http.js';
import { BookDetail, ComicPlay, Chapter } from '../types.js';

const mcHost = 'https://api.copy4000.com';
const mcWeb = 'https://www.mangacopy.com/';
const mcUA = 'Mozilla/5.0 (Linux; Android 8.1.0; JKM-AL00b) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.126 MQQBrowser/6.2 TBS/044807 Mobile Safari/537.36';
const mcSize = 21;
const mcChapterLimit = 100;

function mcHeaders() {
  return {
    'User-Agent': mcUA,
    Referer: mcWeb,
    Accept: 'application/json',
    platform: '1',
    version: '9.9.9',
  };
}

const mangacopyCats = [
  { id: 'new', name: '最近更新', ordering: '-datetime_updated' },
  { id: 'hot', name: '最多人看', ordering: '-popular' },
];

function mcAuthorNames(list) {
  const names = [];
  for (const a of Array.isArray(list) ? list : []) {
    const s = String(a?.name ?? '').trim();
    if (s) names.push(s);
  }
  return names;
}

function mcListItemCard(it) {
  return {
    id: String(it?.path_word ?? '').trim(),
    name: String(it?.name ?? '').trim(),
    pic: String(it?.cover ?? '').trim(),
    author: mcAuthorNames(it?.author).join(' / '),
    plat: 'mangacopy',
  };
}

async function mcListCall(u, page) {
  const body = await httpGet(u, mcHeaders(), 15000);
  let resp = null;
  try {
    resp = JSON.parse(body);
  } catch {
    throw new Error('mangacopy: 非 JSON 响应');
  }
  const list = resp?.results?.list;
  const total = parseInt(resp?.results?.total ?? 0, 10) || 0;
  const out = [];
  for (const it of Array.isArray(list) ? list : []) {
    const c = mcListItemCard(it);
    if (c.name) out.push(c);
  }
  let hasMore = out.length >= mcSize;
  if (total > 0) hasMore = page * mcSize < total;
  return { cards: out, hasMore };
}

export class ProviderMangacopy {
  key() { return 'mangacopy'; }
  name() { return '拷贝漫画'; }
  desc() { return 'mangacopy.com 官方 API（大陆无障碍线路）'; }
  adult() { return false; }

  cats() {
    return mangacopyCats.map((c) => ({ id: c.id, name: c.name }));
  }

  async list(cat, page) {
    if (page < 1) page = 1;
    let ordering = '-datetime_updated';
    for (const c of mangacopyCats) {
      if (c.id === cat) {
        ordering = c.ordering;
        break;
      }
    }
    const u = `${mcHost}/api/v3/comics?ordering=${ordering}&limit=${mcSize}&offset=${(page - 1) * mcSize}&free_type=1&_update=true`;
    return mcListCall(u, page);
  }

  async search(wd, page) {
    if (page < 1) page = 1;
    const u = `${mcHost}/api/v3/search/comic?q=${encode(wd)}&limit=${mcSize}&offset=${(page - 1) * mcSize}`;
    return mcListCall(u, page);
  }

  async chapters(pw) {
    const all = [];
    for (let offset = 0; offset < 5000; offset += mcChapterLimit) {
      const u = `${mcHost}/api/v3/comic/${encode(pw)}/group/default/chapters?limit=${mcChapterLimit}&offset=${offset}`;
      const body = await httpGet(u, mcHeaders(), 15000);
      let resp = null;
      try {
        resp = JSON.parse(body);
      } catch {
        throw new Error('mangacopy: 章节解析失败');
      }
      const list = resp?.results?.list;
      const total = parseInt(resp?.results?.total ?? 0, 10) || 0;
      const items = Array.isArray(list) ? list : [];
      if (items.length === 0) break;
      all.push(...items);
      if (total > 0 && all.length >= total) break;
    }
    const chapters = [];
    for (let i = 0; i < all.length; i++) {
      const uuid = String(all[i]?.uuid ?? '').trim();
      if (!uuid) continue;
      chapters.push(Chapter(i + 1, String(all[i]?.name ?? '').trim(), `${pw}|${uuid}`));
    }
    return chapters;
  }

  async detail(id) {
    const u = `${mcHost}/api/v3/comic2/${encode(id)}?platform=1&_update=true`;
    const body = await httpGet(u, mcHeaders(), 15000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('mangacopy: 详情解析失败');
    }
    const c = resp?.results?.comic ?? {};
    const name = String(c?.name ?? '').trim();
    if (!name) throw new Error('mangacopy: 详情为空');
    const chapters = await this.chapters(id);
    const themes = [];
    for (const t of Array.isArray(c?.theme) ? c.theme : []) {
      const s = String(t?.name ?? '').trim();
      if (s) themes.push(s);
    }
    return BookDetail({
      id,
      name,
      pic: String(c?.cover ?? '').trim(),
      desc: String(c?.brief ?? '').trim(),
      tag: themes.join(' / '),
      remarks: `${chapters.length} 话`,
      author: mcAuthorNames(c?.author).join(' / '),
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const parts = String(ref ?? '').trim().split('|');
    if (parts.length < 2 || !parts[0] || !parts[1]) {
      throw new Error(`mangacopy: 非法章节凭证 ${ref}`);
    }
    const u = `${mcHost}/api/v3/comic/${encode(parts[0])}/chapter2/${encode(parts[1])}?in_mainland=true&platform=1`;
    const body = await httpGet(u, mcHeaders(), 25000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('mangacopy: 章节解析失败');
    }
    const contents = resp?.results?.chapter?.contents;
    const out = [];
    for (const it of Array.isArray(contents) ? contents : []) {
      const v = String(it?.url ?? '').trim();
      if (v) out.push(v);
    }
    if (out.length === 0) throw new Error('mangacopy: 章节无图片（可能需要会员）');
    return ComicPlay({ pics: out, referer: mcWeb, ua: mcUA });
  }
}

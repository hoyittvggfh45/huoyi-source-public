
import { httpGet, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const jjBase = 'https://d.jjmhw.cc';
const jjTagAll = '%E5%85%A8%E9%83%A8';
const jjUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36';

function jjHeaders(ref) {
  const h = {
    'User-Agent': jjUA,
    'Accept-Language': 'zh-CN,zh;q=0.9',
  };
  if (ref) h.Referer = ref;
  return h;
}

const reJjCover = /background-image:\s*url\(([^)]+)\)/;
const reJjTitle = /<h2 class="title">\s*<a href="\/book\/(\d+)"[^>]*>([\s\S]*?)<\/a>/gi;
const reJjAuthor = /作者[:：]\s*<\/span>\s*<span>\s*(?:<a[^>]*>)?([^<]+)/is;
const reJjChapter = /href="\/chapter\/(\d+)"[^>]*>([^<]+)</is;
const reJjChapterAll = /href="\/chapter\/(\d+)"[^>]*>([^<]+)</gis;
const reJjH1 = /<h1[^>]*>([\s\S]*?)<\/h1>/i;
const reJjCoverB = /(https?:\/\/[^"'\s]+\/cover\.(?:jpg|png|webp))/i;
const reJjDesc = /(?:class="content"|intro)[^>]*>([\s\S]*?)<\/(?:p|div)>/is;
const reJjStatus = /(完結|完结)/;
const reJjImg = /<img[^>]+(?:data-original|data-src|src)="(https?:\/\/[^"]+)"/gi;

function jjText(s) {
  return htmlText(s).trim();
}

export class ProviderJjmhw {
  key() { return 'jjmhw'; }
  name() { return '姐姐漫画'; }
  adult() { return true; }
  desc() { return '姐姐漫画 jjmhw.cc：HTML 站点，booklist/排行榜'; }

  cats() {
    return [
      { id: 'all', name: '全部' },
      { id: 'serial', name: '连载' },
      { id: 'end', name: '完结' },
      { id: 'rank_new', name: '新书榜' },
      { id: 'rank_hot', name: '人气榜' },
      { id: 'rank_completed', name: '完结榜' },
      { id: 'rank_rec', name: '推荐榜' },
    ];
  }

  jjCards(html) {
    const out = [];
    reJjTitle.lastIndex = 0;
    for (const m of html.matchAll(reJjTitle)) {
      const id = m[1];
      const name = jjText(m[2]);
      if (!name) continue;
      const start = m.index;
      const end = Math.min(html.length, start + m[0].length + 600);
      const seg = start >= 0 ? html.slice(start, end) : '';
      let pic = '';
      const cm = firstGroup(reJjCover, seg);
      if (cm) pic = cm;
      let author = '';
      const am = firstGroup(reJjAuthor, seg);
      if (am) author = jjText(am);
      let remarks = '';
      if (reJjStatus.test(seg)) {
        remarks = '完结';
      } else {
        const chm = reJjChapter.exec(seg);
        if (chm) remarks = jjText(chm[2]);
      }
      out.push(Card({ id, name, pic, remarks, author }));
    }
    return out;
  }

  async list(cat, page) {
    cat = String(cat || '');
    page = page > 0 ? page : 1;
    let url;
    if (cat.startsWith('rank_')) {
      url = jjBase + '/rank';
    } else if (cat === 'serial') {
      url = `${jjBase}/booklist?tag=${jjTagAll}&area=-1&end=0`;
      if (page > 1) url += `&page=${page}`;
    } else if (cat === 'end') {
      url = `${jjBase}/booklist?tag=${jjTagAll}&area=-1&end=1`;
      if (page > 1) url += `&page=${page}`;
    } else {
      url = `${jjBase}/booklist?tag=${jjTagAll}&area=-1&end=-1`;
      if (page > 1) url += `&page=${page}`;
    }
    const body = await httpGet(url, jjHeaders(jjBase + '/'), 25000);
    const cards = this.jjCards(body);
    let hasMore = cards.length >= 30;
    if (cat.startsWith('rank_')) hasMore = false;
    return { cards, hasMore };
  }

  async search(wd, page) {
    page = page > 0 ? page : 1;
    let url = `${jjBase}/search?keyword=${encode(wd)}`;
    if (page > 1) url += `&page=${page}`;
    const body = await httpGet(url, jjHeaders(jjBase + '/'), 25000);
    const cards = this.jjCards(body);
    return { cards, hasMore: cards.length >= 30 };
  }

  async detail(id) {
    const bookURL = `${jjBase}/book/${id}`;
    const body = await httpGet(bookURL, jjHeaders(jjBase + '/'), 25000);
    let name = '';
    const hm = firstGroup(reJjH1, body);
    if (hm) name = jjText(hm);
    if (!name) throw new Error(`jjmhw: 详情解析失败 book=${id}`);
    let pic = '';
    const pm = firstGroup(reJjCoverB, body);
    if (pm) pic = pm;
    let desc = '';
    const dm = firstGroup(reJjDesc, body);
    if (dm) desc = jjText(dm);
    let author = '';
    const am = firstGroup(reJjAuthor, body);
    if (am) author = jjText(am);
    let remarks = '连载';
    if (reJjStatus.test(body)) remarks = '完结';
    const chapters = [];
    const seen = new Set();
    reJjChapterAll.lastIndex = 0;
    for (const cm of body.matchAll(reJjChapterAll)) {
      const cid = cm[1];
      if (seen.has(cid)) continue;
      seen.add(cid);
      let cname = jjText(cm[2]);
      if (!cname) cname = `第${chapters.length + 1}話`;
      chapters.push(Chapter(chapters.length + 1, cname, `${id}|${cid}`));
    }
    return BookDetail({
      id, name, pic, desc, remarks, author,
      chapters,
      count: chapters.length,
      adult: true,
    });
  }

  async pics(ref) {
    const parts = String(ref || '').split('|');
    if (parts.length < 2 || !parts[0] || !parts[1]) {
      throw new Error(`jjmhw: 无效引用 "${ref}"`);
    }
    const [bid, cid] = parts;
    const chapURL = `${jjBase}/chapter/${cid}`;
    const body = await httpGet(chapURL, jjHeaders(`${jjBase}/book/${bid}`), 30000);
    const seen = new Set();
    const pics = [];
    reJjImg.lastIndex = 0;
    for (const mm of body.matchAll(reJjImg)) {
      const u = mm[1].trim();
      if (!u || seen.has(u) || u.startsWith('data:')) continue;
      if (!u.includes('/upload/') && !u.includes('/book/')) continue;
      seen.add(u);
      pics.push(u);
    }
    if (pics.length === 0) throw new Error(`jjmhw: 章节无图片 ${cid}`);
    return ComicPlay({ pics, referer: jjBase + '/', ua: jjUA });
  }
}

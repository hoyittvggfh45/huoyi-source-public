
import { httpGet, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { readDataFile, writeDataFile } from '../core/datadir.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const nnDomainPool = [
  'nnhanman2.com',
  'nnhanman.com',
  'nnhanman66.com',
  'nnhanman88.com',
  'nnhm81.com',
  'nnhm92.com',
  'nnhm91.com',
  'nnhmfb.xyz',
];

const NN_DOMAIN_FILE = 'nnhanman_domain.txt';
const NN_COOLDOWN = 60 * 1000;
const NN_MAX_DOMAIN_ATTEMPTS = 3;
const nnUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36';

let nnActive = '';
let nnLoaded = false;
const nnBad = new Map(); 
const nnDetail = new Map(); 
const NN_DETAIL_TTL = 30 * 60 * 1000;

function nnRemembered() {
  if (!nnLoaded) {
    nnLoaded = true;
    const b = readDataFile(NN_DOMAIN_FILE);
    if (b) nnActive = b.trim();
  }
  return nnActive;
}

function nnRemember(domain) {
  nnActive = domain;
  writeDataFile(NN_DOMAIN_FILE, domain);
}

function nnCooling(domain) {
  const until = nnBad.get(domain);
  if (until === undefined) return false;
  if (Date.now() > until) {
    nnBad.delete(domain);
    return false;
  }
  return true;
}

function nnMarkBad(domain) {
  nnBad.set(domain, Date.now() + NN_COOLDOWN);
}

function nnOrder() {
  const head = nnRemembered();
  const ordered = [];
  if (head) ordered.push(head);
  for (const d of nnDomainPool) {
    if (d !== head) ordered.push(d);
  }
  const healthy = [];
  for (const d of ordered) {
    if (nnCooling(d)) continue;
    healthy.push(d);
  }
  let out = healthy.length > 0 ? healthy : ordered;
  if (out.length > NN_MAX_DOMAIN_ATTEMPTS) out = out.slice(0, NN_MAX_DOMAIN_ATTEMPTS);
  return out;
}

const reNNChallenge = /(_cf_chl_opt|challenge-platform\/|Just a moment)/i;
const reNNComicHref = /\/comic\/([^/"]+)\.html/;
const reNNChapHref = /\/comic\/[^/"]+\/chapter-(\d+)\.html/;
const reNNImg = /<img[^>]+src="([^"]+)"/i;
const reNNSource = /<source[^>]+srcset="([^"]+)"/i;
const reNNLi = /<li[^>]*>([\s\S]*?)<\/li>/gis;
const reNNTxtA = /<a[^>]+class="txtA"[^>]*>([\s\S]*?)<\/a>/is;
const reNNInfo = /<span[^>]*class="info"[^>]*>([\s\S]*?)<\/span>/is;
const reNNTitleAttr = /title="([^"]*)"/i;
const reNNAlt = /alt="([^"]*)"/i;
const reNNNext = /href="[^"]*?\/page\/(\d+)"[^>]*>\s*下一页/i;
const reNNItemBox = /<div class="itemBox">/g;
const reNNRankTitle = /<a[^>]+class="title"[^>]*>([\s\S]*?)<\/a>/is;
const reNNRankChap = /<p[^>]*class="txtItme"[^>]*>\s*<a[^>]*href="\/comic\/[^"]+\/chapter-\d+\.html"[^>]*>([\s\S]*?)<\/a>/is;
const reNNH1 = /<h1[^>]*>([\s\S]*?)<\/h1>/is;
const reNNDesc = /<p[^>]*class="txtDesc"[^>]*>([\s\S]*?)<\/p>/is;
const reNNDate = /class="date"[^>]*>([\s\S]*?)</is;
const reNNAuthor = /作者[:：]\s*([^<\r\n]{1,80})/;
const reNNTags = /<a[^>]+href="\/comics\/[^"]*"[^>]*>([\s\S]*?)<\/a>/gis;
const reNNDrama = /<ul[^>]*class="[^"]*Drama[^"]*"[^>]*>([\s\S]*?)<\/ul>/is;
const reNNChapA = /<a[^>]+href="\/comic\/[^/"]+\/chapter-(\d+)\.html"[^>]*>([\s\S]*?)<\/a>/gis;
const reNNChapNum = /第\s*(\d+)\s*[話话]/;
const reNNImgTag = /<img[^>]*>/gis;
const reNNDataSrc = /data-src="([^"]+)"/i;
const reNNDataIdx = /data-index="([^"]*)"/i;
const reNNCover = /id="Cover"[^>]*>[\s\S]{0,800}?<img[^>]+src="([^"]+)"/is;

function nnHeaders(base) {
  return {
    'User-Agent': nnUA,
    Referer: base + '/',
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9',
  };
}


async function nnFetch(path, timeoutMs) {
  let lastErr = null;
  for (const domain of nnOrder()) {
    const base = 'https://' + domain;
    let body = '';
    try {
      body = await httpGet(base + path, nnHeaders(base), timeoutMs);
    } catch (e) {
      lastErr = e;
      nnMarkBad(domain);
      continue;
    }
    if (body.length < 200 || reNNChallenge.test(body) || !body.toLowerCase().includes('<html')) {
      lastErr = new Error(`nnhanman: ${domain} 返回内容异常`);
      nnMarkBad(domain);
      continue;
    }
    nnRemember(domain);
    return { body, base };
  }
  if (!lastErr) lastErr = new Error('nnhanman: 所有线路均不可用，站点可能又换域名了');
  throw lastErr;
}

function nnAbs(base, href) {
  href = String(href ?? '').trim();
  if (!href) return '';
  if (href.startsWith('//')) return 'https:' + href;
  if (href.startsWith('http://') || href.startsWith('https://')) return href;
  if (href.startsWith('/')) return base + href;
  return base + '/' + href;
}

function nnParseList(html) {
  const out = [];
  for (const m of html.matchAll(reNNLi)) {
    const block = m[1];
    const hm = reNNComicHref.exec(block);
    const slug = hm ? hm[1] : '';
    if (!slug) continue;
    let title = htmlText(firstGroup(reNNTxtA, block));
    if (!title) title = htmlText(firstGroup(reNNTitleAttr, block));
    if (!title) title = htmlText(firstGroup(reNNAlt, block));
    if (!title) continue;
    let cover = firstGroup(reNNImg, block);
    if (!cover) cover = firstGroup(reNNSource, block);
    let sub = '';
    const info = firstGroup(reNNInfo, block);
    if (info) {
      sub = htmlText(info);
    }
    out.push({ slug, title, cover, sub });
  }
  return out;
}

function nnParseRank(html) {
  const idx = [];
  reNNItemBox.lastIndex = 0;
  for (const m of html.matchAll(reNNItemBox)) idx.push(m.index);
  const out = [];
  for (let i = 0; i < idx.length; i++) {
    const start = idx[i];
    const end = i + 1 < idx.length ? idx[i + 1] : html.length;
    const block = html.slice(start, end);
    const hm = reNNComicHref.exec(block);
    const slug = hm ? hm[1] : '';
    if (!slug) continue;
    let title = htmlText(firstGroup(reNNRankTitle, block));
    if (!title) continue;
    title = title.replace(/^\d+[.、]\s*/, '');
    let cover = firstGroup(reNNImg, block);
    if (!cover) cover = firstGroup(reNNSource, block);
    const sub = htmlText(firstGroup(reNNRankChap, block));
    out.push({ slug, title, cover, sub });
  }
  return out;
}

function nnStripMarks(s) {
  s = String(s).trim();
  s = s.replace(/^[《【[]+/, '');
  s = s.replace(/[》】\]]+$/, '');
  return s.trim();
}

export class ProviderNnhanman {
  key() { return 'nnhanman'; }
  name() { return '鸟鸟韩漫'; }
  adult() { return true; }
  desc() { return '鸟鸟韩漫：韩漫（18+），晴天CMS 全站 SSR，域名池自动切换（记忆可用域名+失败冷却）'; }

  toCards(raw) {
    const out = [];
    for (const it of raw) {
      out.push(Card({ id: it.slug, name: it.title, pic: it.cover, remarks: it.sub, plat: this.key() }));
    }
    return out;
  }

  cats() {
    const cats = [
      { id: 'rk:all', name: '总榜' },
      { id: 'rk:monthly', name: '月榜' },
      { id: 'rk:weekly', name: '周榜' },
      { id: 'rk:daily', name: '日榜' },
      { id: 'up:latest', name: '最近更新' },
      { id: 'up:newbook', name: '新书发布' },
      { id: 'up:recommend', name: '推荐漫画' },
    ];
    const tags = ['全部', '正妹', '恋爱', '出版漫画', '肉慾', '浪漫', '大尺度', '巨乳', '有夫之婦', '女大生', '狗血劇', '同居', '好友', '調教', '动作', '後宮', '不倫', '3D', '校園', '耽美', '日漫'];
    for (const t of tags) {
      cats.push({ id: `${t}|time|all`, name: t });
    }
    return cats;
  }

  async list(cat, page) {
    if (page < 1) page = 1;
    cat = String(cat ?? '').trim();
    if (!cat) cat = 'rk:all';
    let path;
    let useRank = false;
    if (cat.startsWith('rk:')) {
      const r = cat.slice(3);
      path = r === 'weekly' ? '/ranking' : '/ranking/' + r;
      useRank = true;
    } else if (cat.startsWith('up:')) {
      const k = cat.slice(3);
      path = k === 'latest' ? '/update' : '/update/' + k;
      useRank = true;
    } else {
      path = this.nnListPath(cat, page);
    }
    const { body } = await nnFetch(path, 20000);
    let raw = nnParseList(body);
    if (useRank && raw.length === 0) raw = nnParseRank(body);
    const cards = this.toCards(raw);
    let hasMore = false;
    if (!useRank) {
      const mm = reNNNext.exec(body);
      if (mm) {
        const n = parseInt(mm[1], 10) || 0;
        hasMore = n > page;
      }
      if (!hasMore && cards.length >= 20) hasMore = true;
    }
    return { cards, hasMore };
  }

  nnListPath(cat, page) {
    const parts = String(cat).split('|');
    let name = '全部';
    if (parts[0]) name = parts[0];
    let ob = 'time';
    if (parts.length > 1 && (parts[1] === 'time' || parts[1] === 'hits')) ob = parts[1];
    let st = 'all';
    if (parts.length > 2 && ['all', 'serialized', 'completed'].includes(parts[2])) st = parts[2];
    let base = `/comics/${encode(name)}/ob/${ob}/st/${st}`;
    if (page > 1) base += `/page/${page}`;
    return base;
  }

  async search(wd, page) {
    if (page < 1) page = 1;
    let path = '/search/' + encode(String(wd ?? '').trim());
    if (page > 1) path += `/page/${page}`;
    const { body } = await nnFetch(path, 20000);
    const cards = this.toCards(nnParseList(body));
    let hasMore = false;
    const mm = reNNNext.exec(body);
    if (mm) {
      const n = parseInt(mm[1], 10) || 0;
      hasMore = n > page;
    }
    if (!hasMore && cards.length >= 20) hasMore = true;
    return { cards, hasMore };
  }

  async detail(id) {
    id = String(id ?? '').trim();
    if (!id) throw new Error('nnhanman: 空的漫画 ID');
    const cached = nnDetail.get(id);
    if (cached && Date.now() - cached.at < NN_DETAIL_TTL) return cached.detail;
    const { body } = await nnFetch(`/comic/${encode(id)}.html`, 20000);
    let title = nnStripMarks(htmlText(firstGroup(reNNH1, body)));
    const idx = title.indexOf('-');
    if (idx > 0 && idx < title.length - 1) {
      title = title.slice(0, idx).trim();
    }
    title = nnStripMarks(title);
    if (!title) throw new Error('nnhanman: 详情为空（可能已下架）');
    let cover = '';
    const cm = reNNCover.exec(body);
    if (cm) cover = cm[1];
    let desc = htmlText(firstGroup(reNNDesc, body));
    if (desc.startsWith('介绍:')) desc = desc.slice('介绍:'.length);
    else if (desc.startsWith('介绍：')) desc = desc.slice('介绍：'.length);
    const status = htmlText(firstGroup(reNNDate, body));
    const author = htmlText(firstGroup(reNNAuthor, body));
    const tagSeen = new Set();
    const tags = [];
    for (const m of body.matchAll(reNNTags)) {
      const t = htmlText(m[1]);
      if (t && !tagSeen.has(t)) {
        tagSeen.add(t);
        tags.push(t);
      }
    }
    let raw = [];
    const drama = firstGroup(reNNDrama, body);
    if (drama) {
      for (const m of drama.matchAll(reNNChapA)) {
        raw.push({ id: m[1], name: htmlText(m[2]) });
      }
    }
    const seen = new Set();
    raw = raw.filter((c) => {
      if (!c.id || seen.has(c.id)) return false;
      seen.add(c.id);
      return true;
    });
    let numbered = 0;
    for (const c of raw) {
      if (reNNChapNum.test(c.name)) numbered++;
    }
    if (numbered * 5 >= raw.length * 3 && raw.length > 1) {
      let last = 0;
      const items = raw.map((c) => {
        let k = last;
        const mm = reNNChapNum.exec(c.name);
        if (mm) {
          k = parseInt(mm[1], 10) || 0;
          last = k;
        }
        return { c, k };
      });
      
      items.sort((a, b) => a.k - b.k);
      raw = items.map((it) => it.c);
    }
    const chapters = raw.map((c, i) => Chapter(i + 1, c.name, `${id}|${c.id}`));
    let statusTag = '';
    if (status.includes('完结') || status.includes('完結')) statusTag = '完结';
    else if (status.includes('连载') || status.includes('連載')) statusTag = '连载';
    if (statusTag) statusTag = ' · ' + statusTag;
    const detail = BookDetail({
      id,
      name: title,
      pic: cover,
      desc,
      tag: tags.join(' · '),
      remarks: `${chapters.length} 话${statusTag}`,
      author,
      chapters,
      count: chapters.length,
      adult: true,
    });
    if (nnDetail.size > 128) nnDetail.clear();
    nnDetail.set(id, { detail, at: Date.now() });
    return detail;
  }

  async pics(ref) {
    const parts = String(ref ?? '').trim().split('|');
    if (parts.length < 2 || !parts[0] || !parts[1]) {
      throw new Error(`nnhanman: 非法章节凭证 ${ref}`);
    }
    const { body, base } = await nnFetch(`/comic/${encode(parts[0])}/chapter-${encode(parts[1])}.html`, 25000);
    const imgs = [];
    let i = 0;
    for (const m of body.matchAll(reNNImgTag)) {
      const idx0 = i;
      i++;
      const tag = m[0];
      const src = firstGroup(reNNDataSrc, tag);
      if (!src.startsWith('http')) continue;
      let idx = idx0;
      const mm = reNNDataIdx.exec(tag);
      if (mm) {
        const n = parseInt(mm[1].trim(), 10);
        if (Number.isFinite(n)) idx = n;
      }
      imgs.push({ idx, url: src });
    }
    
    imgs.sort((a, b) => a.idx - b.idx);
    const out = [];
    const seen = new Set();
    for (const it of imgs) {
      if (seen.has(it.url)) continue;
      seen.add(it.url);
      out.push(it.url);
    }
    if (out.length === 0) throw new Error('nnhanman: 章节无图片');
    return ComicPlay({ pics: out, referer: base + '/', ua: nnUA });
  }
}

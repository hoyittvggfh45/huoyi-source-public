
import { httpGet, httpPost, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay } from '../types.js';

const HOST = 'https://www.dingmanhua.com';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

function headers(ref) {
  if (!ref) ref = `${HOST}/`;
  return { 'User-Agent': UA, Referer: ref };
}

const CATS = [
  ['/new', '最近更新'],
  ['/hot', '排行榜'],
  ['/sort?category=0&tag=0', '全部'],
  ['/sort?category=1&tag=0', '日本漫画'],
  ['/sort?category=3&tag=0', '大陆漫画'],
  ['/sort?category=4&tag=0', '韩国漫画'],
  ['/sort?category=14&tag=0', '港台漫画'],
  ['/sort?category=15&tag=0', '漫画'],
  ['/sort?category=0&tag=9', '热血'],
  ['/sort?category=0&tag=4', '玄幻'],
  ['/sort?category=0&tag=5', '冒险'],
  ['/sort?category=0&tag=6', '爱情'],
  ['/sort?category=0&tag=67', '恋爱'],
  ['/sort?category=0&tag=1', '悬疑'],
  ['/sort?category=0&tag=3', '搞笑'],
  ['/sort?category=0&tag=60', '爆笑'],
  ['/sort?category=0&tag=12', '奇幻'],
  ['/sort?category=0&tag=13', '校园'],
  ['/sort?category=0&tag=21', '格斗'],
  ['/sort?category=0&tag=32', '科幻'],
  ['/sort?category=0&tag=33', '穿越'],
  ['/sort?category=0&tag=34', '仙侠'],
  ['/sort?category=0&tag=35', '都市'],
  ['/sort?category=0&tag=36', '异能'],
  ['/sort?category=0&tag=24', '治愈'],
  ['/sort?category=0&tag=25', '魔幻'],
  ['/sort?category=0&tag=46', '武侠'],
  ['/sort?category=0&tag=66', '历史'],
  ['/sort?category=0&tag=73', '耽美'],
  ['/sort?category=0&tag=7', '百合'],
  ['/sort?category=0&tag=8', '推理'],
  ['/sort?category=0&tag=41', '重生'],
  ['/sort?category=0&tag=49', '末世'],
].map(([id, name]) => ({ id, name }));

const reDmhAnchor = /<a[^>]*href="\/comic\/([^"]+?)\.html"[^>]*>/gi;
const reDmhPic = /data-src="(https?:\/\/[^"]+)"/;
const reDmhAlt = /alt="([^"]*)"/;
const reDmhTtl = /class="[^"]*manga-title[^"]*"[^>]*>([^<]*)</is;
const reDmhStrong = /<strong[^>]*>([^<]*)<\/strong>/is;
const reDmhBadge = /class="[^"]*chapter-badge[^"]*"[^>]*>([^<]*)</is;
const reDmhPageInfo = /pagination-info">\s*(\d+)\s*\/\s*(\d+)\s*</;
const reDmhContentID = /const\s+contentId\s*=\s*'(\d+)'/;
const reDmhH1 = /<h1[^>]*>([^<]*)<\/h1>/is;
const reDmhAuthor = /id="mangaAuthor"[^>]*>([^<]*)</;
const reDmhStatus = />状态:<\/span>\s*<span[^>]*>([^<]*)</is;
const reDmhOGImage = /property="og:image"[^>]*content="([^"]*)"/is;
const reDmhDescMeta = /<meta[^>]*name="description"[^>]*content='([^']*)'/is;
const reDmhTagsBox = /id="mangaTags"[^>]*>([\s\S]{0,800}?)<\/div>/is;
const reDmhTagSpan = /<span[^>]*class="[^"]*tag[^"]*"[^>]*>([^<]*)</gis;
const reDmhNum = /var\s+num\s*=\s*eval\("(\d+)"\)/;
const reDmhPasd = /var\s+pasd\s*=\s*"([^"]+)"/;

function cards(page) {
  const out = [];
  const seen = new Set();
  const matches = [...page.matchAll(reDmhAnchor)];
  matches.forEach((m, i) => {
    const id = m[1].trim();
    if (!id || seen.has(id)) return;
    let end = m.index + m[0].length + 1400;
    if (i + 1 < matches.length && matches[i + 1].index < end) end = matches[i + 1].index;
    if (end > page.length) end = page.length;
    const blk = page.slice(m.index, end);
    let name = htmlText(firstGroup(reDmhTtl, blk));
    if (!name) name = htmlText(firstGroup(reDmhStrong, blk));
    if (!name) name = htmlText(firstGroup(reDmhAlt, blk));
    if (!name) return;
    seen.add(id);
    out.push(Card({
      id, name,
      pic: firstGroup(reDmhPic, blk),
      remarks: htmlText(firstGroup(reDmhBadge, blk)),
      plat: 'dhmh',
    }));
  });
  return out;
}

function pageURL(cat, page) {
  if (page < 1) page = 1;
  const u = HOST + cat;
  return u.includes('?') ? `${u}&page=${page}` : `${u}?page=${page}`;
}

export class ProviderDingmanhua {
  key() { return 'dhmh'; }
  name() { return '顶漫画'; }
  desc() { return 'dingmanhua.com HTML + JSON 章节接口'; }
  adult() { return false; }

  cats() { return CATS; }

  listPaged() { return true; }
  searchPaged() { return false; }

  async list(cat, page) {
    if (!String(cat || '').trim()) cat = CATS[0].id;
    const body = await httpGet(pageURL(cat, page), headers(''), 20000);
    const cs = cards(body);
    let hasMore = false;
    const m = body.match(reDmhPageInfo);
    if (m) {
      const cur = parseInt(m[1], 10) || 0;
      const total = parseInt(m[2], 10) || 0;
      hasMore = cur < total;
    }
    return { cards: cs, hasMore };
  }

  async search(wd, page) {
    if (page > 1) return { cards: [] };
    const body = await httpGet(`${HOST}/search?query=${encode(String(wd || '').trim())}`, headers(''), 20000);
    return { cards: cards(body), hasMore: false };
  }

  async detail(id) {
    const slug = String(id || '').trim().replace(/^\/+|\/+$/g, '');
    if (!slug) throw new Error('dhmh: 空漫画 id');
    const detailURL = `${HOST}/comic/${slug}.html`;
    const page = await httpGet(detailURL, headers(''), 30000);
    let name = htmlText(firstGroup(reDmhH1, page));
    if (!name) name = htmlText(firstGroup(reDmhAlt, page));
    if (!name) throw new Error(`dhmh: 详情解析失败 ${slug}`);
    const contentID = firstGroup(reDmhContentID, page);
    if (!contentID) throw new Error(`dhmh: 未取到 contentId ${slug}`);

    const hdrs = headers(detailURL);
    hdrs['Content-Type'] = 'application/json';
    const raw = await httpPost(`${HOST}/comic/${contentID}`, '{}', 'application/json', hdrs, 30000);
    let resp;
    try {
      resp = JSON.parse(raw);
    } catch (err) {
      throw new Error(`dhmh: 章节接口解析失败 ${slug}: ${err.message}`);
    }
    if ((resp.code || 0) !== 0) {
      throw new Error(`dhmh: 章节接口返回 code=${resp.code} ${slug}`);
    }

    const list = (resp.data && resp.data.chapters) || [];
    list.reverse();
    const chapters = list.map((c, i) => {
      let nm = htmlText(c.chapterName || '');
      if (!nm) nm = `第${i + 1}话`;
      return { no: i + 1, name: nm, url: `${contentID}|${String(c.id ?? '')}` };
    });
    if (chapters.length === 0) throw new Error(`dhmh: 章节列表为空 ${slug}`);

    const status = htmlText(firstGroup(reDmhStatus, page));
    let desc = firstGroup(reDmhDescMeta, page);
    const di = desc.indexOf('作品简介：');
    if (di >= 0) desc = desc.slice(di + '作品简介：'.length);
    const tags = [];
    const seenTag = new Set();
    const box = firstGroup(reDmhTagsBox, page);
    if (box) {
      for (const m of [...box.matchAll(reDmhTagSpan)]) {
        const v = htmlText(m[1]);
        if (!v || seenTag.has(v)) continue;
        seenTag.add(v);
        tags.push(v);
      }
    }
    let remarks = status;
    remarks = remarks ? `${remarks} · ${chapters.length} 话` : `${chapters.length} 话`;
    return BookDetail({
      id: slug,
      name,
      pic: firstGroup(reDmhOGImage, page),
      desc: htmlText(desc),
      tag: tags.join(' '),
      remarks,
      author: htmlText(firstGroup(reDmhAuthor, page)),
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const parts = String(ref || '').trim().split('|');
    if (parts.length !== 2 || !parts[0] || !parts[1]) {
      throw new Error(`dhmh: 非法章节凭证 ${ref}`);
    }
    const [contentID, chapterID] = parts;
    const chapURL = `${HOST}/chapter/${contentID}-${chapterID}.html`;
    const page = await httpGet(chapURL, headers(`${HOST}/comic/${contentID}.html`), 40000);
    const nm = page.match(reDmhNum);
    const pm = page.match(reDmhPasd);
    if (!nm || !pm) throw new Error(`dhmh: 章节取图参数缺失 ${ref}`);
    const num = parseInt(nm[1], 10) || 0;
    const base = pm[1];
    if (num <= 0 || !base) throw new Error(`dhmh: 章节无图片 ${ref}`);
    const pics = [];
    for (let i = 1; i <= num; i++) pics.push(`${base}${i}.webp`);
    return ComicPlay({ pics, referer: `${HOST}/`, ua: UA });
  }
}


import { httpGet, httpPostJSON, encode, firstNonEmpty } from '../core/http.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const xmHost = 'https://xapi.xinmanhua.net';
const xmUA = 'okhttp/3.12.1';

function xmHeaders() {
  return { 'User-Agent': xmUA, Accept: 'application/vnd.api+json' };
}

const xmCats = [
  { id: '', name: '全部' },
  { id: '恋爱', name: '恋爱' },
  { id: '热血', name: '热血' },
  { id: '奇幻', name: '奇幻' },
  { id: '悬疑', name: '悬疑' },
  { id: '搞笑', name: '搞笑' },
  { id: '古风', name: '古风' },
  { id: '科幻', name: '科幻' },
  { id: '都市', name: '都市' },
  { id: '治愈', name: '治愈' },
];

function cardOf(w) {
  const attrs = w?.attributes ?? {};
  let id = String(attrs.wid ?? '').trim();
  if (!id) id = String(w?.id ?? '').trim();
  return Card({
    id,
    name: String(attrs.title ?? '').trim(),
    pic: String(attrs.logo_detail ?? '').trim(),
    author: String(attrs.author ?? '').trim(),
    remarks: String(attrs.lastctitle ?? '').trim(),
    desc: String(attrs.intro ?? '').trim(),
    plat: 'xinmanhua',
  });
}

function xmWorks(body) {
  let resp = null;
  try {
    resp = JSON.parse(body);
  } catch {
    return [];
  }
  const out = [];
  for (const w of Array.isArray(resp?.data) ? resp.data : []) {
    if (w?.attributes?.title) out.push(w);
  }
  return out;
}

export class ProviderXinmanhua {
  key() { return 'xinmanhua'; }
  name() { return '新漫画'; }
  desc() { return 'xapi.xinmanhua.net JSON:API（webtoon 竖屏条漫）'; }
  adult() { return false; }

  cats() { return xmCats; }

  listPaged() { return true; }
  searchPaged() { return true; }

  async list(cat, page) {
    if (page < 1) page = 1;
    const u = `${xmHost}/search/catalog?keyword=${encode(cat)}&ischarge=2&isfinish=2&order=0&page=${page}`;
    const body = await httpGet(u, xmHeaders(), 20000);
    const cards = xmWorks(body).map(cardOf);
    return { cards, hasMore: cards.length >= 10 };
  }

  async search(wd, page) {
    if (page < 1) page = 1;
    const body = await httpPostJSON(xmHost + '/search/selfdefine', JSON.stringify({ keyword: wd, page }), xmHeaders(), 20000);
    const cards = xmWorks(body).map(cardOf);
    return { cards, hasMore: cards.length >= 10 };
  }

  async detail(id) {
    id = String(id ?? '').trim();
    const body = await httpGet(`${xmHost}/worksinfos/${encode(id)}?include=chapters.digests`, xmHeaders(), 25000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('xinmanhua: 详情解析失败');
    }
    const attrs = resp?.data?.attributes ?? {};
    if (!attrs.title) throw new Error('xinmanhua: 详情解析失败');
    const chs = [];
    for (const inc of Array.isArray(resp?.included) ? resp.included : []) {
      if (inc?.type !== 'chapters' || !String(inc?.id ?? '').trim()) continue;
      chs.push({ id: String(inc.id), cidx: parseInt(inc?.attributes?.cidx ?? 0, 10) || 0 });
    }
    
    chs.sort((a, b) => a.cidx - b.cidx);
    const chapters = [];
    for (const c of chs) {
      let name = `第${c.cidx}话`;
      if (c.cidx === 0) name = `第${chapters.length + 1}话`;
      chapters.push(Chapter(chapters.length + 1, name, c.id));
    }
    let remarks = String(attrs.lastctitle ?? '').trim();
    if (parseInt(attrs.isfinish ?? 0, 10) === 1) {
      remarks = `${remarks} · 已完结`.trim();
    }
    return BookDetail({
      id,
      name: String(attrs.title ?? '').trim(),
      pic: String(attrs.logo_detail ?? '').trim(),
      desc: firstNonEmpty(String(attrs.intro ?? '').trim(), String(attrs.description ?? '').trim()),
      tag: '漫画',
      remarks: remarks.trim(),
      author: String(attrs.author ?? '').trim(),
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    ref = String(ref ?? '').trim();
    if (!ref || ref.includes('/')) throw new Error(`xinmanhua: 非法章节凭证 ${ref}`);
    const body = await httpGet(`${xmHost}/chapters/${encode(ref)}/qualitywebs`, xmHeaders(), 25000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('xinmanhua: 章节解析失败');
    }
    const pics = [];
    for (const it of Array.isArray(resp?.data) ? resp.data : []) {
      let v = String(it?.attributes?.url ?? '').trim();
      if (!v) v = String(it?.attributes?.previewpic ?? '').trim();
      if (v) pics.push(v);
    }
    if (pics.length === 0) throw new Error('xinmanhua: 章节无图片');
    return ComicPlay({ pics, referer: 'http://m.xinmanhua.net/', ua: xmUA });
  }
}

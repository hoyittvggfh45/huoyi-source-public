
import { httpGet, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const szHost = 'https://songzimanhua.com';
const szUA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36';

function szHeaders(ref) {
  if (!ref) ref = szHost + '/';
  return { 'User-Agent': szUA, Referer: ref };
}

const songziCats = [
  { id: 'all', name: '全部', q: '' },
  { id: 'serial', name: '连载中', q: 'status=serial&' },
  { id: 'finished', name: '已完结', q: 'status=finished&' },
];

const reSzCard = /<a[^>]*class="comic-card"[^>]*href="(\/book\/\d+\/)"[^>]*>([\s\S]*?)<\/a>/gis;
const reSzImg = /<img[^>]*\bsrc="([^"]+)"/is;
const reSzName = /<strong[^>]*>([\s\S]*?)<\/strong>/is;
const reSzSub = /<small[^>]*>([\s\S]*?)<\/small>/is;
const reSzStat = /<span[^>]*>([\s\S]*?)<\/span>/is;

function songziParseList(page) {
  const out = [];
  for (const m of page.matchAll(reSzCard)) {
    const href = m[1];
    const blk = m[2];
    const id = href.replace(/^\/book\//, '').replace(/^\/+|\/+$/g, '');
    const name = htmlText(firstGroup(reSzName, blk));
    if (!id || !name) continue;
    out.push(Card({
      id,
      name,
      pic: firstGroup(reSzImg, blk),
      remarks: htmlText(firstGroup(reSzStat, blk)),
      cat: htmlText(firstGroup(reSzSub, blk)),
      plat: 'songzi',
    }));
  }
  return out;
}

const reSzH1 = /<h1[^>]*>([\s\S]*?)<\/h1>/is;
const reSzCover = /<a[^>]*class="detail-cover"[^>]*>\s*<img[^>]*\bsrc="([^"]+)"/is;
const reSzAuthor = /<a[^>]*data-detail-author[^>]*>([\s\S]*?)<\/a>/is;
const reSzIntro = /<div[^>]*class="intro"[^>]*>([\s\S]*?)<\/div>/is;
const reSzChap = /<a[^>]*href="\/read\/(\d+)\/"[^>]*>([\s\S]*?)<\/a>/gis;
const reSzDate = /\s*\d{4}-\d{2}-\d{2}\s*(更新)?\s*$/;

export class ProviderSongzi {
  key() { return 'songzi'; }
  name() { return '松子漫画'; }
  desc() { return 'songzimanhua.com HTML（明文图片接口）'; }
  adult() { return false; }

  cats() {
    return songziCats.map((c) => ({ id: c.id, name: c.name }));
  }

  listPaged() { return true; }
  searchPaged() { return false; }

  async list(cat, page) {
    if (page < 1) page = 1;
    let q = '';
    for (const c of songziCats) {
      if (c.id === cat) {
        q = c.q;
        break;
      }
    }
    const u = `${szHost}/genre/all/?${q}page=${page}`;
    const body = await httpGet(u, szHeaders(''), 15000);
    const cards = songziParseList(body);
    return { cards, hasMore: cards.length > 0 };
  }

  async search(wd, page) {
    if (page > 1) return { cards: [], hasMore: false };
    const u = `${szHost}/search/?q=${encode(wd)}`;
    const body = await httpGet(u, szHeaders(''), 15000);
    return { cards: songziParseList(body), hasMore: false };
  }

  async detail(id) {
    const u = `${szHost}/book/${encode(id)}/`;
    const page = await httpGet(u, szHeaders(''), 15000);
    const name = htmlText(firstGroup(reSzH1, page));
    if (!name) throw new Error('songzi: 详情解析失败（页面可能改版）');
    let chapters = [];
    const seen = new Set();
    reSzChap.lastIndex = 0;
    for (const m of page.matchAll(reSzChap)) {
      const cid = m[1];
      const chName = htmlText(m[2].replace(reSzDate, ''));
      if (!chName || chName === '开始阅读' || seen.has(cid)) continue;
      seen.add(cid);
      chapters.push({ no: 0, name: chName, url: cid });
    }
    chapters.reverse();
    chapters = chapters.map((c, i) => Chapter(i + 1, c.name, c.url));
    return BookDetail({
      id,
      name,
      pic: firstGroup(reSzCover, page),
      desc: htmlText(firstGroup(reSzIntro, page)),
      tag: '漫画',
      remarks: `${chapters.length} 话`,
      author: htmlText(firstGroup(reSzAuthor, page)),
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const cid = String(ref ?? '').trim();
    if (!cid) throw new Error('songzi: 空章节凭证');
    const u = `${szHost}/mobile-data.php?endpoint=chapter_pics&id=${encode(cid)}`;
    const body = await httpGet(u, szHeaders(`${szHost}/read/${cid}/`), 20000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('songzi: 非 JSON 响应');
    }
    const images = Array.isArray(resp?.data?.images) ? resp.data.images : [];
    const out = [];
    for (const s of images) {
      const v = String(s ?? '').trim();
      if (v) out.push(v);
    }
    if (out.length === 0) throw new Error('songzi: 章节无图片');
    return ComicPlay({ pics: out, referer: szHost + '/', ua: szUA });
  }
}

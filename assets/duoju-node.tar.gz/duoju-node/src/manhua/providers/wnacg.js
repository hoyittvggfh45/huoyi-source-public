
import { httpGet, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const wncBase = 'https://www.wnacg.com';
const wncUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36';

function wncHeaders(ref) {
  const h = {
    'User-Agent': wncUA,
    'Accept-Language': 'zh-CN,zh;q=0.9',
  };
  if (ref) h.Referer = ref;
  return h;
}

function wncAbs(raw) {
  raw = String(raw ?? '').trim();
  if (!raw) return '';
  if (raw.startsWith('//')) return 'https:' + raw;
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  if (!raw.startsWith('/')) raw = '/' + raw;
  while (raw.startsWith('////')) raw = raw.slice(2);
  return wncBase + raw;
}

const reWncCard = /<li class="li gallary_item">([\s\S]*?)<\/li>/gis;
const reWncHref = /href="\/photos-index-aid-(\d+)\.html"/;
const reWncImg = /<img[^>]+src="((?:(?:\/\/)+[^"]+|\/[^"]+))"/i;
const reWncTitle = /<div class="title">\s*<a[^>]*>([\s\S]*?)<\/a>/is;
const reWncInfo = /<div class="info_col">([\s\S]*?)<\/div>/is;
const reWncH2 = /<h2>([\s\S]*?)<\/h2>/is;
const reWncCover = /src="((?:(?:\/\/)+[^"]*data\/t\/[^"]+))"/i;
const reWncDesc = /<div class="uwconn">([\s\S]*?)<\/div>/is;
const reWncTag = /class="tagshow"[^>]*>([\s\S]*?)<\/a>/gis;
const reWncPages = /頁數[:：]\s*(\d+)/;
const reWncChid = /data-chid="(\d+)"/g;
const reWncDate = /(\d{4}-\d{2}-\d{2})/;

function wncText(s) {
  return htmlText(s).trim();
}

export class ProviderWnacg {
  key() { return 'wnacg'; }
  name() { return '绅士漫画'; }
  adult() { return true; }
  desc() { return '绅士漫画 wnacg.com：HTML 站点，mReader.initData 取图'; }

  cats() {
    return [
      { id: 'c5', name: '同人誌' },
      { id: 'c1', name: '同人誌·漢化' },
      { id: 'c2', name: 'CG畫集' },
      { id: 'c6', name: '單行本' },
      { id: 'c7', name: '雜誌&短篇' },
      { id: 'c3', name: '寫真&Cosplay' },
      { id: 'c19', name: '韓漫' },
      { id: 'c22', name: '3D&漫畫' },
      { id: 'c37', name: 'AI圖集' },
    ];
  }

  wncCards(html) {
    const out = [];
    for (const m of html.matchAll(reWncCard)) {
      const block = m[1];
      const hm = reWncHref.exec(block);
      const id = hm ? hm[1] : '';
      if (!id) continue;
      const tm = reWncTitle.exec(block);
      const name = tm ? wncText(tm[1]) : '';
      if (!name) continue;
      let pic = '';
      const im = reWncImg.exec(block);
      if (im) pic = wncAbs(im[1]);
      let remarks = '';
      const im2 = reWncInfo.exec(block);
      if (im2) {
        const info = wncText(im2[1]);
        const pm = /(\d+)張圖片/.exec(info);
        if (pm) remarks = pm[1] + 'P';
      }
      out.push(Card({ id, name, pic, remarks }));
    }
    return out;
  }

  async list(cat, page) {
    cat = String(cat ?? '');
    let url = `${wncBase}/albums.html`;
    if (cat.length > 1 && cat[0] === 'c') {
      if (page <= 1) {
        url = `${wncBase}/albums-index-cate-${cat.slice(1)}.html`;
      } else {
        url = `${wncBase}/albums-index-page-${page}-cate-${cat.slice(1)}.html`;
      }
    } else if (page > 1) {
      url = `${wncBase}/albums-index-page-${page}.html`;
    }
    const body = await httpGet(url, wncHeaders(wncBase + '/'), 25000);
    const cards = this.wncCards(body);
    return { cards, hasMore: cards.length >= 20 };
  }

  async search(wd, page) {
    const url = `${wncBase}/search/?q=${encode(wd)}&f=_all&s=create_time_DESC&syn=yes&p=${page}`;
    const body = await httpGet(url, wncHeaders(wncBase + '/'), 25000);
    const cards = this.wncCards(body);
    return { cards, hasMore: cards.length >= 20 };
  }

  async detail(id) {
    const body = await httpGet(`${wncBase}/photos-index-aid-${id}.html`, wncHeaders(wncBase + '/'), 25000);
    let name = '';
    const hm = reWncH2.exec(body);
    if (hm) name = wncText(hm[1]);
    if (!name) throw new Error(`wnacg: 详情解析失败 aid=${id}`);
    let pic = '';
    const cm = reWncCover.exec(body);
    if (cm) pic = wncAbs(cm[1]);
    let desc = '';
    const dm = reWncDesc.exec(body);
    if (dm) {
      desc = wncText(dm[1]);
      if (desc.startsWith('簡介:')) desc = desc.slice('簡介:'.length);
      else if (desc.startsWith('簡介：')) desc = desc.slice('簡介：'.length);
    }
    let remarks = '';
    const pm = reWncPages.exec(body);
    if (pm) remarks = pm[1] + 'P';
    const date = reWncDate.exec(body)?.[1] ?? ''; 
    void date;
    const tags = [];
    for (const mm of body.matchAll(reWncTag)) {
      const t = wncText(mm[1]);
      if (t) tags.push(t);
    }
    const chids = [...body.matchAll(reWncChid)];
    const chapters = [];
    const seen = new Set();
    for (const cm2 of chids) {
      const ch = cm2[1];
      if (!ch || seen.has(ch)) continue;
      seen.add(ch);
      chapters.push(Chapter(chapters.length + 1, `第${chapters.length + 1}話`, `${id}|${ch}`));
    }
    if (chapters.length === 0) {
      chapters.push(Chapter(1, '全一话', id));
    }
    let author = '';
    for (const t of tags) {
      if (!/[，, ]/.test(t)) {
        author = t;
        break;
      }
    }
    return BookDetail({
      id, name, pic, desc,
      tag: tags.join(' · '), remarks, author,
      chapters,
      count: chapters.length,
      adult: true,
    });
  }

  async pics(ref) {
    const parts = String(ref ?? '').split('|');
    if (parts.length === 0 || !parts[0]) {
      throw new Error(`wnacg: 无效引用 "${ref}"`);
    }
    const bookID = parts[0];
    let itemID = parts[0];
    if (parts.length === 2 && parts[1]) itemID = parts[1];
    let url;
    if (itemID === bookID) {
      url = `${wncBase}/photos-item-aid-${itemID}.html`;
    } else {
      url = `${wncBase}/photos-item-aid-${itemID}-sid-${bookID}.html`;
    }
    const body = await httpGet(url, wncHeaders(wncBase + '/'), 30000);
    const pics = wncParseInitData(body);
    return ComicPlay({ pics, referer: wncBase + '/', ua: wncUA });
  }
}

function wncParseInitData(html) {
  const marker = 'mReader.initData(';
  const start = html.indexOf(marker);
  if (start < 0) throw new Error('wnacg: 未找到 initData');
  const js = html.indexOf('{', start);
  if (js < 0) throw new Error('wnacg: initData 无 JSON');
  const s = js;
  let depth = 0;
  let end = -1;
  for (let i = s; i < html.length; i++) {
    const ch = html[i];
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) {
        end = i + 1;
        break;
      }
    }
  }
  let raw = html.slice(s, end);
  raw = raw.replace(/,\s*([\]}])/g, '$1');
  let data = null;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error('wnacg: initData JSON 解析失败');
  }
  const pageURL = Array.isArray(data?.page_url) ? data.page_url : [];
  const out = [];
  for (const u of pageURL) {
    const t = String(u ?? '').trim();
    if (t) out.push(t);
  }
  if (out.length === 0) throw new Error('wnacg: 图片列表为空');
  return out;
}


import { httpGet, httpPostForm, encode } from '../core/http.js';
import { htmlText, unescapeHTML, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const mhkamiHost = 'https://m.mhkami.com';
const mhkamiUA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_6 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) CriOS/31.0.1650.18 Mobile/11B554a Safari/8536.25';

function mhkamiHeaders(ref) {
  const h = {
    'User-Agent': mhkamiUA,
    Referer: mhkamiHost + '/',
    
    'Accept-Encoding': 'identity',
  };
  if (ref) h.Referer = ref;
  return h;
}

const reMhkItem = /<li class="item comic-item"[^>]*>([\s\S]*?)<\/li>/gis;
const reMhkLHref = /<a[^>]*href="(\/book\/(\d+)\/)"/is;
const reMhkLImg = /<img[^>]*\bsrc="([^"]+)"/is;
const reMhkLCh = /<span class="chapter"[^>]*>([\s\S]*?)<\/span>/is;
const reMhkLTag = /<p class="title"[^>]*>([\s\S]*?)<\/p>/is;

const reMhkH1 = /<h1[^>]*>([\s\S]*?)<\/h1>/is;
const reMhkTh = /<[^>]*class="[^"]*thumbnail[^"]*"[^>]*>\s*<img[^>]*\bsrc="([^"]+)"/is;
const reMhkDesc = /id="js_desc_content"[^>]*>([\s\S]*?)</is;
const reMhkChLi = /<li class="comic-chapter-item"[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*title="([^"]*)"/gis;

const MHKAMI_PIC_BATCH = 10;
const MHKAMI_PIC_MAX = 2000;

async function fetchPics(u, headers, cid, aid, offset) {
  const form = `id=${cid}&aid=${aid}&offset=${offset}&limit=${MHKAMI_PIC_BATCH}`;
  const body = await httpPostForm(u, form, headers, 45000);
  let resp = null;
  try {
    resp = JSON.parse(body);
  } catch {
    throw new Error('mhkami: pics 解析失败');
  }
  if (resp?.code !== 1) throw new Error(`mhkami: pics code=${resp?.code ?? ''}`);
  const pics = [];
  for (const it of Array.isArray(resp?.data?.pic) ? resp.data.pic : []) {
    const s = String(it?.pic ?? '').trim();
    if (s) pics.push(s);
  }
  return { pics, total: parseInt(resp?.data?.total ?? 0, 10) || 0 };
}

export class ProviderMhkami {
  key() { return 'mhkami'; }
  name() { return '漫神'; }
  desc() { return 'm.mhkami.com API+HTML（章节图分批接口）'; }
  adult() { return false; }

  cats() {
    return [
      { id: '全部', name: '全部' },
      { id: '长条', name: '长条' },
      { id: '耽美', name: '耽美' },
      { id: '纯爱', name: '纯爱' },
      { id: '韩漫', name: '韩漫' },
      { id: '古风', name: '古风' },
      { id: '都市', name: '都市' },
      { id: '校园', name: '校园' },
      { id: '热血', name: '热血' },
      { id: '悬疑', name: '悬疑' },
      { id: '搞笑', name: '搞笑' },
    ];
  }

  listPaged() { return true; }
  searchPaged() { return false; }

  async list(cat, page) {
    if (!cat) cat = '全部';
    if (page < 1) page = 1;
    const u = `${mhkamiHost}/api/comic/index/lists?tags=${encode(cat)}&page=${page}&area=9&full=3`;
    
    let body = '';
    let resp = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      body = await httpGet(u, mhkamiHeaders(''), 15000);
      try {
        resp = JSON.parse(body);
        break;
      } catch {
        resp = null;
      }
    }
    if (!resp) throw new Error('mhkami: 非 JSON 响应');
    if (resp?.code !== 0) throw new Error(`mhkami: code=${resp?.code ?? ''}`);
    const out = [];
    for (const it of Array.isArray(resp?.data) ? resp.data : []) {
      if (!it?.name) continue;
      out.push(Card({
        id: String(it.id),
        name: String(it.name),
        pic: String(it.cover ?? ''),
        remarks: String(it.author ?? ''),
        author: String(it.author ?? ''),
        desc: String(it.intro ?? ''),
        plat: 'mhkami',
      }));
    }
    if (out.length === 0 && page === 1) throw new Error('mhkami: 列表为空');
    return { cards: out, hasMore: (parseInt(resp?.next ?? 0, 10) || 0) > 0 && page < (parseInt(resp?.end ?? 0, 10) || 0) };
  }

  async search(wd, page) {
    if (page < 1) page = 1;
    if (page > 1) return { cards: [], hasMore: false };
    const u = `${mhkamiHost}/search?searchkey=${encode(wd)}`;
    const html = await httpGet(u, mhkamiHeaders(''), 15000);
    const out = [];
    for (const x of html.matchAll(reMhkItem)) {
      const blk = x[1];
      const href = firstGroup(reMhkLHref, blk);
      const hm = /\/book\/(\d+)\//.exec(href || '');
      const id = hm ? hm[1] : '';
      if (!id) continue;
      const title = htmlText(firstGroup(reMhkLTag, blk));
      if (!title) continue;
      const pic = firstGroup(reMhkLImg, blk);
      const ch = htmlText(firstGroup(reMhkLCh, blk));
      out.push(Card({ id, name: title, pic, remarks: ch, plat: 'mhkami' }));
    }
    return { cards: out, hasMore: false };
  }

  async detail(id) {
    const u = `${mhkamiHost}/book/${id}/`;
    const htmlPage = await httpGet(u, mhkamiHeaders(''), 15000);
    const title = htmlText(firstGroup(reMhkH1, htmlPage));
    if (!title) throw new Error('mhkami: 详情解析失败（页面可能改版）');
    const pic = firstGroup(reMhkTh, htmlPage);
    const desc = htmlText(firstGroup(reMhkDesc, htmlPage));
    const chapters = [];
    const seen = new Set();
    for (const m of htmlPage.matchAll(reMhkChLi)) {
      const href = m[1];
      const name = unescapeHTML(String(m[2]).trim());
      if (!href || seen.has(href)) continue;
      seen.add(href);
      chapters.push(Chapter(chapters.length + 1, name, mhkamiHost + href));
    }
    return BookDetail({
      id,
      name: title,
      pic,
      desc,
      tag: '漫画',
      remarks: `${chapters.length} 话`,
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const m = /\/chapter\/(\d+)\/(\d+)\.html/.exec(String(ref ?? ''));
    if (!m) throw new Error(`mhkami: 非法章节凭证 ${ref}`);
    const aid = m[1];
    const cid = m[2];
    const u = `${mhkamiHost}/api/comic/read/pics`;
    const headers = mhkamiHeaders(ref);

    const first = await fetchPics(u, headers, cid, aid, 0);
    let total = first.total;
    const out = [...first.pics];
    const seen = new Set(first.pics);

    const appendPage = (page) => {
      for (const s of page) {
        if (!seen.has(s)) {
          seen.add(s);
          out.push(s);
        }
      }
    };

    if (total > MHKAMI_PIC_BATCH) {
      let pages = Math.ceil(total / MHKAMI_PIC_BATCH);
      const maxPages = Math.floor(MHKAMI_PIC_MAX / MHKAMI_PIC_BATCH);
      if (pages > maxPages) pages = maxPages;
      const rest = new Array(pages);
      
      let next = 1;
      const workers = [];
      const runWorker = async () => {
        for (;;) {
          const i = next++;
          if (i >= pages) break;
          try {
            const page = await fetchPics(u, headers, cid, aid, i * MHKAMI_PIC_BATCH);
            rest[i] = page.pics;
          } catch {
            
          }
        }
      };
      for (let w = 0; w < 4; w++) workers.push(runWorker());
      await Promise.all(workers);
      for (let i = 1; i < pages; i++) {
        if (rest[i]) appendPage(rest[i]);
      }
    } else {
      for (let offset = MHKAMI_PIC_BATCH; offset < MHKAMI_PIC_MAX; offset += MHKAMI_PIC_BATCH) {
        let page;
        try {
          page = await fetchPics(u, headers, cid, aid, offset);
        } catch {
          break;
        }
        if (!page.pics || page.pics.length === 0) break;
        if (page.total > 0) total = page.total;
        appendPage(page.pics);
        if (total > 0 && out.length >= total) break;
      }
    }

    if (out.length === 0) throw new Error('mhkami: 章节无图片');
    return ComicPlay({ pics: out, referer: ref, ua: mhkamiUA });
  }
}

import { httpGet, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay, Cat } from '../types.js';

const HOST = 'https://wmtt5.com';
const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36';

function headers(ref) {
  return {
    'User-Agent': UA,
    Referer: ref || HOST + '/',
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Accept-Encoding': 'identity',
    Cookie: 'age_verify=1; popup_agreement=1',
  };
}

const CATS = [
  { id: 'newmanga', name: '最近更新', path: () => '/newmanga' },
  { id: 'all', name: '全部漫画', path: (p) => `/mangacata/all/ob/hit/st/all/page/${p}` },
  { id: 'hanman', name: '韩漫', path: (p) => `/mangacata/${encodeURIComponent('韩漫')}/ob/time/st/all/page/${p}` },
  { id: 'riman', name: '日漫', path: (p) => `/mangacata/${encodeURIComponent('日漫')}/ob/time/st/all/page/${p}` },
  { id: 'zhenren', name: '真人漫画', path: (p) => `/mangacata/${encodeURIComponent('真人漫画')}/ob/time/st/all/page/${p}` },
  { id: 'duanpian', name: '短篇', path: (p) => `/mangacata/${encodeURIComponent('短篇')}/ob/time/st/all/page/${p}` },
  { id: 'rank-daily', name: '日榜', path: () => '/mangarank/daily' },
  { id: 'rank-week', name: '周榜', path: () => '/mangarank' },
  { id: 'rank-month', name: '月榜', path: () => '/mangarank/monthly' },
  { id: 'rank-all', name: '总榜', path: () => '/mangarank/all' },
].map((c) => ({ ...c }));

const reCardStart = /<a[^>]*class="[^"]*module-poster-item[^"]*"[^>]*>/gi;
const reHref = /href="([^"]+)"/i;
const reTitle = /title="([^"]+)"/i;
const reImg = /data-original="([^"]+)"/i;
const reImgSrc = /<img[^>]*src="([^"]+)"/i;
const reNote = /class="[^"]*module-item-note[^"]*"[^>]*>([\s\S]*?)<\/div>/i;

const reH1 = /<h1[^>]*>([\s\S]*?)<\/h1>/i;
const reCover = /data-original="([^"]+)"/gi;
const reOgImage = /<meta[^>]*property=["']og:image["'][^>]*content=["']([^"']+)["']/i;
const reAuthor = /class="[^"]*module-info-item-content[^"]*"[^>]*>([\s\S]*?)<\/div>/i;
const reTag = /class="[^"]*module-info-tag-link[^"]*"[^>]*>([\s\S]*?)<\/div>/gi;
const reDesc = /class="[^"]*module-info-introduction-content[^"]*show-desc[^"]*"[^>]*>([\s\S]*?)<\/div>/i;
const reDesc2 = /class="[^"]*module-info-introduction-content[^"]*"[^>]*>([\s\S]*?)<\/div>/i;
const reChap = /<a[^>]*class="[^"]*module-play-list-link[^"]*"[^>]*href="([^"]+)"[^>]*title="([^"]+)"/gi;
const reChapFallback = /<a[^>]*href="(\/mangaread\/\d+\/[^"]+\.html)"[^>]*title="([^"]+)"/gi;
const reImgAny = /<img[^>]*src="([^"]+)"/gi;

function abs(raw) {
  raw = String(raw ?? '').trim();
  if (!raw) return '';
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  if (raw.startsWith('//')) return 'https:' + raw;
  return HOST + '/' + raw.replace(/^\/+/, '');
}

function coverJpg(raw) {
  const u = abs(raw);
  if (!u) return '';
  return u.toLowerCase().endsWith('.webp') ? u.slice(0, -5) + '.jpg' : u;
}

function bookID(href) {
  const m = /\/mangaread\/(\d+)\.html/.exec(href || '');
  return m ? m[1] : String(href || '').trim();
}

function parseCards(page) {
  const starts = [...page.matchAll(reCardStart)].map((m) => ({ at: m.index, tag: m[0] }));
  const out = [];
  const seen = new Set();
  for (let i = 0; i < starts.length; i++) {
    const start = starts[i];
    const end = i + 1 < starts.length ? starts[i + 1].at : page.length;
    const block = page.slice(start.at, end);
    const href = firstGroup(reHref, start.tag);
    if (!href) continue;
    const id = bookID(href);
    if (!id || seen.has(id)) continue;
    const name = htmlText(firstGroup(reTitle, start.tag));
    if (!name) continue;
    seen.add(id);
    let pic = firstGroup(reImg, block);
    if (!pic) pic = firstGroup(reImgSrc, block);
    const card = Card({
      id,
      name,
      pic: coverJpg(pic),
      remarks: htmlText(firstGroup(reNote, block)),
      plat: 'wmtt',
    });
    out.push(card);
  }
  return out;
}

export class ProviderWmtt {
  key() { return 'wmtt'; }
  name() { return '污漫天堂'; }
  desc() { return 'wmtt5.com HTML 漫画（list/detail/chapter 直读）'; }
  adult() { return true; }

  cats() { return CATS.map((c) => Cat(c.id, c.name)); }

  listPaged() { return true; }
  searchPaged() { return true; }

  async list(cat, page) {
    let p = Math.trunc(Number(page));
    if (!p || p < 1) p = 1;
    const cfg = CATS.find((x) => x.id === String(cat || '').trim()) || CATS[0];
    let path = cfg.path(p);
    if (p > 1 && (cfg.id.startsWith('rank') || cfg.id === 'newmanga')) {
      path += `?page=${p}`;
    }
    const body = await httpGet(HOST + path, headers(''), 20000);
    const cards = parseCards(body);
    return { cards, hasMore: cards.length >= 20 };
  }

  async search(wd, page) {
    const key = String(wd || '').trim();
    if (!key) return { cards: [], hasMore: false };
    let p = Math.trunc(Number(page));
    if (!p || p < 1) p = 1;
    let u = `${HOST}/cata.php?key=${encode(key)}`;
    if (p > 1) u += `&page=${p}`;
    const body = await httpGet(u, headers(''), 20000);
    const cards = parseCards(body);
    return { cards, hasMore: cards.length >= 20 };
  }

  async detail(id) {
    const raw = String(id || '').trim();
    if (!raw) throw new Error('wmtt 缺少漫画 ID');
    const bid = bookID(raw);
    const url = raw.startsWith('http') || raw.startsWith('/') ? abs(raw) : `${HOST}/mangaread/${bid}.html`;
    const page = await httpGet(url, headers(''), 25000);

    let name = htmlText(firstGroup(reH1, page)).replace(/^《|》$/g, '').trim();
    if (!name) throw new Error('wmtt 详情解析失败: ' + bid);

    const author = htmlText(firstGroup(reAuthor, page)).replace(/\s+/g, ' ').trim();
    const tags = [];
    for (const m of page.matchAll(reTag)) {
      const t = htmlText(m[1]).trim();
      if (t && !['/', '|', ','].includes(t)) tags.push(t);
    }
    let desc = htmlText(firstGroup(reDesc, page));
    if (!desc) desc = htmlText(firstGroup(reDesc2, page));
    desc = desc.replace(/\s+/g, ' ').trim();

    let pic = '';
    for (const m of page.matchAll(reCover)) {
      const u = m[1];
      if (u.includes('thumb.niaopic.com') && !u.includes('error.png') && !u.includes('logo')) {
        pic = coverJpg(u);
        break;
      }
    }
    if (!pic) pic = coverJpg(firstGroup(reOgImage, page));

    const chapters = [];
    const seen = new Set();
    const push = (href, title) => {
      const chUrl = abs(href);
      if (!chUrl || seen.has(chUrl)) return;
      seen.add(chUrl);
      const chName = htmlText(title).trim();
      if (!chName) return;
      chapters.push({ no: chapters.length + 1, name: chName, url: chUrl });
    };
    for (const m of page.matchAll(reChap)) push(m[1], m[2]);
    if (chapters.length === 0) {
      for (const m of page.matchAll(reChapFallback)) push(m[1], m[2]);
    }
    if (chapters.length === 0) throw new Error('wmtt 详情无章节: ' + bid);

    let remarks = tags.length ? tags.join(' / ') : '';
    if (!remarks) remarks = `共${chapters.length}话`;

    return BookDetail({
      id: bid,
      name,
      pic,
      desc,
      tag: tags.join(' / '),
      remarks,
      author,
      chapters,
      count: chapters.length,
      adult: true,
    });
  }

  async pics(ref) {
    const raw = String(ref || '').trim();
    if (!raw) throw new Error('wmtt 缺少章节地址');
    const url = raw.startsWith('http') ? raw : abs(raw);
    const page = await httpGet(url, headers(url), 25000);
    const pics = [];
    const seen = new Set();
    const add = (u) => {
      const full = abs(u);
      if (!full) return;
      if (!/\.(jpg|jpeg|png|webp|gif)(\?|$)/i.test(full)) return;
      if (full.includes('/imgs/logo') || full.includes('error.png')) return;
      if (seen.has(full)) return;
      seen.add(full);
      pics.push(full);
    };
    for (const m of page.matchAll(reCover)) add(m[1]);
    if (pics.length === 0) {
      for (const m of page.matchAll(reImgAny)) add(m[1]);
    }
    if (pics.length === 0) throw new Error('wmtt 章节无图片');
    return ComicPlay({ pics, referer: url, ua: UA });
  }
}

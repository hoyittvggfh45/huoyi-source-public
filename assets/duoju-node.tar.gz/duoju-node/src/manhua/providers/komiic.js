
import { httpPostJSON } from '../core/http.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const komiicBase = 'https://komiic.com';
const komiicQuery = 'https://komiic.com/api/query';
const komiicUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

function komiicHeaders() {
  return {
    'User-Agent': komiicUA,
    Referer: komiicBase + '/',
    'Content-Type': 'application/json',
    'X-Komiic-Skip-Auth': '1',
  };
}

const komiicComicFields = 'id title status imageUrl authors { id name } categories { id name } dateUpdated monthViews views favoriteCount lastChapterUpdate';

async function komiicQueryAPI(operationName, query, variables) {
  const body = JSON.stringify({ operationName, variables, query });
  const raw = await httpPostJSON(komiicQuery, body, komiicHeaders(), 25000);
  let parsed = null;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error(`komiic: 非 JSON 响应: ${String(raw).slice(0, 80)}`);
  }
  if (Array.isArray(parsed?.errors) && parsed.errors.length > 0) {
    throw new Error(`komiic: ${parsed.errors[0]?.message ?? ''}`);
  }
  if (!parsed?.data || typeof parsed.data !== 'object') {
    throw new Error('komiic: 接口未返回数据');
  }
  return parsed.data;
}

function toCards(items) {
  const out = [];
  for (const raw of items || []) {
    if (!raw || typeof raw !== 'object') continue;
    const id = String(raw.id ?? '');
    const title = String(raw.title ?? '');
    if (!id || !title) continue;
    const authors = [];
    for (const a of Array.isArray(raw.authors) ? raw.authors : []) {
      if (a?.name) authors.push(String(a.name));
    }
    const cats = [];
    for (const g of Array.isArray(raw.categories) ? raw.categories : []) {
      if (g?.name) cats.push(String(g.name));
    }
    let remarks = String(raw.lastChapterUpdate ?? '').trim();
    if (raw.status === 'END') {
      remarks = `${remarks} · 完結`.trim();
    } else if (String(raw.status ?? '').toLowerCase() === 'ongoing') {
      remarks = `${remarks} · 連載`.trim();
    }
    out.push(Card({
      id,
      name: title,
      pic: String(raw.imageUrl ?? ''),
      author: authors.join(' / '),
      cat: cats.join(' · '),
      remarks,
      plat: 'komiic',
    }));
  }
  return out;
}

function chapNum(s) {
  const n = parseInt(String(s ?? '').trim(), 10);
  return Number.isFinite(n) ? n : 0;
}

export class ProviderKomiic {
  key() { return 'komiic'; }
  name() { return 'Komiic'; }
  adult() { return false; }
  desc() { return 'Komiic 漫画 GraphQL API（繁体站）'; }

  cats() {
    return [
      { id: 'recent', name: '最近更新' },
      { id: 'hot', name: '熱門' },
      { id: 'c8', name: '冒險' },
      { id: 'c1', name: '愛情' },
      { id: 'c21', name: '熱血' },
      { id: 'c11', name: '魔幻' },
      { id: 'c4', name: '校園' },
      { id: 'c13', name: '格鬥' },
      { id: 'c7', name: '懸疑' },
      { id: 'c5', name: '搞笑' },
      { id: 'c16', name: '耽美' },
      { id: 'c18', name: '百合' },
      { id: 'c35', name: '武俠' },
    ];
  }

  async list(cat, page) {
    cat = String(cat || '');
    if (!cat) cat = 'recent';
    if (cat.startsWith('c')) {
      const id = cat.slice(1);
      const data = await komiicQueryAPI(
        'comicByCategories',
        `query comicByCategories($categoryId: [ID!]!, $pagination: Pagination!) {
\tcomicByCategories(categoryId: $categoryId, pagination: $pagination) { ${komiicComicFields} } }`,
        {
          categoryId: [id],
          pagination: {
            limit: 30, offset: (page - 1) * 30,
            orderBy: 'DATE_UPDATED', asc: false, status: '',
          },
        },
      );
      const cards = toCards(data.comicByCategories);
      return { cards, hasMore: cards.length >= 30 };
    }
    let op = 'recentUpdate';
    let orderBy = 'DATE_UPDATED';
    if (cat === 'hot') {
      op = 'hotComics';
      orderBy = 'VIEWS';
    }
    const data = await komiicQueryAPI(
      op,
      `query ${op}($pagination: Pagination!) {
\t${op}(pagination: $pagination) { ${komiicComicFields} } }`,
      {
        pagination: {
          limit: 20, offset: (page - 1) * 20,
          orderBy, status: '', asc: true,
        },
      },
    );
    const cards = toCards(data[op]);
    return { cards, hasMore: cards.length >= 20 };
  }

  async search(wd, page) {
    if (page > 1) return { cards: [], hasMore: false };
    const data = await komiicQueryAPI(
      'searchComicAndAuthorQuery',
      `query searchComicAndAuthorQuery($keyword: String!) {
\tsearchComicsAndAuthors(keyword: $keyword) {
\t\tcomics { ${komiicComicFields} }
\t\tauthors { id name comicCount }
\t} }`,
      { keyword: String(wd ?? '').trim() },
    );
    const res = data.searchComicsAndAuthors || {};
    const cards = toCards(res.comics);
    return { cards, hasMore: cards.length >= 20 };
  }

  async detail(id) {
    id = String(id ?? '').trim();
    if (!id) throw new Error('komiic: 空的漫画 ID');
    const data = await komiicQueryAPI(
      'comicByIds',
      `query comicByIds($comicIds: [ID]!) {
\tcomicByIds(comicIds: $comicIds) { ${komiicComicFields} } }`,
      { comicIds: [id] },
    );
    const items = data.comicByIds || [];
    if (items.length === 0) throw new Error('komiic: 漫画不存在');
    const base = toCards(items)[0];
    const chapData = await komiicQueryAPI(
      'chapterByComicId',
      `query chapterByComicId($comicId: ID!) {
\tchaptersByComicId(comicId: $comicId) { id serial type dateUpdated } }`,
      { comicId: id },
    );
    const rawChaps = chapData.chaptersByComicId || [];
    const chaps = [];
    for (const raw of rawChaps) {
      if (!raw || typeof raw !== 'object') continue;
      if (raw.id) chaps.push({ id: String(raw.id), serial: String(raw.serial ?? ''), type: String(raw.type ?? '') });
    }
    
    for (let i = 0; i < chaps.length; i++) {
      for (let j = i + 1; j < chaps.length; j++) {
        if (chapNum(chaps[j].serial) < chapNum(chaps[i].serial)) {
          [chaps[i], chaps[j]] = [chaps[j], chaps[i]];
        }
      }
    }
    const chapters = chaps.map((c, i) => {
      let name = `第 ${c.serial.replace(/^0+/, '')} 話`;
      const n = chapNum(c.serial);
      if (n > 0) name = `第 ${n} 話`;
      if (c.type && c.type !== 'chapter') name += ` · ${c.type}`;
      return Chapter(i + 1, name, `${id}|${c.id}`);
    });
    return BookDetail({
      id: base.vod_id,
      name: base.vod_name,
      pic: base.vod_pic,
      desc: base.vod_content || '',
      tag: base.vod_class || '',
      remarks: `${chapters.length} 話`,
      author: base.vod_director || '',
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const parts = String(ref ?? '').split('|');
    if (parts.length < 2 || !parts[0] || !parts[1]) {
      throw new Error(`komiic: 无效的章节引用 "${ref}"`);
    }
    const data = await komiicQueryAPI(
      'imagesByChapterId',
      `query imagesByChapterId($chapterId: ID!) {
\timagesByChapterId(chapterId: $chapterId) { id kid height width } }`,
      { chapterId: parts[1] },
    );
    const rawImgs = data.imagesByChapterId || [];
    const pics = [];
    for (const raw of rawImgs) {
      if (!raw || typeof raw !== 'object' || !raw.kid) continue;
      pics.push(`${komiicBase}/api/image/${raw.kid}`);
    }
    return ComicPlay({
      pics,
      referer: `${komiicBase}/comic/${parts[0]}/chapter/${parts[1]}`,
      ua: komiicUA,
    });
  }
}

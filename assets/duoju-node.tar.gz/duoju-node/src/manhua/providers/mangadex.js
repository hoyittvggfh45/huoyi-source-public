
import { httpGetJSON, encode } from '../core/http.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const mdAPI = 'https://api.mangadex.org';
const mdUploads = 'https://uploads.mangadex.org';
const mdReferer = 'https://mangadex.org/';
const mdPageSize = 24;

export const MANGADEX_CATS = [
  { id: 'latest', name: '最新更新' },
  { id: 'followed', name: '热门' },
  { id: 'rating', name: '高分' },
  { id: 'tag:391b0423-d847-456f-aff0-8b0cfc03066b', name: '动作' },
  { id: 'tag:423e2eae-a7a2-4a8b-ac03-a8351462d71d', name: '恋爱' },
  { id: 'tag:4d32cc48-9f00-4cca-9b5a-a839f0764984', name: '喜剧' },
  { id: 'tag:87cc87cd-a395-47af-b27a-93258283bbc6', name: '冒险' },
  { id: 'tag:256c8bd9-4904-4360-bf4f-508a76d67183', name: '科幻' },
  { id: 'tag:799c202e-7daa-44eb-9cf7-8a3c0441531e', name: '武斗' },
  { id: 'tag:07251805-a27e-4d59-b488-f0bfbec15168', name: '悬疑' },
  { id: 'tag:33771934-028e-4cb3-8744-691e866a923e', name: '历史' },
  { id: 'tag:69964a64-2f90-4d33-beeb-f3ed2875eb4c', name: '运动' },
  { id: 'tag:3e2b8dae-350e-4ab8-a8ce-016e844b9f0d', name: '长条' },
];

function mdHeaders() {
  return {
    Referer: mdReferer,
    Origin: 'https://mangadex.org',
    Accept: 'application/json',
    
    
    'User-Agent': 'duoju-super/1.0 (github.com/duoju-super)',
  };
}

function mdQuery(parts) {
  return parts.map(([k, v]) => `${encode(k)}=${encode(v)}`).join('&');
}

function hasCJK(s) {
  for (const ch of String(s)) {
    const cp = ch.codePointAt(0);
    if (cp >= 0x4e00 && cp <= 0x9fff) return true;
  }
  return false;
}

const mdTagCN = {
  Action: '动作', Romance: '恋爱', Comedy: '喜剧', Adventure: '冒险',
  'Sci-Fi': '科幻', 'Martial Arts': '武斗', Thriller: '惊悚', Historical: '历史',
  Sports: '运动', 'Long Strip': '长条', Fantasy: '奇幻', Drama: '剧情',
  Horr: '恐怖', Mystery: '悬疑', Psychological: '心理', 'Slice of Life': '日常',
  Supernatural: '超能力', Reincarnation: '转生', Isekai: '异世界',
  'Full Color': '全彩', 'Official Colored': '官方彩色', 'Web Comic': '网络漫画',
  Oneshot: '短篇', 'Award Winning': '获奖作品', Magic: '魔法', Demons: '恶魔',
  Monsters: '怪物', Ghosts: '幽灵', Mecha: '机甲', Cooking: '美食',
  Police: '警察', 'Office Workers': '职场', 'School Life': '校园',
  Ninja: '忍者', Samurai: '武士', Zombies: '丧尸', Survival: '生存',
  'Time Travel': '时光穿梭', 'Virtual Reality': '虚拟现实', Superhero: '超级英雄',
};

const mdTitleOrder = [
  'zh-hk', 'zh', 'zh-tw', 'zh-Hans', 'zh-Hant',
  'ja-ro', 'en', 'ja', 'ko', 'es-la', 'pt-br', 'fr', 'ru',
];

function mdTitle(m) {
  if (!m || typeof m !== 'object') return '';
  for (const loc of mdTitleOrder) {
    const v = m[loc];
    if (typeof v === 'string' && v.trim()) return v.trim();
  }
  for (const k of Object.keys(m).sort()) {
    const s = m[k];
    if (typeof s === 'string' && s.trim()) return s.trim();
  }
  return '';
}

function mdNames(title, altTitles) {
  const n = mdTitle(title);
  if (n && hasCJK(n)) return n;
  for (const alt of Array.isArray(altTitles) ? altTitles : []) {
    const an = mdTitle(alt);
    if (an && hasCJK(an)) return an;
  }
  if (n) return n;
  for (const alt of Array.isArray(altTitles) ? altTitles : []) {
    const an = mdTitle(alt);
    if (an) return an;
  }
  return '';
}

function mdCards(resp) {
  const out = [];
  for (const it of Array.isArray(resp?.data) ? resp.data : []) {
    const attrs = it?.attributes ?? {};
    const id = String(it?.id ?? '');
    const name = mdNames(attrs.title, attrs.altTitles);
    if (!name) continue;
    let pic = '';
    for (const rel of Array.isArray(it?.relationships) ? it.relationships : []) {
      if (rel?.type === 'cover_art') {
        const fn = rel?.attributes?.fileName;
        if (typeof fn === 'string' && fn) {
          pic = `${mdUploads}/covers/${id}/${fn}.256.jpg`;
        }
        break;
      }
    }
    const tags = [];
    for (const tg of Array.isArray(attrs.tags) ? attrs.tags : []) {
      let n = mdTitle(tg?.attributes?.name);
      if (!n) continue;
      if (mdTagCN[n]) n = mdTagCN[n];
      if (tags.length < 3) tags.push(n);
    }
    tags.sort();
    let remarks = tags.join('·');
    if (attrs.status === 'completed') {
      if (remarks) remarks += '·';
      remarks += '完结';
    }
    out.push(Card({
      id,
      name,
      pic,
      remarks,
      desc: mdTitle(attrs.description),
      plat: 'mangadex',
    }));
  }
  return out;
}

function mdListParams() {
  return [
    ['limit', String(mdPageSize)],
    ['hasAvailableChapters', 'true'],
    ['availableTranslatedLanguage[]', 'zh'],
    ['availableTranslatedLanguage[]', 'zh-hk'],
    ['contentRating[]', 'safe'],
    ['contentRating[]', 'suggestive'],
    ['contentRating[]', 'erotica'],
    ['includes[]', 'cover_art'],
  ];
}

async function mdMangaList(extra, page) {
  if (page < 1) page = 1;
  const offset = (page - 1) * mdPageSize;
  const parts = mdListParams();
  parts.push(['offset', String(offset)]);
  parts.push(...extra);
  const body = await httpGetJSON(`${mdAPI}/manga?${mdQuery(parts)}`, mdHeaders(), 20000);
  let resp = null;
  try {
    resp = JSON.parse(body);
  } catch {
    throw new Error('mangadex: 非 JSON 响应');
  }
  return resp;
}

export class ProviderMangadex {
  key() { return 'mangadex'; }
  name() { return 'MangaDex'; }
  desc() { return 'MangaDex 官方 API（中文翻译组聚合，全球分布式图源）'; }
  adult() { return false; }

  cats() { return MANGADEX_CATS; }

  async list(cat, page) {
    cat = String(cat ?? '');
    let extra;
    if (!cat || cat === 'latest') {
      extra = [['order[latestUploadedChapter]', 'desc']];
    } else if (cat === 'followed') {
      extra = [['order[followedCount]', 'desc']];
    } else if (cat === 'rating') {
      extra = [['order[rating]', 'desc']];
    } else if (cat.startsWith('tag:')) {
      extra = [
        ['includedTags[]', cat.slice(4)],
        ['includedTagsMode', 'AND'],
        ['order[latestUploadedChapter]', 'desc'],
      ];
    } else {
      extra = [['order[latestUploadedChapter]', 'desc']];
    }
    const resp = await mdMangaList(extra, page);
    if (resp?.result !== 'ok') throw new Error(`mangadex: result=${resp?.result ?? ''}`);
    const offset = (Math.max(page, 1) - 1) * mdPageSize;
    return { cards: mdCards(resp), hasMore: offset + (resp.data?.length ?? 0) < (resp.total ?? 0) };
  }

  async search(wd, page) {
    const resp = await mdMangaList([['title', String(wd ?? '')]], page);
    const offset = (Math.max(page, 1) - 1) * mdPageSize;
    return { cards: mdCards(resp), hasMore: offset + (resp.data?.length ?? 0) < (resp.total ?? 0) };
  }

  async detail(id) {
    const body = await httpGetJSON(`${mdAPI}/manga/${id}?includes%5B%5D=cover_art&includes%5B%5D=author`, mdHeaders(), 25000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('mangadex: 详情解析失败');
    }
    if (resp?.result !== 'ok') throw new Error(`mangadex: 详情 result=${resp?.result ?? ''}`);
    const attrs = resp?.data?.attributes ?? {};
    const name = mdNames(attrs.title, attrs.altTitles);
    let pic = '';
    let author = '';
    for (const rel of Array.isArray(resp?.data?.relationships) ? resp.data.relationships : []) {
      if (rel?.type === 'cover_art' && !pic) {
        const fn = rel?.attributes?.fileName;
        if (typeof fn === 'string') pic = `${mdUploads}/covers/${id}/${fn}.256.jpg`;
      }
      if (rel?.type === 'author' && !author) {
        const n = rel?.attributes?.name;
        if (typeof n === 'string') author = n;
      }
    }
    let tag = '';
    for (const tg of Array.isArray(attrs.tags) ? attrs.tags : []) {
      let n = mdTitle(tg?.attributes?.name);
      if (n) {
        if (mdTagCN[n]) n = mdTagCN[n];
        tag = n;
        break;
      }
    }

    const chapters = [];
    const seen = new Set();
    for (let offset = 0; offset === 0 || offset < 5000; offset += 500) {
      const parts = [
        ['limit', '500'],
        ['offset', String(offset)],
        ['translatedLanguage[]', 'zh'],
        ['translatedLanguage[]', 'zh-hk'],
        ['order[chapter]', 'asc'],
        ['order[volume]', 'asc'],
        ['includeEmptyPages', '0'],
        ['includeExternalUrl', '0'],
        ['contentRating[]', 'safe'],
        ['contentRating[]', 'suggestive'],
        ['contentRating[]', 'erotica'],
      ];
      let feed = null;
      try {
        const feedBody = await httpGetJSON(`${mdAPI}/manga/${id}/feed?${mdQuery(parts)}`, mdHeaders(), 25000);
        feed = JSON.parse(feedBody);
      } catch (e) {
        if (offset > 0) break;
        throw e;
      }
      const feedData = Array.isArray(feed?.data) ? feed.data : [];
      for (const ch of feedData) {
        const chAttrs = ch?.attributes ?? {};
        if (chAttrs.externalUrl) continue;
        const chID = String(ch?.id ?? '');
        if (!chID || seen.has(chID)) continue;
        seen.add(chID);
        const chName = String(chAttrs.chapter ?? '').trim();
        const title = String(chAttrs.title ?? '').trim();
        let label = '';
        if (chName) {
          label = `第${chName.replace(/\.0$/, '')}话`;
        } else {
          label = `第${chapters.length + 1}话`;
        }
        if (title && title !== 'Oneshot') label += ` ${title}`;
        chapters.push(Chapter(chapters.length + 1, label, chID));
      }
      if (feedData.length < 500) break;
    }
    if (!name) throw new Error('mangadex: 详情解析失败');
    let status = String(attrs.status ?? '');
    if (status === 'completed') status = '已完结';
    else if (status === 'ongoing') status = '连载中';
    return BookDetail({
      id,
      name,
      pic,
      desc: mdTitle(attrs.description),
      tag,
      remarks: `${chapters.length} 话·${status}`,
      author,
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    ref = String(ref ?? '').trim();
    if (!ref || ref.includes('/')) throw new Error(`mangadex: 非法章节凭证 ${ref}`);
    const body = await httpGetJSON(`${mdAPI}/at-home/server/${ref}`, mdHeaders(), 25000);
    let home = null;
    try {
      home = JSON.parse(body);
    } catch {
      throw new Error('mangadex: at-home 解析失败');
    }
    if (home?.result !== 'ok' || !home?.baseUrl) throw new Error('mangadex: at-home 无可用节点');
    const hash = String(home?.chapter?.hash ?? '');
    const dataFiles = Array.isArray(home?.chapter?.data) ? home.chapter.data : [];
    const saverFiles = Array.isArray(home?.chapter?.dataSaver) ? home.chapter.dataSaver : [];
    let pics = dataFiles.map((f) => `${home.baseUrl}/data/${hash}/${f}`);
    if (pics.length === 0) {
      pics = saverFiles.map((f) => `${home.baseUrl}/data-saver/${hash}/${f}`);
    }
    if (pics.length === 0) throw new Error('mangadex: 章节无图片');
    return ComicPlay({ pics, referer: mdReferer });
  }
}

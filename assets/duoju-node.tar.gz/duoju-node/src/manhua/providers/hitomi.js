
import { httpGet, upstreamRequest, defaultUA } from '../core/http.js';
import { Card, BookDetail, ComicPlay } from '../types.js';

const WEB = 'https://hitomi.la';
const CDN = 'https://ltn.gold-usergeneratedcontent.net';
const IMAGE_HOST = 'gold-usergeneratedcontent.net';

function htHeaders() {
  return {
    'User-Agent': 'Breeze-plugin-hitomi/0.1.0',
    Referer: `${WEB}/`,
  };
}


let ggB = '';
let ggZeroSet = null;
let ggLoadAt = 0;
let ggLoading = null;

async function loadGG() {
  const fresh = Date.now() - ggLoadAt < 10 * 60 * 1000;
  if (fresh && ggZeroSet && ggB) return;
  if (ggLoading) return ggLoading;
  ggLoadAt = Date.now();
  ggLoading = (async () => {
    try {
      const body = await httpGet(`${CDN}/gg.js`, htHeaders(), 20000);
      const m = body.match(/b:\s*'([^']+)'/);
      if (m) ggB = m[1];
      const zeroSet = new Set();
      const i = body.indexOf('o = 0;');
      if (i > 0) {
        let blk = body.slice(0, i);
        const j = blk.lastIndexOf('switch');
        if (j >= 0) blk = blk.slice(j);
        for (const cm of [...blk.matchAll(/case (\d+):/g)]) {
          zeroSet.add(parseInt(cm[1], 10) || 0);
        }
      }
      if (zeroSet.size > 0) ggZeroSet = zeroSet;
    } catch {  }
  })();
  try {
    await ggLoading;
  } finally {
    ggLoading = null;
  }
}

function ggM(g) {
  if (g < 0 || g >= 100000) return 0;
  if (ggZeroSet && ggZeroSet.has(g)) return 0;
  return 1;
}

function tailG(h) {
  if (h.length < 3) return 0;
  const m = h.match(/([0-9a-f]{2})([0-9a-f])$/);
  if (!m) return 0;
  return parseInt(m[2] + m[1], 16);
}

function subdomain(hash) {
  return 1 + ggM(tailG(hash.toLowerCase()));
}

function ggS(hash) {
  const m = hash.match(/(..)(.)$/);
  if (!m) return '0';
  return String(parseInt(m[2] + m[1], 16));
}

function imageURL(hash, hasWebp, hasAvif) {
  const h = hash.toLowerCase();
  let ext = 'jpg';
  let prefix = 'a';
  if (hasAvif) ext = 'avif';
  else if (hasWebp) { ext = 'webp'; prefix = 'w'; }
  const m = ggM(tailG(h));
  const sub = prefix + String(1 + m);
  return `https://${sub}.${IMAGE_HOST}/${ggB}${ggS(h)}/${h}.${ext}`;
}

function thumbURL(hash) {
  const h = hash.toLowerCase();
  const m = h.match(/^(.*)(..)(.)$/);
  if (!m) return `https://tn.${IMAGE_HOST}/webpbigtn/${h}.webp`;
  return `https://tn.${IMAGE_HOST}/webpbigtn/${m[3]}/${m[2]}/${h}.webp`;
}

function nozomiURL(area, tag, language) {
  const file = `${tag}-${language}.nozomi`;
  if (!area || area === 'all') return `${CDN}/${file}`;
  return `${CDN}/${area}/${file}`;
}

function decodeNozomi(body) {
  const ids = [];
  for (let i = 0; i + 4 <= body.length; i += 4) {
    ids.push(String(body.readUInt32BE(i)));
  }
  return ids;
}

async function fetchRange(url, headers) {
  const { status, buf, respHeaders } = await upstreamRequest(url, {
    method: 'GET',
    headers: { 'User-Agent': defaultUA, ...headers },
    timeoutMs: 20000,
  });
  if (status !== 200 && status !== 206) {
    throw new Error(`hitomi: HTTP ${status}`);
  }
  const b = buf.length > 4 * 1024 * 1024 ? buf.subarray(0, 4 * 1024 * 1024) : buf;
  return { body: b, contentRange: respHeaders['content-range'] || '' };
}

async function fetchNozomiPage(url, page) {
  const start = (page - 1) * 25 * 4;
  const end = start + 25 * 4 - 1;
  const headers = { ...htHeaders(), Range: `bytes=${start}-${end}` };
  const raw = await fetchRange(url, headers);
  let total = 0;
  const m = raw.contentRange.match(/\/ (\d+)\s*$/);
  if (m) {
    total = (parseInt(m[1], 10) || 0) / 4;
  }
  return [decodeNozomi(raw.body), total];
}

async function fetchGallery(id) {
  const body = await httpGet(`${CDN}/galleries/${id}.js`, htHeaders(), 20000);
  let s = body.trim();
  s = s.replace(/^var galleryinfo\s*=/, '');
  s = s.replace(/;\s*$/, '');
  let g;
  try {
    g = JSON.parse(s);
  } catch (err) {
    throw new Error(`hitomi: gallery 解析失败: ${err.message}`);
  }
  return g;
}

async function mapLimit(items, n, fn) {
  const out = new Array(items.length);
  let idx = 0;
  const worker = async () => {
    for (;;) {
      const i = idx++;
      if (i >= items.length) return;
      try {
        out[i] = await fn(items[i], i);
      } catch {
        out[i] = null;
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(n, Math.max(items.length, 1)) }, worker));
  return out;
}

async function htCards(ids) {
  const results = await mapLimit(ids, 6, (id) => fetchGallery(id));
  const out = [];
  for (const g of results) {
    if (!g || !String(g.id ?? '') || !g.title) continue;
    let pic = '';
    if (g.files && g.files.length > 0) pic = thumbURL(g.files[0].hash);
    const authors = (g.artists || []).map((a) => a.artist).filter(Boolean);
    const tags = [];
    for (const t of g.tags || []) {
      if (tags.length >= 3) break;
      if (t.tag) tags.push(t.tag);
    }
    let remarks = String(g.type || '').trim();
    if (g.language && g.language !== 'none') remarks += ` · ${g.language}`;
    out.push(Card({
      id: String(g.id),
      name: g.title,
      pic,
      remarks,
      cat: tags.join(' '),
      author: authors.join(' / '),
      plat: 'hitomi',
    }));
  }
  return out;
}

export class ProviderHitomi {
  key() { return 'hitomi'; }
  name() { return 'hitomi'; }
  adult() { return true; }
  desc() { return 'hitomi.la：nozomi 索引分页 + gg.js 图片 URL 算法'; }

  cats() {
    return [
      { id: 'all|index|all', name: '全部' },
      { id: 'all|index|chinese', name: '中文' },
      { id: 'all|index|english', name: '英语' },
      { id: 'all|index|japanese', name: '日语' },
      { id: 'tag|doujinshi-chinese|all', name: '同人·中文' },
      { id: 'tag|manga-chinese|all', name: '漫画·中文' },
      { id: 'tag|artistcg-chinese|all', name: 'CG·中文' },
      { id: 'tag|gamecg-chinese|all', name: '游戏CG·中文' },
    ];
  }

  async list(cat, page) {
    let area = 'all';
    let tag = 'index';
    let lang = 'all';
    const parts = String(cat || '').split('|');
    if (parts.length === 3) {
      [area, tag, lang] = parts;
    }
    const [ids, total] = await fetchNozomiPage(nozomiURL(area, tag, lang), page);
    const cards = await htCards(ids);
    const hasMore = (total === 0 || page * 25 < total) && cards.length > 0;
    return { cards, hasMore };
  }

  async search(wd, page) {
    const tag = String(wd || '').trim().replace(/ /g, '_').toLowerCase();
    const [ids, total] = await fetchNozomiPage(nozomiURL('tag', tag, 'all'), page);
    const cards = await htCards(ids);
    const hasMore = (total === 0 || page * 25 < total) && cards.length > 0;
    return { cards, hasMore };
  }

  async detail(id) {
    const g = await fetchGallery(id);
    let pic = '';
    if (g.files && g.files.length > 0) pic = thumbURL(g.files[0].hash);
    const tags = (g.tags || []).map((t) => t.tag).filter(Boolean);
    const authors = (g.artists || []).map((a) => a.artist).filter(Boolean);
    const nPages = g.files && g.files.length > 0 ? g.files.length : 0;
    return BookDetail({
      id,
      name: g.title || '',
      pic,
      tag: tags.join(' · '),
      remarks: `${nPages}P ${g.type || ''}`,
      author: authors.join(' / '),
      chapters: [{ no: 1, name: '全一话', url: id }],
      count: 1,
      adult: true,
    });
  }

  async pics(ref) {
    const g = await fetchGallery(ref);
    await loadGG();
    const pics = (g.files || []).map((f) => imageURL(f.hash, (f.haswebp || 0) > 0, (f.hasavif || 0) > 0));
    if (pics.length === 0) throw new Error('hitomi: 无图片');
    return ComicPlay({ pics, referer: `${WEB}/`, ua: 'Breeze-plugin-hitomi/0.1.0' });
  }
}

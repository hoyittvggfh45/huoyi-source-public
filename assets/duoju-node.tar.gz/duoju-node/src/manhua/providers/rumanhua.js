
import { httpGet, httpPostForm, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';
import { mhgUnpack } from './manhuagui.js';

const rmhBase = 'http://www.rumanhua2.com';
const rmhUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36';

function rmhHeaders(ref) {
  const h = {
    'User-Agent': rmhUA,
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9',
  };
  if (ref) h.Referer = ref;
  return h;
}

const reRmhCard = /<div class="likedata">([\s\S]*?)<\/div>\s*<\/div>/gis;
const reRmhCardID = /href="\/([A-Za-z0-9]{6,10})\/"/;
const reRmhImg = /<img[^>]+data-src="([^"]+)"[^>]*alt="([^"]*)"/i;
const reRmhTitle = /<p class="le-t">([\s\S]*?)<\/p>/is;
const reRmhMeta = /<p>([\s\S]*?)<\/p>/gis;
const reRmhDesc = /<p class="le-j">([\s\S]*?)<\/p>/is;

const reRmhSItem = /<div class="col-auto">([\s\S]*?)<\/div>\s*<\/div>/gis;
const reRmhSLink = /href="\/([A-Za-z0-9]{6,10})\/"/;
const reRmhSImg = /<img[^>]+(?:data-src|src)="([^"]+)"[^>]*alt="([^"]*)"/i;
const reRmhSTitle = /class="e-title"[^>]*>([\s\S]*?)</is;
const reRmhSAuthor = /class="tip"[^>]*>([\s\S]*?)</is;

const reRmhH1 = /<h1[^>]*class="[^"]*name_mh[^"]*"[^>]*>([\s\S]*?)<\/h1>/is;
const reRmhSpan = /<span[^>]*>([\s\S]*?)<\/span>/gis;
const reRmhP = /<p[^>]*class="[^"]*content[^"]*"[^>]*>([\s\S]*?)<\/p>/is;
const reRmhCover = /property="og:image"[^>]*content="([^"]+)"/i;
const reRmhChapA = /<a[^>]*href="\/[A-Za-z0-9]{6,10}\/([A-Za-z0-9]{6,10})\.html"[^>]*>([\s\S]*?)<\/a>/gis;
const reRmhChapter = /<div class="chapterlistload">([\s\S]*?)<\/div>/is;

const reRmhReaderID = /class="readerContainer"[^>]*data-id="(\d+)"/;
const reRmhScript = /eval\(function\(p,a,c,k,e,d\)([\s\S]*?)\)\s*<\/script>/is;
const reRmhPack = /\}\s*\(\s*'((?:\\.|[^'\\])*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:\\.|[^'\\])*)'/s;
const reRmhCipher = /var __c0rst96="([^"]*)"/;

const rmhImageKeys = [
  'smkhy258', 'smkd95fv', 'md496952', 'cdcsdwq', 'vbfsa256',
  'cawf151c', 'cd56cvda', '8kihnt9', 'dso15tlo', '5ko6plhy',
];

function rmhText(s) {
  return htmlText(s).trim();
}

export class ProviderRumanhua {
  key() { return 'rumanhua'; }
  name() { return '如梦漫画'; }
  adult() { return false; }
  desc() { return '如梦漫画 rumanhua2.com：直连可用，章节图走 Packer+XOR 双重解密'; }

  cats() {
    const cats = [
      { id: 'r1', name: '排行榜' },
      { id: 'r5', name: '更新' },
    ];
    const names = ['冒险', '热血', '都市', '玄幻', '悬疑', '耽美', '恋爱', '生活', '搞笑', '穿越', '修真', '后宫', '女主', '古风', '连载', '完结'];
    for (let i = 0; i < names.length; i++) {
      cats.push({ id: 's' + (i + 1), name: names[i] });
    }
    return cats;
  }

  rmhCards(html) {
    const out = [];
    for (const m of html.matchAll(reRmhCard)) {
      const block = m[1];
      const im = reRmhCardID.exec(block);
      const id = im ? im[1] : '';
      if (!id) continue;
      let name = '';
      let pic = '';
      const tm = reRmhTitle.exec(block);
      if (tm) name = rmhText(tm[1]);
      const gm = reRmhImg.exec(block);
      if (gm) {
        pic = gm[1];
        if (!name) name = gm[2].trim();
      }
      if (!name) continue;
      let remarks = '';
      for (const pm of block.matchAll(reRmhMeta)) {
        const t = rmhText(pm[1]);
        if (t.startsWith('最新：')) {
          remarks = t.slice('最新：'.length);
          break;
        }
      }
      let desc = '';
      const dm = reRmhDesc.exec(block);
      if (dm) desc = rmhText(dm[1]);
      out.push(Card({ id, name, pic, remarks, desc, plat: 'rumanhua' }));
    }
    return out;
  }

  async list(cat, page) {
    if (!cat) cat = 'r1';
    cat = String(cat);
    let path;
    if (cat.startsWith('r')) {
      path = '/rank/' + cat.slice(1);
    } else {
      path = '/sort/' + cat.slice(1);
    }
    const body = await httpGet(rmhBase + path, rmhHeaders(''), 20000);
    if (page > 1) return { cards: [], hasMore: false };
    return { cards: this.rmhCards(body), hasMore: false };
  }

  async search(wd, page) {
    if (page > 1) return { cards: [], hasMore: false };
    const body = await httpPostForm(rmhBase + '/s', `k=${encode(String(wd ?? '').trim())}`, rmhHeaders(rmhBase), 20000);
    const cards = [];
    for (const m of body.matchAll(reRmhSItem)) {
      const block = m[1];
      const im = reRmhSLink.exec(block);
      const id = im ? im[1] : '';
      if (!id) continue;
      let name = '';
      let pic = '';
      const gm = reRmhSImg.exec(block);
      if (gm) {
        pic = gm[1];
        name = gm[2].trim();
      }
      if (!name) {
        const tm = reRmhSTitle.exec(block);
        if (tm) name = rmhText(tm[1]);
      }
      if (!name) continue;
      let author = '';
      const am = reRmhSAuthor.exec(block);
      if (am) author = rmhText(am[1]);
      cards.push(Card({ id, name, pic, author, plat: 'rumanhua' }));
    }
    return { cards, hasMore: false };
  }

  async detail(id) {
    id = String(id ?? '').trim();
    if (!id) throw new Error('rumanhua: 空的漫画 ID');
    const body = await httpGet(`${rmhBase}/${id}/`, rmhHeaders(rmhBase), 25000);
    let title = id;
    const hm = reRmhH1.exec(body);
    if (hm) title = rmhText(hm[1]);
    let cover = '';
    const cm = reRmhCover.exec(body);
    if (cm) cover = cm[1];
    let desc = '';
    const pm = reRmhP.exec(body);
    if (pm) desc = rmhText(pm[1]);
    let author = '';
    let tags = '';
    let status = '';
    for (const sm of body.matchAll(reRmhSpan)) {
      const t = rmhText(sm[1]);
      if (t.startsWith('作者：')) author = t.slice('作者：'.length);
      else if (t.startsWith('标签：')) tags = t.slice('标签：'.length);
      else if (t.startsWith('状态：')) status = t.slice('状态：'.length);
    }
    const seen = new Set();
    const merged = [];
    const appendChaps = (list) => {
      for (const c of list) {
        if (!c.id || !c.name || seen.has(c.id)) continue;
        seen.add(c.id);
        merged.push(c);
      }
    };
    const cmBlock = reRmhChapter.exec(body);
    if (cmBlock) {
      const pageChaps = [];
      for (const am of cmBlock[1].matchAll(reRmhChapA)) {
        pageChaps.push({ id: am[1], name: rmhText(am[2]) });
      }
      appendChaps(pageChaps);
    }
    try {
      const moreBody = await httpPostForm(rmhBase + '/morechapter', `id=${id}`, rmhHeaders(rmhBase), 25000);
      let parsed = null;
      try {
        parsed = JSON.parse(moreBody);
      } catch {
        parsed = null;
      }
      if (parsed && parsed.code === '200' && Array.isArray(parsed.data)) {
        const more = parsed.data.map((c) => ({
          id: String(c?.chapterid ?? '').trim(),
          name: String(c?.chaptername ?? '').trim(),
        }));
        appendChaps(more);
      }
    } catch {
      
    }
    const chapters = [];
    for (let i = merged.length - 1; i >= 0; i--) {
      chapters.push(Chapter(chapters.length + 1, merged[i].name, `${id}|${merged[i].id}`));
    }
    let remarks = '';
    if (chapters.length > 0) remarks = `${chapters.length} 话`;
    if (status.includes('完结')) remarks += ' · 完结';
    else if (status.includes('连载')) remarks += ' · 连载';
    return BookDetail({
      id, name: title, pic: cover, desc,
      tag: tags, remarks, author,
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const parts = String(ref ?? '').split('|');
    if (parts.length < 2 || !parts[0] || !parts[1]) {
      throw new Error(`rumanhua: 无效的章节引用 "${ref}"`);
    }
    const bookID = parts[0];
    const chapID = parts[1];
    const body = await httpGet(`${rmhBase}/${bookID}/${chapID}.html`, rmhHeaders(`${rmhBase}/${bookID}/`), 25000);
    const rm = reRmhReaderID.exec(body);
    if (!rm) throw new Error('rumanhua: 未找到 readerContainer');
    const rid = parseInt(rm[1], 10);
    if (!Number.isFinite(rid) || rid < 0 || rid >= rmhImageKeys.length) {
      throw new Error(`rumanhua: 不支持的 data-id ${rm[1]}`);
    }
    const sm = reRmhScript.exec(body);
    if (!sm) throw new Error('rumanhua: 未找到 packed JS');
    const pm = reRmhPack.exec(sm[1]);
    if (!pm) throw new Error('rumanhua: packed 参数解析失败');
    const unpacked = mhgUnpack(pm[1], pm[4].split('|'), parseInt(pm[2].trim(), 10) || 0);
    const cm = reRmhCipher.exec(unpacked);
    if (!cm) throw new Error('rumanhua: 未找到图片密文');
    const cipher = Buffer.from(cm[1], 'base64');
    const key = Buffer.from(rmhImageKeys[rid], 'utf8');
    const xored = Buffer.alloc(cipher.length);
    for (let i = 0; i < cipher.length; i++) {
      xored[i] = cipher[i] ^ key[i % key.length];
    }
    const inner = Buffer.from(xored.toString('binary'), 'base64');
    let urls = null;
    try {
      urls = JSON.parse(inner.toString('utf8'));
    } catch {
      throw new Error('rumanhua: 图片 JSON 解析失败');
    }
    if (!Array.isArray(urls)) throw new Error('rumanhua: 图片 JSON 解析失败');
    const out = [];
    for (const u of urls) {
      const t = String(u ?? '').trim();
      if (t) out.push(t);
    }
    return ComicPlay({ pics: out, referer: rmhBase + '/', ua: rmhUA });
  }
}

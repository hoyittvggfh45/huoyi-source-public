
import { httpPostForm, md5hex, encode, jsonIDString } from '../core/http.js';
import { Card, BookDetail, ComicPlay } from '../types.js';

const HOST = 'http://android.007ting.com';
const UA = 'Dalvik/2.1.0 (Linux; U; Android 9;MIX 2S Build/PKQ1.180729.001)';
const PAGE_SIZE = 70;

const CAT_NAMES = '全部&热血&玄幻&恋爱&纯爱&都市&冒险&古风&穿越&搞笑&奇幻&萝莉&御姐&后宫&修真&耽美&动作&少年&霸总&生活&武侠&大女主&科幻&剧情&悬疑&韩漫&韩国&更新&新增'.split('&');
const CAT_IDS = '0&1&2&3&32&4&5&6&7&8&10&11&12&13&14&15&16&17&19&20&25&26&27&28&29&30&33&34&35'.split('&');

function headers() {
  return {
    'User-Agent': UA,
    'Content-Type': 'application/x-www-form-urlencoded',
  };
}

async function fetchList(query) {
  const body = await httpPostForm(`${HOST}/android_rest.action`, query, headers(), 15000);
  const resp = JSON.parse(body);
  const items = resp.itemsList || [];
  if (items.length > 0) return items;
  return resp.searchList || [];
}

function itemCard(it) {
  return Card({
    plat: 'mh007',
    name: typeof it.title === 'string' ? it.title : '',
    id: jsonIDString(it.comicId),
    pic: typeof it.imageURL === 'string' ? it.imageURL : '',
    remarks: typeof it.updateMsg === 'string' ? it.updateMsg : '',
    author: typeof it.subTitle === 'string' ? it.subTitle : '',
    desc: typeof it.desc === 'string' ? it.desc : '',
  });
}

export class Provider007 {
  key() { return 'mh007'; }
  name() { return '漫画大全'; }
  desc() { return 'android.007ting.com APP接口（MD5签名）'; }
  adult() { return false; }

  cats() {
    const out = [];
    for (let i = 0; i < CAT_NAMES.length; i++) {
      if (i < CAT_IDS.length) out.push({ id: CAT_IDS[i], name: CAT_NAMES[i] });
    }
    return out;
  }

  listPaged() { return true; }
  searchPaged() { return false; }

  async list(cat, page) {
    if (!cat) cat = '0';
    if (page < 1) page = 1;
    const q = `typeId=${cat}&page=${page}&type=index&userId=0`;
    const items = await fetchList(q);
    const out = [];
    for (const it of items) {
      const card = itemCard(it);
      if (!card.vod_name) continue;
      out.push(card);
    }
    if (out.length === 0 && page === 1) {
      throw new Error('mh007: 列表为空');
    }
    return { cards: out, hasMore: out.length >= PAGE_SIZE / 2 };
  }

  async search(wd, page) {
    if (page > 1) return { cards: [] };
    const q = `type=search&userId=0&word=${encode(wd)}`;
    const items = await fetchList(q);
    const out = [];
    for (const it of items) {
      const card = itemCard(it);
      if (!card.vod_name) continue;
      out.push(card);
    }
    return { cards: out, hasMore: false };
  }

  async detail(id) {
    const q = `id=${id}&type=product&userId=0`;
    const body = await httpPostForm(`${HOST}/android_rest.action`, q, headers(), 15000);
    const d = JSON.parse(body);
    if (!d.title) throw new Error('mh007: 详情解析失败');
    const chapters = [];
    for (const ch of d.chapterList || []) {
      const pid = jsonIDString(ch.partId);
      if (!pid) continue;
      chapters.push({ no: chapters.length + 1, name: ch.partName || '', url: `${id}|${pid}` });
    }
    return BookDetail({
      id,
      name: d.title,
      pic: d.imageURL || '',
      desc: d.desc || '',
      tag: '漫画',
      remarks: d.updateMsg || '',
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const parts = String(ref).split('|');
    if (parts.length !== 2 || !parts[0].trim() || !parts[1].trim()) {
      throw new Error(`mh007: 非法章节凭证 ${ref}`);
    }
    const [id, partID] = parts;
    const videoSign = md5hex(`-${id}-${partID}-TcbmGhl247Bc-Rd-android`);
    const q = `chapterId=${partID}&videoSign=${videoSign}&id=${id}&type=imagesList`;
    const body = await httpPostForm(`${HOST}/android_rest.action`, q, headers(), 15000);
    const resp = JSON.parse(body);
    const pics = [];
    for (const it of resp.imagesList || []) {
      const u = String(it.imageURL || '').trim();
      if (u) pics.push(u);
    }
    if (pics.length === 0) throw new Error('mh007: 章节无图片');
    return ComicPlay({ pics, referer: `${HOST}/`, ua: UA });
  }
}

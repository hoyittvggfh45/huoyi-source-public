
import { httpGet, encode, jsonIDString } from '../core/http.js';
import { BookDetail, ComicPlay, Chapter } from '../types.js';

const zmHost = 'https://v4api.zaimanhua.com';
const zmReferer = 'https://manhua.zaimanhua.com/';
const zmUA = 'Mozilla/5.0 (Linux; Android 8.1.0; JKM-AL00b) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.126 MQQBrowser/6.2 TBS/044807 Mobile Safari/537.36';
const zmArgs = '&channel=pc&app_name=zmh&version=1.0.0&timestamp=0&uid=0';
const zmSize = 24;

function zmHeaders() {
  return { 'User-Agent': zmUA, Referer: zmReferer };
}

function zmCardToCard(c) {
  let id = String(c?.comic_py ?? '').trim();
  if (!id) id = jsonIDString(c?.id);
  return {
    id,
    name: String(c?.title ?? '').trim(),
    pic: String(c?.cover ?? '').trim(),
    remarks: String(c?.last_update_chapter_name ?? '').trim(),
    cat: String(c?.types ?? '').trim(),
    author: String(c?.authors ?? '').trim(),
    plat: 'zaimanhua',
  };
}

export class ProviderZaimanhua {
  key() { return 'zaimanhua'; }
  name() { return '再漫画'; }
  desc() { return 'zaimanhua.com 官方 API（人气/吐槽/订阅榜）'; }
  adult() { return false; }

  cats() {
    return [
      { id: '0', name: '人气榜' },
      { id: '1', name: '吐槽榜' },
      { id: '2', name: '订阅榜' },
    ];
  }

  async list(cat, page) {
    if (page < 1) page = 1;
    if (!String(cat ?? '').trim()) cat = '0';
    const u = `${zmHost}/app/v1/comic/rank/list?tag_id=0&by_time=0&rank_type=${encode(cat)}&page=${page}&size=${zmSize}${zmArgs}`;
    const body = await httpGet(u, zmHeaders(), 15000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('zaimanhua: 非 JSON 响应');
    }
    const out = [];
    for (const it of Array.isArray(resp?.data) ? resp.data : []) {
      const c = zmCardToCard(it);
      if (c.name) out.push(c);
    }
    return { cards: out, hasMore: out.length > 0 };
  }

  async search(wd, page) {
    if (page < 1) page = 1;
    const u = `${zmHost}/app/v1/search/index?keyword=${encode(wd)}&source=0&page=${page}&size=${zmSize}${zmArgs}`;
    const body = await httpGet(u, zmHeaders(), 15000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('zaimanhua: 非 JSON 响应');
    }
    const out = [];
    for (const it of Array.isArray(resp?.data?.list) ? resp.data.list : []) {
      const c = zmCardToCard(it);
      if (c.name) out.push(c);
    }
    return { cards: out, hasMore: page * zmSize < (parseInt(resp?.data?.total ?? 0, 10) || 0) };
  }

  async detail(id) {
    const u = `${zmHost}/api/v1/comic2/comic/detail?comic_py=${encode(id)}${zmArgs}`;
    const body = await httpGet(u, zmHeaders(), 15000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('zaimanhua: 详情解析失败');
    }
    const ci = resp?.data?.comicInfo ?? {};
    if (!String(ci.title ?? '').trim()) throw new Error('zaimanhua: 详情为空（可能已下架）');
    const comicID = jsonIDString(ci.id);
    const raw = [];
    for (const vol of Array.isArray(ci.chapterList) ? ci.chapterList : []) {
      for (const ch of Array.isArray(vol?.data) ? vol.data : []) {
        const cid = jsonIDString(ch?.chapter_id);
        if (!cid) continue;
        raw.push({ id: cid, name: String(ch?.chapter_title ?? '').trim(), order: parseInt(ch?.chapter_order ?? 0, 10) || 0 });
      }
    }
    
    raw.sort((a, b) => a.order - b.order);
    const chapters = raw.map((c, i) => Chapter(i + 1, c.name, `${comicID}|${c.id}`));
    const authors = [];
    for (const a of Array.isArray(ci.authorsTagList) ? ci.authorsTagList : []) {
      const s = String(a?.tagName ?? '').trim();
      if (s) authors.push(s);
    }
    let status = '';
    for (const s of Array.isArray(ci.statusTagList) ? ci.statusTagList : []) {
      const v = String(s?.tagName ?? '').trim();
      if (v) status = v;
    }
    return BookDetail({
      id,
      name: String(ci.title ?? '').trim(),
      pic: String(ci.cover ?? '').trim(),
      desc: String(ci.description ?? '').trim(),
      tag: status,
      remarks: `${chapters.length} 话`,
      author: authors.join(' / '),
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const parts = String(ref ?? '').trim().split('|');
    if (parts.length < 2 || !parts[0] || !parts[1]) {
      throw new Error(`zaimanhua: 非法章节凭证 ${ref}`);
    }
    const u = `${zmHost}/api/v1/comic2/chapter/detail?comic_id=${encode(parts[0])}&chapter_id=${encode(parts[1])}${zmArgs}`;
    const body = await httpGet(u, zmHeaders(), 20000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('zaimanhua: 章节解析失败');
    }
    const pageURL = Array.isArray(resp?.data?.chapterInfo?.page_url) ? resp.data.chapterInfo.page_url : [];
    const out = [];
    for (const s of pageURL) {
      const v = String(s ?? '').trim();
      if (v) out.push(v);
    }
    if (out.length === 0) throw new Error('zaimanhua: 章节无图片');
    return ComicPlay({ pics: out, referer: zmReferer, ua: zmUA });
  }
}

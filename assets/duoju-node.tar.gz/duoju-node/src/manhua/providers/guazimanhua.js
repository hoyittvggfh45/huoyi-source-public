
import { httpGet, encode, firstNonEmpty } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay } from '../types.js';

const HOST = 'https://www.guazimanhua.com';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

function headers(ref) {
  if (!ref) ref = `${HOST}/`;
  return { 'User-Agent': UA, Referer: ref };
}

const CATS = [
  ['/category.php', '全部'],
  ['/category.php?sort=update', '最近更新'],
  ['/category.php?sort=daily', '今日热门'],
  ['/category.php?sort=hits', '人气榜'],
  ['/category.php?sort=score', '评分榜'],
  ['/category.php?is_end=2', '连载中'],
  ['/category.php?is_end=1', '已完结'],
  ['/category.php?audience=1', '男频'],
  ['/category.php?audience=2', '女频'],
  ['/category.php?city=338', '国漫'],
  ['/category.php?city=78', '日韩'],
  ['/category.php?city=43', '欧美'],
  ['/category.php?city=77', '港台'],
  ['/category.php?city=42', '大陆'],
  ['/category.php?cid=13', '热血'],
  ['/category.php?cid=30', '冒险'],
  ['/category.php?cid=15', '搞笑'],
  ['/category.php?cid=25', '玄幻'],
  ['/category.php?cid=31', '奇幻'],
  ['/category.php?cid=9', '恋爱'],
  ['/category.php?cid=41', '耽美'],
  ['/category.php?cid=5', '霸总'],
  ['/category.php?cid=42', '都市'],
  ['/category.php?cid=8', '穿越'],
  ['/category.php?cid=23', '古风'],
  ['/category.php?cid=29', '校园'],
  ['/category.php?cid=22', '科幻'],
  ['/category.php?cid=21', '灵异'],
  ['/category.php?cid=54', '动作'],
  ['/category.php?cid=11', '悬疑'],
  ['/category.php?cid=14', '恐怖'],
  ['/category.php?cid=148', '系统'],
  ['/category.php?cid=97', '逆袭'],
  ['/category.php?cid=55', '脑洞'],
  ['/category.php?cid=61', '复仇'],
  ['/category.php?cid=17', '真人'],
  ['/category.php?cid=27', '其它'],
].map(([id, name]) => ({ id, name }));

const reGzCard = /<article class="card">([\s\S]*?)<\/article>/gis;
const reGzID = /href="\/comic\.php\?id=(\d+)"/;
const reGzName = /<h3>\s*<a[^>]*>([^<]*)<\/a>/is;
const reGzPic = /<img[^>]*class="cover"[^>]*src="([^"]+)"/is;
const reGzMeta = /<div class="meta">([^<]*)<\/div>/is;
const reGzGenre = /<span class="genre">([^<]*)<\/span>/is;
const reGzPageInfo = /第\s*(\d+)\s*\/\s*(\d+)\s*页/;
const reGzTitle = /<h1[^>]*id="cinema-title"[^>]*>([^<]*)<\/h1>/is;
const reGzAuthor = /"author":\{[^}]*?"name":"([^"]*)"/;
const reGzCover = /<img[^>]*class="mobile-comic-cover[^"]*"[^>]*src="([^"]+)"/is;
const reGzStatus = /<p class="mobile-comic-meta">([\s\S]{0,80}?)<\/p>/is;
const reGzTags = /<p class="mobile-comic-tags">([\s\S]{0,240}?)<\/p>/is;
const reGzDesc = /<p class="mobile-comic-desc">([\s\S]*?)<\/p>/is;
const reGzChapBox = /data-mobile-chapter-list[^>]*>([\s\S]*?)<\/section>/is;
const reGzChap = /<a[^>]*href="\/chapter\.php\?id=(\d+)"[^>]*>([^<]*)<\/a>/gis;
const reGzReadingImg = /<img[^>]*class="reading-image[^"]*"[^>]*src="([^"]+)"/gis;

function cards(page) {
  const out = [];
  for (const m of [...page.matchAll(reGzCard)]) {
    const blk = m[1];
    const id = firstGroup(reGzID, blk);
    const name = htmlText(firstGroup(reGzName, blk));
    if (!id || !name) continue;
    const meta = htmlText(firstGroup(reGzMeta, blk));
    let author = '';
    const i = meta.indexOf('·');
    if (i > 0) author = meta.slice(0, i).trim();
    out.push(Card({
      id, name,
      pic: firstGroup(reGzPic, blk),
      remarks: firstNonEmpty(meta, htmlText(firstGroup(reGzGenre, blk))),
      author,
      plat: 'gzmh',
    }));
  }
  return out;
}

function pageURL(cat, page) {
  if (page < 1) page = 1;
  const u = HOST + cat;
  return u.includes('?') ? `${u}&page=${page}` : `${u}?page=${page}`;
}

function hasMore(page, cur) {
  const m = page.match(reGzPageInfo);
  if (!m) return false;
  const total = parseInt(m[2], 10) || 0;
  return cur < total;
}

export class ProviderGuazimanhua {
  key() { return 'gzmh'; }
  name() { return '瓜子漫画'; }
  desc() { return 'guazimanhua.com 纯 HTML（服务端渲染，无加密）'; }
  adult() { return false; }

  cats() { return CATS; }

  listPaged() { return true; }
  searchPaged() { return true; }

  async list(cat, page) {
    if (!String(cat || '').trim() || !String(cat).startsWith('/category.php')) cat = CATS[0].id;
    if (page < 1) page = 1;
    const body = await httpGet(pageURL(cat, page), headers(''), 25000);
    return { cards: cards(body), hasMore: hasMore(body, page) };
  }

  async search(wd, page) {
    if (page < 1) page = 1;
    const u = `${HOST}/category.php?keyword=${encode(String(wd || '').trim())}&page=${page}`;
    const body = await httpGet(u, headers(`${HOST}/`), 25000);
    return { cards: cards(body), hasMore: hasMore(body, page) };
  }

  async detail(id) {
    id = String(id || '').trim().replace(/^\/+|\/+$/g, '');
    if (!id || /[/?&]/.test(id)) throw new Error(`gzmh: 非法漫画 id "${id}"`);
    const detailURL = `${HOST}/comic.php?id=${encode(id)}`;
    const page = await httpGet(detailURL, headers(`${HOST}/`), 30000);
    const name = htmlText(firstGroup(reGzTitle, page));
    if (!name) throw new Error(`gzmh: 详情解析失败 ${id}`);

    let chapters = [];
    const box = firstGroup(reGzChapBox, page);
    if (box) {
      const list = [];
      const seen = new Set();
      for (const m of [...box.matchAll(reGzChap)]) {
        const cid = m[1];
        const cname = htmlText(m[2]);
        if (!cid || !cname || seen.has(cid)) continue;
        seen.add(cid);
        list.push({ no: 0, name: cname, url: cid });
      }
      list.reverse();
      list.forEach((c, i) => { c.no = i + 1; });
      chapters = list;
    }
    if (chapters.length === 0) throw new Error(`gzmh: 章节列表为空 ${id}`);

    const status = htmlText(firstGroup(reGzStatus, page)).replace(/ /g, '').trim();
    const tag = htmlText(firstGroup(reGzTags, page));
    let remarks = status.replace(/·/g, ' · ');
    if (!remarks) remarks = `${chapters.length} 话`;
    return BookDetail({
      id, name,
      pic: firstNonEmpty(firstGroup(reGzCover, page), firstGroup(reGzPic, page)),
      desc: htmlText(firstGroup(reGzDesc, page)),
      tag: tag.replace(/ \/ /g, ' '),
      remarks,
      author: htmlText(firstGroup(reGzAuthor, page)),
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const cid = String(ref || '').trim().replace(/^\/+|\/+$/g, '');
    if (!cid || /[/?&]/.test(cid)) throw new Error(`gzmh: 非法章节凭证 "${ref}"`);
    const chapURL = `${HOST}/chapter.php?id=${encode(cid)}`;
    const page = await httpGet(chapURL, headers(`${HOST}/`), 40000);
    const pics = [];
    const seen = new Set();
    for (const m of [...page.matchAll(reGzReadingImg)]) {
      const v = m[1].replace(/&amp;/g, '&');
      if (!v || seen.has(v)) continue;
      seen.add(v);
      pics.push(v);
    }
    if (pics.length === 0) throw new Error(`gzmh: 章节无图片 ${ref}`);
    return ComicPlay({ pics, referer: `${HOST}/`, ua: UA });
  }
}


import { httpGet } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const kanmanHost = 'https://www.kanman.com';

const kanmanCats = [
  { id: 'story', name: '全部作品' },
  { id: 'area', name: '地区筛选' },
  { id: 'status', name: '连载状态' },
  { id: 'other', name: '题材标签' },
  { id: 'letter', name: '字母索引' },
];

const kanmanUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';

function kanmanHeaders(ref) {
  const h = { 'User-Agent': kanmanUA, 'Accept-Language': 'zh-CN,zh;q=0.9' };
  if (ref) h.Referer = ref;
  return h;
}

const reKmItem = /<li class="acgn-item">([\s\S]*?)<\/li>/gis;
const reKmHref = /href="\/(\d{3,8})\/"/i;
const reKmImg = /data-src="([^"]+)"/i;
const reKmName = /<h3 class="acgn-title"><a[^>]*>([\s\S]*?)<\/a>/is;
const reKmLatest = /class="latest-cartoon"[^>]*>([\s\S]*?)<\/a>/is;
const reKmOgMeta = /<meta property="(og:description|og:novel:author|og:novel:book_name|og:novel:status|og:novel:category|og:image)" content="([^"]*)"/gi;
const reKmChapter = /<li class="item" data-id="\d+" data-chapter="(\d+)"><a title="([^"]*)" href="([^"]+)"/gis;
const reKmImgList = /chapter_img_list:\[([\s\S]*?)\]/is;
const reKmPic = /"(https?:\/\/[^"]+?)"/g;

function kanmanAbs(href) {
  href = String(href ?? '').trim();
  if (href.startsWith('//')) return 'https:' + href;
  if (href.startsWith('/')) return kanmanHost + href;
  return href;
}

function kanmanParseCards(page) {
  const out = [];
  const seen = new Set();
  for (const m of page.matchAll(reKmItem)) {
    const block = m[1];
    const id = firstGroup(reKmHref, block);
    if (!id || seen.has(id)) continue;
    const name = htmlText(firstGroup(reKmName, block));
    if (!name) continue;
    seen.add(id);
    out.push(Card({
      id,
      name,
      pic: kanmanAbs(firstGroup(reKmImg, block)),
      remarks: htmlText(firstGroup(reKmLatest, block)),
      cat: 'kanman',
      plat: 'kanman',
    }));
  }
  return out;
}

function kanmanSortURL(cat, page) {
  if (page <= 1) return `${kanmanHost}/sort/${cat}.html`;
  return `${kanmanHost}/sort/${cat}_${page}.html`;
}

export class ProviderKanman {
  key() { return 'kanman'; }
  name() { return '看漫画'; }
  adult() { return false; }
  desc() { return '看漫画：321mh 韩漫/恋爱/古风/都市平台，SSR 分类列表直取，章节页 chapter_img_list 出带 auth_key 直链'; }

  cats() { return kanmanCats; }

  listPaged() { return true; }
  searchPaged() { return false; }

  async list(cat, page) {
    if (!String(cat || '').trim()) cat = 'story';
    if (page < 1) page = 1;
    const body = await httpGet(kanmanSortURL(cat, page), kanmanHeaders(kanmanHost + '/'), 30000);
    const cards = kanmanParseCards(body);
    return { cards, hasMore: cards.length > 0 && page < 50 };
  }

  async search(wd, page) {
    wd = String(wd ?? '').trim();
    if (!wd || page > 1) return { cards: [] };
    let cards = [];
    for (const src of ['top', 'gengxin']) {
      try {
        const body = await httpGet(`${kanmanHost}/${src}/`, kanmanHeaders(kanmanHost + '/'), 20000);
        cards = cards.concat(kanmanParseCards(body));
      } catch {
        continue;
      }
    }
    wd = wd.toLowerCase();
    const out = [];
    for (const c of cards) {
      if (String(c.vod_name || '').toLowerCase().includes(wd)) {
        out.push(c);
        if (out.length >= 30) break;
      }
    }
    return { cards: out, hasMore: false };
  }

  async detail(id) {
    id = String(id ?? '').trim().replace(/^\/+|\/+$/g, '');
    const i = id.indexOf('/');
    if (i > 0) id = id.slice(0, i);
    const body = await httpGet(`${kanmanHost}/${id}/`, kanmanHeaders(kanmanHost + '/'), 40000);
    const book = {
      id,
      name: '',
      pic: '',
      desc: '',
      tag: '',
      remarks: '',
      author: '',
    };
    for (const m of body.matchAll(reKmOgMeta)) {
      switch (m[1]) {
        case 'og:novel:book_name':
          book.name = htmlText(m[2].trim());
          break;
        case 'og:description':
          book.desc = htmlText(m[2].trim());
          break;
        case 'og:image':
          book.pic = m[2].trim();
          break;
        case 'og:novel:author':
          book.author = htmlText(m[2].trim());
          break;
        case 'og:novel:status':
          book.remarks = htmlText(m[2].trim());
          break;
        case 'og:novel:category':
          book.tag = htmlText(m[2].trim());
          break;
      }
    }
    if (!book.name) throw new Error('kanman: 解析为空');
    const caps = [];
    const seen = new Set();
    for (const m of body.matchAll(reKmChapter)) {
      const href = kanmanAbs(m[3]);
      if (seen.has(href)) continue;
      seen.add(href);
      let name = htmlText(m[2].trim());
      if (!name) name = `第 ${m[1]} 话`;
      caps.push({ name, href });
    }
    if (caps.length === 0) throw new Error('kanman: 章节解析为空');
    caps.reverse();
    const chapters = caps.map((c, idx) => Chapter(idx + 1, c.name, c.href));
    let remarks = book.remarks;
    if (!remarks) {
      remarks = `${chapters.length} 话`;
    } else {
      remarks += ` · ${chapters.length} 话`;
    }
    return BookDetail({
      id: book.id,
      name: book.name,
      pic: book.pic,
      desc: book.desc,
      tag: book.tag,
      remarks,
      author: book.author,
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const u = kanmanAbs(ref);
    const body = await httpGet(u, kanmanHeaders(kanmanHost + '/'), 30000);
    let block = body;
    const lm = reKmImgList.exec(body);
    if (lm) block = lm[1];
    const out = [];
    const seen = new Set();
    for (const m of block.matchAll(reKmPic)) {
      const pic = m[1].trim();
      if (!pic || seen.has(pic)) continue;
      seen.add(pic);
      out.push(pic);
    }
    if (out.length === 0) throw new Error('kanman: 解析为空');
    return ComicPlay({ pics: out, referer: kanmanHost + '/', ua: kanmanUA });
  }
}

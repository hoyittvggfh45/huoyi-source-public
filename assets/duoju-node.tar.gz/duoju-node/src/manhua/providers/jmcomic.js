
import crypto from 'node:crypto';
import { httpGet, encode, md5hex } from '../core/http.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const jmVersion = '2.0.20';
const jmSecret = '185Hcomic3PAPP7R';
const jmHostCfgSeed = 'diosfjckwpqpdfjkvnqQjsik';
const jmFallbackAPI = 'https://www.cdnhjk.net';
const jmFallbackImg = 'https://cdn-msp3.jmdanjonproxy.vip';
const jmUA = 'Mozilla/5.0 (Linux; Android 13; M2012K11AC Build/TQ1A.230305.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.230 Mobile Safari/537.36';
const jmSettingSeed2 = '18comicAPPContent';

const jmHostCfgURLs = [
  'https://rup4a04-c02.tos-cn-hongkong.bytepluses.com/newsvr-2025.txt',
  'https://rup4a04-c01.tos-ap-southeast-1.bytepluses.com/newsvr-2025.txt',
];

let jmAPI = '';
let jmImg = '';
let jmInitAt = 0;
let jmInitPromise = null;

function jmB64Clean(s) {
  
  return String(s).replace(/[^A-Za-z0-9+/=]/g, '');
}


function jmECBDecrypt(data, key) {
  try {
    if (!Buffer.isBuffer(data)) data = Buffer.from(data);
    if (data.length === 0 || data.length % 16 !== 0) return null;
    if (![16, 24, 32].includes(key.length)) return null;
    const d = crypto.createDecipheriv(`aes-${key.length * 8}-ecb`, key, null);
    d.setAutoPadding(false);
    const out = Buffer.concat([d.update(data), d.final()]);
    const pad = out[out.length - 1];
    if (pad <= 0 || pad > 16 || pad > out.length) return null;
    for (let i = out.length - pad; i < out.length; i++) {
      if (out[i] !== pad) return null;
    }
    return out.subarray(0, out.length - pad);
  } catch {
    return null;
  }
}

function jsonValid(s) {
  try {
    JSON.parse(s);
    return true;
  } catch {
    return false;
  }
}


function jmDecode(body, ts) {
  let wrap = null;
  try {
    wrap = JSON.parse(body);
  } catch {
    wrap = null;
  }
  if (wrap && typeof wrap === 'object' && typeof wrap.data === 'string' && wrap.data !== '') {
    const compact = jmB64Clean(String(wrap.data).replace(/-/g, '+').replace(/_/g, '/'));
    let ct = null;
    try {
      ct = Buffer.from(compact, 'base64');
    } catch {
      ct = null;
    }
    if (ct && ct.length > 0) {
      for (const seed of [jmSecret, jmSettingSeed2]) {
        const pt = jmECBDecrypt(ct, Buffer.from(md5hex(ts + seed), 'utf8'));
        if (pt !== null) return pt.toString('utf8');
      }
    }
  }
  return String(body);
}

function jmNormalizeBase(raw) {
  raw = String(raw ?? '').trim();
  if (!raw) return '';
  if (!raw.startsWith('http')) raw = 'https://' + raw;
  return raw.replace(/\/+$/, '');
}

async function jmLoadServers() {
  for (const u of jmHostCfgURLs) {
    let body = '';
    try {
      body = await httpGet(u, { 'User-Agent': jmUA });
    } catch {
      continue;
    }
    const ct = Buffer.from(jmB64Clean(body), 'base64');
    const pt = jmECBDecrypt(ct, Buffer.from(md5hex(jmHostCfgSeed), 'utf8'));
    if (!pt) continue;
    let cfg = null;
    try {
      cfg = JSON.parse(pt.toString('utf8'));
    } catch {
      continue;
    }
    if (!cfg || !Array.isArray(cfg.Server) || cfg.Server.length === 0) continue;
    const out = [];
    for (const s of cfg.Server) {
      const n = jmNormalizeBase(s);
      if (n) out.push(n);
    }
    if (out.length > 0) return out;
  }
  return [];
}

async function jmInitEndpoints() {
  const now = Date.now();
  if (jmAPI && now - jmInitAt < 15 * 60 * 1000) return;
  if (jmInitPromise) return jmInitPromise;
  jmInitPromise = (async () => {
    jmInitAt = Date.now();
    if (!jmAPI) {
      jmAPI = jmFallbackAPI;
      jmImg = jmFallbackImg;
    }
    const servers = await jmLoadServers();
    for (let i = 0; i < servers.length && i < 6; i++) {
      const s = servers[i];
      const sec = String(Math.floor(Date.now() / 1000));
      const url = `${s}/setting?app_img_shunt=1&t=${sec}`;
      const headers = {
        tokenparam: `${sec},${jmVersion}`,
        token: md5hex(sec + jmSecret),
        'user-agent': jmUA,
      };
      let body = '';
      try {
        body = await httpGet(url, headers);
      } catch {
        continue;
      }
      let st = null;
      try {
        st = JSON.parse(jmDecode(body, sec));
      } catch {
        st = null;
      }
      const imgHost = String(st?.img_host ?? '').trim();
      if (imgHost) {
        jmAPI = s;
        jmImg = jmNormalizeBase(imgHost);
        return;
      }
    }
  })().finally(() => {
    jmInitPromise = null;
  });
  return jmInitPromise;
}

function jmHeaders(tsMs) {
  return {
    token: md5hex(tsMs + jmVersion),
    tokenparam: `${tsMs},${jmVersion}`,
    'user-agent': jmUA,
  };
}

async function jmAPIGet(path) {
  await jmInitEndpoints();
  let lastErr = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    const tsMs = String(Date.now());
    try {
      const body = await httpGet(jmAPI + path, jmHeaders(tsMs));
      return jmDecode(body, tsMs);
    } catch (e) {
      lastErr = e;
      if (attempt === 0) {
        if (jmAPI === jmFallbackAPI) break;
        jmAPI = jmFallbackAPI;
      }
    }
  }
  throw new Error(`jmcomic: ${lastErr?.message || 'EOF'}`);
}


function jmStrList(raw) {
  if (raw == null) return '';
  if (Array.isArray(raw)) return raw.map((v) => String(v)).join(' ');
  if (typeof raw === 'string') return raw;
  return '';
}

function jmCover(imgBase, id) {
  return `${imgBase}/media/albums/${id}_3x4.jpg`;
}

function parseJmItems(data) {
  let resp = null;
  try {
    resp = JSON.parse(data);
  } catch {
    throw new Error('jmcomic: 列表解析失败');
  }
  if (!resp || !Array.isArray(resp.content)) throw new Error('jmcomic: 列表解析失败');
  return resp;
}

export class ProviderJm {
  key() { return 'jmcomic'; }
  name() { return '禁漫天堂'; }
  adult() { return true; }
  desc() { return '禁漫天堂：Tokenparam 签名 API + AES-ECB 响应解密 + 域名池'; }

  cats() {
    return [
      { id: '0|new', name: '最新' },
      { id: '0|mv', name: '总排行' },
      { id: '0|mv_m', name: '月排行' },
      { id: '0|mv_w', name: '周排行' },
      { id: '0|mv_t', name: '日排行' },
      { id: '0|tf', name: '最多点赞' },
      { id: 'doujin_chinese|new', name: '同人汉化' },
      { id: 'doujin_japanese|new', name: '同人日语' },
      { id: 'doujin_CG|new', name: 'CG图集' },
      { id: 'single_chinese|new', name: '单本汉化' },
      { id: 'single_japanese|new', name: '单本日语' },
      { id: 'short_chinese|new', name: '短篇' },
      { id: 'hanman_chinese|new', name: '韩漫' },
      { id: 'another_3d|new', name: '3D' },
      { id: 'another_cosplay|new', name: '角色扮演' },
    ];
  }

  async jmCards(path) {
    const data = await jmAPIGet(path);
    const resp = parseJmItems(data);
    const imgBase = jmImg;
    const cards = [];
    for (const it of resp.content) {
      const id = String(it?.id ?? '').trim();
      const name = String(it?.name ?? '');
      if (!id || !name) continue;
      let remarks = '';
      const l = String(it?.likes ?? '').trim();
      if (l && l !== '0') remarks = '❤' + l;
      cards.push(Card({
        id,
        name,
        pic: jmCover(imgBase, id),
        remarks,
        cat: String(it?.category?.title ?? ''),
        author: jmStrList(it?.author),
      }));
    }
    return { cards, hasMore: resp.content.length >= 80 };
  }

  async list(cat, page) {
    cat = String(cat ?? '');
    let c = '0';
    let o = 'new';
    const i = cat.indexOf('|');
    if (i >= 0) {
      c = cat.slice(0, i);
      o = cat.slice(i + 1);
    }
    const path = `/categories/filter?page=${page}&c=${encode(c)}&o=${encode(o)}`;
    return this.jmCards(path);
  }

  async search(wd, page) {
    const path = `/search?search_query=${encode(wd)}&page=${page}&o=new`;
    return this.jmCards(path);
  }

  async detail(id) {
    const data = await jmAPIGet(`/album?id=${id}`);
    let a = null;
    try {
      a = JSON.parse(data);
    } catch {
      throw new Error('jmcomic: 详情解析失败');
    }
    if (!a || typeof a !== 'object') throw new Error('jmcomic: 详情解析失败');
    const imgBase = jmImg;
    const albumID = String(a?.id ?? '');
    const chapters = [];
    for (const s of Array.isArray(a?.series) ? a.series : []) {
      if (String(s?.sort ?? '') === '0') continue;
      chapters.push(Chapter(chapters.length + 1, String(s?.name ?? ''), String(s?.id ?? '')));
    }
    if (chapters.length === 0) {
      chapters.push(Chapter(1, '本篇', albumID));
    }
    let remarks = `${parseInt(a?.total_photos ?? 0, 10) || 0}页`;
    const l = String(a?.likes ?? '').trim();
    if (l && l !== '0') remarks += ' ❤' + l;
    return BookDetail({
      id: albumID,
      name: String(a?.name ?? ''),
      pic: jmCover(imgBase, albumID),
      desc: String(a?.description ?? ''),
      tag: jmStrList(a?.tags),
      remarks,
      author: jmStrList(a?.author),
      chapters,
      count: chapters.length,
      adult: true,
    });
  }

  async pics(ref) {
    const chapterID = String(ref ?? '').trim();
    if (!chapterID) throw new Error(`jmcomic: 无效引用 "${ref}"`);
    const data = await jmAPIGet(`/chapter?skip=&id=${chapterID}`);
    let ch = null;
    try {
      ch = JSON.parse(data);
    } catch {
      throw new Error('jmcomic: 章节解析失败');
    }
    if (!ch || !Array.isArray(ch.images)) throw new Error('jmcomic: 章节解析失败');
    const imgBase = jmImg;
    const items = [];
    let allNum = true;
    for (const img of ch.images) {
      if (!img) continue;
      let num = -1;
      let base = img;
      const dot = base.lastIndexOf('.');
      if (dot >= 0) base = base.slice(0, dot);
      const t = String(base).trim();
      if (/^-?\d+$/.test(t)) {
        const n = parseInt(t, 10);
        if (n >= 0) num = n;
        else allNum = false;
      } else {
        allNum = false;
      }
      items.push({ name: img, num });
    }
    if (allNum && items.length > 1) {
      items.sort((x, y) => x.num - y.num);
    }
    const pics = items.map((it) => `${imgBase}/media/photos/${chapterID}/${it.name}`);
    if (pics.length === 0) throw new Error('jmcomic: 章节无图片');
    return ComicPlay({ pics, ua: jmUA, decrypt: 'jm' });
  }
}

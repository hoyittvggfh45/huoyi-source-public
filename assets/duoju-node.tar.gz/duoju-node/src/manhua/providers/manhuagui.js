
import { httpGet, encode } from '../core/http.js';
import { htmlText, firstGroup } from '../core/htmlutil.js';
import { Card, BookDetail, ComicPlay, Chapter } from '../types.js';

const mhgBase = 'https://tw.manhuagui.com';
const mhgUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.0 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.0';
const mhgImgSrv = 'https://i.hamreus.com';

function mhgHeaders() {
  return {
    'User-Agent': mhgUA,
    Referer: mhgBase + '/',
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-TW,zh;q=0.9',
  };
}

function mhgAbs(u) {
  u = String(u ?? '').trim();
  if (!u) return '';
  if (u.startsWith('//')) return 'https:' + u;
  if (u.startsWith('http://') || u.startsWith('https://')) return u;
  if (u.startsWith('/')) return mhgBase + u;
  return u;
}

const mhgDetailSeed = new Map(); 
const MHG_DETAIL_TTL = 30 * 60 * 1000;

const reMhgLi = /<li[^>]*>([\s\S]*?)<\/li>/gis;
const reMhgComicH = /href="\/comic\/(\d+)\/"/;
const reMhgChapH = /href="\/comic\/\d+\/(\d+)\.html"/;
const reMhgTitle = /<p class="ell">\s*<a[^>]*>([\s\S]*?)<\/a>/is;
const reMhgTitleA = /title="([^"]*)"/i;
const reMhgImg = /<img[^>]+src="([^"]+)"/i;
const reMhgTT = /<span class="tt"[^>]*>([\s\S]*?)<\/span>/is;
const reMhgNext = /href="[^"]*?index_p(\d+)\.html"/gi;
const reMhgH1 = /<h1[^>]*>([\s\S]*?)<\/h1>/is;
const reMhgCover = /class="book-cover"[^>]*>[\s\S]*?<img[^>]+src="([^"]+)"/is;
const reMhgIntro = /id="intro-cut"[^>]*>([\s\S]*?)<\/div>/is;
const reMhgDlSpan = /<span[^>]*>\s*<strong>([\s\S]*?)<\/strong>([\s\S]*?)<\/span>/gis;
const reMhgDlA = /<a[^>]*>([\s\S]*?)<\/a>/gis;
const reMhgStatus = /<li[^>]*class="[^"]*status[^"]*"[^>]*>([\s\S]*?)<\/li>/is;
const reMhgChapUl = /<ul[^>]*>([\s\S]*?)<\/ul>/gis;
const reMhgChapTag = /<a\b[^>]*>([\s\S]*?)<\/a>/gis;
const reMhgChapAt = /\btitle="([^"]*)"/i;
const reMhgChapHr = /\bhref="[^"]*\/comic\/\d+\/(\d+)\.html"/i;
const reMhgScript = /<script[^>]*>([\s\S]*?)<\/script>/gis;
const reMhgB64 = /'([A-Za-z0-9+/=]{200,})'/g;
const reMhgPacker = /}\('((?:\\.|[^'\\])*)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,/;
const reMhgPackerD = /}\("((?:\\.|[^"\\])*)"\s*,\s*(\d+)\s*,\s*(\d+)\s*,/;
const reMhgImgData = /SMH\.imgData\((\{[\s\S]*?\})\)\.preInit\(\)/s;
const reMhgWebp = /\.webp$/i;
const reMhgResultN = /class="result-count"[^>]*>[\s\S]*?<strong[^>]*>([\d,]+)<\/strong>/is;

function quoteMeta(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export class ProviderManhuagui {
  key() { return 'manhuagui'; }
  name() { return '漫画柜'; }
  adult() { return false; }
  desc() { return '漫画柜 tw 镜像：全站 SSR，章节图片走 LZString+Packer 解密（Breeze 插件同源算法）'; }

  cats() {
    return [
      { id: 'all', name: '全部' },
      { id: 'japan', name: '日本' },
      { id: 'korea', name: '韩国' },
      { id: 'gaoxiao', name: '搞笑' },
      { id: 'aishang', name: '爱戀' },
      { id: 'maoxian', name: '冒險' },
      { id: 'kehuan', name: '科幻' },
      { id: 'shaonian', name: '少年' },
      { id: 'shaonv', name: '少女' },
    ];
  }

  toCards(html) {
    const out = [];
    for (const m of html.matchAll(reMhgLi)) {
      const block = m[1];
      const hm = reMhgComicH.exec(block);
      const bid = hm ? hm[1] : '';
      if (!bid) continue;
      let title = htmlText(firstGroup(reMhgTitle, block));
      if (!title) title = htmlText(firstGroup(reMhgTitleA, block));
      if (!title) continue;
      const cover = mhgAbs(firstGroup(reMhgImg, block));
      const sub = htmlText(firstGroup(reMhgTT, block));
      out.push(Card({ id: bid, name: title, pic: cover, remarks: sub, plat: this.key() }));
    }
    return out;
  }

  mhgListPath(cat, page) {
    if (!cat) cat = 'all';
    if (page <= 1) {
      if (cat === 'all') return '/list/';
      return `/list/${cat}/`;
    }
    if (cat === 'all') return `/list/index_p${page}.html`;
    return `/list/${cat}/index_p${page}.html`;
  }

  async list(cat, page) {
    if (page < 1) page = 1;
    const body = await httpGet(mhgBase + this.mhgListPath(cat, page), mhgHeaders(), 20000);
    const cards = this.toCards(body);
    let hasMore = false;
    let maxPage = 0;
    for (const v of body.matchAll(reMhgNext)) {
      const n = parseInt(v[1], 10) || 0;
      if (n > maxPage) maxPage = n;
    }
    hasMore = maxPage > page;
    if (!hasMore && cards.length >= 20) hasMore = true;
    return { cards, hasMore };
  }

  async search(wd, page) {
    if (page < 1) page = 1;
    const kw = encode(String(wd ?? '').trim());
    let path = `/s/${kw}.html`;
    if (page > 1) path = `/s/${kw}_p${page}.html`;
    const body = await httpGet(mhgBase + path, mhgHeaders(), 20000);
    const cards = this.toCards(body);
    let hasMore = cards.length >= 10;
    const rm = reMhgResultN.exec(body);
    if (rm) {
      const total = parseInt(rm[1].replace(/,/g, ''), 10) || 0;
      hasMore = total > page * 10;
    }
    return { cards, hasMore };
  }

  async detail(id) {
    id = String(id ?? '').trim();
    if (!id) throw new Error('manhuagui: 空的漫画 ID');
    const cached = mhgDetailSeed.get(id);
    if (cached && Date.now() - cached.at < MHG_DETAIL_TTL) {
      return cached.detail;
    }
    const body = await httpGet(`${mhgBase}/comic/${id}/`, mhgHeaders(), 20000);
    const title = htmlText(firstGroup(reMhgH1, body));
    if (!title) throw new Error('manhuagui: 详情为空（可能已下架）');
    const cover = mhgAbs(firstGroup(reMhgCover, body));
    const desc = htmlText(firstGroup(reMhgIntro, body));
    const author = mhgDlLabels(body, '作者');
    const tags = mhgDlLabels(body, '劇情');
    const statusText = htmlText(firstGroup(reMhgStatus, body));
    let status = '連載中';
    if (statusText.includes('完結') || statusText.includes('已完结')) status = '完結';
    const chaptersRaw = [];
    for (const um of body.matchAll(reMhgChapUl)) {
      if (!reMhgChapH.test(um[1])) continue;
      const group = [];
      for (const am of um[1].matchAll(reMhgChapTag)) {
        const cid = firstGroup(reMhgChapHr, am[0]);
        if (!cid) continue;
        let name = firstGroup(reMhgChapAt, am[0]);
        if (!name) name = htmlText(am[1]);
        group.push({ id: cid, name });
      }
      group.reverse();
      chaptersRaw.push(...group);
    }
    const seen = new Set();
    const chapters = [];
    for (const c of chaptersRaw) {
      if (!c.id || seen.has(c.id)) continue;
      seen.add(c.id);
      chapters.push(Chapter(chapters.length + 1, c.name, `${id}|${c.id}`));
    }
    if (chapters.length === 0) throw new Error('manhuagui: 未解析到章节');
    const detail = BookDetail({
      id,
      name: title,
      pic: cover,
      desc,
      tag: tags,
      remarks: `${chapters.length} 话 · ${status}`,
      author,
      chapters,
      count: chapters.length,
    });
    if (mhgDetailSeed.size > 128) mhgDetailSeed.clear();
    mhgDetailSeed.set(id, { detail, at: Date.now() });
    return detail;
  }

  async pics(ref) {
    const parts = String(ref ?? '').trim().split('|');
    if (parts.length < 2 || !parts[0] || !parts[1]) {
      throw new Error(`manhuagui: 非法章节凭证 ${ref}`);
    }
    const body = await httpGet(`${mhgBase}/comic/${parts[0]}/${parts[1]}.html`, mhgHeaders(), 25000);
    const { files, path, cid, md5sum } = mhgDecodeImgData(body);
    const out = [];
    for (const f of files) {
      if (!String(f).trim()) continue;
      const base = f.replace(reMhgWebp, '');
      out.push(`${mhgImgSrv}${path}${base}?cid=${cid}&md5=${md5sum}`);
    }
    if (out.length === 0) throw new Error('manhuagui: 章节无图片');
    return ComicPlay({ pics: out, referer: mhgBase + '/', ua: mhgUA });
  }
}

function mhgDlLabels(body, label) {
  for (const m of body.matchAll(reMhgDlSpan)) {
    if (htmlText(m[1]).includes(label)) {
      const parts = [];
      for (const am of m[2].matchAll(reMhgDlA)) {
        const v = htmlText(am[1]);
        if (v) parts.push(v);
      }
      if (parts.length > 0) return parts.join(' / ');
      return htmlText(m[2]);
    }
  }
  return '';
}

function mhgDecodeImgData(html) {
  let script = '';
  for (const m of html.matchAll(reMhgScript)) {
    if (m[1].includes('function(p,a,c,k,e,d)')) {
      script = m[1];
      break;
    }
  }
  if (!script) throw new Error('manhuagui: 未找到 packed script');
  let b64 = '';
  for (const m of script.matchAll(reMhgB64)) {
    if (m[1].length > b64.length) b64 = m[1];
  }
  if (!b64) throw new Error('manhuagui: 未找到 base64 数据');
  const decoded = mhgLZDecompress(b64);
  if (!decoded) throw new Error('manhuagui: LZString 解压失败');
  const words = decoded.split('|');
  let template = '';
  let base = 0;
  const m1 = reMhgPacker.exec(script);
  const m2 = reMhgPackerD.exec(script);
  if (m1) {
    template = m1[1].replace(/\\'/g, "'");
    base = parseInt(m1[2], 10) || 0;
  } else if (m2) {
    template = m2[1].replace(/\\"/g, '"');
    base = parseInt(m2[2], 10) || 0;
  }
  if (!template || base === 0) throw new Error('manhuagui: 未找到 Packer 模板');
  const unpacked = mhgUnpack(template, words, base);
  const im = reMhgImgData.exec(unpacked);
  if (!im) throw new Error('manhuagui: 未找到 imgData JSON');
  let data = null;
  try {
    data = JSON.parse(im[1]);
  } catch {
    throw new Error('manhuagui: imgData 解析失败');
  }
  const files = Array.isArray(data?.files) ? data.files : [];
  const path = String(data?.path ?? '');
  if (files.length === 0 || !path) throw new Error('manhuagui: imgData 为空');
  return { files, path, cid: String(parseInt(data.cid ?? 0, 10) || 0), md5sum: String(data?.sl?.m ?? '') };
}



const mhgPackChars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

function mhgToBase(n, radix) {
  if (n === 0) return '0';
  let out = '';
  while (n > 0) {
    const r = n % radix;
    let c;
    if (r > 35) c = String.fromCharCode(r + 29);
    else c = mhgPackChars[r];
    out = c + out;
    n = Math.floor(n / radix);
  }
  return out;
}

function mhgUnpack(packed, words, a) {
  const keys = words.map((_, i) => mhgToBase(i, a));
  let out = packed;
  for (let i = words.length - 1; i >= 0; i--) {
    if (words[i] === '' || words[i] === keys[i]) continue;
    const re = new RegExp(`\\b${quoteMeta(keys[i])}\\b`, 'g');
    out = out.replace(re, () => words[i]);
  }
  return out;
}

export { mhgUnpack };

const mhgB64Alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';

function mhgB64Val(c) {
  return mhgB64Alphabet.indexOf(String.fromCharCode(c));
}


function mhgLZDecompress(input) {
  const clean = [];
  for (let i = 0; i < input.length; i++) {
    const v = mhgB64Val(input.charCodeAt(i));
    if (v >= 0) clean.push(v);
  }
  const length = clean.length;
  if (length === 0) return '';
  let val = clean[0];
  let position = 32;
  let index = 1;
  let enlargeIn = 4;
  let dictSize = 4;
  let numBits = 3;
  const dictionary = ['0', '1', '2'];
  const result = [];
  const readBits = (n) => {
    let b = 0;
    const maxpower = 1 << n;
    for (let power = 1; power !== maxpower; power <<= 1) {
      const resb = val & position;
      position >>= 1;
      if (position === 0) {
        position = 32;
        if (index < length) val = clean[index];
        else val = 0;
        index++;
      }
      if (resb > 0) b |= power;
    }
    return b;
  };
  const readChar = (n) => String.fromCharCode(readBits(n));
  let w = '';
  let entry;
  const first = readBits(2);
  if (first === 0) entry = readChar(8);
  else if (first === 1) entry = readChar(16);
  else return '';
  dictionary.push(entry);
  w = entry;
  result.push(entry);
  for (;;) {
    if (index > length) return '';
    let cInt = readBits(numBits);
    if (cInt === 0) {
      dictionary.push(readChar(8));
      cInt = dictSize;
      dictSize++;
      enlargeIn--;
    } else if (cInt === 1) {
      dictionary.push(readChar(16));
      cInt = dictSize;
      dictSize++;
      enlargeIn--;
    } else if (cInt === 2) {
      return result.join('');
    }
    if (enlargeIn === 0) {
      enlargeIn = 1 << numBits;
      numBits++;
    }
    if (cInt < dictionary.length) {
      entry = dictionary[cInt];
    } else if (cInt === dictSize && w !== '') {
      entry = w + w[0];
    } else {
      return '';
    }
    result.push(entry);
    dictionary.push(w + entry[0]);
    dictSize++;
    enlargeIn--;
    w = entry;
    if (enlargeIn === 0) {
      enlargeIn = 1 << numBits;
      numBits++;
    }
  }
}

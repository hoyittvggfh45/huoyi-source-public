
import { httpGet, encode } from '../core/http.js';
import { BookDetail, ComicPlay, Chapter } from '../types.js';

const mkzHost = 'https://comic.mkzcdn.com';
const mkzUA = 'okhttp/3.11.0';
const mkzSize = 18;

function mkzHeaders() {
  return { 'User-Agent': mkzUA };
}

const mkzCats = [
  { id: '1', name: '人气榜' },
  { id: '2', name: '最新榜' },
  { id: '3', name: '完结榜' },
  { id: '4', name: '收藏榜' },
];

function cardOf(it) {
  const c = {
    id: String(it?.comic_id ?? '').trim(),
    name: String(it?.title ?? '').trim(),
    pic: String(it?.cover ?? '').trim(),
    author: String(it?.author_title ?? '').trim(),
    plat: 'mkz',
  };
  let rem = String(it?.chapter_title ?? '').trim();
  if (!rem) rem = String(it?.feature ?? '').trim();
  c.remarks = rem;
  return c;
}

function parseCards(list, minCount) {
  const out = [];
  for (const it of Array.isArray(list) ? list : []) {
    const c = cardOf(it);
    if (c.name) out.push(c);
  }
  return out;
}

export class ProviderMkz {
  key() { return 'mkz'; }
  name() { return '漫客栈'; }
  desc() { return 'comic.mkzcdn.com 全 JSON API（知音漫客/飒漫画）'; }
  adult() { return false; }

  cats() { return mkzCats; }

  listPaged() { return true; }
  searchPaged() { return true; }

  async list(cat, page) {
    if (!String(cat ?? '').trim()) cat = '1';
    if (page < 1) page = 1;
    const u = `${mkzHost}/search/filter/?audience=0&order=${encode(cat)}&page_num=${page}&page_size=${mkzSize}`;
    const body = await httpGet(u, mkzHeaders(), 15000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('mkz: 非 JSON 响应');
    }
    const cards = parseCards(resp?.data?.list);
    return { cards, hasMore: cards.length >= mkzSize };
  }

  async search(wd, page) {
    if (page < 1) page = 1;
    const u = `${mkzHost}/search/keyword/?keyword=${encode(wd)}&page_num=${page}&page_size=20`;
    const body = await httpGet(u, mkzHeaders(), 15000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('mkz: 非 JSON 响应');
    }
    const cards = parseCards(resp?.data?.list);
    return { cards, hasMore: cards.length >= 20 };
  }

  async detail(id) {
    id = String(id ?? '').trim();
    const body = await httpGet(`${mkzHost}/comic/info/?comic_id=${encode(id)}`, mkzHeaders(), 20000);
    let info = null;
    try {
      info = JSON.parse(body);
    } catch {
      throw new Error('mkz: 详情解析失败');
    }
    const d = info?.data ?? {};
    if (!d.title) throw new Error('mkz: 详情解析失败');

    const chBody = await httpGet(`${mkzHost}/chapter/v1/?comic_id=${encode(id)}`, mkzHeaders(), 20000);
    let chResp = null;
    try {
      chResp = JSON.parse(chBody);
    } catch {
      throw new Error('mkz: 章节解析失败');
    }
    const chapters = [];
    for (const ch of Array.isArray(chResp?.data) ? chResp.data : []) {
      const cid = String(ch?.chapter_id ?? '').trim();
      if (!cid) continue;
      let name = String(ch?.title ?? '').trim();
      if (!name) name = `第${String(ch?.number ?? '').trim()}话`;
      chapters.push(Chapter(chapters.length + 1, name, `${id}|${cid}`));
    }
    return BookDetail({
      id,
      name: String(d.title ?? ''),
      pic: String(d.cover ?? ''),
      desc: String(d.content ?? ''),
      tag: '漫画',
      author: String(d.author_title ?? ''),
      remarks: `${chapters.length} 话`,
      chapters,
      count: chapters.length,
    });
  }

  async pics(ref) {
    const parts = String(ref ?? '').trim().split('|');
    if (parts.length < 2 || !parts[0] || !parts[1]) {
      throw new Error(`mkz: 非法章节凭证 ${ref}`);
    }
    const comicID = parts[0];
    const chapterID = parts[1];
    const u = `${mkzHost}/chapter/content/?chapter_id=${encode(chapterID)}&comic_id=${encode(comicID)}`;
    const body = await httpGet(u, mkzHeaders(), 20000);
    let resp = null;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('mkz: 章节解析失败');
    }
    const pics = [];
    for (const it of Array.isArray(resp?.data) ? resp.data : []) {
      const v = String(it?.image ?? '').trim();
      if (v) pics.push(v);
    }
    if (pics.length === 0) throw new Error('mkz: 章节无图片');
    return ComicPlay({ pics, referer: mkzHost + '/', ua: mkzUA });
  }
}

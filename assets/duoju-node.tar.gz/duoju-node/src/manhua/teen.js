
import * as teenhub from '../teenhub.js';
import { providers } from './registry.js';
import { Card, BookDetail } from './types.js';

export const teenScheme = 'teen://';
export const teenPlaceholderID = '__teen__';

export function teenEnabled() {
  return teenhub.teenEnabled();
}

export function setTeenEnabled(enabled) {
  teenhub.setTeen(!!enabled);
}

export function teenSnapshot() {
  const enabled = teenEnabled();
  const snap = { enabled, blocked: 0 };
  if (!enabled) {
    snap.note = '青少年模式已关闭：成人漫画源已显示';
  } else {
    snap.blocked = adultProviderCount();
    snap.note = '青少年模式开启中：成人漫画源已隐藏';
  }
  return snap;
}

function adultProviderCount() {
  let n = 0;
  for (const p of providers()) {
    if (p.adult()) n++;
  }
  return n;
}


export function teenSameOrigin(req) {
  const origin = String(req.headers.origin || '').trim();
  const referer = String(req.headers.referer || '').trim();
  let probe = origin || referer;
  if (!probe) return true;
  const i = probe.indexOf('://');
  let after = i >= 0 ? probe.slice(i + 3) : probe;
  const cut = after.search(/[/?]/);
  if (cut >= 0) after = after.slice(0, cut);
  
  let host = after;
  const m = /^( \[[^\]]+\]|[^:]+)(?::(\d+))?$/.exec(after.replace(/^ /, ''));
  if (m) host = m[1];
  if (host.startsWith('[') && host.endsWith(']')) host = host.slice(1, -1);
  return host === '127.0.0.1' || host === '::1' || host === 'localhost';
}

export function teenBlocked(p) {
  return teenEnabled() && p.adult();
}

export function teenEffective() {
  return teenEnabled();
}

export function teenPlaceholderCard(plat) {
  return Card({
    id: teenPlaceholderID,
    name: '【青少年模式已隐藏】',
    pic: '',
    remarks: '成人内容 · 关闭青少年模式后查看',
    cat: 'adult',
    desc: '该来源标记为成人内容，青少年模式下不可见。请在设置中关闭青少年模式后查看。',
    plat,
  });
}

export function teenPlaceholderDetail(plat) {
  void plat;
  return BookDetail({
    id: teenPlaceholderID,
    name: '【青少年模式已隐藏】',
    pic: '',
    desc: '该来源标记为成人内容，青少年模式下不可见。请在设置中关闭青少年模式后查看。',
    tag: 'adult',
    remarks: '关闭青少年模式后查看',
    chapters: [{ no: 1, name: '解锁提示', url: teenScheme + 'unlock' }],
    count: 1,
    adult: true,
  });
}

export function teenPlaceholderPlay() {
  return { pics: [] };
}

export default {
  teenScheme,
  teenPlaceholderID,
  teenEnabled,
  setTeenEnabled,
  teenSnapshot,
  teenSameOrigin,
  teenBlocked,
  teenEffective,
  teenPlaceholderCard,
  teenPlaceholderDetail,
  teenPlaceholderPlay,
};

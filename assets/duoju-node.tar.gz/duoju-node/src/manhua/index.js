
import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { BrowserClient } from '../core/client.js';
import { setUpstreamClient, atoiDefault, firstNonEmpty } from './core/http.js';
import { AppVersion, setDataDir } from './core/datadir.js';
import { provider, providers, platformList, catOrDefault, proxyPicsURL } from './registry.js';
import { MediaProxy } from './media.js';
import * as teen from './teen.js';


import './providers/index.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const WEB_ROOT_CANDIDATES = [
  path.resolve(here, '../../web/manhua'),
  path.join(process.cwd(), 'web/manhua'),
];

function webRoot() {
  for (const dir of WEB_ROOT_CANDIDATES) {
    try {
      if (fs.statSync(path.join(dir, 'index.html')).isFile()) return dir;
    } catch {  }
  }
  return WEB_ROOT_CANDIDATES[0];
}



function sendJSON(res, obj, status = 200) {
  res.status(status);
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cache-Control', 'no-store');
  res.send(JSON.stringify(obj) + '\n');
}

function writeError(res, status, msg) {
  sendJSON(res, { code: status, msg }, status);
}



function loopbackOnly(req) {
  let host = String(req.socket?.remoteAddress || '');
  if (host.startsWith('::ffff:')) host = host.slice(7);
  return host === '127.0.0.1' || host === '::1' || host === '[::1]' || host === 'localhost';
}

function externalBase(req) {
  const ext = String(req.headers['x-jdd-external'] || '').trim();
  if (ext) return ext;
  const host = String(req.headers.host || '127.0.0.1').trim();
  if (!host) return 'http://127.0.0.1';
  return `http://${host}`;
}

function chapterScope(plat, cid, ch) {
  if (!cid || ch < 0) return '';
  return `${plat}|${cid}|${ch}`;
}

function sortSearchCards(cards, wd) {
  if (!cards || cards.length < 2) return;
  const kw = String(wd || '').trim().toLowerCase();
  if (!kw) return;
  
  const idx = new Map(cards.map((c, i) => [c, i]));
  cards.sort((a, b) => {
    const ma = String(a.vod_name || '').toLowerCase().includes(kw);
    const mb = String(b.vod_name || '').toLowerCase().includes(kw);
    if (ma !== mb) return ma ? -1 : 1;
    return idx.get(a) - idx.get(b);
  });
}



const DISC_CACHE_TTL = 30 * 60 * 1000;
const discCache = new Map(); 

function discCacheGet(key) {
  const e = discCache.get(key);
  if (!e) return null;
  if (Date.now() - e.at > DISC_CACHE_TTL) {
    discCache.delete(key);
    return null;
  }
  return e;
}

function discCachePut(key, status, body) {
  if (discCache.size >= 128) discCache.clear();
  discCache.set(key, { status, body, at: Date.now() });
}



const sourceStats = new Map(); 

function recordSourceStat(key, err) {
  if (!err) {
    sourceStats.set(key, { ok: true, err: '', at: Date.now() });
  } else {
    sourceStats.set(key, { ok: false, err: String(err.message || err), at: Date.now() });
  }
}

function getSourceStat(key) {
  return sourceStats.get(key) || null;
}



async function computeList(req) {
  const query = req.query || {};
  let key = String(query.plat || '').trim();
  if (!key) key = 'manga';
  const p = provider(key);
  if (!p) return { status: 400, resp: { code: 400, msg: '未知平台: ' + key } };
  if (teen.teenBlocked(p)) {
    return {
      status: 200,
      resp: {
        code: 200,
        data: {
          plat: key, category: query.cat || '', page: 1,
          list: [teen.teenPlaceholderCard(key)], teen: true,
        },
      },
    };
  }
  const cat = catOrDefault(p, query.cat);
  const page = atoiDefault(query.page, 1);
  try {
    const res = await p.list(cat, page);
    recordSourceStat(key, null);
    return {
      status: 200,
      resp: {
        code: 200,
        data: {
          plat: key, category: cat, page,
          list: res.cards || [], hasMore: !!res.hasMore, teen: false,
        },
      },
    };
  } catch (err) {
    recordSourceStat(key, err);
    return { status: 502, resp: { code: 502, msg: '抓取列表失败: ' + String(err.message || err) } };
  }
}

async function computeSearch(req) {
  const query = req.query || {};
  const wd = String(query.wd || '').trim();
  if (!wd) return { status: 400, resp: { code: 400, msg: '缺少关键词' } };
  const page = atoiDefault(query.page, 1);

  if (!('plat' in query) || String(query.plat || '').trim() === '') {
    return aggregateSearch(wd, page, String(query.plats || ''));
  }

  const key = String(query.plat || '').trim();
  const p = provider(key);
  if (!p) return { status: 400, resp: { code: 400, msg: '未知平台: ' + key } };
  if (teen.teenBlocked(p)) {
    return {
      status: 200,
      resp: {
        code: 200,
        data: { plat: key, wd, page, list: [teen.teenPlaceholderCard(key)], teen: true },
      },
    };
  }
  try {
    const res = await p.search(wd, page);
    recordSourceStat(key, null);
    const cards = res.cards || [];
    sortSearchCards(cards, wd);
    return {
      status: 200,
      resp: { code: 200, data: { plat: key, wd, page, list: cards, hasMore: !!res.hasMore, teen: false } },
    };
  } catch (err) {
    recordSourceStat(key, err);
    return { status: 502, resp: { code: 502, msg: '搜索失败: ' + String(err.message || err) } };
  }
}

async function aggregateSearch(wd, page, plats) {
  let all = providers();
  plats = String(plats || '').trim();
  if (plats) {
    const want = new Set(plats.split(',').map((k) => k.trim()).filter(Boolean));
    all = all.filter((p) => want.has(p.key()));
  }
  all = all.filter((p) => !teen.teenBlocked(p));
  if (all.length === 0) {
    return {
      status: 200,
      resp: {
        code: 200,
        data: { wd, page, list: [], platforms: [], totalPlatforms: 0 },
      },
    };
  }

  const TIMEOUT_SENTINEL = Symbol('timeout');
  const results = await Promise.all(
    all.map(async (p) => {
      try {
        const res = await Promise.race([
          p.search(wd, page),
          new Promise((_, rej) => setTimeout(() => rej(TIMEOUT_SENTINEL), 7 * 1000)),
        ]);
        recordSourceStat(p.key(), null);
        return { ok: true, cards: res.cards || [], more: !!res.hasMore, timedOut: false };
      } catch (err) {
        recordSourceStat(p.key(), err === TIMEOUT_SENTINEL ? new Error('context deadline exceeded') : err);
        return { ok: false, cards: [], more: false, timedOut: err === TIMEOUT_SENTINEL };
      }
    }),
  );

  const merged = [];
  const hitPlats = [];
  const slowPlats = [];
  let hasMore = false;
  results.forEach((r, i) => {
    const p = all[i];
    if (!r.ok) {
      if (r.timedOut) slowPlats.push(p.key());
      return;
    }
    hitPlats.push(p.key());
    hasMore = hasMore || r.more;
    for (const c of r.cards) {
      if (!String(c.vod_pic || '').trim() && !String(c.vod_name || '').trim()) continue;
      const copy = { ...c };
      copy.vod_plat = p.key();
      merged.push(copy);
    }
  });

  sortSearchCards(merged, wd);

  return {
    status: 200,
    resp: {
      code: 200,
      data: {
        wd,
        page,
        list: merged,
        hasMore,
        platforms: hitPlats,
        timeout: slowPlats,
        totalPlatforms: all.length,
      },
    },
  };
}

async function computeDetail(req) {
  const query = req.query || {};
  const id = String(query.id || '').trim();
  if (!id) return { status: 400, resp: { code: 400, msg: '缺少 id' } };
  let key = String(query.plat || '').trim();
  if (!key) key = 'manga';
  const p = provider(key);
  if (!p) return { status: 400, resp: { code: 400, msg: '未知平台: ' + key } };
  if (teen.teenBlocked(p)) {
    return { status: 200, resp: { code: 200, data: teen.teenPlaceholderDetail(key) } };
  }
  try {
    const detail = await p.detail(id);
    recordSourceStat(key, null);
    if (!detail) {
      return { status: 502, resp: { code: 502, msg: '抓取详情失败: not found' } };
    }
    detail.vod_class = firstNonEmpty(detail.vod_class, p.name());
    return { status: 200, resp: { code: 200, data: detail } };
  } catch (err) {
    recordSourceStat(key, err);
    return { status: 502, resp: { code: 502, msg: '抓取详情失败: ' + String(err.message || err) } };
  }
}

async function computePlay(req, media) {
  const query = req.query || {};
  const ref = String(query.url || '').trim();
  if (!ref) return { status: 400, resp: { code: 400, msg: '缺少 url（章节凭证）' } };
  let key = String(query.plat || '').trim();
  if (!key) key = 'manga';
  const p = provider(key);
  if (!p) return { status: 400, resp: { code: 400, msg: '未知平台: ' + key } };
  if (teen.teenBlocked(p)) {
    return { status: 200, resp: { code: 200, data: { pics: [], teen: true } } };
  }
  try {
    const result = await p.pics(ref);
    if (!result) return { status: 502, resp: { code: 502, msg: '解析图片失败: not found' } };
    const mediaBase = externalBase(req);

    const cid = String(query.cid || '').trim();
    const ch = atoiDefault(query.ch, -1);
    const scope = chapterScope(key, cid, ch);
    const pics = proxyPicsURL(mediaBase, result, ref, scope);
    if (scope) {
      media.imgCache.retainScopes(scope, chapterScope(key, cid, ch - 1));
    }

    const warm = atoiDefault(query.warm, 0);
    if (warm > 0) {
      media.warm(pics, warm);
    }
    return {
      status: 200,
      resp: {
        code: 200,
        data: {
          pics,
          total: pics.length,
          referer: result.referer || '',
          ua: result.ua || '',
          teen: false,
        },
      },
    };
  } catch (err) {
    return { status: 502, resp: { code: 502, msg: '解析图片失败: ' + String(err.message || err) } };
  }
}



export class ManhuaServer {
  constructor(options = {}) {
    setDataDir(options.dataDir || '');
    const client = options.client || new BrowserClient({ profile: 'chrome_136' });
    setUpstreamClient(client);
    this.port = options.port || 0;
    this.media = new MediaProxy();
    this.app = express();
    this.app.disable('x-powered-by');
    this.setupRoutes();
  }

  setupRoutes() {
    const app = this.app;

    
    app.use((req, res, next) => {
      const start = Date.now();
      res.on('finish', () => {
        if (String(req.path || '').startsWith('/media')) return;
        
        console.log(`${req.method} ${req.path} ${Date.now() - start}ms`);
      });
      next();
    });

    app.get('/favicon.ico', (req, res) => res.status(204).end());
    app.get('/api/platform', (req, res) => this.handlePlatform(req, res));
    app.get('/api/cats', (req, res) => this.handleCats(req, res));

    const cached = (compute) => async (req, res) => {
      const key = (req.originalUrl || req.url) + '|teen=' + teen.teenEnabled();
      const hit = discCacheGet(key);
      if (hit) {
        res.status(hit.status);
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Cache-Control', 'no-store');
        res.send(hit.body);
        return;
      }
      const { status, resp } = await compute(req);
      if (status === 200) discCachePut(key, status, JSON.stringify(resp) + '\n');
      sendJSON(res, resp, status);
    };

    const guard = (fn) => (req, res) => {
      Promise.resolve(fn(req, res)).catch((err) => {
        console.error('[manhua] handler error:', err && err.stack ? err.stack : err);
        if (!res.headersSent) writeError(res, 500, 'internal error');
        else try { res.destroy(); } catch {}
      });
    };
    app.get('/api/home', cached(computeList));
    app.get('/api/category', cached(computeList));
    app.get('/api/search', guard(async (req, res) => {
      const { status, resp } = await computeSearch(req);
      sendJSON(res, resp, status);
    }));
    app.get('/api/detail', guard(async (req, res) => {
      const { status, resp } = await computeDetail(req);
      sendJSON(res, resp, status);
    }));
    app.get('/api/play', guard(async (req, res) => {
      const { status, resp } = await computePlay(req, this.media);
      sendJSON(res, resp, status);
    }));
    app.all('/web/api/teen', express.json({ limit: '64kb' }), (req, res) => this.handleWebTeen(req, res));

    app.post('/api/checkupdate', express.json({ limit: '1mb' }), (req, res) => this.handleCheckUpdate(req, res));
    app.get(['/media/audio', '/media'], guard((req, res) => this.media.handleAudio(req, res)));
    app.get('/media/img', guard((req, res) => this.media.handleImg(req, res)));
    app.get('/api/cache', (req, res) => this.handleCache(req, res));
    app.post('/api/cache', (req, res) => this.handleCache(req, res));
    app.get('/internal/hello', (req, res) => this.handleHello(req, res));

    app.all('*', (req, res) => this.handleRoot(req, res));
  }

  handleHello(req, res) {
    if (!loopbackOnly(req)) {
      res.status(403).type('text/plain; charset=utf-8').send('forbidden');
      return;
    }
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.send(JSON.stringify({
      app: 'duoju-manhua',
      version: AppVersion,
      port: this.port,
      pid: process.pid,
      ok: true,
    }) + '\n');
  }

  handleRoot(req, res) {
    const urlPath = String(req.path || '/');
    if (urlPath !== '/') {
      if (this.serveRootAsset(req, res, urlPath)) return;
      writeError(res, 404, 'not found');
      return;
    }
    const accept = String(req.headers.accept || '').toLowerCase();
    if (accept.includes('text/html')) {
      this.serveIndex(req, res);
      return;
    }
    sendJSON(res, {
      code: 200,
      msg: 'duoju-manhua ok',
      data: {
        name: '多聚漫画后台',
        version: AppVersion,
        port: this.port,
        api: ['/api/platform', '/api/cats', '/api/home', '/api/category', '/api/search', '/api/detail', '/api/play', '/media/img', '/web/api/teen'],
        web: '/web/',
      },
    });
  }

  serveRootAsset(req, res, urlPath) {
    const name = urlPath.replace(/^\/+/, '');
    if (!name || name.includes('..')) return false;
    const ext = path.extname(name).toLowerCase();
    const extMap = {
      '.js': 'application/javascript; charset=utf-8',
      '.css': 'text/css; charset=utf-8',
      '.svg': 'image/svg+xml',
      '.ico': 'image/x-icon',
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.webp': 'image/webp',
      '.json': 'application/json; charset=utf-8',
    };
    const ct = extMap[ext];
    if (!ct) return false;
    let data;
    try {
      data = fs.readFileSync(path.join(webRoot(), name));
    } catch {
      return false;
    }
    res.setHeader('Content-Type', ct);
    res.setHeader('Cache-Control', 'public, max-age=600');
    res.send(data);
    return true;
  }

  serveIndex(req, res) {
    let data;
    try {
      data = fs.readFileSync(path.join(webRoot(), 'index.html'), 'utf8');
    } catch {
      writeError(res, 500, '前端资源缺失');
      return;
    }
    let html = data.replaceAll('href="style.css"', `href="style.css?v=${AppVersion}"`);
    html = html.replaceAll('src="app.js"', `src="app.js?v=${AppVersion}"`);
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache');
    res.send(html);
  }

  handlePlatform(req, res) {
    const all = platformList();
    const t = teen.teenEnabled();
    const visible = [];
    const adults = [];
    let blocked = 0;
    for (const p of all) {
      if (p.adult) {
        const vp = { ...p, name: '🔞 ' + p.name };
        if (t) blocked++;
        adults.push(vp);
        continue;
      }
      visible.push(p);
    }
    visible.push(...adults);

    const status = [];
    for (const p of visible) {
      const st = getSourceStat(p.key);
      if (!st) continue;
      status.push({ key: p.key, ok: st.ok, err: st.err, at: st.at });
    }
    sendJSON(res, {
      code: 200,
      data: { platforms: visible, teen: t, blocked, status },
    });
  }

  handleCats(req, res) {
    const key = String((req.query || {}).plat || '').trim();
    const p = provider(key);
    if (!p) {
      writeError(res, 400, '未知平台: ' + key);
      return;
    }
    if (teen.teenBlocked(p)) {
      sendJSON(res, { code: 200, data: { plat: key, cats: [], teen: true } });
      return;
    }
    sendJSON(res, { code: 200, data: { plat: key, cats: p.cats ? p.cats() : [], teen: false } });
  }

  handleWebTeen(req, res) {
    if (!loopbackOnly(req)) {
      writeError(res, 403, '仅本机可访问');
      return;
    }
    if (req.method === 'GET') {
      sendJSON(res, { code: 200, data: teen.teenSnapshot() });
      return;
    }
    if (req.method !== 'POST') {
      writeError(res, 405, 'method not allowed');
      return;
    }
    if (!teen.teenSameOrigin(req)) {
      writeError(res, 403, '来源不合法');
      return;
    }
    let body;
    try {
      body = typeof req.body === 'object' && req.body ? req.body : JSON.parse(String(req.body || '{}'));
    } catch {
      writeError(res, 400, '参数错误');
      return;
    }
    const action = body.action;
    if (action === 'disable') {
      teen.setTeenEnabled(false);
      sendJSON(res, { code: 200, msg: '青少年模式已关闭', data: teen.teenSnapshot() });
    } else if (action === 'enable') {
      teen.setTeenEnabled(true);
      sendJSON(res, { code: 200, msg: '青少年模式已开启', data: teen.teenSnapshot() });
    } else {
      writeError(res, 400, '未知 action');
    }
  }

  async handleCheckUpdate(req, res) {
    if (req.method !== 'POST' || !loopbackOnly(req)) {
      writeError(res, 403, 'forbidden');
      return;
    }
    let body;
    try {
      body = typeof req.body === 'object' && req.body ? req.body : JSON.parse(String(req.body || '{}'));
    } catch {
      writeError(res, 400, '参数错误');
      return;
    }
    let items = Array.isArray(body.items) ? body.items : [];
    if (items.length > 200) items = items.slice(0, 200);

    const UPD_CHECK_N = 6;
    const UPD_DETAIL_TO = 30 * 1000;

    const results = items.map((it) => ({ plat: it.plat || '', id: it.id || '', ok: false, hasUpdate: false, total: 0 }));
    let idx = 0;
    const worker = async () => {
      while (idx < items.length) {
        const i = idx++;
        const it = items[i];
        const p = provider(it.plat);
        if (!p || teen.teenBlocked(p)) {
          results[i].err = '源不可用';
          continue;
        }
        try {
          const detail = await Promise.race([
            p.detail(it.id),
            new Promise((_, rej) => setTimeout(() => rej(new Error('context deadline exceeded')), UPD_DETAIL_TO)),
          ]);
          recordSourceStat(it.plat, null);
          results[i].ok = true;
          results[i].total = detail && Array.isArray(detail.chapters) ? detail.chapters.length : 0;
          results[i].hasUpdate = results[i].total > (Number(it.ch) || 0) + 1;
        } catch (err) {
          recordSourceStat(it.plat, err);
          results[i].err = '详情获取失败';
        }
      }
    };
    await Promise.all(Array.from({ length: Math.min(UPD_CHECK_N, Math.max(items.length, 1)) }, worker));
    sendJSON(res, { code: 200, data: { results } });
  }

  handleCache(req, res) {
    if (!loopbackOnly(req)) {
      writeError(res, 403, 'forbidden');
      return;
    }
    if (req.method === 'POST') {
      this.media.imgCache.clear();
      sendJSON(res, { code: 200, msg: '图片缓存已清空', data: this.media.imgCache.stats() });
      return;
    }
    sendJSON(res, { code: 200, data: this.media.imgCache.stats() });
  }
}

export default ManhuaServer;

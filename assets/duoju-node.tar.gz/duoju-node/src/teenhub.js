
import fs from 'node:fs';
import path from 'node:path';

let teenPath = '';
let loaded = false;
let enabled = true;

export function setPath(p) {
  p = String(p || '').trim();
  if (p) p = path.normalize(p);
  if (teenPath !== p) {
    teenPath = p;
    loaded = false;
  }
}

function ensure() {
  if (loaded) return;
  loaded = true;
  enabled = true;
  if (!teenPath) return;
  try {
    const b = fs.readFileSync(teenPath, 'utf8');
    enabled = b.trim() !== '0';
  } catch {}
}

export function teenEnabled() {
  ensure();
  return enabled;
}

export function setTeen(on) {
  ensure();
  enabled = on;
  write();
}

function write() {
  if (!teenPath) return;
  const c = enabled ? '1' : '0';
  try {
    fs.writeFileSync(teenPath + '.tmp', c);
    fs.renameSync(teenPath + '.tmp', teenPath);
  } catch {}
}

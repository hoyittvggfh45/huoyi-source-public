

import { createCipheriv } from 'node:crypto';
import { pipeline } from 'node:stream/promises';
import { Readable } from 'node:stream';
import { isM3U8 } from './util.js';

const CENC_MOOV_PROBE = 1 << 20;
const CENC_FETCH_CHUNK = 1 << 20;
const CENC_INDEX_TTL = 20 * 60 * 1000;
const CENC_INDEX_MAX = 32;

export const MEDIA_NO_REFERER = '-';

export function guessMediaType(target) {
  const path = String(target || '').split('?')[0].toLowerCase();
  if (path.endsWith('.mp4')) return 'video/mp4';
  if (path.endsWith('.ts')) return 'video/mp2t';
  if (path.endsWith('.key') || path.endsWith('.bin')) return 'application/octet-stream';
  if (path.endsWith('.m4s')) return 'video/iso.segment';
  if (path.endsWith('.aac')) return 'audio/aac';
  return 'application/octet-stream';
}

export class MediaProxy {
  constructor(client) {
    this.client = client;
    this.host = '';
    this.cenc = new CENCCache();
  }

  
  forRequest(req) {
    const cp = new MediaProxy(this.client);
    const ext = String(req.headers['x-jdd-external'] || '').trim();
    cp.host = ext || `http://${req.headers.host || '127.0.0.1'}`;
    cp.cenc = this.cenc;
    return cp;
  }

  proxyURL(target, referer, cookie) {
    return this.proxyURLUA(target, referer, cookie, '');
  }

  proxyURLUA(target, referer, cookie, ua) {
    const q = new URLSearchParams();
    q.set('url', target);
    if (referer) q.set('ref', referer);
    if (cookie) q.set('ck', cookie);
    if (ua) q.set('ua', ua);
    const suffix = isM3U8(target) ? 'media/playlist.m3u8' : 'media';
    return `${this.host}/${suffix}?${q.toString()}`;
  }

  cencProxyURL(target, referer, cookie, keyHex) {
    const q = new URLSearchParams();
    q.set('url', target);
    q.set('dec', 'cenc');
    q.set('key', keyHex);
    if (referer) q.set('ref', referer);
    if (cookie) q.set('ck', cookie);
    return `${this.host}/media?${q.toString()}`;
  }

  cencM3U8ProxyURL(target, referer, cookie, keyHex) {
    const q = new URLSearchParams();
    q.set('url', target);
    q.set('dec', 'cenc');
    q.set('m3u8', '1');
    q.set('key', keyHex);
    if (referer) q.set('ref', referer);
    if (cookie) q.set('ck', cookie);
    return `${this.host}/media?${q.toString()}`;
  }

  imgProxyURL(target, referer) {
    const q = new URLSearchParams();
    q.set('url', target);
    q.set('dec', 'img');
    if (referer) q.set('ref', referer);
    return `${this.host}/media?${q.toString()}`;
  }

  inlineKeyProxyURL(payload) {
    return `${this.host}/media?dec=key&k=${Buffer.from(payload).toString('base64url')}`;
  }

  
  async Handle(target, referer, cookie, ua) {
    if (!/^https?:\/\//.test(target || '')) {
      return { code: 400, phase: '', body: null, headers: {}, error: new Error('非法的媒体地址') };
    }
    if (!isM3U8(target)) {
      try {
        const resp = await this.client.fetchMediaBytesUA(target, referer, cookie, ua);
        const body = await resp.buffer();
        
        
        const head = body.subarray(0, 7).toString('latin1');
        if (head === '#EXTM3U') {
          return this.rewritePlaylistBody(body, target, referer, cookie, ua);
        }
        const headers = {};
        headers['Content-Type'] = resp.headers['content-type'] || guessMediaType(target);
        const cl = Number(resp.headers['content-length'] || 0);
        if (cl > 0) headers['Content-Length'] = String(cl);
        headers['Cache-Control'] = 'no-store';
        headers['Access-Control-Allow-Origin'] = '*';
        headers['Accept-Ranges'] = 'bytes';
        return { code: 200, phase: 'probe', body, headers };
      } catch (err) {
        return { code: 502, phase: '', body: null, headers: {}, error: err };
      }
    }

    if (target.includes('/playlist') || !target.includes('/master')) {
      return this.servePlaylist(target, referer, cookie, ua);
    }
    try {
      const resp = await this.client.fetchMediaBytesUA(target, referer, cookie, ua);
      const body = await resp.buffer();
      const best = selectBestVariant(body.toString('utf8'), target);
      if (!best) return this.rewritePlaylistBody(body, target, referer, cookie, ua);
      return this.servePlaylist(best, referer, cookie, ua);
    } catch (err) {
      return { code: 502, phase: '', body: null, headers: {}, error: err };
    }
  }

  async servePlaylist(playlistURL, referer, cookie, ua) {
    try {
      const resp = await this.client.fetchMediaBytesUA(playlistURL, referer, cookie, ua);
      const body = await resp.buffer();
      return this.rewritePlaylistBody(body, playlistURL, referer, cookie, ua);
    } catch (err) {
      return { code: 502, phase: '', body: null, headers: {}, error: err };
    }
  }

  rewritePlaylistBody(body, playlistURL, referer, cookie, ua) {
    const text = body.toString('latin1');
    if (!text.includes('#EXT-X-ENDLIST') && !text.includes('#EXTM3U')) {
      return {
        code: 200, phase: 'raw', body,
        headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' },
      };
    }
    const rewritten = this.rewriteInner(body.toString('utf8'), playlistURL, referer, cookie, ua);
    return {
      code: 200, phase: 'm3u8', body: Buffer.from(rewritten, 'utf8'),
      headers: { 'Content-Type': 'application/vnd.apple.mpegurl; charset=utf-8', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' },
    };
  }

  rewriteInner(raw, playlistURL, referer, cookie, ua) {
    let base = null;
    try { base = new URL(playlistURL); } catch {}
    const lines = raw.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const trimmed = line.trim();
      if (!trimmed) continue;
      if (trimmed.startsWith('#EXT-X-KEY')) {
        const m = /URI="([^"]+)"/i.exec(line);
        if (m) {
          let keyURL = m[1];
          if (keyURL.startsWith('data:')) {
            const payload = parseDataURI(keyURL);
            if (payload) {
              lines[i] = line.replace(/URI="([^"]+)"/i, `URI="${this.inlineKeyProxyURL(payload)}"`);
              continue;
            }
          } else {
            if (!/^https?:\/\//.test(keyURL) && base) {
              try { keyURL = new URL(keyURL, base).toString(); } catch {}
            }
            lines[i] = line.replace(/URI="([^"]+)"/i, `URI="${this.proxyURLUA(keyURL, referer, cookie, ua)}"`);
          }
        }
        continue;
      }
      if (trimmed.startsWith('#')) continue;
      let resolved = trimmed;
      if (!/^https?:\/\//.test(trimmed) && base) {
        try { resolved = new URL(trimmed, base).toString(); } catch {}
      }
      lines[i] = this.proxyURLUA(resolved, referer, cookie, ua);
    }
    return lines.join('\n');
  }

  

  async fetchCENCRange(target, referer, start, end) {
    const headers = {};
    if (referer) headers.Referer = referer;
    headers['User-Agent'] = 'com.phoenix.read/71332 (Linux; U; Android 16; zh_CN; 25053RT47C; Build/BP2A.250605.031.A3; Cronet/TTNetVersion:04657795 2026-01-23 QuicVersion:c67e9834 2025-09-08)';
    if (start >= 0) headers.Range = `bytes=${start}-${end}`;
    const resp = await this.client.doCustom('GET', target, null, headers);
    if (resp.status !== 200 && resp.status !== 206) {
      resp.stream.destroy?.();
      throw new Error(`HTTP ${resp.status}: ${target}`);
    }
    const body = await readLimited(resp.stream, 32 << 20);
    let total = 0;
    const cr = resp.headers['content-range'] || '';
    if (cr) {
      const slash = cr.lastIndexOf('/');
      if (slash >= 0) {
        const parsed = parseInt(cr.slice(slash + 1).trim(), 10);
        if (Number.isFinite(parsed)) total = parsed;
      }
    }
    if (total <= 0) {
      const cl = Number(resp.headers['content-length'] || 0);
      if (cl > 0) total = cl;
    }
    return { body, total };
  }

  async cencIndexFor(target, referer, key) {
    const cacheKey = `${target}\x00${key.toString('hex')}`;
    const cached = this.cenc.get(cacheKey);
    if (cached) return cached;
    const entry = await this.buildCENCIndex(target, referer, key);
    this.cenc.put(cacheKey, entry);
    return entry;
  }

  async buildCENCIndex(target, referer, key) {
    if (!key || key.length !== 16) throw new Error('解密密钥无效');
    const index = new CENCIndex(key);
    const first = await this.fetchCENCRange(target, referer, 0, CENC_MOOV_PROBE - 1);
    let probe = first.body;
    let total = probe.length;
    let boxes = parseBoxes(probe, 0n, 0, probe.length, true);
    let moov = boxes.find((b) => b.typ === 'moov');
    if (!moov) throw new Error('未找到 MP4 moov 结构');

    let base = 0n;
    if (moov.size > BigInt(probe.length)) {
      const full = await this.fetchCENCRange(target, referer, Number(moov.start), Number(moov.start + moov.size) - 1);
      probe = full.body;
      base = moov.start;
      boxes = parseBoxes(probe, base, 0, probe.length, true);
    }
    for (const box of boxes) {
      if (box.typ === 'mdat') {
        const end = box.start + box.size;
        if (end > total) total = Number(end);
      }
    }
    for (const box of boxes) {
      if (box.typ !== 'trak') continue;
      const inner = parseBoxes(probe, base, Number(box.start - base), Number(box.start - base) + Number(box.size), true);
      const table = buildSampleTable(probe, base, inner);
      if (!table) continue;
      index.regions.push(...tableRegions(table));
    }
    for (const box of boxes) {
      if (box.typ === 'mvhd') {
        const start = Number(box.start - base) + 8;
        const body = probe.subarray(start, Number(box.start - base) + Number(box.size));
        if (body.length >= 20) {
          const version = body[0];
          let timescale = 0;
          let dur = 0;
          if (version === 1 && body.length >= 32) {
            timescale = body.readUInt32BE(20);
            dur = body.readUInt32BE(28);
          } else {
            timescale = body.readUInt32BE(12);
            dur = body.readUInt32BE(16);
          }
          if (timescale > 0) index.duration = dur / timescale;
        }
        break;
      }
    }
    if (index.regions.length === 0) throw new Error('未找到加密样本信息');
    index.regions.sort((a, b) => Number(a.start - b.start));
    try {
      const { total: total2 } = await this.fetchCENCRange(target, referer, 0, 0);
      if (total2 > 0) index.total = total2;
      else index.total = total;
    } catch {
      index.total = total;
    }
    if (index.total < total) index.total = total;
    return index;
  }

  
  async serveCENC(req, res, target, referer, cookie, keyHex) {
    const key = hexToBuf(keyHex);
    if (!key || key.length !== 16) return httpError(res, 400, '解密密钥无效');
    let index;
    try {
      index = await this.cencIndexFor(target, referer, key);
    } catch (err) {
      return httpError(res, 502, 'CENC 索引失败: ' + err.message);
    }
    const total = index.total;
    res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    if (req.method === 'HEAD') {
      res.setHeader('Content-Length', String(total));
      res.status(200).end();
      return;
    }
    const range = parseByteRange(req.headers.range || '', total);
    let start = range.start;
    let end = range.end;
    if (!range.has) { start = 0; end = total - 1; }
    if (end >= total) end = total - 1;
    if (start > end || start >= total) {
      res.setHeader('Content-Range', `bytes */${total}`);
      return httpError(res, 416, '请求范围不合法');
    }
    res.setHeader('Content-Length', String(end - start + 1));
    if (range.has) res.setHeader('Content-Range', `bytes ${start}-${end}/${total}`);
    res.status(range.has ? 206 : 200);
    let pos = start;
    while (pos <= end) {
      let chunkEnd = pos + CENC_FETCH_CHUNK - 1;
      if (chunkEnd > end) chunkEnd = end;
      let body;
      try {
        const r = await this.fetchCENCRange(target, referer, pos, chunkEnd);
        body = r.body;
      } catch {
        return;
      }
      index.decryptInto(body, body, pos);
      if (!res.write(body)) {
        await new Promise((resolve) => res.once('drain', resolve));
      }
      pos = chunkEnd + 1;
    }
    res.end();
  }

  
  async serveCENCM3U8(req, res, target, referer, cookie, keyHex) {
    const key = hexToBuf(keyHex);
    if (!key || key.length !== 16) return httpError(res, 400, '解密密钥无效');
    let index;
    try {
      index = await this.cencIndexFor(target, referer, key);
    } catch (err) {
      return httpError(res, 502, 'CENC 索引失败: ' + err.message);
    }
    const total = index.total;
    let duration = index.duration;
    if (duration <= 0) duration = 120;
    let chunkSize = Math.floor((total / duration) * 4.0);
    if (chunkSize < 100 * 1024) chunkSize = 100 * 1024;
    if (chunkSize > 2 * 1024 * 1024) chunkSize = 2 * 1024 * 1024;
    let targetDuration = Math.floor((chunkSize / total) * duration + 0.5) + 1;
    if (targetDuration < 2) targetDuration = 2;
    if (targetDuration > 10) targetDuration = 10;

    const segmentURL = new URL(req.url, 'http://x');
    segmentURL.searchParams.delete('cencm3u8');
    segmentURL.searchParams.delete('m3u8');
    
    const segBase = `${this.host}/media?${segmentURL.searchParams.toString()}`;

    const sb = [];
    sb.push('#EXTM3U\n');
    sb.push('#EXT-X-VERSION:4\n');
    sb.push(`#EXT-X-TARGETDURATION:${targetDuration}\n`);
    sb.push('#EXT-X-PLAYLIST-TYPE:VOD\n');
    let pos = 0;
    while (pos < total) {
      let size = chunkSize;
      if (pos + size > total) size = total - pos;
      let segDur = (size / total) * duration;
      if (pos + chunkSize >= total) segDur = duration - (pos / total) * duration;
      if (segDur < 0.1) segDur = 0.1;
      sb.push(`#EXTINF:${segDur.toFixed(3)},\n`);
      sb.push(`#EXT-X-BYTERANGE:${size}@${pos}\n`);
      sb.push(`${segBase}\n`);
      pos += size;
    }
    sb.push('#EXT-X-ENDLIST\n');
    res.setHeader('Content-Type', 'application/vnd.apple.mpegurl');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.send(sb.join(''));
  }
}

function httpError(res, status, msg) {
  res.status(status).setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.send(msg);
}

function hexToBuf(hex) {
  if (!hex || /[^0-9a-fA-F]/.test(hex) || hex.length % 2 !== 0) return null;
  return Buffer.from(hex, 'hex');
}

async function readLimited(stream, limit) {
  const chunks = [];
  let size = 0;
  for await (const chunk of stream) {
    chunks.push(chunk);
    size += chunk.length;
    if (size > limit) break;
  }
  return Buffer.concat(chunks);
}

export function parseDataURI(uri) {
  if (!uri.startsWith('data:')) return null;
  const comma = uri.indexOf(',');
  if (comma < 0) return null;
  const meta = uri.slice(5, comma);
  const payload = uri.slice(comma + 1);
  if (meta.includes(';base64')) {
    try { return Buffer.from(payload, 'base64'); } catch { return null; }
  }
  try { return Buffer.from(decodeURIComponent(payload), 'utf8'); } catch { return null; }
}

export function selectBestVariant(master, masterURL) {
  let base = null;
  try { base = new URL(masterURL); } catch { return ''; }
  const lines = master.split('\n');
  const variants = [];
  let pending = { height: 0, bandwidth: 0 };
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    if (trimmed.startsWith('#EXT-X-STREAM-INF')) {
      pending = { height: 0, bandwidth: 0 };
      const mRes = /RESOLUTION\s*=\s*(\d+)x(\d+)/i.exec(trimmed);
      if (mRes) pending.height = parseInt(mRes[2], 10);
      const mBw = /(?:AVERAGE-)?BANDWIDTH\s*=\s*(\d+)/i.exec(trimmed);
      if (mBw) pending.bandwidth = parseInt(mBw[1], 10);
      continue;
    }
    if (trimmed.startsWith('#')) continue;
    if (pending.height > 0 || pending.bandwidth > 0) {
      try {
        const raw = new URL(trimmed, base).toString();
        variants.push({ raw, ...pending, order: variants.length });
      } catch {}
      pending = { height: 0, bandwidth: 0 };
    }
  }
  if (variants.length === 0) return '';
  variants.sort((a, b) => {
    if (a.height !== b.height) return b.height - a.height;
    if (a.bandwidth !== b.bandwidth) return b.bandwidth - a.bandwidth;
    return a.order - b.order;
  });
  return variants[0].raw;
}

export function parseByteRange(header, total) {
  if (!header || !header.startsWith('bytes=')) return { start: 0, end: total - 1, has: false };
  let spec = header.slice(6);
  if (spec.includes(',')) spec = spec.split(',')[0];
  const dash = spec.indexOf('-');
  if (dash <= 0) return { start: 0, end: total - 1, has: false };
  const first = parseInt(spec.slice(0, dash).trim(), 10);
  if (!Number.isFinite(first) || first < 0) return { start: 0, end: total - 1, has: false };
  if (dash === spec.length - 1) return { start: first, end: total - 1, has: true };
  const last = parseInt(spec.slice(dash + 1).trim(), 10);
  if (!Number.isFinite(last) || last < first) return { start: 0, end: total - 1, has: false };
  return { start: first, end: last, has: true };
}



function parseBoxes(data, base, start, end, recurse) {
  const out = [];
  let pos = start;
  while (pos + 8 <= end) {
    if (pos < 0 || pos + 8 > data.length) break;
    let size = data.readUInt32BE(pos);
    const typ = data.toString('latin1', pos + 4, pos + 8);
    let header = 8;
    if (size === 1) {
      if (pos + 16 > data.length) break;
      size = Number(data.readBigUInt64BE(pos + 8));
      header = 16;
    } else if (size === 0) {
      size = end - pos;
    }
    if (size < header || pos + size > end) break;
    out.push({ start: base + BigInt(pos), size: BigInt(size), typ });
    if (recurse && ['moov', 'trak', 'mdia', 'minf', 'stbl'].includes(typ)) {
      out.push(...parseBoxes(data, base, pos + header, pos + size, true));
    }
    pos += size;
  }
  return out;
}

function boxBody(data, boxStart, boxSize) {
  return { bodyStart: Number(boxStart) + 8, bodyEnd: Number(boxStart) + Number(boxSize) };
}

function buildSampleTable(data, base, boxes) {
  const stsz = boxes.find((b) => b.typ === 'stsz');
  const stsc = boxes.find((b) => b.typ === 'stsc');
  const stco = boxes.find((b) => b.typ === 'stco');
  const co64 = boxes.find((b) => b.typ === 'co64');
  const senc = boxes.find((b) => b.typ === 'senc');
  if (!stsz || !stsc || !senc || (!stco && !co64)) return null;

  const stszBody = boxBody(data, stsz.start - base).bodyStart;
  const sampleSize = data.readUInt32BE(stszBody + 4);
  const sampleCount = data.readUInt32BE(stszBody + 8);
  const sizes = new Array(sampleCount);
  if (sampleSize !== 0) {
    for (let i = 0; i < sampleCount; i++) sizes[i] = sampleSize;
  } else {
    for (let i = 0; i < sampleCount; i++) {
      const off = stszBody + 12 + i * 4;
      if (off + 4 > data.length) return null;
      sizes[i] = data.readUInt32BE(off);
    }
  }
  const stscBody = boxBody(data, stsc.start - base).bodyStart;
  const stscCount = data.readUInt32BE(stscBody + 4);
  const chunks = [];
  for (let i = 0; i < stscCount; i++) {
    const off = stscBody + 8 + i * 12;
    if (off + 12 > data.length) return null;
    chunks.push({ firstChunk: data.readUInt32BE(off), perChunk: data.readUInt32BE(off + 4) });
  }
  let offsets;
  if (co64) {
    const coBody = boxBody(data, co64.start - base).bodyStart;
    const count = data.readUInt32BE(coBody + 4);
    offsets = new Array(count);
    for (let i = 0; i < count; i++) {
      const off = coBody + 8 + i * 8;
      if (off + 8 > data.length) return null;
      offsets[i] = data.readBigUInt64BE(off);
    }
  } else {
    const stBody = boxBody(data, stco.start - base).bodyStart;
    const count = data.readUInt32BE(stBody + 4);
    offsets = new Array(count);
    for (let i = 0; i < count; i++) {
      const off = stBody + 8 + i * 4;
      if (off + 4 > data.length) return null;
      offsets[i] = BigInt(data.readUInt32BE(off));
    }
  }
  const sencBody = boxBody(data, senc.start - base).bodyStart;
  const flags = data.readUInt32BE(sencBody) & 0xffffff;
  const sencCount = data.readUInt32BE(sencBody + 4);
  if (sencCount !== sampleCount) return null;
  const ivSize = flags & 0x1 ? 16 : 8;
  const hasSubsamples = (flags & 0x2) !== 0;
  const ivs = new Array(sencCount);
  const subs = new Array(sencCount);
  let pos = sencBody + 8;
  for (let i = 0; i < sencCount; i++) {
    if (pos + ivSize > data.length) return null;
    ivs[i] = data.subarray(pos, pos + ivSize);
    pos += ivSize;
    if (hasSubsamples) {
      if (pos + 2 > data.length) return null;
      const subCount = data.readUInt16BE(pos);
      pos += 2;
      const pairs = [];
      for (let j = 0; j < subCount; j++) {
        if (pos + 6 > data.length) return null;
        pairs.push([data.readUInt16BE(pos), data.readUInt16BE(pos + 2)]);
        pos += 6;
      }
      subs[i] = pairs;
    } else {
      subs[i] = [];
    }
  }
  const sampleOffsets = new Array(sampleCount);
  let sampleIndex = 0;
  for (let ci = 0; ci < offsets.length && sampleIndex < sampleCount; ci++) {
    let spc = 1;
    for (let i = chunks.length - 1; i >= 0; i--) {
      if (Number(chunks[i].firstChunk) <= ci + 1) {
        spc = chunks[i].perChunk;
        break;
      }
    }
    let offset = offsets[ci];
    for (let j = 0; j < spc && sampleIndex < sampleCount; j++) {
      sampleOffsets[sampleIndex] = offset;
      offset += BigInt(sizes[sampleIndex]);
      sampleIndex++;
    }
  }
  if (sampleIndex !== sampleCount) return null;
  return { sizes, offsets: sampleOffsets, ivs, subs };
}

class CENCIndex {
  constructor(key) {
    this.key = key;
    this.total = 0;
    this.duration = 0;
    this.regions = [];
    this.built = Date.now();
  }

  decryptInto(dst, src, fileStart) {
    const fileEnd = fileStart + dst.length;
    for (const region of this.regions) {
      const regionStart = Number(region.start);
      const regionEnd = regionStart + Number(region.size);
      if (regionEnd <= fileStart || regionStart >= fileEnd) continue;
      let from = Math.max(fileStart, regionStart);
      let to = Math.min(fileEnd, regionEnd);
      if (from >= to) continue;
      const cipher = createCipheriv('aes-128-ecb', this.key, null);
      cipher.setAutoPadding(false);
      let counter = addCounter(region.iv, BigInt(Math.floor((from - regionStart) / 16)));
      let offset = from;
      while (offset < to) {
        const ks = cipher.update(counter);
        const blockStart = regionStart + Math.floor((offset - regionStart) / 16) * 16;
        const blockEnd = Math.min(blockStart + 16, to);
        for (let position = offset; position < blockEnd; position++) {
          dst[position - fileStart] = src[position - fileStart] ^ ks[position - blockStart];
        }
        offset = blockEnd;
        counter = incrementCounter(counter);
      }
    }
  }
}

function incrementCounter(counter) {
  const out = Buffer.from(counter);
  for (let i = 15; i >= 0; i--) {
    out[i] = (out[i] + 1) & 0xff;
    if (out[i] !== 0) break;
  }
  return out;
}

function addCounter(iv, blocks) {
  const result = Buffer.alloc(16);
  iv.copy(result, 0, 0, Math.min(16, iv.length));
  
  let carry = blocks;
  for (let i = 15; i >= 0 && carry > 0n; i--) {
    const sum = BigInt(result[i]) + (carry & 0xffn);
    result[i] = Number(sum & 0xffn);
    carry = (carry >> 8n) + (sum >> 8n);
  }
  return result;
}


function tableRegions(t) {
  const out = [];
  for (let i = 0; i < t.sizes.length; i++) {
    const iv = Buffer.alloc(16);
    t.ivs[i].copy(iv, 0);
    if (t.ivs[i].length === 8) {
      
    }
    if (!t.subs[i] || t.subs[i].length === 0) {
      out.push({ start: t.offsets[i], size: BigInt(t.sizes[i]), iv });
      continue;
    }
    let offset = t.offsets[i];
    for (const pair of t.subs[i]) {
      offset += BigInt(pair[0]);
      if (pair[1] > 0) {
        out.push({ start: offset, size: BigInt(pair[1]), iv });
        offset += BigInt(pair[1]);
      }
    }
  }
  out.sort((a, b) => Number(a.start - b.start));
  return out;
}


export class CENCCache {
  constructor() {
    this.entries = new Map();
    this.order = [];
  }

  get(key) {
    const entry = this.entries.get(key);
    if (!entry) return null;
    if (Date.now() - entry.built > CENC_INDEX_TTL) {
      this.entries.delete(key);
      this.order = this.order.filter((k) => k !== key);
      return null;
    }
    return entry;
  }

  put(key, entry) {
    if (this.entries.size >= CENC_INDEX_MAX && !this.entries.has(key)) {
      const oldest = this.order.shift();
      if (oldest) this.entries.delete(oldest);
    }
    if (!this.entries.has(key)) this.order.push(key);
    this.entries.set(key, entry);
  }
}


export function pushTableRegions(index, table) {
  index.regions.push(...tableRegions(table));
}

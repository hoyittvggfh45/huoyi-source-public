

import { Readable } from 'node:stream';
import { Agent, ProxyAgent, request as undiciRequest, EnvHttpProxyAgent } from 'undici';

export const mediaUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36';
export const legacyUserAgent = 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36';

const BROWSER_HEADERS = {
  'sec-ch-ua': '"Chromium";v="150", "Google Chrome";v="150", "Not_A Brand";v="24"',
  'sec-ch-ua-mobile': '?0',
  'sec-ch-ua-platform': '"Android"',
  'upgrade-insecure-requests': '1',
  'user-agent': legacyUserAgent,
  'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
  'sec-fetch-site': 'same-origin',
  'sec-fetch-mode': 'navigate',
  'sec-fetch-user': '?1',
  'sec-fetch-dest': 'document',
  'accept-language': 'zh-CN,zh;q=0.9',
};
const BROWSER_HEADER_ORDER = ['sec-ch-ua', 'sec-ch-ua-mobile', 'sec-ch-ua-platform', 'upgrade-insecure-requests', 'user-agent', 'accept', 'sec-fetch-site', 'sec-fetch-mode', 'sec-fetch-user', 'sec-fetch-dest', 'referer', 'accept-encoding', 'accept-language', 'cookie'];

let proxyAgent = null;
function getProxyAgent() {
  if (proxyAgent) return proxyAgent;
  const p = process.env.HTTPS_PROXY || process.env.https_proxy || process.env.HTTP_PROXY || process.env.http_proxy;
  if (p) {
    proxyAgent = new EnvHttpProxyAgent();
  }
  return proxyAgent;
}



import { spawnSync } from 'node:child_process';
let sysProxyCache = { addr: null, at: 0 };
function normalizeProxyAddr(raw) {
  raw = String(raw || '').trim();
  if (!raw) return '';
  raw = raw.replace(/^https?:\/\//, '');
  const cut = raw.search(/[/;]/);
  if (cut >= 0) raw = raw.slice(0, cut);
  if (!/^[a-zA-Z0-9.\-]+:\d+$/.test(raw)) return '';
  return raw;
}
function readWindowsRegistryProxy() {
  try {
    const out = spawnSync(
      'reg',
      ['query', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings', '/v', 'ProxyEnable'],
      { encoding: 'utf8', timeout: 3000 },
    );
    if (out.status !== 0 || !/0x1/.test(out.stdout || '')) return '';
    const out2 = spawnSync(
      'reg',
      ['query', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings', '/v', 'ProxyServer'],
      { encoding: 'utf8', timeout: 3000 },
    );
    if (out2.status !== 0) return '';
    const m = /ProxyServer\s+REG_SZ\s+(.+)/.exec(out2.stdout || '');
    if (!m) return '';
    const server = m[1].trim();
    if (server.includes('=')) {
      for (const want of ['https', 'http']) {
        for (const part of server.split(';')) {
          const kv = part.trim().split('=', 2);
          if (kv.length === 2 && kv[0].toLowerCase() === want) return kv[1];
        }
      }
      return '';
    }
    return server;
  } catch {
    return '';
  }
}
function systemProxyAddr() {
  if (Date.now() - sysProxyCache.at < 30000) return sysProxyCache.addr;
  let addr = normalizeProxyAddr(
    process.env.ALL_PROXY || process.env.all_proxy || process.env.HTTPS_PROXY || process.env.https_proxy
      || process.env.HTTP_PROXY || process.env.http_proxy || '',
  );
  if (!addr) addr = normalizeProxyAddr(readWindowsRegistryProxy());
  sysProxyCache = { addr, at: Date.now() };
  return addr;
}
let fallbackProxyAgent = null;
let fallbackProxyFor = '';
function getFallbackProxyAgent() {
  const addr = systemProxyAddr();
  if (!addr) return null;
  if (!fallbackProxyAgent || fallbackProxyFor !== addr) {
    fallbackProxyAgent = new ProxyAgent(`http://${addr}`);
    fallbackProxyFor = addr;
  }
  return fallbackProxyAgent;
}

let tlsAvailable = null; 
let moduleClient = null;

async function ensureTLSModule() {
  if (tlsAvailable !== null) return tlsAvailable;
  try {
    const mod = await import('tlsclientwrapper');
    moduleClient = new mod.ModuleClient();
    
    const probe = new mod.SessionClient(moduleClient, { timeout: 15000, clientIdentifier: 'chrome_131' });
    await probe.get('https://www.baidu.com/').catch(() => {});
    try { await probe.destroySession(); } catch {}
    tlsAvailable = true;
  } catch (err) {
    console.warn('[client] tls-client 不可用, 回退 undici:', err.message);
    tlsAvailable = false;
  }
  return tlsAvailable;
}


function wrapTLSResponse(r) {
  const headers = {};
  const raw = r.headers || {};
  if (typeof raw.forEach === 'function') {
    raw.forEach((v, k) => { headers[String(k).toLowerCase()] = Array.isArray(v) ? v.join(', ') : String(v); });
  } else {
    for (const k of Object.keys(raw)) headers[k.toLowerCase()] = Array.isArray(raw[k]) ? raw[k].join(', ') : String(raw[k]);
  }
  
  
  let buf;
  if (r.body && Buffer.isBuffer(r.body)) buf = r.body;
  else if (typeof r.body === 'string' && r.bodyIsBase64) {
    let s = r.body;
    const i = s.indexOf(';base64,');
    if (i >= 0) s = s.slice(i + 8);
    buf = Buffer.from(s, 'base64');
  } else buf = Buffer.from(r.body || '', 'utf8');
  const stream = Readable.from(buf);
  return { status: r.status, headers, stream, buffer: async () => buf, contentLength: buf.length };
}

function wrapUndiciResponse(resp) {
  const headers = {};
  for (const [k, v] of Object.entries(resp.headers)) headers[k.toLowerCase()] = Array.isArray(v) ? v.join(', ') : String(v);
  
  const stream = resp.body && typeof resp.body.pipe === 'function'
    ? resp.body
    : Readable.from([]);
  return {
    status: resp.statusCode,
    headers,
    stream,
    buffer: async () => Buffer.from(await resp.body.arrayBuffer()),
    contentLength: Number(resp.headers['content-length'] || 0) || null,
  };
}

export class BrowserClient {
  constructor(opts = {}) {
    this.profile = opts.profile || 'chrome_131';
    this.referers = new Map();
    this.mediaGuard = opts.mediaGuard || null; 
    this.timeoutMs = opts.timeoutMs || 45000;
    this.tlsReady = ensureTLSModule();
  }

  setReferer(host, referer) {
    if (!host || !referer) return;
    this.referers.set(host.toLowerCase().replace(/^www\./, ''), referer);
  }

  getReferer(rawURL) {
    try {
      const host = new URL(rawURL).host;
      if (!host) return '';
      return this.referers.get(host.toLowerCase().replace(/^www\./, '')) || '';
    } catch {
      return '';
    }
  }

  
  buildHeaders(userHeaders = {}, media = false, requestHost = '') {
    const incoming = {};
    for (const [k, v] of Object.entries(userHeaders || {})) incoming[k.toLowerCase()] = v;
    if (media) {
      const headers = {
        accept: '*/*',
        'accept-language': 'zh-CN,zh;q=0.9',
        'user-agent': incoming['user-agent'] || mediaUserAgent,
      };
      for (const [k, v] of Object.entries(incoming)) {
        if (['host', 'connection', 'user-agent', 'accept', 'accept-language'].includes(k)) continue;
        headers[k] = v;
      }
      return headers;
    }
    const headers = { ...BROWSER_HEADERS };
    for (const [k, v] of Object.entries(incoming)) {
      if (k in headers || k === 'host' || k === 'connection') continue;
      headers[k] = v;
    }
    const referer = incoming.referer || '';
    let refHost = '';
    try { refHost = referer ? new URL(referer).host : ''; } catch {}
    if (!referer) headers['sec-fetch-site'] = 'none';
    else if (refHost && requestHost && refHost.toLowerCase() !== requestHost.toLowerCase()) headers['sec-fetch-site'] = 'cross-site';
    return headers;
  }

  
  async do(method, url, headers = {}, opts = {}) {
    const media = !!opts.media;
    
    let currentURL = url;
    let currentMethod = method;
    let currentBody = opts.body;
    for (let hop = 0; hop < 10; hop++) {
      const resp = await this.doOnce(currentMethod, currentURL, headers, { ...opts, body: currentBody });
      const loc = resp.headers.location;
      const status = resp.status;
      if (loc && [301, 302, 303, 307, 308].includes(status)) {
        
        try { await resp.buffer(); } catch {}
        let next;
        try { next = new URL(loc, currentURL).toString(); } catch { return resp; }
        if (status === 303 && currentMethod !== 'GET' && currentMethod !== 'HEAD') {
          currentMethod = 'GET';
          currentBody = undefined;
        } else if (status !== 307 && status !== 308) {
          
          if (currentMethod === 'POST') { currentMethod = 'GET'; currentBody = undefined; }
        }
        currentURL = next;
        continue;
      }
      return resp;
    }
    return this.doOnce(currentMethod, currentURL, headers, { ...opts, body: currentBody });
  }

  async doOnce(method, url, headers = {}, opts = {}) {
    const media = !!opts.media;
    const useTLS = await this.tlsReady;
    let requestHost = '';
    try { requestHost = new URL(url).host; } catch {}
    const reqHeaders = opts.noBrowserHeaders
      ? Object.fromEntries(Object.entries(headers).map(([k, v]) => [k.toLowerCase(), v]))
      : this.buildHeaders(headers, media, requestHost);

    if (useTLS && moduleClient) {
      const SessionCtor = (await import('tlsclientwrapper')).SessionClient;
      const sessionOpts = {
        clientIdentifier: this.profile,
        timeout: opts.timeoutMs || this.timeoutMs,
        withRandomTLSExtensionOrder: true,
        withoutCookieJar: !!opts.withoutCookieJar,
        headerOrder: opts.headerOrder || BROWSER_HEADER_ORDER,
      };
      const tlsOpts = {
        ...sessionOpts,
        headers: reqHeaders,
        forceHttp1: !!opts.forceHttp1,
        
        
        isByteResponse: true,
      };
      if (opts.body !== undefined && opts.body !== null) tlsOpts.requestBody = opts.body;
      
      const tlsRequest = (session) => session.request({ ...tlsOpts, requestUrl: url, requestMethod: method.toUpperCase() });
        const attempt = async (extra) => {
          const session = new SessionCtor(moduleClient, { ...sessionOpts, ...extra });
          try {
            const resp = await tlsRequest(session);
            
            if (resp && resp.status > 0) {
              resp.bodyIsBase64 = true; 
              return wrapTLSResponse(resp);
            }
          } catch {}
          finally {
            try { await session.destroySession(); } catch {}
          }
          return null;
        };
      
      const direct = await attempt({});
      
      
      const ANTI_BOT = new Set([400, 403, 406, 412, 429, 451, 503]);
      if (direct && !ANTI_BOT.has(direct.status)) return direct;
      
      const sysProxy = systemProxyAddr();
      if (sysProxy) {
        const viaProxy = await attempt({ proxyUrl: `http://${sysProxy}` });
        if (viaProxy && !ANTI_BOT.has(viaProxy.status)) return viaProxy;
        if (viaProxy) {
          
          try {
            const undiciResp = await undiciRequest(url, {
              method: method.toUpperCase(),
              headers: { ...reqHeaders, host: new URL(url).host },
              body: opts.body || undefined,
              headersTimeout: opts.timeoutMs || this.timeoutMs,
              bodyTimeout: opts.timeoutMs || this.timeoutMs,
              dispatcher: getProxyAgent() || new Agent({ connect: { rejectUnauthorized: false } }),
            });
            if (undiciResp.statusCode < 400) return wrapUndiciResponse(undiciResp);
          } catch {}
          return viaProxy;
        }
      }
      if (direct) return direct;
    }

    const agent = getProxyAgent() || new Agent({ connect: { rejectUnauthorized: false } });
    let resp;
    try {
      resp = await undiciRequest(url, {
        method: method.toUpperCase(),
        headers: { ...reqHeaders, host: new URL(url).host },
        body: opts.body || undefined,
        headersTimeout: opts.timeoutMs || this.timeoutMs,
        bodyTimeout: opts.timeoutMs || this.timeoutMs,
        dispatcher: agent,
      });
    } catch (err) {
      
      const pAgent = getFallbackProxyAgent();
      if (!pAgent) throw err;
      resp = await undiciRequest(url, {
        method: method.toUpperCase(),
        headers: { ...reqHeaders, host: new URL(url).host },
        body: opts.body || undefined,
        headersTimeout: opts.timeoutMs || this.timeoutMs,
        bodyTimeout: opts.timeoutMs || this.timeoutMs,
        dispatcher: pAgent,
      });
    }
    return wrapUndiciResponse(resp);
  }

  
  async doCustom(method, url, body, headers = {}) {
    return this.do(method, url, headers, { body, noBrowserHeaders: true, withoutCookieJar: true });
  }

  async fetchWith(url, referer, media, cookie, ua) {
    if (referer === '-') referer = '';
    else if (!referer) referer = this.getReferer(url);
    const headers = {};
    if (referer) headers.Referer = referer;
    if (cookie) headers.Cookie = cookie;
    if (ua) headers['User-Agent'] = ua;
    const resp = await this.do('GET', url, headers, { media });
    if (resp.status >= 400) {
      resp.stream.destroy?.();
      const err = new Error(`HTTP ${resp.status}: ${url}`);
      err.status = resp.status;
      throw err;
    }
    try { this.setReferer(new URL(url).host, url); } catch {}
    return resp;
  }

  async fetchBytes(url, referer) {
    return this.fetchWith(url, referer, false, '', '');
  }

  async fetchMediaBytes(url, referer, cookie) {
    return this.fetchWith(url, referer, true, cookie, '');
  }

  async fetchMediaBytesUA(url, referer, cookie, ua) {
    return this.fetchWith(url, referer, true, cookie, ua);
  }

  
  async fetchWithHeaders(method, url, headers = {}, body) {
    const h = { ...headers };
    if (!h['User-Agent'] && !h['user-agent']) h['User-Agent'] = legacyUserAgent;
    const resp = await this.doCustom(method, url, body, h);
    const raw = await resp.buffer();
    return { raw, status: resp.status };
  }

  
  async stream(url, headers = {}, timeoutMs = 120000) {
    return this.do('GET', url, headers, { media: true, timeoutMs });
  }
}


export function newBrowserClient(opts) {
  return new BrowserClient(opts);
}

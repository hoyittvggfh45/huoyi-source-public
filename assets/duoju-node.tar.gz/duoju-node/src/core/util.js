
export function writeJSON(res, payload, status = 200) {
  res.status(status);
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(payload) + '\n');
}

export function apiResponse(code, msg, data) {
  const out = { code, msg };
  if (data !== undefined) out.data = data;
  return out;
}

export function writeAPI(res, data, code = 200) {
  writeJSON(res, { code, data });
}

export function writeError(res, status, msg) {
  res.status(status);
  writeJSON(res, { code: status, msg });
}

export function atoiDefault(s, fallback) {
  if (s === undefined || s === null || s === '') return fallback;
  const n = parseInt(s, 10);
  if (!Number.isFinite(n) || n < 1) return fallback;
  return n;
}

export function cleanText(s) {
  return String(s ?? '').split(/\s+/).filter(Boolean).join(' ');
}

export function firstNonEmpty(...values) {
  for (const v of values) {
    if (v !== undefined && v !== null && String(v).trim() !== '') return v;
  }
  return '';
}


export function mapString(m, ...keys) {
  if (!m) return '';
  for (const key of keys) {
    if (!(key in m)) continue;
    const v = m[key];
    if (v === undefined || v === null) continue;
    if (typeof v === 'string') return v;
    if (typeof v === 'boolean') return v ? 'true' : 'false';
    if (typeof v === 'number') {
      if (Number.isInteger(v)) return String(v);
      return String(v);
    }
    if (typeof v === 'object' && typeof v.toString === 'function') {
      const s = v.toString();
      if (s !== '[object Object]') return s;
    }
  }
  return '';
}


export function anyList(v) {
  if (Array.isArray(v)) return v;
  if (v && typeof v === 'object') {
    for (const key of ['list', 'items', 'data']) {
      const out = anyList(v[key]);
      if (out.length > 0) return out;
    }
  }
  return [];
}

export function nestedMap(m, key) {
  if (!m) return null;
  const v = m[key];
  return v && typeof v === 'object' && !Array.isArray(v) ? v : null;
}

export function resolveURL(pageURL, ref) {
  if (!ref) return '';
  if (ref.startsWith('http://') || ref.startsWith('https://')) return ref;
  try {
    return new URL(ref, pageURL).toString();
  } catch {
    return ref;
  }
}

export function isM3U8(target) {
  const path = String(target || '').split('?')[0].toLowerCase();
  return path.endsWith('.m3u8') || path.endsWith('.m3u');
}

export function parsePlayScheme(raw, prefix) {
  if (!raw || !raw.startsWith(prefix)) return null;
  const rest = raw.slice(prefix.length);
  const idx = rest.indexOf('/');
  if (idx <= 0 || idx === rest.length - 1) return null;
  let id = rest.slice(0, idx);
  let extra = rest.slice(idx + 1);
  try { id = decodeURIComponent(id); } catch {}
  try { extra = decodeURIComponent(extra); } catch {}
  return { id, extra };
}


const KNOWN_PREFIXES = new Set([
  'hongguo', 'huangdou', 'huangguo', 'huangju', 'dj51', 'chengguo', 'huanggua',
  'huangdou2', 'dj91', 'md2048', 'huangguo2', 'huangguoold', 'weiguan',
  'hema', 'shanhai', 'haokan', 'baidu', 'xingya', 'xifan', 'xingxing', 'yimi',
  'qimao', 'damang', 'wusheng', 'qixing', 'kuwo', 'niuniu', 'xifu',
  'wuwu', 'souju', 'yizk', 'heiliao', 'bday',
]);

export function splitPrefixedID(id) {
  const i = id.indexOf(':');
  if (i > 0) {
    const head = id.slice(0, i);
    if (KNOWN_PREFIXES.has(head)) return { plat: head, pure: id.slice(i + 1), ok: true };
  }
  return { plat: '', pure: id, ok: false };
}



export function parseRouterData(raw) {
  const m = /(?:window\.)?_ROUTER_DATA\s*=\s*/.exec(raw);
  if (!m) return null;
  const text = extractFirstJSON(raw.slice(m.index + m[0].length));
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}


export function extractFirstJSON(text) {
  const start = text.search(/[{[]/);
  if (start < 0) return null;
  const open = text[start];
  const close = open === '{' ? '}' : ']';
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') inString = true;
    else if (ch === open) depth++;
    else if (ch === close) {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null;
}


export function routerLoaderMap(data, ...names) {
  if (!data) return null;
  const loader = data.loaderData;
  if (!loader || typeof loader !== 'object') return null;
  for (const name of names) {
    const page = loader[name];
    if (page && typeof page === 'object' && Object.keys(page).length > 0) return page;
  }
  for (const key of Object.keys(loader)) {
    for (const name of names) {
      const trimmed = name.endsWith('$') ? name.slice(0, -1) : name;
      if (!trimmed || !key.startsWith(trimmed)) continue;
      const page = loader[key];
      if (page && typeof page === 'object' && Object.keys(page).length > 0) return page;
    }
  }
  return null;
}

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function fnv1a64Hex(input) {
  
  let h = 0xcbf29ce484222325n;
  const prime = 0x100000001b3n;
  const bytes = Buffer.from(String(input), 'utf8');
  for (const b of bytes) {
    h ^= BigInt(b);
    h = (h * prime) & 0xffffffffffffffffn;
  }
  return h.toString(16);
}

export function btoaUrl(buf) {
  return Buffer.from(buf).toString('base64url');
}

export function decodeBase64Strict(value) {
  
  const s = String(value ?? '').trim();
  if (/^[A-Za-z0-9+/]+={0,2}$/.test(s)) {
    return Buffer.from(s, 'base64');
  }
  return Buffer.from(s.replace(/=+$/, ''), 'base64');
}

export function encodeQuery(obj) {
  
  const keys = Object.keys(obj).sort();
  const parts = [];
  for (const k of keys) {
    const vals = Array.isArray(obj[k]) ? obj[k] : [obj[k]];
    for (const v of vals) parts.push(`${encodeURIComponent(k)}=${encodeURIComponent(v)}`);
  }
  return parts.join('&');
}

export function randomHex(n) {
  const bytes = require('node:crypto').randomBytes(n);
  return bytes.toString('hex');
}

export function nowMillis() {
  return Date.now();
}

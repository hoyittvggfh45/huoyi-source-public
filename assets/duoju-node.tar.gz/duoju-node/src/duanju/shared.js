
import { createDecipheriv, createCipheriv } from 'node:crypto';
import { huangguoAIImgKey, huangguoAIImgIV, legacyCoverXORKey } from './consts.js';

export const huangjuNewestCat = '@new';
export const legacyUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36';

export function truncate(s, n) {
  s = String(s ?? '');
  if (s.length <= n) return s;
  return s.slice(0, n) + '...';
}

export function aesCBCDecrypt(cipherText, key, iv) {
  if (cipherText.length === 0 || cipherText.length % 16 !== 0) throw new Error('黄豆密文不是块对齐的');
  const d = createDecipheriv(`aes-${key.length * 8}-cbc`, key, iv);
  
  d.setAutoPadding(false);
  const out = Buffer.concat([d.update(cipherText), d.final()]);
  return pkcs7Unpad(out, 16);
}

export function aesCBCEncrypt(plain, key, iv) {
  const c = createCipheriv(`aes-${key.length * 8}-cbc`, key, iv);
  
  c.setAutoPadding(false);
  return Buffer.concat([c.update(pkcs7Pad(plain, 16)), c.final()]);
}

export function pkcs7Pad(src, blockSize) {
  const pad = blockSize - (src.length % blockSize);
  const out = Buffer.alloc(src.length + pad);
  src.copy(out);
  out.fill(pad, src.length);
  return out;
}

export function pkcs7Unpad(src, blockSize) {
  if (src.length === 0 || src.length % blockSize !== 0) throw new Error('黄豆解密结果无效');
  const pad = src[src.length - 1];
  if (pad <= 0 || pad > blockSize || pad > src.length) throw new Error('黄豆解密结果无效');
  for (let i = src.length - pad; i < src.length; i++) {
    if (src[i] !== pad) throw new Error('黄豆解密结果无效');
  }
  return src.subarray(0, src.length - pad);
}

export function stripTagsSimple(s) {
  return String(s ?? '').replace(/<[^>]*>/gs, '');
}

export function isPlainImage(b) {
  return (
    (b[0] === 0xff && b[1] === 0xd8) ||
    b.subarray(0, 8).toString('latin1') === '\x89PNG\r\n\x1a\n' ||
    (b.subarray(0, 4).toString('latin1') === 'RIFF' && b.length >= 12 && b.subarray(8, 12).toString('latin1') === 'WEBP') ||
    b.subarray(0, 6).toString('latin1') === 'GIF87a' ||
    b.subarray(0, 6).toString('latin1') === 'GIF89a'
  );
}

function decryptHuangguoImageAES(raw) {
  if (raw.length === 0 || raw.length % 16 !== 0) return null;
  try {
    
    const d = createDecipheriv('aes-128-cbc', huangguoAIImgKey, huangguoAIImgIV);
    d.setAutoPadding(false);
    let plain = Buffer.concat([d.update(raw), d.final()]);
    if (!isPlainImage(plain)) return null;
    let out = plain;
    const pad = plain[plain.length - 1];
    if (pad > 0 && pad <= 16 && pad <= plain.length) {
      let same = true;
      for (let i = plain.length - pad; i < plain.length; i++) {
        if (plain[i] !== pad) { same = false; break; }
      }
      if (same) out = plain.subarray(0, plain.length - pad);
    }
    if (out[0] === 0xff && out[1] === 0xd8) {
      const i = out.lastIndexOf(Buffer.from([0xff, 0xd9]));
      if (i >= 0) out = out.subarray(0, i + 2);
    } else if (out.subarray(0, 8).toString('latin1') === '\x89PNG\r\n\x1a\n') {
      const i = out.lastIndexOf('IEND');
      if (i >= 0) out = out.subarray(0, i + 8);
    }
    return out;
  } catch {
    return null;
  }
}

function decryptLegacyCoverXOR(raw) {
  if (raw.length === 0) return null;
  const plain = Buffer.from(raw);
  const limit = Math.min(plain.length, legacyCoverXORKey.length * 10);
  for (let i = 0; i < limit; i++) {
    plain[i] ^= legacyCoverXORKey.charCodeAt(i % legacyCoverXORKey.length);
  }
  if (!isPlainImage(plain)) return null;
  return plain;
}

export function decryptHuangguoImage(raw) {
  const a = decryptHuangguoImageAES(raw);
  if (a) return a;
  const b = decryptLegacyCoverXOR(raw);
  if (b) return b;
  return raw;
}


import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { writeJSON, writeError, writeAPI, atoiDefault, splitPrefixedID, isM3U8 } from '../core/util.js';
import { MediaProxy } from '../core/media.js';
import { PlatformRouter, teenEnabled, teenBlocked, teenPlaceholderPlay, isTeenPlayURL, playSchemePlatforms, platNameForTag, prefixCardIDs, inferPlatform, defaultCat, teenPlaceholderID, teenPlaceholderVideo } from './router.js';
import { registerWebRoutes, teenPlaceholderDetail, teenPlaceholderList, detailOf } from './web.js';
import { getRegisterProviders } from './providers/index.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const AppVersion = '1.4.58';


let dataDir = path.join(process.cwd(), 'jdd-data');
export function setDataDir(dir) { dataDir = dir; }
export function getDataDir() { return dataDir; }

export class DuanjuServer {
  constructor(client) {
    this.client = client;
    this.media = new MediaProxy(client);
    this.router = new PlatformRouter(client, this.media, getRegisterProviders());
    this.imageCache = new Map(); 
    this.detailCache = new Map();
    this.app = express();
    this.app.disable('x-powered-by');
    this.setupRoutes();
  }

  setupRoutes() {
    const app = this.app;
    const s = this;

    app.get('/', (req, res) => {
      const accept = String(req.headers.accept || '').toLowerCase();
      if (accept.includes('text/html')) return s.serveIndex(req, res);
      writeJSON(res, {
        code: 200, msg: 'duoju-lite ok',
        data: {
          name: '短剧库精简后台',
          port: s.port || 0,
          api: ['/api/platform', '/api/home', '/api/category', '/api/search', '/api/detail', '/api/play', '/media', '/api/dns'],
          web: '/web/',
        },
      });
    });

    
    const rootAssetExt = {
      '.js': 'application/javascript; charset=utf-8',
      '.css': 'text/css; charset=utf-8',
      '.svg': 'image/svg+xml',
      '.ico': 'image/x-icon',
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.webp': 'image/webp',
      '.json': 'application/json; charset=utf-8',
      '.map': 'application/json; charset=utf-8',
    };
    const webRoot = path.join(__dirname, '../../web/duanju');
    app.get(/^\/(?!api\/|media|internal\/|web\/).+$/, (req, res) => {
      const name = req.path.replace(/^\//, '');
      if (!name || name.includes('..')) return s.notFound(res);
      const ext = path.extname(name).toLowerCase();
      const ct = rootAssetExt[ext];
      if (!ct) return s.notFound(res);
      try {
        const data = fs.readFileSync(path.join(webRoot, name));
        res.setHeader('Content-Type', ct);
        res.setHeader('Cache-Control', 'public, max-age=600');
        res.send(data);
      } catch {
        s.notFound(res);
      }
    });

    app.get('/api/platform', (req, res) => {
      const teen = teenEnabled();
      const plats = s.router.Platforms().map((p) => ({ ...p }));
      plats.sort((a, b) => {
        if (teen) {
          const ta = teenPlatformRank(a.key), tb = teenPlatformRank(b.key);
          if (ta !== tb) return ta - tb;
        }
        return 0;
      });
      writeAPI(res, { platforms: plats });
    });

    app.get('/api/cats', async (req, res) => {
      const plat = String(req.query.plat || '').trim();
      if (!plat) return writeError(res, 400, '缺少 plat');
      if (teenBlocked(plat)) {
        return writeJSON(res, { code: 200, data: { plat, cats: [], teen: true } });
      }
      const prov = s.router.provider(plat);
      if (!prov || typeof prov.categories !== 'function') {
        return writeError(res, 400, '该平台无动态分类接口');
      }
      try {
        const cats = await withTimeout(prov.categories(), 45000);
        writeAPI(res, { plat, cats });
      } catch (err) {
        writeError(res, 502, '抓取分类失败: ' + err.message);
      }
    });

    app.get('/api/dns', (req, res) => {
      writeAPI(res, { summary: 'smart-dns(默认系统解析)' });
    });

    const handleList = async (req, res) => {
      let plat = String(req.query.plat || '').trim();
      let cat = String(req.query.cat || '').trim();
      const page = atoiDefault(req.query.page, 1);
      if (cat === '' || cat === 'undefined') cat = defaultCat(plat);
      if (plat === '') plat = 'huangguo';
      const prov = s.router.provider(plat);
      if (!prov) return writeError(res, 400, '未知平台: ' + plat);
      if (teenBlocked(plat)) {
        return writeJSON(res, { code: 200, data: { plat, category: cat, page, list: teenPlaceholderList(plat), teen: true } });
      }
      try {
        const cards = await withTimeout(prov.List(cat, page), 45000);
        prefixCardIDs(plat, cards);
        writeAPI(res, { plat, category: cat, page, list: cards });
      } catch (err) {
        writeError(res, 502, '抓取列表失败: ' + err.message);
      }
    };
    app.get('/api/home', handleList);
    app.get('/api/category', handleList);

    app.get('/api/search', async (req, res) => {
      let wd = String(req.query.wd || '').trim() || String(req.query.q || '').trim();
      if (!wd) return writeError(res, 400, '缺少搜索词 wd');
      const page = atoiDefault(req.query.page, 1);
      const plat = String(req.query.plat || '').trim();
      if (plat && teenBlocked(plat)) {
        return writeJSON(res, { code: 200, data: { wd, page, plat, list: teenPlaceholderList(plat), teen: true } });
      }
      const { cards, err } = await s.searchWithFallback(wd, page, teenEnabled());
      if (cards.length > 0) {
        return writeAPI(res, { wd, page, plat, list: cards });
      }
      if (err) return writeError(res, 502, '搜索失败: ' + err.message);
      writeAPI(res, { wd, page, plat, list: cards });
    });

    app.get('/api/detail', async (req, res) => {
      let id = String(req.query.id || '').trim();
      if (!id) return writeError(res, 400, '缺少 id');
      let plat = String(req.query.plat || '').trim();
      const sp = splitPrefixedID(id);
      if (sp.ok) {
        plat = sp.plat;
        id = sp.pure;
      } else if (!plat) {
        plat = inferPlatform(id);
      }
      const prov = s.router.provider(plat);
      if (!prov) return writeError(res, 400, '未知平台: ' + plat);
      if (teenBlocked(plat)) {
        return writeJSON(res, { code: 200, data: teenPlaceholderDetail(id, plat) });
      }
      try {
        const detail = await withTimeout(prov.Detail(id), 45000);
        detail.vod_class = detail.vod_class || platNameForTag(plat);
        writeAPI(res, detail);
      } catch (err) {
        writeError(res, 502, '抓取详情失败: ' + err.message);
      }
    });

    app.get('/api/play', async (req, res) => {
      let playURL = String(req.query.url || '').trim();
      if (!playURL) return writeError(res, 400, '缺少 url');
      let plat = String(req.query.plat || '').trim();
      if (isTeenPlayURL(playURL)) {
        return writeJSON(res, { code: 200, data: teenPlaceholderPlay() });
      }
      if (!plat) {
        for (const [prefix, key] of Object.entries(playSchemePlatforms)) {
          if (playURL.startsWith(prefix)) { plat = key; break; }
        }
        if (!plat) plat = 'huangguo';
      }
      if (teenBlocked(plat)) {
        return writeJSON(res, { code: 200, data: teenPlaceholderPlay() });
      }
      const prov = s.router.provider(plat);
      if (!prov) return writeError(res, 400, '未知平台: ' + plat);
      if (plat === 'huangguo' && !playURL.includes('://')) {
        playURL = prov.baseURLFor ? prov.baseURLFor(playURL) : playURL;
      }
      let result;
      try {
        result = await withTimeout(prov.Play(playURL), 45000);
      } catch (err) {
        return writeError(res, 502, '解析播放地址失败: ' + err.message);
      }
      const mediaURL = result.src;
      const referer = result.referer || '';
      const cookie = result.cookie || '';
      let proxy;
      const mp = this.media.forRequest(req);
      if (result.key && !isM3U8(mediaURL)) {
        proxy = result.m3u8 ? mp.cencM3U8ProxyURL(mediaURL, referer, cookie, result.key) : mp.cencProxyURL(mediaURL, referer, cookie, result.key);
      } else if (mediaURL.startsWith('/')) {
        
        proxy = mediaURL;
      } else {
        proxy = mp.proxyURLUA(mediaURL, referer, cookie, result.userAgent || '');
      }
      writeAPI(res, { src: mediaURL, url: proxy, referer, cookie });
    });

    const handleMedia = async (req, res) => {
      const q = req.query;
      if (q.dec === 'key') {
        let payload;
        try {
          payload = Buffer.from(String(q.k || '').trim(), 'base64url');
        } catch {}
        if (!payload || payload.length === 0) return httpPlainError(res, 400, '密钥参数无效');
        res.setHeader('Content-Type', 'application/octet-stream');
        res.setHeader('Content-Length', String(payload.length));
        res.setHeader('Cache-Control', 'no-store');
        res.setHeader('Access-Control-Allow-Origin', '*');
        return res.send(payload);
      }
      let target = String(q.url || '').trim() || String(q.u || '').trim();
      if (!target) return httpPlainError(res, 400, '缺少 url');
      let referer = String(q.ref || '').trim();
      if (!referer) referer = s.client.getReferer(target);
      const cookie = String(q.ck || '').trim();
      const mediaUA = String(q.ua || '').trim();

      if (q.dec === 'cenc') {
        const mp = s.media.forRequest(req);
        if (q.m3u8 === '1') return mp.serveCENCM3U8(req, res, target, referer, cookie, String(q.key || '').trim());
        return mp.serveCENC(req, res, target, referer, cookie, String(q.key || '').trim());
      }
      if (q.dec === 'img') {
        return s.serveImage(req, res, target, referer, cookie);
      }
      if (!isM3U8(target)) {
        return s.streamMedia(req, res, target, referer, cookie, mediaUA);
      }
      const { code, phase, body, headers, error } = await s.media.forRequest(req).Handle(target, referer, cookie, mediaUA);
      if (error) return httpPlainError(res, code || 502, '媒体代理失败: ' + error.message);
      for (const [k, v] of Object.entries(headers)) res.setHeader(k, v);
      res.setHeader('X-Media-Phase', phase);
      res.status(code || 200).send(body);
    };
    app.get('/media', handleMedia);
    app.get('/media/playlist.m3u8', handleMedia);
    app.get('/media/*', handleMedia);

    app.get('/internal/trim', (req, res) => {
      s.trimCaches();
      console.error(`[mem] 系统内存紧张(level=${req.query.level || ''})：已清空缓存并归还内存`);
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.send('{"ok":true}');
    });

    app.get('/internal/hello', (req, res) => {
      writeJSON(res, { app: 'duoju-lite', version: AppVersion, port: s.port || 0, pid: process.pid, ok: true });
    });

    
    registerWebRoutes(app, s, webRoot);
  }

  notFound(res) {
    writeError(res, 404, 'not found');
  }

  trimCaches() {
    this.imageCache.clear();
    this.detailCache.clear();
  }

  async searchWithFallback(wd, page, teen) {
    const targets = this.router.Platforms().filter((p) => this.router.provider(p.key) && (!teen || isTeenPlatformKey(p.key)));
    const searchPlatformTimeout = 10000;
    const searchAggregateWindow = 7000;
    const results = await Promise.allSettled(
      targets.map(async (p) => {
        const prov = this.router.provider(p.key);
        const cards = await withTimeout(prov.Search(wd, page), searchPlatformTimeout);
        if (cards && cards.length > 0) prefixCardIDs(p.key, cards);
        return cards;
      })
    );
    let firstErr = null;
    const merged = [];
    for (let i = 0; i < targets.length; i++) {
      const r = results[i];
      if (r.status === 'fulfilled') {
        merged.push(...r.value);
      } else if (!firstErr) {
        firstErr = new Error(`${targets[i].name}: ${r.reason?.message || r.reason}`);
      }
    }
    if (merged.length === 0 && !firstErr) firstErr = new Error('所有平台均无结果');
    return { cards: merged, err: firstErr };
  }

  async serveImage(req, res, target, referer, cookie) {
    const etag = `"${imageTag(target)}"`;
    res.setHeader('ETag', etag);
    if (req.headers['if-none-match'] === etag) {
      res.status(304).end();
      return;
    }
    const cached = this.imageCache.get(target);
    if (cached) return writeImageBytes(res, cached.body, cached.ctype);
    try {
      const resp = await this.client.fetchMediaBytes(target, referer, cookie);
      const body = await resp.buffer();
      const plain = decryptHuangguoImage(body);
      const ctype = imageContentType(plain);
      this.imageCache.set(target, { body: plain, ctype, at: Date.now() });
      writeImageBytes(res, plain, ctype);
    } catch (err) {
      httpPlainError(res, 502, '图片代理失败: ' + err.message);
    }
  }

  async streamMedia(req, res, target, referer, cookie, ua) {
    const headers = {};
    if (referer && referer !== '-') headers.Referer = referer;
    if (cookie) headers.Cookie = cookie;
    if (ua) headers['User-Agent'] = ua;
    if (req.headers.range) headers.Range = req.headers.range;
    let resp;
    try {
      resp = await this.client.do('GET', target, headers, { media: true, timeoutMs: 120000 });
    } catch (err) {
      return httpPlainError(res, 502, '媒体代理失败: ' + err.message);
    }
    const passHeaders = ['Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges', 'Last-Modified', 'ETag', 'Cache-Control'];
    for (const k of passHeaders) {
      const v = resp.headers[k.toLowerCase()];
      if (v) res.setHeader(k, v);
    }
    if (!res.getHeader('Accept-Ranges')) res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.status(resp.status);
    const { pipeline } = await import('node:stream/promises');
    try {
      await pipeline(resp.stream, res);
    } catch {}
  }

  async serveIndex(req, res) {
    const webRoot = path.join(__dirname, '../../web/duanju');
    try {
      const data = fs.readFileSync(path.join(webRoot, 'index.html'));
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache');
      res.send(data);
    } catch {
      writeError(res, 500, '前端资源缺失');
    }
  }
}



const teenRankMap = { hongguo: 0, weiguan: 1, hema: 2, shanhai: 3, haokan: 4, baidu: 5, xingya: 6, qimao: 7, damang: 8, xifan: 9, xingxing: 10, yimi: 11, wusheng: 12, qixing: 13, kuwo: 14, niuniu: 15, xifu: 16, wuwu: 17, souju: 18 };
function teenPlatformRank(key) {
  return key in teenRankMap ? teenRankMap[key] : 99;
}
function isTeenPlatformKey(key) {
  return key in teenRankMap;
}

export function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`请求超时(${ms}ms)`)), ms);
  });
  return Promise.race([Promise.resolve(promise), timeout]).finally(() => clearTimeout(timer));
}

function httpPlainError(res, status, msg) {
  res.status(status).setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.send(msg);
}

function writeImageBytes(res, body, ctype) {
  res.setHeader('Content-Type', ctype);
  res.setHeader('Content-Length', String(body.length));
  res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.send(body);
}

function imageTag(target) {
  let h = 0xcbf29ce484222325n;
  const prime = 0x100000001b3n;
  for (const b of Buffer.from(target, 'utf8')) {
    h ^= BigInt(b);
    h = (h * prime) & 0xffffffffffffffffn;
  }
  return h.toString(16);
}

function decryptHuangguoImage(body) {
  
  try {
    const mod = getRegisterProviders().decryptHuangguoImage;
    if (typeof mod === 'function') return mod(body);
  } catch {}
  return body;
}

export function imageContentType(b) {
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg';
  if (b.length > 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'image/png';
  if (b.length > 12 && b.toString('latin1', 0, 4) === 'RIFF' && b.toString('latin1', 8, 12) === 'WEBP') return 'image/webp';
  if (b.length > 6 && (b.toString('latin1', 0, 3) === 'GIF')) return 'image/gif';
  return 'image/jpeg';
}

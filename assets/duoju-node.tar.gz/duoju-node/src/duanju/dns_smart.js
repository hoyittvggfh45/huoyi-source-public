



import dns from 'node:dns';
import https from 'node:https';
import { publicDNSServers, fallbackDNSQueryTimeout, hasUsableIPv4, filterUsableIPs, ipv4First, isIPv4 } from './netutil.js';



class DnsServerStat {
  constructor() {
    this.okCount = 0;
    this.failCount = 0;
    this.consecutiveFail = 0;
    this.lastOK = 0;
    this.lastFail = 0;
    this.quarantineUntil = 0;
    this.latency = 0;
  }
}

const dnsHealth = { stats: new Map() };

export function dnsRecordResult(server, ok, latencyMs = 0) {
  let st = dnsHealth.stats.get(server);
  if (!st) {
    st = new DnsServerStat();
    dnsHealth.stats.set(server, st);
  }
  const now = Date.now();
  if (ok) {
    st.okCount++;
    st.consecutiveFail = 0;
    st.lastOK = now;
    st.quarantineUntil = 0;
    if (latencyMs > 0) {
      st.latency = st.latency === 0 ? latencyMs : Math.floor((st.latency * 2 + latencyMs) / 3);
    }
    return;
  }
  st.failCount++;
  st.consecutiveFail++;
  st.lastFail = now;
  if (st.consecutiveFail >= 2) {
    let backoff = (1 << Math.min(st.consecutiveFail - 2, 8)) * 20000;
    if (backoff > 300000) backoff = 300000;
    st.quarantineUntil = now + backoff;
  }
}

export function dnsServerAvailable(server) {
  const st = dnsHealth.stats.get(server);
  if (!st) return true;
  return Date.now() > st.quarantineUntil;
}

export function dnsOrderedServers() {
  const now = Date.now();
  const list = [];
  for (const server of publicDNSServers) {
    const st = dnsHealth.stats.get(server);
    if (!st) {
      list.push({ server, usable: true, rate: 0.5, lat: 0 });
      continue;
    }
    const total = st.okCount + st.failCount;
    const rate = total > 0 ? st.okCount / total : 1.0;
    list.push({ server, usable: now > st.quarantineUntil, rate, lat: st.latency });
  }
  list.sort((a, b) => {
    if (a.usable !== b.usable) return a.usable ? -1 : 1;
    if (a.rate !== b.rate) return b.rate - a.rate;
    return a.lat - b.lat;
  });
  return list.map((e) => e.server);
}

export function dnsSwitchSummary() {
  if (dnsHealth.stats.size === 0) return 'dns: 尚无解析统计';
  const parts = [];
  const now = Date.now();
  for (const [server, st] of dnsHealth.stats) {
    const state = now < st.quarantineUntil ? '隔离' : 'ok';
    parts.push(`${server}(${state} ok=${st.okCount} fail=${st.failCount})`);
  }
  parts.sort();
  return 'dns: ' + parts.join(' | ');
}



class HostResolveEntry {
  constructor() {
    this.ips = [];
    this.expiresAt = 0;
    this.viaPublic = false;
    this.goodIP = '';
    this.goodAt = 0;
  }
}

const hostCacheTTL = 5 * 60 * 1000;
const lastGoodIPMaxAge = 24 * 60 * 60 * 1000;

const hostCache = { m: new Map() };

export function hostEntry(host) {
  return hostCache.m.get(host) || null;
}

export function cachedHostIPs(host) {
  const e = hostCache.m.get(host);
  if (!e || e.ips.length === 0 || Date.now() > e.expiresAt) return null;
  return e.ips.slice();
}

export function rememberHostIPs(host, ips, viaPublic) {
  if (!ips || ips.length === 0) return;
  let e = hostCache.m.get(host);
  if (!e) {
    e = new HostResolveEntry();
    hostCache.m.set(host, e);
  }
  e.ips = ips.slice();
  e.expiresAt = Date.now() + hostCacheTTL;
  e.viaPublic = viaPublic;
}

export function rememberGoodIP(host, ip) {
  if (!host || !ip) return;
  let e = hostCache.m.get(host);
  if (!e) {
    e = new HostResolveEntry();
    hostCache.m.set(host, e);
  }
  if (e.goodIP !== ip) {
    e.goodIP = ip;
    e.goodAt = Date.now();
    const rest = e.ips.filter((v) => v !== ip);
    e.ips = [ip, ...rest];
  }
}

export function lastGoodIP(host) {
  const e = hostCache.m.get(host);
  if (!e || !e.goodIP) return '';
  if (Date.now() - e.goodAt > lastGoodIPMaxAge) return '';
  return e.goodIP;
}

export function staleHostIPs(host) {
  const e = hostCache.m.get(host);
  if (!e || e.ips.length === 0) return null;
  if (e.goodAt && Date.now() - e.goodAt > lastGoodIPMaxAge) return null;
  return e.ips.slice();
}



const dohEndpoints = [
  { host: 'dns.alidns.com', ip: '223.5.5.5', path: '/resolve' },
  { host: 'cloudflare-dns.com', ip: '1.1.1.1', path: '/dns-query' },
  { host: 'dns.google', ip: '8.8.8.8', path: '/resolve' },
];

function dohQueryOne(ep, name, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    const started = Date.now();
    const req = https.request({
      host: ep.ip,
      port: 443,
      servername: ep.host,
      method: 'GET',
      path: `${ep.path}?name=${encodeURIComponent(name)}&type=A`,
      headers: { Host: ep.host, Accept: 'application/dns-json' },
      timeout: timeoutMs,
    }, (res) => {
      const chunks = [];
      let total = 0;
      res.on('data', (c) => {
        total += c.length;
        if (total <= 32 << 20) chunks.push(c);
      });
      res.on('end', () => {
        if (res.statusCode !== 200) {
          reject(new Error(`DoH ${ep.host} 返回 ${res.statusCode}`));
          return;
        }
        let reply;
        try {
          reply = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        } catch (err) {
          reject(new Error(`DoH ${ep.host} 返回格式异常`));
          return;
        }
        const ips = [];
        for (const ans of reply && reply.Answer || []) {
          if (ans && (ans.type === 1 || ans.type === '1') && isIPv4(ans.data)) ips.push(ans.data);
        }
        resolve({ ips, latency: Date.now() - started });
      });
      res.on('error', reject);
    });
    req.on('timeout', () => {
      req.destroy(new Error(`DoH ${ep.host} 超时`));
    });
    req.on('error', reject);
    req.end();
  });
}

export async function dohLookupA(name) {
  let lastErr = null;
  for (const ep of dohEndpoints) {
    if (!dnsServerAvailable('doh:' + ep.host)) continue;
    try {
      const { ips, latency } = await dohQueryOne(ep, name);
      dnsRecordResult('doh:' + ep.host, true, latency);
      if (ips.length > 0) return ips;
      lastErr = new Error(`DoH 无 A 记录: ${ep.host}`);
    } catch (err) {
      lastErr = err;
      dnsRecordResult('doh:' + ep.host, false, 0);
    }
  }
  if (!lastErr) lastErr = new Error('DoH 全部不可用');
  throw lastErr;
}



function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`请求超时(${ms}ms)`)), ms);
  });
  return Promise.race([Promise.resolve(promise), timeout]).finally(() => clearTimeout(timer));
}


function systemLookup4(host, timeoutMs = 3000) {
  const r = new dns.Resolver({ timeout: 2000, tries: 2 });
  return new Promise((resolve, reject) => {
    r.resolve4(host, (err, addrs) => {
      try { r.cancel(); } catch {}
      if (err) reject(err);
      else resolve(addrs || []);
    });
  });
}


function lookupViaServer(server, host, timeoutMs = 2500) {
  const ip = String(server).replace(/:\d+$/, '');
  const r = new dns.Resolver({ timeout: fallbackDNSQueryTimeout, tries: 1 });
  try { r.setServers([ip]); } catch (err) { return Promise.reject(err); }
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      try { r.cancel(); } catch {}
      reject(new Error(`DNS ${server} 查询超时`));
    }, timeoutMs);
    r.resolve4(host, (err, addrs) => {
      clearTimeout(timer);
      try { r.cancel(); } catch {}
      if (err) reject(err);
      else resolve(addrs || []);
    });
  });
}

export async function resolveHostSmart(host) {
  const cached = cachedHostIPs(host);
  if (cached) return cached;

  const budget = Date.now() + 12000;
  const expired = () => Date.now() > budget;
  const entry = hostEntry(host);

  if (!entry || !entry.viaPublic) {
    try {
      const addrs = await withTimeout(systemLookup4(host, 3000), Math.min(3000, Math.max(1, budget - Date.now())));
      if (hasUsableIPv4(addrs)) {
        rememberHostIPs(host, addrs, false);
        return addrs;
      }
    } catch {}
  }

  for (const server of dnsOrderedServers()) {
    if (expired()) break;
    const started = Date.now();
    try {
      const addrs = await withTimeout(lookupViaServer(server, host, 2500), Math.min(2500, Math.max(1, budget - Date.now())));
      const latency = Date.now() - started;
      if (hasUsableIPv4(addrs)) {
        dnsRecordResult(server, true, latency);
        rememberHostIPs(host, addrs, true);
        return addrs;
      }
      dnsRecordResult(server, false, 0);
    } catch {
      dnsRecordResult(server, false, 0);
    }
  }

  if (!expired()) {
    try {
      const addrs = await withTimeout(dohLookupA(host), Math.min(6000, Math.max(1, budget - Date.now())));
      if (hasUsableIPv4(addrs)) {
        rememberHostIPs(host, addrs, true);
        return addrs;
      }
    } catch {}
  }

  const stale = staleHostIPs(host);
  if (stale && stale.length > 0) return stale;
  throw new Error(`域名解析失败（系统/公共 DNS 与 DoH 均不可用）: ${host}`);
}


export async function resolveHost(host) {
  return resolveHostSmart(host);
}


export async function dialOrder(host) {
  const out = [];
  const seen = new Set();
  const add = (ips) => {
    for (const ip of ipv4First(filterUsableIPs(ips || []))) {
      if (!seen.has(ip)) {
        seen.add(ip);
        out.push(ip);
      }
    }
  };
  const good = lastGoodIP(host);
  if (good) add([good]);
  const cached = cachedHostIPs(host);
  if (cached) add(cached);
  try {
    add(await resolveHostSmart(host));
  } catch {}
  return out;
}



export const mirrorPickTTL = 10 * 60 * 1000;


export function noSwitch(err) {
  if (!err) return err;
  err.noSwitch = true;
  return err;
}

export function mirrorSwitchable(err) {
  return !!err && !err.noSwitch;
}

export class Mirror {
  constructor(name, hosts, client, probe, ttl = mirrorPickTTL) {
    this.name = name;
    this.hosts = hosts || [];
    this.client = client || null;
    this.probe = probe || null; 
    this.ttl = ttl;
    this.best = this.hosts.length > 0 ? this.hosts[0] : '';
    this.at = 0;
  }

  current() {
    if (this.best) return this.best;
    if (this.hosts.length > 0) return this.hosts[0];
    return '';
  }

  order() {
    const out = [];
    if (this.best) out.push(this.best);
    for (const host of this.hosts) {
      if (host !== this.best) out.push(host);
    }
    return out;
  }

  favorite(host) {
    if (!host) return;
    if (this.best !== host) this.best = host;
    this.at = Date.now();
  }

  invalidate() {
    this.at = 0;
  }

  async ensure() {
    const fresh = this.best !== '' && Date.now() - this.at < this.ttl;
    if (fresh || !this.probe || this.hosts.length === 0) return null;
    let first = null;
    const results = await Promise.all(this.hosts.map(async (host) => {
      try {
        await withTimeout(this.probe(host), 14000);
        return { host, err: null };
      } catch (err) {
        return { host, err };
      }
    }));
    for (const r of results) {
      if (!r.err) {
        this.favorite(r.host);
        return null;
      }
      if (!first) first = r.err;
    }
    return first;
  }

  async run(fn) {
    return withMirror(this, fn);
  }
}

export async function withMirror(m, fn) {
  if (!m || m.hosts.length === 0) throw new Error('镜像池为空');
  try { await m.ensure(); } catch {}
  let last = null;
  for (const host of m.order()) {
    try {
      const value = await fn(host);
      m.favorite(host);
      return value;
    } catch (err) {
      last = err;
      if (!mirrorSwitchable(err)) break;
    }
  }
  m.invalidate();
  if (!last) last = new Error(`${m.name} 无可用镜像`);
  throw last;
}


export function httpStatusSwitch(status, err) {
  if (!err && status >= 200 && status < 300) return null;
  if (status >= 400 && status < 500) return noSwitch(new Error(`站点返回 ${status}`));
  if (err) return err;
  return new Error(`站点返回 ${status}`);
}

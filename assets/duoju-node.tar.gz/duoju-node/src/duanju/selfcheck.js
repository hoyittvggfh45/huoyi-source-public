


import http from 'node:http';
import net from 'node:net';

const selfClientTimeoutMs = 700;


export function probeSelfPort(port) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (v) => {
      if (settled) return;
      settled = true;
      resolve(v);
    };
    let body = '';
    const req = http.request({
      host: '127.0.0.1',
      port: Number(port) || 0,
      path: '/internal/hello',
      method: 'GET',
      timeout: selfClientTimeoutMs,
      
      agent: new http.Agent({ keepAlive: false }),
    }, (res) => {
      if (res.statusCode !== 200) {
        res.resume();
        return done(false);
      }
      res.on('data', (c) => { body += c.toString('utf8'); });
      res.on('end', () => {
        try {
          const got = JSON.parse(body);
          done(!!got && got.app === 'duoju-lite');
        } catch {
          done(false);
        }
      });
      res.on('error', () => done(false));
    });
    req.on('timeout', () => {
      req.destroy();
      done(false);
    });
    req.on('error', () => done(false));
    req.end();
  });
}


export async function portBusy(bind, port) {
  const free = await new Promise((resolve) => {
    const ln = net.createServer();
    ln.once('error', () => resolve(false));
    ln.listen(Number(port) || 0, bind, () => {
      ln.close(() => resolve(true));
    });
  });
  if (free) return { busy: false, who: '' };
  if (await probeSelfPort(port)) return { busy: true, who: 'duoju-lite 服务已在运行' };
  return { busy: true, who: '其它程序' };
}


export async function selfcheck(deps = {}) {
  const bind = deps.bind || '127.0.0.1';
  const port = Number(deps.port) || 0;
  const busyInfo = await portBusy(bind, port);
  const selfHello = port > 0 ? await probeSelfPort(port) : false;
  return {
    bind,
    port,
    busy: busyInfo.busy,
    who: busyInfo.who,
    selfHello,
    ok: busyInfo.busy ? selfHello : true,
  };
}

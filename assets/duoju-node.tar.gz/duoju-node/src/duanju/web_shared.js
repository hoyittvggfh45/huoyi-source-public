
import { mapString, resolveURL } from '../core/util.js';

export const webProviderNumericID = /^[1-9][0-9]{0,17}$/;

export function webProviderInteger(value, maximum) {
  const n = Number.parseInt(String(value ?? ''), 10);
  return Number.isFinite(n) && n >= 0 && n <= maximum ? n : null;
}

export function isProviderHTTPMediaURL(value) {
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    return false;
  }
  if (parsed.username || parsed.password || !parsed.host) return false;
  return parsed.protocol === 'https:' || parsed.protocol === 'http:';
}

export function providerMediaOrigin(address) {
  if (!address) return '';
  try {
    const u = new URL(address);
    let host = u.host.toLowerCase();
    if ((u.protocol === 'https:' && u.port === '443') || (u.protocol === 'http:' && u.port === '80')) {
      host = host.replace(/:(443|80)$/, '');
    }
    return `${u.protocol}//${host}`;
  } catch {
    return '';
  }
}

export function providerCoverAddress(value, pageURL) {
  if (Array.isArray(value)) {
    for (const entry of value) {
      const address = providerCoverAddress(entry, pageURL);
      if (address) return address;
    }
    return '';
  }
  if (value && typeof value === 'object') {
    for (const key of ['url', 'contentUrl', 'thumbnailUrl']) {
      const address = providerCoverAddress(value[key], pageURL);
      if (address) return address;
    }
    return '';
  }
  if (typeof value === 'string') {
    let item = value.trim();
    if (item === '' || item.startsWith('data:') || item.startsWith('javascript:')) return '';
    if (item.startsWith('//')) item = 'https:' + item;
    return resolveURL(pageURL, item);
  }
  return '';
}

export function providerCoverString(v, keys) {
  return mapString(v, ...keys);
}


import * as teenhub from '../teenhub.js';
import { HongguoProvider } from './providers/hongguo.js';
import { firstNonEmpty } from '../core/util.js';

export const greenBuild = false;

export function isTeenPlatform(key) {
  return teenPlatforms[key] === true;
}

export const teenPlatforms = {
  hongguo: true, weiguan: true, hema: true, shanhai: true,
  haokan: true, baidu: true, xingya: true, xifan: true,
  xingxing: true, yimi: true, qimao: true, damang: true,
  wusheng: true, qixing: true, kuwo: true, niuniu: true,
  xifu: true, wuwu: true,
  souju: true,
};

export function teenEnabled() {
  if (greenBuild) return false;
  return teenhub.teenEnabled();
}

export function setTeenEnabled(on) {
  teenhub.setTeen(on);
}

export function teenBlocked(plat) {
  return teenEnabled() && !isTeenPlatform(plat);
}

const teenPlaceholderName = '请先关闭青少年模式';
const teenPlayScheme = 'teen://unlock';
export const teenPlaceholderID = '__teen__';
export const teenPlaceholderVideo = 'https://static.jyshare.com/video/mov_bbb.mp4';

export function isTeenPlayURL(u) {
  return String(u || '').trim().startsWith('teen://');
}

export function teenPlaceholderPlay() {
  return { src: teenPlaceholderVideo, url: teenPlaceholderVideo, teen: true };
}



export const platformCats = {
  hongguo: [
    { id: 'rank-hot', name: '总热播榜' },
    { id: 'rank-real', name: '真人剧榜' },
    { id: 'rank-comic', name: '漫剧榜' },
    { id: 'rank-ai', name: 'AI剧榜' },
    { id: 'real-drama', name: '真人剧' },
    { id: 'comic-drama', name: '漫剧' },
    { id: 'ai-drama', name: 'AI剧' },
  ],
};

export const platformOrder = [
  'hongguo', 'weiguan', 'hema', 'shanhai', 'haokan', 'baidu',
  'xingya', 'qimao', 'damang', 'xifan', 'xingxing', 'yimi',
  'wusheng', 'qixing', 'kuwo', 'niuniu', 'xifu', 'wuwu',
  'huangdou', 'huangdou2', 'huangguo', 'huangguo2', 'huangguoold',
  'huangju', 'dj51', 'chengguo', 'huanggua', 'dj91', 'md2048',
  'souju', 'yizk', 'heiliao', 'bday',
];

export const platformNameMap = {
  hongguo: '红果', huangdou: '黄豆', huangguo: '黄果', dj51: '51短剧', chengguo: '橙果',
  huangju: '黄剧', damang: '大芒', huanggua: '黄瓜', huangdou2: '黄豆2',
  dj91: '91短剧', md2048: '2048短剧', huangguo2: '黄果2', huangguoold: '黄果旧版', weiguan: '围观',
  hema: '河马', shanhai: '山海', haokan: '好看', baidu: '百度', xingya: '星芽', xifan: '西饭',
  xingxing: '星星', yimi: '薏米', qimao: '七猫', wusheng: '悟圣', qixing: '七星', kuwo: '酷我',
  niuniu: '牛牛', xifu: '喜福', wuwu: '五五', souju: '搜剧AI',
  yizk: '一直看', heiliao: '黑料', bday: '不打烊',
};

export function platformName(key) {
  return platformNameMap[key] || key;
}

export function platNameForTag(plat) {
  if (plat === 'damang') return '大芒短剧';
  if (plat === 'qimao') return '七猫短剧';
  return platformNameMap[plat] || plat;
}

export function defaultCat(platform) {
  const map = {
    hongguo: 'real-drama', huangdou: 'all', huangguo: 'updates', dj51: 'rank',
    chengguo: 'yuanchuang', damang: 'aiqing', huanggua: 'recommend',
    huangdou2: 'home', dj91: 'duanju', md2048: 'cat-29', huangguo2: 'all', huangguoold: 'tab-0',
    weiguan: 'all', hema: 'jingxuan', shanhai: 'jingxuan', haokan: 'reboduanju',
    baidu: 'quanbu', xingya: 'juchang', xifan: 'all', xingxing: 'jingxuan', yimi: 'jingxuan',
    qimao: '0', wusheng: '1287', qixing: '1', kuwo: '10', niuniu: '', xifu: '3',
    wuwu: '全部', souju: 'all', yizk: 'all',
    heiliao: 'ysdj', bday: 'swdj',
  };
  let v = map[platform];
  if (v === null) {
    const cats = platformCats[platform];
    v = cats && cats[0] ? cats[0].id : 'all';
  }
  if (v === undefined) v = 'all';
  return v;
}

export const playSchemePlatforms = {
  'hongguo://': 'hongguo', 'huangdou://': 'huangdou', 'huangguo://': 'huangguo', 'dj51://': 'dj51',
  'chengguo://': 'chengguo', 'damang://': 'damang', 'huangju://': 'huangju',
  'huanggua://': 'huanggua', 'huangdou2://': 'huangdou2', 'dj91://': 'dj91', 'md2048://': 'md2048',
  'huangguo2://': 'huangguo2', 'huangguoold://': 'huangguoold', 'weiguan://': 'weiguan', 'hema://': 'hema',
  'shanhai://': 'shanhai', 'haokan://': 'haokan', 'baidu://': 'baidu', 'xingya://': 'xingya',
  'xifan://': 'xifan', 'xingxing://': 'xingxing', 'yimi://': 'yimi', 'qimao://': 'qimao',
  'wusheng://': 'wusheng', 'qixing://': 'qixing', 'kuwo://': 'kuwo',
  'niuniu://': 'niuniu', 'xifu://': 'xifu', 'souju://': 'souju', 'yizk://': 'yizk',
  'heiliao://': 'heiliao', 'bday://': 'bday',
};

export function prefixCardIDs(platform, cards) {
  const plat = platform || 'huangguo';
  for (const card of cards) {
    if (card.vod_id && !card.vod_id.includes(':')) card.vod_id = `${plat}:${card.vod_id}`;
  }
}

export function inferPlatform(id) {
  if (hongguoNumericID.test(id)) return 'hongguo';
  if (id.length >= 16 && /^[0-9a-fA-F]+$/.test(id)) return 'huangdou';
  return 'huangguo';
}

const hongguoNumericID = /^[0-9]{1,32}$/;



export class PlatformRouter {
  constructor(client, media, providersModule) {
    this.client = client;
    this.media = media;
    this.providers = {};
    this.platforms = [];
    if (providersModule) providersModule.registerAll(this, client, media);
    
    if (!this.providers.hongguo) {
      this.providers.hongguo = new HongguoProvider(client);
      if (!this.platforms.find((p) => p.key === 'hongguo')) {
        this.platforms.push({ key: 'hongguo', name: '红果', cats: platformCats.hongguo });
      }
    }
    this.platforms.sort((a, b) => {
      const ia = platformOrder.indexOf(a.key);
      const ib = platformOrder.indexOf(b.key);
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
    if (greenBuild) {
      this.platforms = this.platforms.filter((p) => isTeenPlatform(p.key));
      for (const key of Object.keys(this.providers)) {
        if (!isTeenPlatform(key)) delete this.providers[key];
      }
    }
  }

  provider(key) {
    if (!key) key = 'huangguo';
    return this.providers[key] || null;
  }

  Platforms() {
    return this.platforms;
  }
}

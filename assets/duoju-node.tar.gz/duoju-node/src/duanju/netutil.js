


import net from 'node:net';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);


export const publicDNSServers = [
  '223.5.5.5:53',
  '119.29.29.29:53',
  '8.8.8.8:53',
  '1.1.1.1:53',
];

export const fallbackDNSQueryTimeout = 3000;



export function isIPv4(s) {
  return net.isIPv4(String(s || ''));
}

export function isIPLiteral(s) {
  return net.isIP(String(s || '')) !== 0;
}

function v4ToInt(ip) {
  const parts = String(ip).split('.');
  if (parts.length !== 4) return -1;
  let v = 0;
  for (const p of parts) {
    const n = Number(p);
    if (!Number.isInteger(n) || n < 0 || n > 255) return -1;
    v = v * 256 + n;
  }
  return v;
}

export function isLoopbackIP(ip) {
  if (isIPv4(ip)) {
    const v = v4ToInt(ip);
    return v >>> 24 === 127;
  }
  const low = String(ip).toLowerCase();
  return low === '::1' || low === '[::1]' || low === '0:0:0:0:0:0:0:1';
}

export function isPrivateIP(ip) {
  if (isIPv4(ip)) {
    const v = v4ToInt(ip) >>> 0;
    const a = v >>> 24, b = (v >>> 16) & 0xff;
    return a === 10 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
  }
  const low = String(ip).toLowerCase();
  return low.startsWith('fc') || low.startsWith('fd');
}

export function isLinkLocalIP(ip) {
  if (isIPv4(ip)) {
    const v = v4ToInt(ip) >>> 0;
    return (v >>> 16) === 0xa9fe; 
  }
  const low = String(ip).toLowerCase();
  return low.startsWith('fe80');
}

export function isMulticastIP(ip) {
  if (isIPv4(ip)) {
    const v = v4ToInt(ip) >>> 0;
    return (v >>> 24) >= 224 && (v >>> 24) <= 239;
  }
  const low = String(ip).toLowerCase();
  return low.startsWith('ff');
}

export function isUnspecifiedIP(ip) {
  const s = String(ip || '').replace(/^\[|\]$/g, '');
  return s === '0.0.0.0' || s === '::';
}


export function mediaBlockedIP(ip) {
  if (!ip) return true;
  return isUnspecifiedIP(ip) || isLoopbackIP(ip) || isPrivateIP(ip) ||
    isLinkLocalIP(ip) || isMulticastIP(ip);
}


export function hasUsableIPv4(addrs) {
  if (!Array.isArray(addrs)) return false;
  for (const a of addrs) {
    if (!isIPv4(a)) continue;
    if (isUnspecifiedIP(a) || isLoopbackIP(a) || isMulticastIP(a)) continue;
    return true;
  }
  return false;
}


export function filterUsableIPs(addrs) {
  const out = [];
  for (const a of addrs || []) {
    if (!isIPLiteral(a) || isUnspecifiedIP(a) || isLoopbackIP(a) || isMulticastIP(a)) continue;
    out.push(a);
  }
  return out;
}


export function ipv4First(addrs) {
  const v4 = [];
  const rest = [];
  for (const a of addrs || []) {
    if (isIPv4(a)) v4.push(a);
    else rest.push(a);
  }
  return [...v4, ...rest];
}

export function splitHostPort(addr) {
  const s = String(addr || '');
  const m = /^\[([^\]]+)\]:(\d+)$/.exec(s);
  if (m) return [m[1], m[2]];
  const i = s.lastIndexOf(':');
  if (i <= 0 || i === s.length - 1) return null;
  const host = s.slice(0, i);
  const port = s.slice(i + 1);
  if (!/^\d{1,5}$/.test(port)) return null;
  return [host, port];
}


export function isUsableSystemDNS(address) {
  if (!address) return false;
  const hp = splitHostPort(address);
  if (!hp) return false;
  const [host] = hp;
  if (!isIPLiteral(host)) return false;
  return !isLoopbackIP(host);
}



const proxyCache = { addr: '', at: 0 };

function normalizeProxyAddr(raw) {
  raw = String(raw || '').trim();
  if (!raw) return '';
  raw = raw.replace(/^https?:\/\//i, '');
  const cut = raw.search(/[/;]/);
  if (cut >= 0) raw = raw.slice(0, cut);
  const hp = splitHostPort(raw);
  if (!hp) return '';
  return `${hp[0]}:${hp[1]}`;
}


async function readPlatformProxy() {
  if (process.platform !== 'win32') return '';
  const key = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings';
  try {
    const { stdout } = await execFileAsync('reg', ['query', key, '/v', 'ProxyEnable'], { timeout: 2500, windowsHide: true });
    const m = /ProxyEnable\s+REG_DWORD\s+0x([0-9a-fA-F]+)/.exec(stdout || '');
    if (!m || parseInt(m[1], 16) === 0) return '';
    const { stdout: out2 } = await execFileAsync('reg', ['query', key, '/v', 'ProxyServer'], { timeout: 2500, windowsHide: true });
    const m2 = /ProxyServer\s+REG_SZ\s+(.*)/i.exec(out2 || '');
    if (!m2) return '';
    const server = m2[1].trim();
    if (server.includes('=')) {
      for (const want of ['https', 'http']) {
        for (const part of server.split(';')) {
          const kv = part.trim().split('=');
          if (kv.length === 2 && kv[0].toLowerCase() === want) return kv[1];
        }
      }
      return '';
    }
    return server;
  } catch {
    return '';
  }
}


export async function systemProxyAddr() {
  for (const key of ['HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy', 'ALL_PROXY', 'all_proxy']) {
    const addr = normalizeProxyAddr(process.env[key] || '');
    if (addr) return addr;
  }
  return normalizeProxyAddr(await readPlatformProxy());
}


export async function cachedProxyAddr() {
  const now = Date.now();
  if (!proxyCache.at || now - proxyCache.at > 30000) {
    proxyCache.addr = await systemProxyAddr();
    proxyCache.at = now;
  }
  return proxyCache.addr;
}


export function dialViaSystemProxy(addr, timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    cachedProxyAddr().then((proxyAddr) => {
      if (!proxyAddr) return reject(new Error('系统代理未启用'));
      const target = splitHostPort(addr);
      if (!target) return reject(new Error(`代理目标地址无效: ${addr}`));
      if (target[1] !== '443') return reject(new Error(`非 https 流量不走代理: ${addr}`));
      const ph = splitHostPort(proxyAddr);
      if (!ph) return reject(new Error(`系统代理地址无效: ${proxyAddr}`));
      const sock = net.createConnection({ host: ph[0], port: Number(ph[1]) });
      sock.setTimeout(timeoutMs, () => {
        sock.destroy();
        reject(new Error('代理连接超时'));
      });
      let buf = Buffer.alloc(0);
      const onData = (chunk) => {
        buf = Buffer.concat([buf, chunk]);
        const idx = buf.indexOf('\r\n\r\n');
        if (idx < 0) return;
        sock.removeListener('data', onData);
        sock.setTimeout(0);
        const status = buf.slice(0, buf.indexOf('\r\n')).toString('latin1');
        if (!status.includes(' 200 ')) {
          sock.destroy();
          return reject(new Error(`代理 CONNECT 被拒绝: ${status.trim()}`));
        }
        resolve(sock);
      };
      sock.on('data', onData);
      sock.on('error', (err) => reject(err));
      sock.on('connect', () => {
        sock.write(`CONNECT ${addr} HTTP/1.1\r\nHost: ${addr}\r\n\r\n`);
      });
    }, reject);
  });
}



export function dialSmart(host, port, opts = {}) {
  
  return (async () => {
    const { dialOrder, rememberGoodIP } = await import('./dns_smart.js');
    const timeoutMs = opts.timeoutMs || 5000;
    const candidates = await dialOrder(host);
    let lastErr = null;
    for (const ip of candidates) {
      try {
        const sock = await new Promise((resolve, reject) => {
          const s = net.createConnection({ host: ip, port: Number(port) });
          s.setTimeout(timeoutMs, () => {
            s.destroy();
            reject(new Error(`连接 ${ip}:${port} 超时`));
          });
          s.once('connect', () => {
            s.setTimeout(0);
            resolve(s);
          });
          s.once('error', reject);
        });
        rememberGoodIP(host, ip);
        return sock;
      } catch (err) {
        lastErr = err;
      }
    }
    try {
      return await dialViaSystemProxy(`${host}:${port}`);
    } catch {}
    if (!lastErr) lastErr = new Error(`${host} 无可用连接地址`);
    throw lastErr;
  })();
}


export function mediaDialCandidates(host, candidates) {
  const out = [];
  let blocked = false;
  for (const cand of candidates || []) {
    if (!isIPLiteral(cand)) continue;
    if (mediaBlockedIP(cand)) {
      blocked = true;
      continue;
    }
    out.push(cand);
  }
  return { candidates: out, blocked };
}

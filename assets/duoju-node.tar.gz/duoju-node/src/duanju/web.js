


import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { writeJSON, atoiDefault, firstNonEmpty, splitPrefixedID, isM3U8, encodeQuery, sleep } from '../core/util.js';
import {
  teenEnabled, teenBlocked, isTeenPlatform, setTeenEnabled,
  teenPlaceholderID, teenPlaceholderVideo, platformName,
  prefixCardIDs, inferPlatform, defaultCat, platNameForTag,
} from './router.js';
import { webSeasons } from './season.js';
import { withTimeout, getDataDir } from './index.js';

const teenPlaceholderName = '请先关闭青少年模式';



function contentETag(buf) {
  
  let h = 0xcbf29ce484222325n;
  const prime = 0x100000001b3n;
  for (const b of buf) {
    h ^= BigInt(b);
    h = (h * prime) & 0xffffffffffffffffn;
  }
  return `"${h.toString(16)}"`;
}

function mimeByName(name) {
  if (name.endsWith('.js')) return 'application/javascript; charset=utf-8';
  if (name.endsWith('.css')) return 'text/css; charset=utf-8';
  if (name.endsWith('.html')) return 'text/html; charset=utf-8';
  if (name.endsWith('.svg')) return 'image/svg+xml';
  if (name.endsWith('.ico')) return 'image/x-icon';
  if (name.endsWith('.json')) return 'application/json; charset=utf-8';
  if (name.endsWith('.png')) return 'image/png';
  if (name.endsWith('.jpg') || name.endsWith('.jpeg')) return 'image/jpeg';
  if (name.endsWith('.webp')) return 'image/webp';
  return '';
}

function webFileServer(webRoot) {
  const root = path.resolve(webRoot);
  return (req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    let name = req.path.replace(/^\/+/, '');
    if (name === '' || name.endsWith('/')) name += 'index.html';
    if (name.includes('..')) {
      res.status(404).type('text/plain; charset=utf-8').send('404 page not found\n');
      return;
    }
    let data;
    try {
      data = fs.readFileSync(path.join(root, name));
    } catch {
      res.status(404).type('text/plain; charset=utf-8').send('404 page not found\n');
      return;
    }
    const etag = contentETag(data);
    res.setHeader('ETag', etag);
    res.setHeader('Cache-Control', 'no-cache');
    if (req.headers['if-none-match'] === etag) {
      res.status(304).end();
      return;
    }
    const ct = mimeByName(name);
    if (ct) res.setHeader('Content-Type', ct);
    res.setHeader('Content-Length', String(data.length));
    res.status(200).send(data);
  };
}



function teenOn(req) {
  return req != null && String(req.query && req.query.teen || '') === '1';
}

function teenEffective(req) {
  return teenEnabled() || teenOn(req);
}

function teenSameOrigin(req) {
  const origin = String(req.headers.origin || '').trim();
  if (!origin) {
    const sfs = String(req.headers['sec-fetch-site'] || '').toLowerCase().trim();
    if (sfs) return sfs === 'same-origin' || sfs === 'same-site' || sfs === 'none';
    return true;
  }
  let u;
  try {
    u = new URL(origin);
  } catch {
    return false;
  }
  if (!u.host) return false;
  const host = u.hostname;
  if (host === 'localhost' || host === '127.0.0.1' || host === '::1' || host.startsWith('127.')) return true;
  return u.host.toLowerCase() === String(req.headers.host || '').toLowerCase();
}



export function teenPlaceholderCard(plat) {
  return {
    vod_id: teenPlaceholderID,
    vod_name: teenPlaceholderName,
    vod_pic: '',
    vod_remarks: '青少年模式',
    vod_class: '青少年模式',
    vod_content: '该平台不在青少年模式白名单里：请先在网页端关闭青少年模式再观看',
    url: 'teen://unlock',
  };
}

export function teenPlaceholderList(plat) {
  const cards = [teenPlaceholderCard(plat)];
  prefixCardIDs(plat, cards);
  return cards;
}

export function teenPlaceholderDetail(id, plat) {
  if (!id) id = teenPlaceholderID;
  return {
    vod_id: id,
    vod_name: teenPlaceholderName,
    vod_pic: '',
    vod_content: '该平台不在青少年模式白名单里：请先在网页端关闭青少年模式再观看',
    vod_class: firstNonEmpty(platNameForTag(plat), '青少年模式'),
    episodes: [{ no: 1, name: teenPlaceholderName, url: 'teen://unlock' }],
    episode_count: 1,
  };
}



function lanIPv4s() {
  const out = [];
  try {
    for (const ifaces of Object.values(os.networkInterfaces())) {
      for (const info of ifaces || []) {
        if (info.internal || info.family !== 'IPv4') continue;
        out.push(info.address);
      }
    }
  } catch {}
  return out;
}

export function localOrigin(raw) {
  const sep = '://';
  const i = raw.indexOf(sep);
  if (i <= 0) return '';
  const scheme = raw.slice(0, i).toLowerCase();
  if (scheme !== 'http' && scheme !== 'https') return '';
  const rest = raw.slice(i + sep.length);
  let host = rest;
  const j = rest.search(/[/?#]/);
  if (j >= 0) host = rest.slice(0, j);
  let name = host;
  const k = name.lastIndexOf(':');
  if (k >= 0) name = name.slice(0, k);
  name = name.replace(/^\[/, '').replace(/\]$/, '');
  const low = name.toLowerCase();
  if (low === '127.0.0.1' || low === 'localhost' || low === '::1') {
    return raw.slice(0, i + sep.length) + host;
  }
  return '';
}

function selfOrigins(s) {
  const port = Number(s && s.port) || 0;
  const list = [];
  if (port > 0) {
    list.push(`http://127.0.0.1:${port}`, `http://localhost:${port}`);
    for (const ip of lanIPv4s()) list.push(`http://${ip}:${port}`);
  } else {
    
    for (const ip of ['127.0.0.1', 'localhost', ...lanIPv4s()]) list.push(`http://${ip}:`);
  }
  return list;
}

export function localize(s, raw) {
  if (!raw || raw.startsWith('/')) return raw;
  const origin = localOrigin(raw);
  if (origin) {
    const rel = raw.slice(origin.length);
    return rel || '/';
  }
  for (const o of selfOrigins(s)) {
    if (raw.startsWith(o)) return raw.slice(o.length);
  }
  return raw;
}



class DetailCache {
  constructor(limit = 400) {
    this.items = new Map();
    this.limit = limit;
    this.sideClear = null; 
  }
  get(key) {
    const box = this.items.get(key);
    if (!box || Date.now() > box.expire) {
      if (box) this.items.delete(key);
      return null;
    }
    return box.detail;
  }
  put(key, detail) {
    if (this.items.size >= this.limit) {
      const now = Date.now();
      for (const [k, v] of this.items) {
        if (now > v.expire) this.items.delete(k);
      }
      if (this.items.size >= this.limit) {
        let n = 0;
        for (const k of this.items.keys()) {
          this.items.delete(k);
          if (++n >= Math.floor(this.limit / 2)) break;
        }
      }
    }
    this.items.set(key, { detail, expire: Date.now() + 20 * 60 * 1000 });
  }
  clear() {
    this.items = new Map();
    if (this.sideClear) {
      try { this.sideClear(); } catch {}
    }
  }
}

function detailCacheOf(s) {
  if (!s.detailCache || typeof s.detailCache.put !== 'function' || s.detailCache instanceof Map) {
    s.detailCache = new DetailCache();
    s.detailCache.sideClear = () => {
      if (s.seasonCache && typeof s.seasonCache.clear === 'function') s.seasonCache.clear();
      if (s.coverMemo && typeof s.coverMemo.clear === 'function') s.coverMemo.clear();
    };
  }
  return s.detailCache;
}

export function detailOf(srv, plat, id, prov) {
  const cache = detailCacheOf(srv);
  const key = `${plat}|${id}`;
  const hit = cache.get(key);
  if (hit) return Promise.resolve(hit);
  return (async () => {
    const detail = await prov.Detail(id);
    if (!detail) throw new Error('详情为空');
    if (!detail.vod_class) detail.vod_class = platNameForTag(plat);
    cache.put(key, detail);
    return detail;
  })();
}



class CoverMemo {
  constructor(maxItems = 4000) {
    this.items = new Map();
    this.maxItems = maxItems;
  }
  remember(cards) {
    for (const card of cards) {
      if (!card.plat || !card.id || !card.cover) continue;
      const key = card.plat + '\x00' + card.id;
      if (!this.items.has(key) && this.items.size >= this.maxItems) {
        this.items = new Map();
      }
      this.items.set(key, card.cover);
    }
  }
  clear() {
    this.items = new Map();
  }
  lookup(plat, id) {
    if (!plat || !id) return '';
    return this.items.get(plat + '\x00' + id) || '';
  }
}

export function covers(s) {
  if (!s.coverMemo) s.coverMemo = new CoverMemo();
  return s.coverMemo;
}

export function localPlayURL(res) {
  const src = res.src || '';
  const query = { url: src };
  if (res.key && !isM3U8(src)) {
    query.dec = 'cenc';
    query.key = res.key;
    if (res.referer) query.ref = res.referer;
    if (res.cookie) query.ck = res.cookie;
    if (res.userAgent) query.ua = res.userAgent;
    return ['/media?' + encodeQuery(query), false];
  }
  if (res.referer) query.ref = res.referer;
  if (res.cookie) query.ck = res.cookie;
  if (res.userAgent) query.ua = res.userAgent;
  const suffix = isM3U8(src) ? 'media/playlist.m3u8' : 'media';
  return ['/' + suffix + '?' + encodeQuery(query), isM3U8(src)];
}



export function toWebCards(s, plat, cards) {
  const out = [];
  for (const c of cards || []) {
    let owner = plat || '';
    let raw = String(c.vod_id ?? '');
    const sp = splitPrefixedID(raw);
    if (sp.ok) {
      owner = sp.plat;
      raw = sp.pure;
    }
    if (!owner) owner = inferPlatform(raw);
    out.push({
      id: raw,
      plat: owner,
      plat_name: platformName(owner),
      name: c.vod_name || '',
      cover: localize(s, c.vod_pic || ''),
      ref: '',
      remarks: firstNonEmpty(c.vod_remarks, c.vod_class),
      desc: c.vod_content || '',
    });
  }
  covers(s).remember(out);
  return out;
}

export function seriesCover(s, plat, id, detailPic) {
  const pic = localize(s, detailPic || '');
  const memo = covers(s).lookup(plat, id);
  if (memo) return memo;
  if (pic) covers(s).remember([{ plat, id, cover: pic }]);
  return pic;
}

export function sortPlatforms(plats, mark) {
  const kept = [];
  const adults = [];
  for (const p of plats || []) {
    if (isTeenPlatform(p.key)) {
      kept.push(p);
      continue;
    }
    const bp = { ...p };
    if (mark) bp.name = '🔞 ' + p.name;
    adults.push(bp);
  }
  return [...kept, ...adults];
}

export function webTeenCards(s, plat) {
  return toWebCards(s, plat, teenPlaceholderList(plat));
}

export function filterTeenCards(cards) {
  return (cards || []).filter((c) => isTeenPlatform(c.plat));
}



const searchPlatformTimeout = 10000;
const searchAggregateWindow = 7000;

export function searchPlatform(s, prov, wd, page) {
  return withTimeout(prov.Search(wd, page), searchPlatformTimeout);
}


export async function searchWithFallback(s, wd, page, teen) {
  const targets = (s.router.Platforms() || []).filter(
    (p) => s.router.provider(p.key) && (!teen || isTeenPlatform(p.key))
  );
  const windowTimer = sleep(searchAggregateWindow);
  const results = await Promise.all(targets.map(async (p) => {
    const outcome = searchPlatform(s, s.router.provider(p.key), wd, page).then(
      (cards) => {
        if (cards && cards.length > 0) prefixCardIDs(p.key, cards);
        return { ok: true, cards: cards || [] };
      },
      (err) => ({ ok: false, err })
    );
    return Promise.race([outcome, windowTimer.then(() => ({ timeout: true }))]);
  }));
  let firstErr = null;
  const merged = [];
  for (let i = 0; i < targets.length; i++) {
    const r = results[i];
    if (!r || r.timeout) continue;
    if (r.ok) merged.push(...r.cards);
    else if (!firstErr) firstErr = new Error(`${targets[i].name}: ${(r.err && r.err.message) || r.err}`);
  }
  if (merged.length === 0 && !firstErr) firstErr = new Error('所有平台均无结果');
  return { cards: merged, err: firstErr };
}



const unionMaxParallel = 8;

const unionPreferred = [
  '最新', '新剧', '推荐', '排行', '精选', '热门',
  '真人剧榜', '漫剧榜', 'AI剧榜', '真人剧', '漫剧', 'AI剧', '人气',
  '热播', '榜单', '今日', '高分',
];

function unionRank(name) {
  const low = String(name || '').toLowerCase();
  for (let i = 0; i < unionPreferred.length; i++) {
    if (low.includes(unionPreferred[i].toLowerCase())) return i;
  }
  return unionPreferred.length;
}

function unionKey(name) {
  let n = String(name || '').trim();
  n = n.split('\u3000').join('');
  n = n.split(' ').join('');
  return n.toLowerCase();
}

export function unionIndex(s, teen) {
  const order = [];
  const index = new Map();
  for (const pf of s.router.Platforms() || []) {
    if (!s.router.provider(pf.key) || feedBlocked(pf.key)) continue;
    if (teen && !isTeenPlatform(pf.key)) continue;
    for (const c of pf.cats || []) {
      const key = unionKey(c.name);
      if (!key) continue;
      let uc = index.get(key);
      if (!uc) {
        uc = { name: String(c.name || '').trim(), plats: [] };
        index.set(key, uc);
        order.push(uc);
      }
      if (!uc.plats.some((ref) => ref.key === pf.key)) {
        uc.plats.push({ key: pf.key, name: pf.name, cat: c.id });
      }
    }
  }
  const out = order.map((uc) => ({ name: uc.name, plats: uc.plats, n: uc.plats.length }));
  out.sort((a, b) => {
    const ri = unionRank(a.name), rj = unionRank(b.name);
    if (ri !== rj) return ri - rj;
    return b.n - a.n;
  });
  return out;
}



export const feedReadyTarget = 24;
export const feedBatchParallel = 6;
export const feedRecentKeep = 240;
export const feedPerPlatCap = 10;
export const feedSeedPlatform = 'hongguo';
export const feedCandTarget = 60;
export const feedCandLow = 24;
export const feedRefillLow = 2;
export const feedPersistMaxCands = 200;
export const feedPersistMaxReady = feedReadyTarget * 2;
export const feedPersistMaxServed = 4000;
export const feedPersistAutoEvery = 45000;

let feedPersistTTL = 6 * 60 * 60 * 1000;

export function setFeedTTL(ms) {
  if (ms > 0) feedPersistTTL = ms;
}

export function feedTTL() {
  return feedPersistTTL;
}

const feedBlockPlats = { wuwu: true };

export function feedBlocked(plat) {
  return !!feedBlockPlats[plat];
}

export function feedKey(plat, drama, episode) {
  return `${plat}|${drama}|${episode}`;
}

const randInt = (n) => Math.floor(Math.random() * n);

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = randInt(i + 1);
    const t = arr[i];
    arr[i] = arr[j];
    arr[j] = t;
  }
  return arr;
}

function feedStorePath() {
  return path.join(getDataDir(), 'feedpool.json');
}

export function feedStoreFile() {
  return feedStorePath();
}

class FeedPool {
  constructor(srv) {
    this.srv = srv;
    this.cands = [];
    this.ready = [];
    this.seen = new Set();
    this.recent = [];
    this.busy = false;
    this.lastTake = 0;
    this.seeded = false;
    this.seedTries = 0;
    this.seedTaken = false;
    this.served = new Set();
    this.teen = false;
    this.age = new Map();
    this.harvests = 0;
    this.harvestCands = 0;
    this.resolves = 0;
    this.resolveOK = 0;
    this.lastErr = '';
    this.lastErrAt = 0;
    this.lastSave = 0;
    this.warmStarted = false;
    this.autoSaveStarted = false;
    this.restore();
    this.startAutosave();
  }

  restore() {
    let raw;
    try {
      raw = fs.readFileSync(feedStorePath());
    } catch (err) {
      console.error(`[feed] 没有可用的推荐池存盘（${(err && err.code) || (err && err.message) || err}），本次冷启动要重新抓取`);
      return;
    }
    let snap;
    try {
      snap = JSON.parse(raw.toString('utf8'));
    } catch {
      console.error('[feed] 推荐池存盘解析失败，本次冷启动要重新抓取');
      return;
    }
    const savedAt = Date.parse(snap && snap.saved_at || '') || 0;
    if (!savedAt || Date.now() - savedAt > feedPersistTTL) {
      console.error(`[feed] 推荐池存盘已过期（${savedAt ? new Date(savedAt).toISOString() : '空'} 前），本次重新抓取`);
      return;
    }
    let ready = (snap.ready || []).filter((it) => it.play && it.plat && it.drama_id);
    if (ready.length > feedPersistMaxReady) ready = ready.slice(0, feedPersistMaxReady);
    let cands = snap.cands || [];
    if (cands.length > feedPersistMaxCands) cands = cands.slice(0, feedPersistMaxCands);
    if (ready.length === 0 && cands.length === 0) {
      console.error('[feed] 推荐池存盘是空的，本次冷启动要重新抓取');
      return;
    }
    this.cands = cands;
    this.ready = ready;
    this.seeded = !!snap.seeded;
    this.seedTaken = !!snap.seed_taken;
    this.seedTries = snap.seed_tries || 0;
    for (const it of ready) {
      const k = feedKey(it.plat, it.drama_id, it.episode_no);
      const t = (snap.ages && Date.parse(snap.ages[k] || '')) || 0;
      this.age.set(k, t || savedAt);
    }
    this.dropStaleLocked();
    this.recent.push(...(snap.recent || []));
    if (this.recent.length > feedRecentKeep) {
      this.recent = this.recent.slice(this.recent.length - feedRecentKeep);
    }
    for (const k of snap.seen || []) this.seen.add(k);
    for (const k of snap.served || []) this.served.add(k);
    console.error(`[feed] 沿用上次未用完的推荐池：可播 ${this.ready.length} 条 / 候选 ${this.cands.length} 条（有效期 ${feedPersistTTL}ms）`);
  }

  persist() {
    this.save(false);
  }

  persistNow() {
    this.save(true);
  }

  save(force) {
    const now = Date.now();
    if (!force && this.lastSave && now - this.lastSave < 1500) return;
    this.lastSave = now;
    const ready = this.ready.slice(0, feedPersistMaxReady);
    const cands = this.cands.slice(0, feedPersistMaxCands);
    let recent = this.recent;
    if (recent.length > feedRecentKeep) recent = recent.slice(recent.length - feedRecentKeep);
    const ages = {};
    for (const it of ready) {
      const k = feedKey(it.plat, it.drama_id, it.episode_no);
      const t = this.age.get(k) || 0;
      ages[k] = new Date(t || now).toISOString();
    }
    const snap = {
      saved_at: new Date(now).toISOString(),
      seeded: this.seeded,
      seed_taken: this.seedTaken,
      seed_tries: this.seedTries,
      cands,
      ready,
      recent,
      seen: [...this.seen],
      served: [...this.served].slice(0, feedPersistMaxServed),
      ages,
    };
    try {
      const file = feedStorePath();
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file + '.tmp', JSON.stringify(snap));
      fs.renameSync(file + '.tmp', file);
    } catch {}
  }

  startAutosave() {
    if (this.autoSaveStarted) return;
    this.autoSaveStarted = true;
    const timer = setInterval(() => {
      const hot = this.lastTake && Date.now() - this.lastTake < 15 * 60 * 1000;
      const has = this.ready.length > 0 || this.cands.length > 0;
      if (!hot || !has) return;
      this.persistNow();
    }, feedPersistAutoEvery);
    if (typeof timer.unref === 'function') timer.unref();
  }

  startPrwarm() {
    if (this.warmStarted) return;
    this.warmStarted = true;
    (async () => {
      for (;;) {
        await sleep(2000);
        const zero = !this.lastTake;
        const idle = Date.now() - this.lastTake;
        if (zero || idle > 10 * 60 * 1000) continue;
        if (!this.needsFill()) continue;
        try { await this.topUp(true); } catch {}
      }
    })();
  }

  needsFill() {
    return this.ready.length <= feedRefillLow;
  }

  readyView(block) {
    if (!block) return this.ready;
    return this.ready.filter((it) => !feedBlocked(it.plat));
  }

  keepRest(rest, block) {
    if (!block) {
      this.ready = rest || [];
      return;
    }
    const kept = [...(rest || [])];
    for (const it of this.ready) {
      if (feedBlocked(it.plat)) kept.push(it);
    }
    this.ready = kept;
  }

  noteErr(tag, err) {
    if (!err) return;
    let msg = String((err && err.message) || err);
    msg = msg.replace(/\r|\n/g, ' ');
    if (msg.length > 90) msg = msg.slice(0, 90);
    this.lastErr = `${tag}:${msg}`;
    this.lastErrAt = Date.now();
  }

  diag() {
    let str = `补货${this.harvests}轮 候选${this.harvestCands}条 解析${this.resolveOK}/${this.resolves}`;
    if (this.lastErr) str += ` 最近错误[${this.lastErr}]`;
    return str;
  }

  async take(want, teen, block) {
    if (want < 1) want = 1;
    if (this.teen !== teen) {
      this.teen = teen;
      if (teen) {
        this.ready = this.ready.filter((it) => isTeenPlatform(it.plat));
        this.cands = this.cands.filter((c) => isTeenPlatform(c.plat));
      }
    }
    const deadline = Date.now() + 35000;
    const softAt = Date.now() + 3500;
    const lonelyAt = Date.now() + 15000;
    this.lastTake = Date.now();
    this.startPrwarm();
    this.topUp(false).catch(() => {});
    let nextTop = Date.now() + 5000;

    for (;;) {
      if (Date.now() > nextTop) {
        this.topUp(true).catch(() => {});
        nextTop = Date.now() + 5000;
      }
      const pool = this.readyView(block);
      const have = pool.length;
      let out = [];
      if (have >= want || (have >= 2 && Date.now() > softAt) || (have >= 1 && Date.now() > lonelyAt)) {
        const [sel, rest] = pickBalanced(pool, want);
        out = sel;
        this.keepRest(rest, block);
      }
      if (out.length > 0) {
        for (const it of out) this.served.add(feedKey(it.plat, it.drama_id, it.episode_no));
        if (this.served.size > 4000) {
          this.served = new Set(this.ready.map((it) => feedKey(it.plat, it.drama_id, it.episode_no)));
        }
        if (this.seeded && !this.seedTaken) {
          this.seedTaken = true;
          this.cands = this.cands.filter((c) => c.plat === feedSeedPlatform);
        }
        const left = this.readyView(block).length;
        this.persist();
        if (left <= feedRefillLow) this.topUp(true).catch(() => {});
        return out;
      }
      if (Date.now() > deadline) {
        const pool = this.readyView(block);
        if (pool.length > 0) {
          this.keepRest(null, block);
          for (const it of pool) this.served.add(feedKey(it.plat, it.drama_id, it.episode_no));
          this.persist();
          this.topUp(true).catch(() => {});
          return pool;
        }
        throw new Error(`暂时没能取到可播放的短剧（${this.diag()}），请检查网络后重试`);
      }
      await sleep(150);
    }
  }

  dropStale() {
    this.dropStaleLocked();
  }

  dropStaleLocked() {
    if (this.ready.length === 0) return;
    const now = Date.now();
    const kept = [];
    const ages = new Map();
    for (const it of this.ready) {
      const k = feedKey(it.plat, it.drama_id, it.episode_no);
      let t = this.age.get(k) || 0;
      if (!t) t = now;
      if (now - t > feedPersistTTL) {
        this.served.delete(k);
        continue;
      }
      ages.set(k, t);
      kept.push(it);
    }
    if (kept.length !== this.ready.length) {
      console.error(`[feed] 淘汰过期条目 ${this.ready.length - kept.length} 条（超过 ${feedPersistTTL}ms）`);
    }
    this.ready = kept;
    this.age = ages;
  }

  async topUp(fresh) {
    this.dropStale();
    if (fresh) {
      try { await this.fillCands(true); } catch {}
    }
    if (this.busy) return;
    this.busy = true;
    try {
      const budget = Date.now() + 90000;
      for (let round = 0; round < 3; round++) {
        const need = feedReadyTarget - this.ready.length;
        const ready0 = this.ready.length;
        const have = this.cands.length;
        if (need <= 0) {
          if (have < feedCandLow) {
            await this.fillCands(false, Math.max(1, budget - Date.now()));
            this.persist();
          }
          return;
        }
        if (have < feedCandLow) {
          await this.fillCands(false, Math.max(1, budget - Date.now()));
        }
        const cands = this.grabCandidates(need + 4);
        if (cands.length === 0) {
          this.noteErr('harvest', new Error('一轮补货后仍没有任何候选'));
          return;
        }
        await this.resolve(cands, need);
        const gained = this.ready.length - ready0;
        if (gained >= need || gained === 0) return;
      }
    } finally {
      this.busy = false;
      this.persist();
    }
  }

  async fillCands(force, budgetMs = 90000) {
    const deadline = Date.now() + budgetMs;
    for (let i = 0; i < 3; i++) {
      if (Date.now() > deadline) return;
      const have = this.cands.length;
      if (have >= feedCandTarget && !(force && i === 0)) return;
      await this.harvest(Math.min(20000, Math.max(1, deadline - Date.now())));
      const grew = this.cands.length > have;
      if (!grew) return;
    }
  }

  grabCandidates(count) {
    if (count > this.cands.length) count = this.cands.length;
    if (count <= 0) return [];
    const out = this.cands.slice(0, count);
    this.cands = this.cands.slice(count);
    return out;
  }

  async resolve(cands, target) {
    let stopped = false;
    const push = (item) => {
      if (this.ready.length >= feedReadyTarget) {
        stopped = true;
        return false;
      }
      const key = feedKey(item.plat, item.drama_id, item.episode_no);
      if (this.served.has(key)) return false;
      this.ready.push(item);
      this.age.set(key, Date.now());
      return true;
    };
    const taken = new Array(cands.length).fill(false);
    let idx = 0;
    const worker = async () => {
      while (!stopped && idx < cands.length) {
        const i = idx++;
        taken[i] = true;
        const c = cands[i];
        this.resolves++;
        try {
          const item = await withTimeout(buildFeedItem(this.srv, c), 90000);
          if (item) {
            this.resolveOK++;
            push(item);
          } else {
            this.noteErr(c.plat, new Error('无结果'));
          }
        } catch (err) {
          this.noteErr(c.plat, err);
        }
      }
    };
    await Promise.all(Array.from({ length: Math.min(feedBatchParallel, cands.length) }, worker));
    const rest = cands.filter((_, i) => !taken[i]);
    if (rest.length > 0) {
      this.cands = [...rest, ...this.cands];
    }
  }

  harvestKeys() {
    const all = [];
    for (const plat of this.srv.router.Platforms() || []) {
      if (!this.srv.router.provider(plat.key)) continue;
      if (this.teen && !isTeenPlatform(plat.key)) continue;
      all.push(plat.key);
    }
    if (all.length === 0) return [];
    if (!this.seeded && this.seedTries < 2) {
      const hit = all.find((k) => k === feedSeedPlatform);
      if (hit) return [hit];
    }
    const keys = shuffle(all.slice());
    const pick = Math.min(keys.length, 6);
    return keys.slice(0, pick);
  }

  async harvest(budgetMs = 20000) {
    const keys = this.harvestKeys();
    if (keys.length === 0) {
      this.noteErr('harvest', new Error('没有可用平台'));
      return;
    }
    this.harvests++;
    const pick = keys.length;
    const seedMode = pick === 1 && keys[0] === feedSeedPlatform;
    const quota = seedMode ? 12 : 60;
    let got = 0;
    const deadline = Date.now() + 7000;
    const deadlineReached = () => Date.now() >= deadline;

    const consume = (converted) => {
      if (deadlineReached() || got >= quota) return;
      let batch = converted;
      if (batch.length > quota - got) batch = batch.slice(0, quota - got);
      if (!seedMode && batch.length > feedPerPlatCap) batch = batch.slice(0, feedPerPlatCap);
      for (const c of batch) {
        this.remember(c);
        this.harvestCands++;
        got++;
      }
      if (got > 0) this.seeded = true;
    };

    const deadlineWaiter = sleep(7000).then(() => '__deadline__');
    await Promise.all(keys.map(async (key) => {
      const task = (async () => {
        const prov = this.srv.router.provider(key);
        if (!prov) return null;
        const cat = randomCat(this.srv, key);
        let cards = null;
        try {
          cards = await prov.List(cat, 1 + randInt(4));
        } catch {
          try {
            cards = await prov.List(defaultCat(key), 1 + randInt(4));
          } catch (err2) {
            this.noteErr(`${key}(${cat})`, err2);
            return null;
          }
        }
        if (!cards || cards.length === 0) {
          this.noteErr(`${key}(${cat})`, new Error('列表为空'));
          return null;
        }
        return shuffle(toWebCards(this.srv, key, cards));
      })().catch((err) => {
        this.noteErr(key, err);
        return null;
      });
      const r = await Promise.race([
        withTimeout(task, Math.min(20000, Math.max(1, budgetMs))),
        deadlineWaiter,
      ]);
      if (r && r !== '__deadline__') consume(r);
    }));

    if (!this.seeded) this.seedTries++;
    this.persist();
  }

  remember(c) {
    if (!c.id || !c.plat) return;
    const key = c.plat + '|' + c.id;
    if (this.seen.has(key)) return;
    this.seen.add(key);
    this.recent.push(key);
    if (this.recent.length > feedRecentKeep) {
      for (let i = 0; i < this.recent.length - feedRecentKeep; i++) {
        this.seen.delete(this.recent[i]);
      }
      this.recent = this.recent.slice(this.recent.length - feedRecentKeep);
    }
    this.cands.push(c);
  }
}

export function pickBalanced(items, want) {
  if (want <= 0 || items.length === 0) return [[], items];
  if (items.length <= want) return [items.slice(), []];
  const buckets = new Map();
  const order = [];
  items.forEach((it, i) => {
    if (!buckets.has(it.plat)) {
      buckets.set(it.plat, []);
      order.push(it.plat);
    }
    buckets.get(it.plat).push(i);
  });
  const cursor = new Map();
  const picked = new Set();
  const sel = [];
  while (sel.length < want) {
    let added = false;
    for (const key of order) {
      const at = cursor.get(key) || 0;
      const bag = buckets.get(key);
      if (at >= bag.length) continue;
      const index = bag[at];
      cursor.set(key, at + 1);
      if (picked.has(index)) continue;
      picked.add(index);
      sel.push(items[index]);
      added = true;
      if (sel.length >= want) break;
    }
    if (!added) break;
  }
  const rest = [];
  items.forEach((it, i) => {
    if (!picked.has(i)) rest.push(it);
  });
  return [sel, rest];
}

export function buildFeedItem(s, c) {
  return (async () => {
    const prov = s.router.provider(c.plat);
    if (!prov) throw new Error('未知平台 ' + c.plat);
    const detail = await detailOf(s, c.plat, c.id, prov);
    const episodes = detail.episodes || [];
    if (episodes.length === 0) throw new Error('无剧集');
    const pick = episodes[randInt(episodes.length)];
    const res = await prov.Play(pick.url);
    if (!res || !res.src) throw new Error('无播放地址');
    const [play, m3u8] = localPlayURL(res);
    if (s.media && res.key && !isM3U8(res.src) && typeof s.media.warmCENC === 'function') {
      try { Promise.resolve(s.media.warmCENC(res)).catch(() => {}); } catch {}
    }
    const name = firstNonEmpty(detail.vod_name, c.name);
    const cover = localize(s, firstNonEmpty(detail.vod_pic, c.cover));
    const desc = firstNonEmpty(detail.vod_content, c.desc);
    let no = pick.no || 0;
    if (no <= 0) no = 1;
    return {
      plat: c.plat,
      plat_name: platformName(c.plat),
      drama_id: c.id,
      drama_name: name,
      cover,
      desc,
      total: episodes.length,
      episode_no: no,
      episode_name: firstNonEmpty(pick.name, `第${no}集`),
      play,
      m3u8,
    };
  })();
}



export const feedMixPlatforms = 2;
export const feedMixMaxPlats = 4;

export function mixKeys(s, teen) {
  const all = [];
  for (const pf of s.router.Platforms() || []) {
    if (!s.router.provider(pf.key)) continue;
    if (feedBlocked(pf.key)) continue;
    if (teen && !isTeenPlatform(pf.key)) continue;
    all.push(pf.key);
  }
  return shuffle(all);
}

export function randomCat(s, plat) {
  const pf = (s.router.Platforms() || []).find((p) => p.key === plat);
  if (pf && pf.cats && pf.cats.length > 0) return pf.cats[randInt(pf.cats.length)].id;
  return defaultCat(plat);
}

async function webMix(s, req, res) {
  let n = atoiDefault(req.query.n, 12);
  if (n < 1) n = 1;
  if (n > 24) n = 24;
  const teen = teenEffective(req);

  const keys = mixKeys(s, teen);
  if (keys.length === 0) {
    httpError(res, 502, '没有可用平台');
    return;
  }

  const seen = new Set();
  const buckets = [];
  const used = [];
  const cats = [];
  let lastErr = '';

  for (const key of keys) {
    if (buckets.length >= feedMixPlatforms) break;
    const prov = s.router.provider(key);
    if (!prov) continue;
    const cat = randomCat(s, key);
    let cards = null;
    let err = null;
    try {
      cards = await withTimeout(prov.List(cat, 1 + randInt(3)), 15000);
    } catch (e) {
      err = e;
    }
    if (!cards || cards.length === 0) {
      lastErr = `${key}(${cat}): ${err ? err.message : '列表为空'}`;
      console.error(`[mix] ${lastErr}，换下一个平台`);
      continue;
    }
    const got = shuffle(toWebCards(s, key, cards));
    const kept = [];
    for (const c of got) {
      if (!c.id || seen.has(c.id)) continue;
      seen.add(c.id);
      kept.push(c);
    }
    if (kept.length === 0) continue;
    buckets.push(kept);
    used.push(key);
    cats.push(cat);
  }

  const out = [];
  for (let i = 0; out.length < n; i++) {
    let added = false;
    for (const b of buckets) {
      if (i >= b.length) continue;
      out.push(b[i]);
      added = true;
      if (out.length >= n) break;
    }
    if (!added) break;
  }

  if (out.length === 0) {
    let msg = '暂时没能取到内容';
    if (lastErr) msg += `（${lastErr}）`;
    httpError(res, 504, msg);
    return;
  }
  ok(res, { list: out, plats: used, cats });
}



export const feedFetchPlats = 3;
export const feedFetchMaxPlats = 6;
export const feedListTimeout = 12000;
export const feedPlayTimeout = 12000;
export const feedSoftWait = 9000;
export const feedHardWait = 24000;

const feedServedTTL = 30 * 60 * 1000;
const feedServedMax = 3000;

const feedServedStore = {
  at: new Map(),
  has(key) {
    const t = this.at.get(key);
    if (t === undefined) return false;
    return Date.now() - t < feedServedTTL;
  },
  add(...keys) {
    const now = Date.now();
    for (const k of keys) this.at.set(k, now);
    if (this.at.size > feedServedMax) this.at.clear();
  },
};

export async function feedFresh(s, want, teen) {
  if (want < 1) want = 1;
  let keys = mixKeys(s, teen);
  if (keys.length === 0) throw new Error('没有可用平台');
  if (keys.length > feedFetchMaxPlats) keys = keys.slice(0, feedFetchMaxPlats);
  const hard = Date.now() + feedHardWait;
  const soft = Date.now() + feedSoftWait;
  const out = [];
  const seen = new Set();

  for (let start = 0; start < keys.length && out.length < want; start += feedFetchPlats) {
    const end = Math.min(start + feedFetchPlats, keys.length);
    const got = await feedRound(s, keys.slice(start, end), want - out.length, seen, hard, soft);
    out.push(...got);
    if (Date.now() > hard) break;
  }
  if (out.length === 0) {
    throw new Error(`暂时没能取到可播放的短剧（已试平台: ${keys.join('/')}）`);
  }

  const served = [];
  const plats = [];
  const seenPlat = new Set();
  for (const it of out) {
    served.push(`${it.plat}|${it.drama_id}`);
    if (!seenPlat.has(it.plat)) {
      seenPlat.add(it.plat);
      plats.push(it.plat);
    }
  }
  feedServedStore.add(...served);
  return { items: out, plats };
}

async function feedRound(s, keys, want, seen, hard, soft) {
  const out = [];
  if (want < 1 || keys.length === 0) return out;

  const queues = []; 
  let openCount = keys.length;
  let closed = false;
  const listTasks = keys.map((key) =>
    feedListCards(s, key)
      .then((cards) => {
        if (cards.length > 0) queues.push(cards);
      })
      .catch(() => {})
      .finally(() => { openCount--; })
  );

  const workers = Math.min(10, Math.max(4, want * 2));
  let inflight = 0;

  const tryDispatch = () => {
    while (inflight < workers) {
      let dispatched = false;
      for (let bi = 0; bi < queues.length && inflight < workers; bi++) {
        const q = queues[bi];
        while (q.length > 0) {
          const c = q.shift();
          if (!c.id || seen.has(c.id)) continue;
          if (feedServedStore.has(c.plat + '|' + c.id)) continue;
          seen.add(c.id);
          inflight++;
          buildFeedItem(s, c)
            .then((item) => { if (item && !closed) out.push(item); })
            .catch(() => {})
            .finally(() => { inflight--; });
          dispatched = true;
          break;
        }
        if (inflight >= workers) break;
      }
      if (!dispatched) break;
    }
  };

  let waited = 0;
  for (;;) {
    const readyCount = queues.reduce((n, q) => n + (q.length > 0 ? 1 : 0), 0);
    if (openCount > 0 && readyCount < 2 && waited < 2000 && inflight === 0) {
      await sleep(400);
      waited += 400;
      continue;
    }
    tryDispatch();
    if (out.length >= want) break;
    if (openCount === 0 && inflight === 0) break;
    if (Date.now() > hard) break;
    await sleep(300);
    if (out.length > 0 && Date.now() > soft) break;
  }
  closed = true;
  await Promise.allSettled(listTasks);
  return out;
}

async function feedListCards(s, key) {
  const prov = s.router.provider(key);
  if (!prov) return [];
  const deadline = Date.now() + feedListTimeout;
  const left = () => Math.max(0, deadline - Date.now());
  const cat = randomCat(s, key);
  let cards = null;
  try {
    cards = await withTimeout(prov.List(cat, 1 + randInt(3)), left());
  } catch {
    cards = null;
  }
  if (!cards || cards.length === 0) {
    try {
      cards = await withTimeout(prov.List(defaultCat(key), 1 + randInt(3)), left());
    } catch {
      return [];
    }
  }
  if (!cards || cards.length === 0) return [];
  const got = toWebCards(s, key, cards);
  return shuffle(got);
}



let feedServerRef = null;

export function setFeedServer(s) {
  feedServerRef = s;
}

function feedPoolOf(s) {
  if (!s.feed || !(s.feed instanceof FeedPool)) {
    s.feed = new FeedPool(s);
  }
  return s.feed;
}


export async function warmFeed(srv) {
  const s = srv || feedServerRef;
  if (!s) return;
  try {
    await feedPoolOf(s).topUp(true);
  } catch (err) {
    console.error(`[feed] 预热失败: ${(err && err.message) || err}`);
  }
}


export function flushFeed(srv) {
  const s = srv || feedServerRef;
  if (!s || !s.feed || !(s.feed instanceof FeedPool)) return;
  try {
    s.feed.persistNow();
  } catch {}
}



function ok(res, data) {
  writeJSON(res, { code: 200, msg: '', data });
}



function httpError(res, status, msg) {
  writeJSON(res, { code: status, msg }, status);
}

async function webPlatforms(s, req, res) {
  const plats = sortPlatforms(s.router.Platforms(), teenEffective(req));
  ok(res, { platforms: plats });
}

async function webUnions(s, req, res) {
  ok(res, { unions: unionIndex(s, teenEffective(req)) });
}

async function webUnion(s, req, res) {
  const q = req.query;
  const name = String(q.cat || '').trim();
  if (!name) {
    httpError(res, 400, '缺少聚合分类名');
    return;
  }
  let page = atoiDefault(q.page, 1);
  if (page < 1) page = 1;
  const unions = unionIndex(s, teenEffective(req));
  let idx = -1;
  for (let i = 0; i < unions.length; i++) {
    if (unions[i].name === name) {
      idx = i;
      break;
    }
  }
  if (idx < 0 || unions[idx].plats.length === 0) {
    httpError(res, 404, '没有平台绑定该分类: ' + name);
    return;
  }
  const refs = unions[idx].plats;

  const results = new Array(refs.length).fill(null);
  let cursor = 0;
  const worker = async () => {
    while (cursor < refs.length) {
      const i = cursor++;
      const ref = refs[i];
      try {
        const prov = s.router.provider(ref.key);
        if (!prov) continue;
        const cards = await withTimeout(prov.List(ref.cat, page), 15000);
        if (!cards || cards.length === 0) continue;
        results[i] = { key: ref.key, name: ref.name, cards: toWebCards(s, ref.key, cards) };
      } catch (err) {
        console.error(`[union] ${ref.key}(${ref.cat}) 第${page}页取不到内容：${(err && err.message) || err}`);
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(unionMaxParallel, refs.length) }, worker));

  const out = [];
  const seen = new Set();
  for (let i = 0; ; i++) {
    let added = false;
    for (const b of results) {
      if (!b || i >= b.cards.length) continue;
      const c = b.cards[i];
      if (!c.id || seen.has(c.id)) continue;
      seen.add(c.id);
      out.push(c);
      added = true;
    }
    if (!added) break;
  }
  const used = [];
  const usedNames = [];
  for (const b of results) {
    if (!b || b.cards.length === 0) continue;
    used.push(b.key);
    usedNames.push(b.name);
  }
  if (out.length === 0) {
    httpError(res, 504, `「${name}」这几个平台暂时没取到内容`);
    return;
  }
  ok(res, { cat: name, page, plats: used, plat_names: usedNames, list: out });
}

async function webList(s, req, res) {
  const q = req.query;
  let plat = String(q.plat || '').trim();
  if (!plat) plat = 'huangguo';
  let cat = String(q.cat || '').trim();
  if (!cat || cat === 'undefined') cat = defaultCat(plat);
  const page = atoiDefault(q.page, 1);

  if (teenBlocked(plat)) {
    ok(res, { plat, category: cat, page, list: webTeenCards(s, plat), teen: true });
    return;
  }
  const prov = s.router.provider(plat);
  if (!prov) {
    httpError(res, 400, '未知平台: ' + plat);
    return;
  }
  let cards;
  try {
    cards = await withTimeout(prov.List(cat, page), 45000);
  } catch (err) {
    httpError(res, 502, '抓取失败: ' + ((err && err.message) || err));
    return;
  }
  ok(res, { plat, category: cat, page, list: toWebCards(s, plat, cards) });
}

async function webSearch(s, req, res) {
  const q = req.query;
  let wd = String(q.wd || '').trim() || String(q.q || '').trim();
  if (!wd) {
    httpError(res, 400, '请输入搜索关键词');
    return;
  }
  const page = atoiDefault(q.page, 1);
  const plat = String(q.plat || '').trim();
  const teen = teenEffective(req);

  let cards = [];
  let searchErr = null;
  if (plat) {
    if (teenBlocked(plat)) {
      ok(res, { wd, page, plat, list: webTeenCards(s, plat), teen: true });
      return;
    }
    const prov = s.router.provider(plat);
    if (!prov) {
      httpError(res, 400, '未知平台: ' + plat);
      return;
    }
    try {
      cards = await searchPlatform(s, prov, wd, page);
      if (cards) prefixCardIDs(plat, cards);
    } catch (err) {
      searchErr = err;
      cards = cards || [];
    }
  } else {
    const r = await searchWithFallback(s, wd, page, teen);
    cards = r.cards;
    searchErr = r.err;
  }
  let list = toWebCards(s, plat, cards || []);
  if (teen) list = filterTeenCards(list);
  const data = { wd, page, plat, list };
  if ((cards || []).length === 0 && searchErr) {
    data.hint = (searchErr && searchErr.message) || String(searchErr);
  }
  ok(res, data);
}

async function webSeries(s, req, res) {
  const q = req.query;
  let plat = String(q.plat || '').trim();
  let id = String(q.id || '').trim();
  if (!id) {
    httpError(res, 400, '缺少 id');
    return;
  }
  const sp = splitPrefixedID(id);
  if (sp.ok) {
    plat = sp.plat;
    id = sp.pure;
  }
  if (!plat) plat = inferPlatform(id);

  if (teenBlocked(plat)) {
    ok(res, {
      name: teenPlaceholderName,
      cover: '',
      desc: '该平台不在青少年模式白名单里：请先在网页端关闭青少年模式再观看',
      plat,
      plat_name: platformName(plat),
      total: 1,
      episodes: [{ no: 1, name: teenPlaceholderName }],
    });
    return;
  }
  const prov = s.router.provider(plat);
  if (!prov) {
    httpError(res, 400, '未知平台: ' + plat);
    return;
  }
  let detail;
  try {
    detail = await detailOf(s, plat, id, prov);
  } catch (err) {
    httpError(res, 502, '抓取详情失败: ' + ((err && err.message) || err));
    return;
  }
  const pic = seriesCover(s, plat, id, detail.vod_pic || '');
  const eps = [];
  (detail.episodes || []).forEach((ep, i) => {
    let no = ep.no || 0;
    if (no <= 0) no = i + 1;
    eps.push({ no, name: firstNonEmpty(ep.name, `第${no}集`) });
  });
  eps.sort((a, b) => a.no - b.no);
  ok(res, {
    name: detail.vod_name || '',
    cover: pic,
    desc: detail.vod_content || '',
    plat,
    plat_name: platformName(plat),
    total: eps.length,
    episodes: eps,
  });
}

async function webEpisode(s, req, res) {
  const q = req.query;
  let plat = String(q.plat || '').trim();
  let id = String(q.id || '').trim();
  if (!id) {
    httpError(res, 400, '缺少 id');
    return;
  }
  const sp = splitPrefixedID(id);
  if (sp.ok) {
    plat = sp.plat;
    id = sp.pure;
  }
  if (!plat) plat = inferPlatform(id);

  if (teenBlocked(plat)) {
    ok(res, { no: 1, play: teenPlaceholderVideo, m3u8: false, src: teenPlaceholderVideo, teen: true });
    return;
  }
  const prov = s.router.provider(plat);
  if (!prov) {
    httpError(res, 400, '未知平台: ' + plat);
    return;
  }
  const no = atoiDefault(q.ep, 1);
  let detail;
  try {
    detail = await detailOf(s, plat, id, prov);
  } catch (err) {
    httpError(res, 502, '抓取详情失败: ' + ((err && err.message) || err));
    return;
  }
  const episodes = detail.episodes || [];
  if (episodes.length === 0) {
    httpError(res, 404, '这部剧没有可播剧集');
    return;
  }
  let target = episodes.find((e) => e.no === no) || null;
  if (!target) {
    if (no >= 1 && no <= episodes.length) target = episodes[no - 1];
    else target = episodes[0];
  }
  let result;
  try {
    result = await withTimeout(prov.Play(target.url), 45000);
  } catch (err) {
    httpError(res, 502, '解析播放地址失败: ' + ((err && err.message) || err));
    return;
  }
  if (!result || !result.src) {
    httpError(res, 502, '这一集拿不到播放地址');
    return;
  }
  const [play, m3u8] = localPlayURL(result);
  ok(res, { no: target.no, play, m3u8, src: result.src });
}

async function webFeed(s, req, res) {
  let n = atoiDefault(req.query.n, 6);
  if (n > 12) n = 12;
  if (n < 1) n = 1;
  try {
    const { items, plats } = await withTimeout(feedFresh(s, n, teenEffective(req)), feedHardWait + 4000);
    ok(res, { items, plats });
  } catch (err) {
    console.error(`[feed] 取推荐失败: ${(err && err.message) || err}`);
    httpError(res, 504, (err && err.message) || String(err));
  }
}

export function webAPIDocs() {
  return [
    '/web/api/platforms', '/web/api/list', '/web/api/search',
    '/web/api/series', '/web/api/seasons', '/web/api/episode', '/web/api/feed',
  ];
}



export function registerWebRoutes(app, s, webRoot) {
  
  if (!feedServerRef) feedServerRef = s;

  
  app.get('/web', (req, res, next) => {
    if (req.path !== '/web') return next();
    res.redirect('/web/');
  });

  app.get('/web/api/platforms', (req, res) => {
    Promise.resolve(webPlatforms(s, req, res)).catch((err) => {
      if (!res.headersSent) httpError(res, 500, (err && err.message) || '内部错误');
    });
  });

  app.get('/web/api/list', (req, res) => {
    Promise.resolve(webList(s, req, res)).catch((err) => {
      if (!res.headersSent) httpError(res, 500, (err && err.message) || '内部错误');
    });
  });

  app.get('/web/api/search', (req, res) => {
    Promise.resolve(webSearch(s, req, res)).catch((err) => {
      if (!res.headersSent) httpError(res, 500, (err && err.message) || '内部错误');
    });
  });

  app.get('/web/api/series', (req, res) => {
    Promise.resolve(webSeries(s, req, res)).catch((err) => {
      if (!res.headersSent) httpError(res, 500, (err && err.message) || '内部错误');
    });
  });

  app.get('/web/api/seasons', (req, res) => {
    Promise.resolve(webSeasons(s, req, res, searchPlatform)).catch((err) => {
      if (!res.headersSent) httpError(res, 500, (err && err.message) || '内部错误');
    });
  });

  app.get('/web/api/episode', (req, res) => {
    Promise.resolve(webEpisode(s, req, res)).catch((err) => {
      if (!res.headersSent) httpError(res, 500, (err && err.message) || '内部错误');
    });
  });

  app.get('/web/api/feed', (req, res) => {
    Promise.resolve(webFeed(s, req, res)).catch((err) => {
      if (!res.headersSent) httpError(res, 500, (err && err.message) || '内部错误');
    });
  });

  app.get('/web/api/mix', (req, res) => {
    Promise.resolve(webMix(s, req, res)).catch((err) => {
      if (!res.headersSent) httpError(res, 500, (err && err.message) || '内部错误');
    });
  });

  app.get('/web/api/unions', (req, res) => {
    Promise.resolve(webUnions(s, req, res)).catch((err) => {
      if (!res.headersSent) httpError(res, 500, (err && err.message) || '内部错误');
    });
  });

  app.get('/web/api/union', (req, res) => {
    Promise.resolve(webUnion(s, req, res)).catch((err) => {
      if (!res.headersSent) httpError(res, 500, (err && err.message) || '内部错误');
    });
  });

  app.all('/web/api/teen', (req, res) => {
    const onQ = String(req.query.on || '').trim();
    if (onQ === '') {
      ok(res, { teen: teenEnabled() });
      return;
    }
    if (req.method !== 'POST') {
      httpError(res, 405, '青少年模式开关只接受 POST');
      return;
    }
    if (!teenSameOrigin(req)) {
      httpError(res, 403, '跨站请求被拒绝');
      return;
    }
    setTeenEnabled(onQ !== '0');
    ok(res, { teen: teenEnabled() });
  });

  
  app.use('/web', webFileServer(webRoot));
}

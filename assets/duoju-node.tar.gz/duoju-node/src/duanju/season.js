
import { writeJSON, firstNonEmpty, splitPrefixedID } from '../core/util.js';
import { teenBlocked, inferPlatform, platformName, prefixCardIDs } from './router.js';
import { localize } from './web.js';




function httpError(res, status, msg) {
  writeJSON(res, { code: status, msg }, status);
}

export const seasonUnknown = 0;
export const seasonPartBase = 900;
export const seasonSpecialNo = 990;


export const seasonMatchers = [
  { kind: 'num', re: /第\s*([0-9０-９]{1,3})\s*[季部篇]/, reAll: /第\s*([0-9０-９]{1,3})\s*[季部篇]/g },
  { kind: 'cn', re: /第\s*([一二三四五六七八九十百两]{1,4})\s*[季部篇]/, reAll: /第\s*([一二三四五六七八九十百两]{1,4})\s*[季部篇]/g },
  { kind: 'roman', re: /第\s*([Ⅰ-Ⅻⅰ-ⅻIiVvXxLlCcDdMm]{1,7})\s*[季部篇]/, reAll: /第\s*([Ⅰ-Ⅻⅰ-ⅻIiVvXxLlCcDdMm]{1,7})\s*[季部篇]/g },
  { kind: 'en', re: /(?:season|s)\s*([0-9]{1,3})(?:[^0-9]|$)/i, reAll: /(?:season|s)\s*([0-9]{1,3})(?:[^0-9]|$)/gi },
  { kind: 'num2', re: /([0-9０-９]{1,3})\s*[季部]/, reAll: /([0-9０-９]{1,3})\s*[季部]/g },
  { kind: 'cn2', re: /([一二三四五六七八九十]{1,3})\s*[季部]/, reAll: /([一二三四五六七八九十]{1,3})\s*[季部]/g },
];

const reSeasonSpecial = /(番外篇|番外|特别篇|彩蛋|花絮|幕后)/;
const reSeasonSpecialAll = /(番外篇|番外|特别篇|彩蛋|花絮|幕后)/g;
const reSeasonPart = /([上中下])\s*[部卷篇]/;
const reSeasonPartAll = /([上中下])\s*[部卷篇]/g;

export function stripSeasonMarks(name) {
  let s = String(name ?? '');
  for (const m of seasonMatchers) s = s.replace(m.reAll, ' ');
  s = s.replace(reSeasonSpecialAll, ' ');
  s = s.replace(reSeasonPartAll, ' ');
  return s;
}

export function normTitle(s) {
  let out = '';
  for (const ch of String(s ?? '')) {
    const cp = ch.codePointAt(0);
    if (cp >= 0xff10 && cp <= 0xff19) { out += String.fromCharCode(cp - 0xff10 + 0x30); continue; }
    if (cp >= 0xff41 && cp <= 0xff5a) { out += String.fromCharCode(cp - 0xff41 + 0x61); continue; }
    if (cp >= 0xff21 && cp <= 0xff3a) { out += String.fromCharCode(cp - 0xff21 + 0x41); continue; }
    if (/\s/u.test(ch)) continue;
    if (/[\p{P}\p{S}]/u.test(ch)) continue;
    out += ch.toLowerCase();
  }
  return out;
}

function seasonNumber(raw, kind) {
  switch (kind) {
    case 'num':
    case 'num2': {
      let n = 0;
      for (const ch of String(raw)) {
        let d = ch.charCodeAt(0) - 0x30;
        if (ch >= '０' && ch <= '９') d = ch.charCodeAt(0) - 0xff10;
        if (d < 0 || d > 9) return 0;
        n = n * 10 + d;
      }
      return n;
    }
    case 'cn':
    case 'cn2':
      return cnNumber(raw);
    case 'roman':
      return romanNumber(String(raw).toUpperCase());
    case 'en': {
      let n = 0;
      for (const ch of String(raw)) {
        if (ch < '0' || ch > '9') return 0;
        n = n * 10 + (ch.charCodeAt(0) - 0x30);
      }
      return n;
    }
  }
  return 0;
}

function cnNumber(s) {
  const digit = { '零': 0, '一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9, '两': 2 };
  const runes = [...String(s)];
  let total = 0, section = 0, number = 0;
  for (const r of runes) {
    if (r === '十') {
      section = 10 * Math.max(number, 1);
      number = 0;
    } else if (r === '百') {
      section = 100 * Math.max(number, 1);
      number = 0;
    } else if (r in digit) {
      number = digit[r];
    }
  }
  if (section === 0 && number === 0 && runes.length > 0) return 0;
  total = section + number;
  return total;
}

const fullwidthRoman = {
  'Ⅰ': 'I', 'Ⅱ': 'II', 'Ⅲ': 'III', 'Ⅳ': 'IV', 'Ⅴ': 'V',
  'Ⅵ': 'VI', 'Ⅶ': 'VII', 'Ⅷ': 'VIII', 'Ⅸ': 'IX', 'Ⅹ': 'X',
  'Ⅺ': 'XI', 'Ⅻ': 'XII',
  'ⅰ': 'I', 'ⅱ': 'II', 'ⅲ': 'III', 'ⅳ': 'IV', 'ⅴ': 'V',
  'ⅵ': 'VI', 'ⅶ': 'VII', 'ⅷ': 'VIII', 'ⅸ': 'IX', 'ⅹ': 'X',
  'ⅺ': 'XI', 'ⅻ': 'XII',
};

function romanNumber(s) {
  let norm = '';
  for (const r of String(s)) {
    if (r in fullwidthRoman) {
      norm += fullwidthRoman[r];
      continue;
    }
    norm += r.toUpperCase();
  }
  const val = { I: 1, V: 5, X: 10, L: 50, C: 100, D: 500, M: 1000 };
  let total = 0, prev = 0;
  for (let i = norm.length - 1; i >= 0; i--) {
    const cur = val[norm[i]];
    if (!cur) return 0;
    if (cur < prev) total -= cur;
    else {
      total += cur;
      prev = cur;
    }
  }
  return total;
}

export function collapseSpace(s) {
  s = String(s ?? '').split(/\s+/).filter(Boolean).join(' ').trim();
  s = s.replace(/^[ \-—–·、|:：/\\]+|[ \-—–·、|:：/\\]+$/g, '');
  return s.trim();
}

export function seasonSearchKeys(rawName, base) {
  const out = [];
  const add = (s) => {
    s = collapseSpace(s);
    if ([...s].length < 2) return;
    if (out.includes(s)) return;
    out.push(s);
  };
  add(stripSeasonMarks(rawName));
  add(base);
  const head = collapseSpace(stripSeasonMarks(rawName)).split(/[\p{P}\p{S}\s]/u).filter(Boolean);
  if (head.length > 0 && [...head[0]].length >= 3) add(head[0]);
  return out;
}

function seasonRank(season) {
  if (season === seasonUnknown) return -1;
  return season;
}

export function sameSeries(cur, cand, strict) {
  if (!cur.base || !cand.base) return false;
  if (cur.base === cand.base) return [...cur.base].length >= 2;
  if (strict) return false;
  if (!cand.hasMark) return false;
  const a = cur.base, b = cand.base;
  const la = [...a].length, lb = [...b].length;
  if (la < 3 || lb < 3) return false;
  return a.includes(b) || b.includes(a);
}

export function parseTitleSeason(name) {
  const trimmed = String(name ?? '').trim();
  const out = { season: seasonUnknown, label: '正剧', base: '', hasMark: false };
  if (!trimmed) return out;
  const special = reSeasonSpecial.exec(trimmed);
  if (special) {
    out.season = seasonSpecialNo;
    out.label = special[1];
    out.base = normTitle(stripSeasonMarks(trimmed));
    out.hasMark = true;
    return out;
  }
  for (const m of seasonMatchers) {
    const match = m.re.exec(trimmed);
    if (!match) continue;
    const no = seasonNumber(match[1], m.kind);
    if (no <= 0 || no > 200) continue;
    out.season = no;
    out.label = `第${no}季`;
    out.base = normTitle(stripSeasonMarks(trimmed));
    out.hasMark = true;
    return out;
  }
  const part = reSeasonPart.exec(trimmed);
  if (part) {
    let idx = { '上': 1, '中': 2, '下': 3 }[part[1]] || 0;
    if (idx === 0) idx = 1;
    out.season = seasonPartBase + idx;
    out.label = part[1] + '部';
    out.base = normTitle(stripSeasonMarks(trimmed));
    out.hasMark = true;
    return out;
  }
  out.base = normTitle(trimmed);
  return out;
}

export function pureCardID(id) {
  const sp = splitPrefixedID(String(id ?? ''));
  if (sp.ok) return sp.pure;
  return String(id ?? '');
}



class SeasonCache {
  constructor() { this.items = new Map(); }
  get(key) {
    const box = this.items.get(key);
    if (!box || Date.now() > box.expire) {
      if (box) this.items.delete(key);
      return null;
    }
    return box.items;
  }
  put(key, items) {
    if (this.items.size > 200) this.items = new Map();
    this.items.set(key, { items, expire: Date.now() + 10 * 60 * 1000 });
  }
  clear() { this.items = new Map(); }
}

function seasonCacheOf(s) {
  if (!s.seasonCache || typeof s.seasonCache.clear !== 'function' || s.seasonCache instanceof Map) {
    s.seasonCache = new SeasonCache();
  }
  return s.seasonCache;
}

export async function webSeasons(s, req, res, searchPlatform) {
  const q = req.query;
  let plat = String(q.plat || '').trim();
  let id = String(q.id || '').trim();
  const name = String(q.name || '').trim();
  if (!id || !name) return httpError(res, 400, '缺少 id 或 name');
  const sp = splitPrefixedID(id);
  if (sp.ok) {
    plat = sp.plat;
    id = sp.pure;
  }
  if (!plat) plat = inferPlatform(id);

  if (teenBlocked(plat)) {
    return writeJSON(res, {
      code: 200, msg: '',
      data: { plat, id, name, season: 0, label: '', list: [], teen: true },
    });
  }
  const prov = s.router.provider(plat);
  if (!prov) return httpError(res, 400, '未知平台: ' + plat);

  const cur = parseTitleSeason(name);
  if (!cur.base) cur.base = normTitle(name);
  const cacheKey = `${plat}|${id}|${cur.base}`;
  const cache = seasonCacheOf(s);
  const cached = cache.get(cacheKey);
  if (cached) {
    return writeJSON(res, {
      code: 200, msg: '',
      data: { plat, id, name, base: cur.base, season: cur.season, label: cur.label, list: cached },
    });
  }

  const items = await seasonMates(s, plat, prov, id, name, cur, searchPlatform);
  if (items.length > 0) cache.put(cacheKey, items);
  writeJSON(res, {
    code: 200, msg: '',
    data: { plat, id, name, base: cur.base, season: cur.season, label: cur.label, list: items },
  });
}

async function seasonMates(s, plat, prov, id, rawName, cur, searchPlatform) {
  const keys = seasonSearchKeys(rawName, cur.base);

  const cards = [];
  const seen = new Set();
  for (const key of keys) {
    if (!key) continue;
    let got = null;
    try {
      got = await searchPlatform(s, prov, key, 1);
    } catch {
      continue; 
    }
    got = got || [];
    prefixCardIDs(plat, got);
    for (const c of got) {
      const pid = pureCardID(c.vod_id);
      if (!pid || seen.has(pid)) continue;
      seen.add(pid);
      cards.push(c);
    }
    if (cards.length >= 40) break;
  }
  if (cards.length === 0) return [];

  const collect = (strict) => {
    const out = [];
    for (const c of cards) {
      const pid = pureCardID(c.vod_id);
      const info = parseTitleSeason(c.vod_name || '');
      if (!info.base) info.base = normTitle(c.vod_name || '');
      const isCur = pid === id;
      if (!isCur && !sameSeries(cur, info, strict)) continue;
      if (isCur) {
        info.season = cur.season;
        info.label = cur.label;
      }
      let owner = plat;
      const sp = splitPrefixedID(String(c.vod_id ?? ''));
      if (sp.ok) owner = sp.plat;
      out.push({
        id: pid,
        plat: owner,
        plat_name: platformName(owner),
        name: String(c.vod_name || '').trim(),
        cover: localize(s, c.vod_pic || ''),
        remarks: firstNonEmpty(c.vod_remarks, c.vod_class),
        season: info.season,
        label: info.label,
        current: isCur,
      });
      if (out.length >= 20) break;
    }
    return out;
  };

  let items = collect(true);
  if (others(items) === 0) items = collect(false);
  if (others(items) === 0) return [];
  sortSeasonItems(items);
  return items;
}

export function sortSeasonItems(items) {
  items.sort((a, b) => {
    const ri = seasonRank(a.season), rj = seasonRank(b.season);
    if (ri !== rj) return ri - rj;
    if (a.current !== b.current) return a.current ? -1 : 1;
    return a.name < b.name ? -1 : a.name > b.name ? 1 : 0;
  });
}

function others(items) {
  let n = 0;
  for (const it of items) {
    if (!it.current) n++;
  }
  return n;
}

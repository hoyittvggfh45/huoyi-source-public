
import { createDecipheriv } from 'node:crypto';
import { anyList, atoiDefault, cleanText, firstNonEmpty, mapString, parsePlayScheme } from '../../core/util.js';
import { hemaIVHex, hemaKeyHex, hemaSiteBase, hemaStaticDatas } from '../consts.js';
import { aesCBCDecrypt, aesCBCEncrypt, truncate } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';

const hemaCodeList = '1125';
const hemaCodeDetail = '1131';
const hemaCodeChapters = '1132';
const hemaCodePlay = '1133';
const hemaCodeSearch = '1803';

const hemaCatList = [
  { id: 'jingxuan', name: '精选', channel: 53 },
  { id: 'guzhuang', name: '古装', channel: 54 },
  { id: 'chongsheng', name: '重生', channel: 55 },
  { id: 'jiating', name: '家庭', channel: 56 },
  { id: 'lianai', name: '恋爱', channel: 57 },
];

export const platformCats = hemaCatList.map((c) => ({ ID: c.id, Name: c.name }));

function hemaChannel(cat) {
  for (const item of hemaCatList) {
    if (item.id === cat) return [item.channel, item.name];
  }
  const fallback = hemaCatList[0];
  return [fallback.channel, fallback.name];
}

function hemaKeys() {
  const key = Buffer.from(hemaKeyHex, 'hex');
  const iv = Buffer.from(hemaIVHex, 'hex');
  if (key.length === 0) throw new Error('河马 AES key 无效');
  if (iv.length === 0) throw new Error('河马 AES iv 无效');
  return [key, iv];
}

async function hemaEncryptBody(payload) {
  const raw = Buffer.from(JSON.stringify(payload), 'utf8');
  const [key, iv] = hemaKeys();
  const sealed = aesCBCEncrypt(raw, key, iv);
  return sealed.toString('hex').toUpperCase();
}

async function hemaDecryptBody(text) {
  const trimmed = String(text ?? '').trim();
  if (trimmed === '' || trimmed.length % 2 !== 0 || !/^[0-9a-fA-F]+$/.test(trimmed)) {
    throw new Error('河马响应密文无效');
  }
  const blob = Buffer.from(trimmed, 'hex');
  const [key, iv] = hemaKeys();
  try {
    return aesCBCDecrypt(blob, key, iv);
  } catch (err) {
    throw new Error('河马响应解密失败: ' + err.message);
  }
}

export class HemaProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async call(code, payload) {
    const body = await hemaEncryptBody(payload);
    const headers = {
      datas: hemaStaticDatas,
      'content-type': 'text/plain',
      'user-agent': 'okhttp/4.10.0',
      Referer: hemaSiteBase,
    };
    const { raw, status } = await this.client.fetchWithHeaders('POST', `${hemaSiteBase}/free-video-portal/portal/${code}`, headers, body);
    if (status >= 400) {
      throw new Error(`河马接口 HTTP ${status}`);
    }
    let envelope;
    let dataText = '';
    try {
      envelope = JSON.parse(raw.toString('utf8'));
      dataText = String(envelope?.data ?? '').trim();
    } catch {
      throw new Error('河马接口无数据');
    }
    if (dataText === '') {
      throw new Error('河马接口无数据');
    }
    const plain = await hemaDecryptBody(dataText);
    let data;
    try {
      data = JSON.parse(plain.toString('utf8'));
    } catch {
      throw new Error('河马接口响应无法解析');
    }
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      throw new Error('河马接口响应无法解析');
    }
    return data;
  }

  card(item, cat) {
    const id = mapString(item, 'bookId');
    const title = cleanText(mapString(item, 'bookName'));
    if (id === '' || title === '') return null;
    const card = { vod_id: id, vod_name: title, vod_class: cat, vod_score: '', vod_content: '' };
    const cover = mapString(item, 'coverWap');
    if (cover !== '') card.vod_pic = this.media.imgProxyURL(cover, `${hemaSiteBase}/`);
    const n = atoiDefault(mapString(item, 'updateNum'), 0);
    if (n > 0) card.vod_remarks = `更新${n}集`;
    return card;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    const [channelID, channelName] = hemaChannel(cat);
    const payload = {
      recSwitch: true,
      storePageId: 10002,
      channelGroupId: '10',
      channelId: channelID,
      channelName,
      lastColumnStyle: 3,
      fromColumnId: '1',
      pageFlag: String(page),
      theaterSubscriptSwitch: true,
    };
    const data = await this.call(hemaCodeList, payload);
    const items = hemaVideoItems(data);
    if (page > 1 && items.length === 0) {
      return [];
    }
    const cards = [];
    const seen = new Set();
    for (const item of items) {
      const card = this.card(item, channelName);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('河马列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    wd = String(wd || '').trim();
    if (wd === '') {
      throw new Error('河马搜索关键词为空');
    }
    if (page < 1) page = 1;
    const data = await this.call(hemaCodeSearch, { keyword: wd, page, size: 15 });
    const items = [];
    for (const raw of anyList(data.searchVos)) {
      if (raw && typeof raw === 'object' && !Array.isArray(raw)) items.push(raw);
    }
    const cards = [];
    const seen = new Set();
    for (const item of items) {
      const card = this.card(item, '');
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('河马搜索无结果: ' + wd);
    }
    return cards;
  }

  async Detail(id) {
    id = String(id || '').trim();
    if (id === '') {
      throw new Error('无效的河马剧集 ID');
    }
    const infoRes = await this.call(hemaCodeDetail, { bookId: id });
    const info = infoRes?.videoInfo;
    if (!info || typeof info !== 'object' || Array.isArray(info)) {
      throw new Error('河马详情无数据: ' + id);
    }
    const detail = {
      vod_id: id,
      vod_name: cleanText(mapString(info, 'bookName')),
      vod_class: cleanText(mapString(info, 'finishStatusCn')),
      vod_content: truncate(cleanText(mapString(info, 'introduction')), 400),
      vod_pic: '',
      episodes: [],
      episode_count: 0,
    };
    const cover = mapString(info, 'coverWap');
    if (cover !== '') detail.vod_pic = this.media.imgProxyURL(cover, `${hemaSiteBase}/`);
    const chapterRes = await this.call(hemaCodeChapters, { bookId: id, chapterMin: 1, chapterMax: 10000 });
    const seen = new Set();
    const chapterList = anyList(chapterRes.chapterList);
    for (let i = 0; i < chapterList.length; i++) {
      const chapter = chapterList[i];
      if (!chapter || typeof chapter !== 'object' || Array.isArray(chapter)) continue;
      const chapterID = mapString(chapter, 'chapterId');
      if (chapterID === '') continue;
      let order = atoiDefault(mapString(chapter, 'chapterIndex'), 0);
      if (order < 1) order = i + 1;
      if (seen.has(order)) continue;
      seen.add(order);
      detail.episodes.push({
        no: order,
        name: firstNonEmpty(cleanText(mapString(chapter, 'chapterName')), `第${order}集`),
        url: `hema://${id}/${chapterID}`,
      });
    }
    detail.episodes.sort((a, b) => a.no - b.no);
    detail.episode_count = detail.episodes.length;
    if (detail.episodes.length === 0) {
      throw new Error('河马详情无剧集: ' + id);
    }
    if (detail.vod_name === '') {
      detail.vod_name = '河马短剧 ' + id;
    }
    return detail;
  }

  async Play(playURL) {
    const scheme = parsePlayScheme(playURL, 'hema://');
    if (!scheme || scheme.id === '') {
      throw new Error('河马播放参数无效');
    }
    const bookID = scheme.id;
    const chapterID = scheme.extra;
    const data = await this.call(hemaCodePlay, {
      bookId: bookID,
      chapterId: chapterID,
      unClockType: 'pay',
      confirmPay: 2,
      autoPayFlag: true,
      omap: {
        channelName: '精选',
        logId: '17a6500357709bb2547e1e122b438cfc',
        originName: '书城',
        recId: 'bigdata_rec',
        scene: 'nsc_727',
        sceneId: 'dzmf_video_sc_reco',
        strategyId: 'g6y6b5sq',
      },
    });
    if (mapString(data, 'chaptersPayType') !== '免费') {
      throw new Error(`河马章节 ${chapterID} 需付费`);
    }
    const infos = anyList(data.chapterInfo);
    const first = infos[0];
    if (!first || typeof first !== 'object') {
      throw new Error(`河马章节 ${chapterID} 暂无播放地址`);
    }
    const content = first.content;
    if (!content || typeof content !== 'object' || Array.isArray(content)) {
      throw new Error(`河马章节 ${chapterID} 暂无播放地址`);
    }
    let src = mapString(content, 'm3u8720p');
    if (src === '') {
      for (const raw of anyList(content.mp4SwitchUrl)) {
        if (typeof raw === 'string' && raw.trim() !== '') {
          src = raw;
          break;
        }
      }
    }
    if (!isProviderHTTPMediaURL(src)) {
      throw new Error(`河马章节 ${chapterID} 暂无播放地址`);
    }
    return { src, referer: `${hemaSiteBase}/` };
  }
}

function hemaVideoItems(data) {
  const columns = anyList(data?.columnData);
  if (columns.length === 0) return [];
  const first = columns[0];
  if (!first || typeof first !== 'object' || Array.isArray(first)) return [];
  const items = [];
  for (const raw of anyList(first.videoData)) {
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) items.push(raw);
  }
  return items;
}

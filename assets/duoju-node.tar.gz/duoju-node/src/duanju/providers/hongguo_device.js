





import { createCipheriv, createHash, randomBytes } from 'node:crypto';
import { gzipSync } from 'node:zlib';
import { mapString, nestedMap, firstNonEmpty } from '../../core/util.js';
import { hongguoNumericID, hongguoSelectAppMedia } from './hongguo.js';
import { hongguoAppBaseURL } from '../../duanju/consts.js';
import { Sign } from './sign6.js';

export const hongguoDeviceRegisterURL =
  'https://log5-applog-lf.fqnovel.com/service/2/device_register/' +
  '?tt_data=a&cronet_version=8d40f833_2026-03-03&ttnet_version=4.2.243.31-douyin&use_store_region_cookie=1';

export const hongguoDeviceRegisterUA =
  'com.phoenix.read/73932 (Linux; U; Android 16; zh_CN; 25053RT47C; Build/BP2A.250605.031.A3)';


export const hongguoPlaybackUA =
  'com.phoenix.read/71532 (Linux; U; Android 9; SM-N9860; Build/PQ3A.190705.10241111;tt-ok/3.12.13.20)';


const HONGGUO_DEVICE_KDF_SALT = Buffer.from(
  '4dd4c2e6b83162090e52b3c7a6733ba41cb2462b829ab58a196b39db57177524' +
  'f49baf7f08e8d68d26a72e37c1a95a2f1f05a51892aef2949732b62a38aadd58',
  'hex',
);


const HONGGUO_DEVICE_RETRY_COOLDOWN = 60 * 1000;

const deviceState = {
  deviceID: '',
  installID: '',
  failedAt: 0,
};

export function hongguoAppBaseURLValue() {
  return hongguoAppBaseURL;
}



export async function hongguoPlaybackIdentity(client, force = false) {
  if (!force) {
    if (deviceState.deviceID && deviceState.installID) {
      return { deviceID: deviceState.deviceID, installID: deviceState.installID };
    }
    if (deviceState.failedAt && Date.now() - deviceState.failedAt < HONGGUO_DEVICE_RETRY_COOLDOWN) {
      throw new Error('红果播放身份暂不可用，请稍后重试');
    }
  }
  try {
    const ids = await registerHongguoPlaybackDevice(client);
    deviceState.deviceID = ids.deviceID;
    deviceState.installID = ids.installID;
    deviceState.failedAt = 0;
    return ids;
  } catch (err) {
    deviceState.failedAt = Date.now();
    throw err;
  }
}

function hongguoRegisterID(payload, name) {
  for (const key of [`${name}_str`, name]) {
    const value = payload ? payload[key] : undefined;
    if (typeof value === 'string' && hongguoNumericID.test(value) && /[1-9]/.test(value)) return value;
    if (typeof value === 'number' && Number.isSafeInteger(value) && value > 0) return String(value);
  }
  return '';
}

function hongguoRandomUUID() {
  const buffer = randomBytes(16);
  buffer[6] = (buffer[6] & 0x0f) | 0x40;
  buffer[8] = (buffer[8] & 0x3f) | 0x80;
  const hex = buffer.toString('hex');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}




export function hongguoDeviceRegisterBody(now) {
  const header = {
    display_name: '红果免费短剧', update_version_code: 73932, manifest_version_code: 73932,
    app_version_minor: '7.3.9.32', aid: 8662, channel: 'update_64', package: 'com.phoenix.read',
    app_version: '7.3.9.32', version_code: 73932, sdk_version: '3.7.0-rc.34-fanqie-xiaoshuo',
    sdk_target_version: 29, git_hash: '3a88f4e', os: 'Android', os_version: '16', os_api: 36,
    device_model: '25053RT47C', device_brand: 'Redmi', device_manufacturer: 'Redmi',
    cpu_abi: 'arm64-v8a', release_build: 'b5e187f', density_dpi: 520, display_density: 'mdpi',
    resolution: '1280x2772', language: 'zh', timezone: 8, access: 'wifi', not_request_sender: 0,
    carrier: 'CHINA MOBILE', mcc_mnc: '46000', rom: 'eng.root.20231116.160340',
    rom_version: 'W528JS release-keys', cdid: hongguoRandomUUID(),
    sig_hash: '56a962410c494bbaf0b58dba20cae56f', openudid: randomBytes(8).toString('hex'),
    clientudid: hongguoRandomUUID(), ipv6_list: [], region: 'CN', tz_name: 'Asia/Shanghai',
    tz_offset: 28800, sim_region: 'cn', sim_serial_number: [], oaid_may_support: false,
    req_id: hongguoRandomUUID(), device_platform: 'android',
    custom: {
      account_region_src: 'fallback', account_region: 'cn', host_bit: 64,
      dragon_device_type: 'phone',
    },
    pre_installed_channel: '', apk_first_install_time: now, is_system_app: 0,
    sdk_flavor: 'china', guest_mode: 0,
  };
  const plain = Buffer.from(JSON.stringify({ magic_tag: 'ss_app_log', header, _gen_time: now }), 'utf8');
  const compressed = gzipSync(plain);

  const random = randomBytes(32);
  const inner = createHash('sha512').update(random).digest();
  const derived = createHash('sha512').update(inner).update(HONGGUO_DEVICE_KDF_SALT).digest();

  const digest = createHash('sha512').update(compressed).digest();
  const payload = Buffer.concat([digest, compressed]);
  const padding = 16 - (payload.length % 16);
  const padded = Buffer.concat([payload, Buffer.alloc(padding, padding)]);
  const encrypted = createCipheriv('aes-128-cbc', derived.subarray(0, 16), derived.subarray(16, 32))
    .setAutoPadding(false);
  const body = Buffer.concat([
    Buffer.from('746305100000', 'hex'),
    random,
    Buffer.concat([encrypted.update(padded), encrypted.final()]),
  ]);
  return body;
}


export async function registerHongguoPlaybackDevice(client) {
  const now = Date.now();
  const body = hongguoDeviceRegisterBody(now);
  const headers = {
    'User-Agent': hongguoDeviceRegisterUA,
    Accept: 'application/json',
    'Content-Type': 'application/octet-stream;tt-data=a',
    'log-encode-type': 'gzip',
    'x-ss-dp': '8662',
    'x-ss-req-ticket': String(now),
    'x-vc-bdturing-sdk-version': '4.0.3.cn',
    lc: '101',
    'sdk-version': '2',
    'passport-sdk-version': '5051452',
    'x-neptune': '-8|50:51:59:30:40:47:49:39',
    'x-ss-stub': createHash('md5').update(body).digest('hex').toUpperCase(),
  };
  const resp = await client.doCustom('POST', hongguoDeviceRegisterURL, body, headers);
  const content = await resp.buffer();
  if (resp.status !== 200) {
    throw new Error(`红果播放身份注册失败: HTTP ${resp.status}`);
  }
  let parsed;
  try {
    parsed = JSON.parse(content.toString('utf8'));
  } catch {
    throw new Error('红果播放身份注册返回格式异常');
  }
  const data = nestedMap(parsed, 'data') || parsed;
  const deviceID = hongguoRegisterID(data, 'device_id');
  const installID = hongguoRegisterID(data, 'install_id');
  if (!deviceID || !installID) {
    throw new Error('红果播放身份注册未返回有效设备号');
  }
  return { deviceID, installID };
}


export async function hongguoPlaybackModel(client, videoID) {
  let { deviceID, installID } = await hongguoPlaybackIdentity(client);
  const baseParams = {
    ac: 'wifi', channel: 'update_64', aid: '8662', app_name: 'novelread',
    version_code: '71332', version_name: '7.1.3.32', device_platform: 'android',
    os: 'android', ssmix: 'a', device_type: '25053RT47C', device_brand: 'Redmi',
    language: 'zh', os_api: '36', os_version: '16', manifest_version_code: '71332',
    resolution: '1280*2772', dpi: '520', update_version_code: '71332',
    host_abi: 'arm64-v8a', dragon_device_type: 'phone', pv_player: '71332',
    compliance_status: '0', need_personal_recommend: '1', player_so_load: '1',
    is_android_pad_screen: '0',
  };
  const payload = JSON.stringify({
    biz_param: {
      detail_page_version: 0, device_level: 3, disable_digg_stat: false,
      need_all_video_definition: true, need_mp4_align: false,
      use_os_player: false, use_server_dns: false, video_platform: 1024,
    },
    mixed_video_id_map: { '1004': [videoID] },
  });
  const headers = {
    
    
    'User-Agent': hongguoPlaybackUA,
    Accept: 'application/json; charset=utf-8,application/x-protobuf',
    'Content-Type': 'application/json; charset=UTF-8',
    'x-xs-from-web': '0',
    'sdk-version': '2',
  };
  
  const attempts = 5;
  let lastErr = null;
  let emptyStreak = 0;
  const payloadBuf = Buffer.from(payload, 'utf8');
  for (let attempt = 0; attempt < attempts; attempt++) {
    if (attempt > 0) {
      await new Promise((r) => setTimeout(r, attempt * 700));
      if (emptyStreak >= 2) {
        emptyStreak = 0;
        try {
          ({ deviceID, installID } = await hongguoPlaybackIdentity(client, true));
        } catch {}
      }
    }
    const params = {
      ...baseParams,
      device_id: deviceID,
      iid: installID,
      _rticket: String(Date.now()),
    };
    const rawQuery = Object.keys(params).sort()
      .map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(params[k])}`).join('&');
    const target = `${hongguoAppBaseURLValue()}/novel/player/multi_video_model/v1/?${rawQuery}`;
    try {
      const reqHeaders = { ...headers, ...Sign(target, payloadBuf) };
      const resp = await client.doCustom('POST', target, payloadBuf, reqHeaders);
      const content = await resp.buffer();
      if (resp.status !== 200) throw new Error(`红果播放接口 HTTP ${resp.status}`);
      if (content.length === 0) {
        emptyStreak++;
        throw new Error('红果播放接口未返回数据');
      }
      emptyStreak = 0;
      let parsed;
      try {
        parsed = JSON.parse(content.toString('utf8'));
      } catch {
        throw new Error('红果播放接口返回格式异常');
      }
      const code = firstNonEmpty(mapString(parsed, 'code', 'Code'));
      if (code !== '' && code !== '0') {
        throw new Error(`红果播放接口暂不可用（${code.slice(0, 20)}）`);
      }
      const entry = nestedMap(nestedMap(parsed, 'data'), videoID) || {};
      let model = entry.video_model;
      if (typeof model === 'string') {
        try {
          model = JSON.parse(model);
        } catch {
          model = null;
        }
      }
      if (!model || typeof model !== 'object' || Object.keys(model).length === 0) {
        throw new Error('红果播放接口未返回该集片源');
      }
      return model;
    } catch (err) {
      lastErr = err;
      if (String(err.message).includes('暂不可用')) throw err;
    }
  }
  throw lastErr;
}


export async function resolveHongguoAppMedia(client, videoID, signedPath) {
  if (!hongguoNumericID.test(videoID)) {
    throw new Error('红果视频 ID 无效');
  }
  let unsignedErr = null;
  try {
    const model = await hongguoPlaybackModel(client, videoID);
    return hongguoMediaFromModel(client, model);
  } catch (err) {
    unsignedErr = err;
  }
  if (signedPath) {
    try {
      const model = await signedPath(videoID);
      return hongguoMediaFromModel(client, model);
    } catch (err) {
      throw new Error(`红果取流失败：无签名路径(${unsignedErr.message})；签名路径(${err.message})`);
    }
  }
  throw unsignedErr;
}


async function hongguoMediaFromModel(client, model) {
  if (!model || Object.keys(model).length === 0) {
    throw new Error('红果未返回片源模型');
  }
  let primaryErr = null;
  try {
    const media = hongguoSelectAppMedia(model);
    if (media && media.url) return media;
    primaryErr = new Error('红果未返回兼容的媒体');
  } catch (err) {
    primaryErr = err;
  }
  const fallback = await hongguoFallbackMedia(client, model);
  if (fallback && fallback.url) return fallback;
  throw primaryErr;
}


async function hongguoFallbackMedia(client, model) {
  const address = hongguoFallbackAddress(model ? model.fallback_api : undefined);
  if (!address) return null;
  let parsed;
  try {
    parsed = new URL(address);
  } catch {
    return null;
  }
  if (parsed.protocol !== 'https:' ||
      (!parsed.hostname.endsWith('fqnovel.com') && !parsed.hostname.endsWith('snssdk.com'))) {
    return null;
  }
  try {
    const resp = await client.fetchWith(address, 'https://hongguoduanju.com/');
    const text = (await resp.buffer()).toString('utf8');
    const outer = JSON.parse(text);
    const info = nestedMap(outer, 'video_info') || nestedMap(outer, 'data') || {};
    return hongguoSelectAppMedia(info);
  } catch {
    return null;
  }
}

export function hongguoFallbackAddress(value) {
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      if (parsed && typeof parsed.fallback_api === 'string') return parsed.fallback_api;
    } catch {}
    return value;
  }
  if (Array.isArray(value)) return value.length > 0 && typeof value[0] === 'string' ? value[0] : '';
  if (value && typeof value === 'object') return typeof value.fallback_api === 'string' ? value.fallback_api : '';
  return '';
}

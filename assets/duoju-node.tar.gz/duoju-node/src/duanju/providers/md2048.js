

import { mapString, firstNonEmpty, cleanText, parsePlayScheme } from '../../core/util.js';
import { truncate } from '../shared.js';
import { Mirror, withMirror, httpStatusSwitch, noSwitch, atoiStrict } from './nine.js';

const md2048Hosts = [
  'https://2048ai.vip',
  'https://mdcmai4.xyz',
  'https://2048ai.xyz',
  'https://mdcmai5.xyz',
];

const md2048Cats = [
  { id: 'cat-29', name: 'AI短剧' },
  { id: 'cat-6', name: '麻豆原创AI' },
  { id: 'cat-9', name: '麻豆传媒' },
  { id: 'cat-13', name: '清纯少女' },
  { id: 'cat-2', name: 'AV中文字幕' },
  { id: 'cat-1', name: '国产自拍' },
  { id: 'cat-4', name: '探花大神' },
  { id: 'cat-7', name: '91大神' },
  { id: 'cat-14', name: '重口调教' },
  { id: 'cat-22', name: '白虎嫩妹' },
  { id: 'cat-23', name: '家庭乱伦' },
  { id: 'cat-19', name: '黑料吃瓜' },
  { id: 'posts', name: '吃瓜图文' },
  { id: 'all', name: '全部视频' },
];

const reMD2048Digits = /^\d+$/;

function md2048Abs(host, raw) {
  raw = String(raw ?? '').trim();
  if (raw === '') return '';
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  return host + '/' + raw.replace(/^\/+/, '');
}

function md2048PageQuery(page, size) {
  return 'page=' + page + '&size=' + size;
}

export class Md2048Provider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
    this.mirror = new Mirror('2048', md2048Hosts, client, (host) => this.probe(host));
  }

  async probe(host) {
    await this.call(host, '/videos?page=1&size=1');
  }

  async call(host, path) {
    let result;
    try {
      result = await this.client.fetchWithHeaders(
        'GET',
        host + '/api/v1' + path,
        { Referer: host + '/', Accept: 'application/json, text/plain, */*' },
        null,
      );
    } catch (err) {
      throw new Error('2048 请求失败: ' + err.message);
    }
    const sw = httpStatusSwitch(result.status, null);
    if (sw) throw new Error('2048 请求失败: ' + sw.message);
    let decoded;
    try {
      decoded = JSON.parse(result.raw.toString('utf8'));
    } catch {
      throw new Error('2048 接口返回非 JSON: ' + host);
    }
    if (!decoded || typeof decoded !== 'object' || Array.isArray(decoded)) {
      throw new Error('2048 接口返回非 JSON: ' + host);
    }
    const data = decoded.data && typeof decoded.data === 'object' && !Array.isArray(decoded.data) ? decoded.data : null;
    if (decoded.code !== 200 || !data) {
      const msg = decoded.message ? String(decoded.message) : '无数据';
      throw noSwitch(new Error('2048 接口返回异常: ' + msg));
    }
    return data;
  }

  async api(path) {
    return withMirror(this.mirror, (host) => this.call(host, path));
  }

  md2048Card(host, kind, item) {
    const num = mapString(item, 'id');
    if (num === '' || !reMD2048Digits.test(num)) return null;
    const title = mapString(item, 'title').trim();
    if (title === '') return null;
    const card = {
      vod_id: kind + '-' + num,
      vod_name: title,
      vod_pic: '',
      vod_remarks: '',
      vod_class: '',
      vod_score: '',
      vod_content: '',
    };
    const cover = md2048Abs(host, firstNonEmpty(mapString(item, 'coverUrl'), mapString(item, 'cover')));
    if (cover !== '') {
      if (item.coverEncrypted === true) card.vod_pic = this.media.imgProxyURL(cover, host + '/');
      else card.vod_pic = cover;
    }
    card.vod_class = mapString(item, 'categoryName');
    const parts = [];
    const secs = mapString(item, 'durationSec');
    if (secs !== '' && secs !== '0') {
      const n = atoiStrict(secs);
      if (n !== null && n > 0) parts.push(Math.floor(n / 60) + '分' + (n % 60) + '秒');
    }
    const views = mapString(item, 'viewCount');
    if (views !== '' && views !== '0') {
      const n = atoiStrict(views);
      if (n !== null && n > 0) parts.push(n + '次播放');
    }
    const author = mapString(item, 'authorName');
    if (author !== '') parts.push(author);
    card.vod_remarks = parts.join(' · ');
    card.vod_content = truncate(cleanText(firstNonEmpty(mapString(item, 'description'), mapString(item, 'content'))), 200);
    return card;
  }

  async md2048Items(path) {
    return withMirror(this.mirror, async (host) => {
      const data = await this.call(host, path);
      const items = Array.isArray(data.items) ? data.items : [];
      const kind = path.startsWith('/posts') ? 'posts' : 'videos';
      const cards = [];
      const seen = new Set();
      for (const raw of items) {
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) continue;
        const card = this.md2048Card(host, kind, raw);
        if (!card || seen.has(card.vod_id)) continue;
        seen.add(card.vod_id);
        cards.push(card);
      }
      if (cards.length === 0) throw new Error('2048 列表无内容: ' + path);
      return cards;
    });
  }

  async listByCat(cat, query) {
    if (cat === 'posts') return this.md2048Items('/posts?' + query);
    if (cat === 'all') return this.md2048Items('/videos?' + query);
    if (typeof cat === 'string' && cat.startsWith('cat-')) {
      const id = cat.slice(4);
      return this.md2048Items('/videos?categoryId=' + id + '&' + query);
    }
    return this.md2048Items('/videos?' + query);
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    if (!cat) cat = md2048Cats[0].id;
    const query = md2048PageQuery(page, 24);
    try {
      return await this.listByCat(cat, query);
    } catch (err) {
      if (page > 1) return [];
      throw err;
    }
  }

  async Search() {
    throw new Error('2048 站点搜索需登录，暂不支持关键词搜索');
  }

  async md2048DetailItem(id) {
    const trimmed = String(id ?? '').trim();
    const idx = trimmed.indexOf('-');
    const kind = idx >= 0 ? trimmed.slice(0, idx) : '';
    const num = idx >= 0 ? trimmed.slice(idx + 1) : '';
    if (idx < 0 || num === '' || !reMD2048Digits.test(num)) {
      throw noSwitch(new Error('无效的 2048 ID: ' + id));
    }
    let path = '/videos/' + num;
    if (kind === 'posts') path = '/posts/' + num;
    return withMirror(this.mirror, async (host) => {
      const data = await this.call(host, path);
      return { data, host };
    });
  }

  async Detail(id) {
    const { data: item, host } = await this.md2048DetailItem(id);
    const kind = String(id ?? '').split('-', 2)[0];
    const card = this.md2048Card(host, kind, item);
    if (!card) throw new Error('2048 详情数据不完整: ' + id);
    return {
      vod_id: id,
      vod_name: card.vod_name,
      vod_pic: card.vod_pic,
      vod_content: card.vod_content,
      vod_class: card.vod_class,
      episodes: [{ no: 1, name: firstNonEmpty(card.vod_remarks, '播放'), url: 'md2048://' + id + '/1' }],
      episode_count: 1,
    };
  }

  async Play(playURL) {
    const parsed = parsePlayScheme(playURL, 'md2048://');
    if (!parsed) throw new Error('2048 播放参数无效');
    const { data: item, host: gotHost } = await this.md2048DetailItem(parsed.id);
    let host = gotHost;
    if (!host) host = this.mirror.current();
    const raw = mapString(item, 'videoUrl', 'playUrl', 'url').trim();
    if (raw === '') throw new Error('2048 该内容没有视频源');
    const src = host + '/api/v1/m3u8/proxy?path=' + encodeURIComponent(raw).replace(/%20/g, '+');
    return { src, referer: host + '/' };
  }
}

export const platformCats = md2048Cats.map((c) => ({ ...c }));

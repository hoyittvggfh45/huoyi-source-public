
import { createHash } from 'node:crypto';
import { cleanText, encodeQuery, firstNonEmpty, mapString } from '../../core/util.js';
import { baiduFeedBase, baiduVideoBase } from '../consts.js';
import { truncate } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { haokanQuery, playletDetailData, playletRelateURL, providerSchemeArg, mapStringList } from './haokan.js';

const baiduAppUserAgent = 'Dalvik/2.1.0 (Linux; U; Android 9; 22081212C Build/PQ3B.190801.002) Talos/1.8.13 SP-engine/3.47.0 bd_dvt/1 baiduboxapp/15.21.0.10 (Baidu; P1 9)';
const baiduAppCookie = 'BAIDUCUID=0Ovgu0uAvu0_828wj8Hma_8i28joaSuIlOvOigiAH88ikS8f0k35aD6mA';

const baiduVideoQuery = haokanQuery;

const baiduCats = [
  { id: 'quanbu', name: '全部' },
  { id: 'shenyi', name: '神医' },
  { id: 'dushi', name: '都市' },
  { id: 'xiandaiyanqing', name: '现代言情' },
  { id: 'yineng', name: '异能' },
  { id: 'nixi', name: '逆袭' },
  { id: 'tianchong', name: '甜宠' },
  { id: 'zongcai', name: '总裁' },
  { id: 'mengbao', name: '萌宝' },
  { id: 'zhanshen', name: '战神' },
  { id: 'gongdouzhaidou', name: '宫斗宅斗' },
  { id: 'shenhao', name: '神豪' },
  { id: 'nuelian', name: '虐恋' },
  { id: 'shanhun', name: '闪婚' },
  { id: 'xuanhuan', name: '玄幻' },
  { id: 'chuanyuechongsheng', name: '穿越重生' },
  { id: 'niandai', name: '年代' },
  { id: 'jiatinglunli', name: '家庭伦理' },
  { id: 'gudaiyanqing', name: '古代言情' },
  { id: 'wuxiawuda', name: '武侠武打' },
  { id: 'zhuixu', name: '赘婿' },
  { id: 'qingchunxiaoyuan', name: '青春校园' },
];

export const platformCats = baiduCats.map((c) => ({ ID: c.id, Name: c.name }));

function baiduTheme(cat) {
  cat = String(cat || '').trim();
  for (const item of baiduCats) {
    if (item.id === cat && item.id !== 'quanbu') return item.name;
  }
  return '';
}

function baiduCatName(cat) {
  cat = String(cat || '').trim();
  for (const item of baiduCats) {
    if (item.id === cat) return item.name;
  }
  return baiduCats[0].name;
}

function baiduFeedVersion(stamp) {
  return createHash('md5').update(`${stamp}v2`).digest('hex');
}

export class BaiduProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async call(target, form) {
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'User-Agent': baiduAppUserAgent,
      Cookie: baiduAppCookie,
    };
    const { raw, status } = await this.client.fetchWithHeaders('POST', target, headers, encodeQuery(form));
    if (status >= 400) {
      throw new Error(`百度接口 HTTP ${status}`);
    }
    return JSON.parse(raw.toString('utf8'));
  }

  async listItems(cat, page) {
    if (page < 1) page = 1;
    const stamp = Math.floor(Date.now() / 1000);
    const payload = {
      data: {
        refreshIndex: page,
        timestamp: stamp,
        version: baiduFeedVersion(stamp),
        themes: [
          { kind: '综合', names: ['新剧'] },
          { kind: '题材', names: [baiduTheme(cat)] },
        ],
        extRequest: { flow_tabid: '13' },
        from: 'feed',
        page: 'channel_video_landing',
        pd: 'feed',
        theme: '',
      },
    };
    const form = { data: JSON.stringify(payload) };
    const target = `${baiduFeedBase}/feedapi/v1/videoserver/playlets/list?service=bdbox`;
    const raw = await this.call(target, form);
    const items = raw?.data?.items;
    if (!Array.isArray(items)) {
      throw new Error('百度列表解析失败');
    }
    return items;
  }

  card(item, catName) {
    const id = mapString(item, 'collId');
    const title = cleanText(mapString(item, 'title'));
    if (id === '' || title === '') return null;
    const card = { vod_id: id, vod_name: title, vod_class: catName, vod_score: '', vod_content: '' };
    const cover = mapString(item, 'img');
    if (cover !== '') card.vod_pic = this.media.imgProxyURL(cover, `${baiduFeedBase}/`);
    card.vod_remarks = firstNonEmpty(cleanText(mapString(item, 'updateStatus')), '全集');
    return card;
  }

  async List(cat, page) {
    const items = await this.listItems(cat, page);
    if (page > 1 && items.length === 0) {
      return [];
    }
    const catName = baiduCatName(cat);
    const cards = [];
    const seen = new Set();
    for (const item of items) {
      const card = this.card(item, catName);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('百度列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    throw new Error('百度接口未提供搜索');
  }

  async detail(playletID) {
    playletID = String(playletID || '').trim();
    if (playletID === '') {
      throw new Error('无效的百度剧集 ID');
    }
    const form = { playlet_id: playletID, vid: 'undefined' };
    const target = `${baiduVideoBase}/haokan/ui-video/playlet/rec/detail?${baiduVideoQuery}`;
    const raw = await this.call(target, form);
    return playletDetailData(JSON.stringify(raw));
  }

  async Detail(id) {
    const collID = String(id || '').trim();
    if (collID === '') {
      throw new Error('无效的百度剧集 ID');
    }
    const data = await this.detail(collID);
    const vids = mapStringList(data.vid_list);
    if (vids.length === 0) {
      throw new Error('百度详情无剧集: ' + collID);
    }
    const detail = {
      vod_id: collID,
      vod_name: cleanText(mapString(data, 'playlet_title')),
      vod_pic: '',
      vod_content: '',
      vod_class: '百度',
      episodes: [],
      episode_count: 0,
    };
    detail.vod_content = truncate(cleanText(mapString(data, 'description')), 400);
    const cover = mapString(data, 'playlet_poster');
    if (cover !== '') detail.vod_pic = this.media.imgProxyURL(cover, `${baiduVideoBase}/`);
    for (let i = 0; i < vids.length; i++) {
      const no = i + 1;
      detail.episodes.push({ no, name: `第${no}集`, url: 'baidu://' + vids[i] });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') {
      detail.vod_name = '百度短剧 ' + collID;
    }
    return detail;
  }

  async Play(playURL) {
    let vid;
    try {
      vid = providerSchemeArg(playURL, 'baidu://');
    } catch {
      throw new Error('百度播放参数无效');
    }
    const form = { method: 'post', vid };
    const target = `${baiduVideoBase}/appui/api?cmd=video/relate&${baiduVideoQuery}`;
    const raw = await this.call(target, form);
    const src = playletRelateURL(JSON.stringify(raw));
    if (!isProviderHTTPMediaURL(src)) {
      throw new Error(`百度剧集无播放地址: ${vid}`);
    }
    return { src, referer: `${baiduVideoBase}/` };
  }
}

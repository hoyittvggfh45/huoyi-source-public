

import { parsePlayScheme, cleanText } from '../../core/util.js';
import { stripTagsSimple } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { huangguo2SiteBase } from '../consts.js';
import { unescapeHTML } from './nine.js';

export const huangguo2Cats = [
  { id: 'all', name: '全部' },
  { id: '3', name: '连续剧' },
  { id: '1', name: 'MV/音乐剧' },
  { id: '2', name: '短片' },
  { id: '4', name: '片段' },
  { id: 'updates', name: '最近更新' },
  { id: 'ranking', name: '排行榜' },
];

const reHG2CardStart = /<article\s+class="[^"]*\bvideo-card\b[^"]*"[^>]*>/gi;
const reHG2CardHref = /href="(?:https?:\/\/[^/"]+)?\/(series|video)\/([0-9a-zA-Z]+)"/i;
const reHG2ImgSrc = /<img[^>]*\bsrc="([^"]+)"/i;
const reHG2ImgAlt = /<img[^>]*\balt="([^"]*)"/i;
const reHG2Remarks = /bg-black\/(?:50|55)[^>]*>([^<]+)</i;
const reHG2CardMeta = /<p\s+class="[^"]*\bmt-2\b[^"]*font-mono-meta[^"]*"[^>]*>([^<]*)</i;
const reHG2Title = /<p[^>]*class="[^"]*\bmt-2\.5\b[^"]*"[^>]*>([\s\S]*?)<\/p>/is;
const reHG2H1 = /<h1[^>]*>([\s\S]*?)<\/h1>/is;
const reHG2OgImage = /<meta[^>]*property="og:image"[^>]*content="([^"]+)"/i;
const reHG2MetaDesc = /<meta[^>]*name="description"[^>]*content="([^"]*)"/i;
const reHG2VideoLink = /href="(?:https?:\/\/[^/"]+)?\/video\/([0-9a-zA-Z]+)"/gi;
const reHG2DataHLS = /data-hls="([^"]+)"/i;

function huangguo2Abs(raw) {
  raw = String(raw ?? '').trim();
  if (raw === '') return '';
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  return huangguo2SiteBase + '/' + raw.replace(/^\/+/, '');
}

function huangguo2CatName(cat) {
  for (const c of huangguo2Cats) {
    if (c.id === cat) return c.name;
  }
  return '';
}


function huangguo2ID(id) {
  id = String(id ?? '').trim().replace(/^\/+|\/+$/g, '');
  const idx = id.indexOf('-');
  if (idx < 0) return null;
  const kind = id.slice(0, idx);
  const key = id.slice(idx + 1);
  if (key === '' || (kind !== 'series' && kind !== 'video')) return null;
  return { kind, key };
}

export class HuangguoProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async fetch(path) {
    const resp = await this.client.fetchBytes(huangguo2SiteBase + path, huangguo2SiteBase + '/');
    const body = await resp.buffer();
    if (body.length === 0) throw new Error('黄果2空响应: ' + path);
    return body.toString('utf8');
  }

  huangguo2Cards(pageHTML, catName) {
    const starts = [...pageHTML.matchAll(reHG2CardStart)].map((m) => m.index);
    const cards = [];
    const seen = new Set();
    for (let i = 0; i < starts.length; i++) {
      const start = starts[i];
      const end = i + 1 < starts.length ? starts[i + 1] : pageHTML.length;
      const block = pageHTML.slice(start, end);
      const href = reHG2CardHref.exec(block);
      if (!href) continue;
      const id = href[1] + '-' + href[2];
      if (seen.has(id)) continue;
      let name = '';
      const alt = reHG2ImgAlt.exec(block);
      if (alt) name = cleanText(unescapeHTML(alt[1]));
      if (name === '') {
        const t = reHG2Title.exec(block);
        if (t) name = cleanText(stripTagsSimple(t[1]));
      }
      if (name === '') continue;
      seen.add(id);
      const card = { vod_id: id, vod_name: name, vod_pic: '', vod_remarks: '', vod_class: catName, vod_score: '', vod_content: '' };
      const img = reHG2ImgSrc.exec(block);
      if (img) {
        const cover = huangguo2Abs(img[1]);
        if (cover !== '') card.vod_pic = this.media.imgProxyURL(cover, huangguo2SiteBase + '/');
      }
      const rem = reHG2Remarks.exec(block);
      if (rem) card.vod_remarks = cleanText(rem[1]);
      const meta = reHG2CardMeta.exec(block);
      if (meta) {
        const m = cleanText(meta[1]);
        const idx = m.indexOf(' · ');
        if (idx > 0) {
          card.vod_class = m.slice(0, idx);
          card.vod_content = m;
        } else {
          card.vod_content = m;
        }
      }
      cards.push(card);
    }
    return cards;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    if (cat === '') cat = 'all';
    let path;
    if (cat === 'updates' || cat === 'ranking') {
      path = `/${cat}?page=${page}`;
    } else {
      path = `/videos?category=${encodeURIComponent(cat)}&page=${page}`;
    }
    let body;
    try {
      body = await this.fetch(path);
    } catch (err) {
      if (page > 1 && String(err && err.message).includes('404')) return [];
      throw err;
    }
    const cards = this.huangguo2Cards(body, huangguo2CatName(cat));
    if (cards.length === 0) {
      if (page > 1) return [];
      throw new Error('黄果2列表无内容: ' + path);
    }
    return cards;
  }

  async Search(wd, page) {
    wd = String(wd ?? '').trim();
    if (wd === '') throw new Error('黄果2搜索关键词为空');
    if (page < 1) page = 1;
    let path = '/search?q=' + encodeURIComponent(wd);
    if (page > 1) path += `&page=${page}`;
    const body = await this.fetch(path);
    const cards = this.huangguo2Cards(body, '');
    if (cards.length === 0) throw new Error('黄果2搜索无结果: ' + wd);
    return cards;
  }

  async Detail(id) {
    const parsed = huangguo2ID(id);
    if (!parsed) throw new Error('无效的黄果2 ID: ' + id);
    const { kind, key } = parsed;
    const body = await this.fetch('/' + kind + '/' + encodeURIComponent(key));
    const detail = { vod_id: kind + '-' + key, vod_name: '', vod_pic: '', vod_content: '', vod_class: '', episodes: [], episode_count: 0 };
    const h1 = reHG2H1.exec(body);
    if (h1) detail.vod_name = cleanText(unescapeHTML(stripTagsSimple(h1[1])));
    const desc = reHG2MetaDesc.exec(body);
    if (desc) detail.vod_content = cleanText(unescapeHTML(desc[1]));
    const og = reHG2OgImage.exec(body);
    if (og) {
      const cover = huangguo2Abs(og[1]);
      if (cover !== '') detail.vod_pic = this.media.imgProxyURL(cover, huangguo2SiteBase + '/');
    }
    if (kind === 'video') {
      detail.episodes.push({ no: 1, name: '播放', url: 'huangguo2://video-' + key + '/1' });
    } else {
      const seen = new Set();
      for (const m of body.matchAll(reHG2VideoLink)) {
        const vid = m[1];
        if (seen.has(vid)) continue;
        seen.add(vid);
        detail.episodes.push({
          no: detail.episodes.length + 1,
          name: `第${detail.episodes.length + 1}集`,
          url: 'huangguo2://video-' + vid + '/1',
        });
      }
      detail.episodes.sort((a, b) => a.no - b.no);
    }
    if (detail.episodes.length === 0) throw new Error('黄果2详情页无剧集: ' + id);
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') detail.vod_name = '黄果2 ' + key;
    return detail;
  }

  async Play(playURL) {
    let id = '';
    let ok = false;
    const scheme = parsePlayScheme(playURL, 'huangguo2://');
    if (scheme) {
      id = scheme.id;
      ok = true;
    }
    if (!ok) {
      id = String(playURL ?? '').replace(/^\/+|\/+$/g, '');
      const i = id.indexOf('huangguo.video/');
      if (i >= 0) id = id.slice(i + 'huangguo.video/'.length);
      id = id.replace(/^\/+|\/+$/g, '');
      const last = id.lastIndexOf('/');
      if (last >= 0) id = id.slice(0, last);
      ok = id.startsWith('video-') || id.startsWith('series-');
    }
    const parsed = huangguo2ID(id);
    if (!ok || !parsed) throw new Error('黄果2播放参数无效');
    const { kind, key } = parsed;
    if (kind !== 'video') throw new Error('黄果2连续剧请选择具体分集');
    const body = await this.fetch('/video/' + encodeURIComponent(key));
    const m = reHG2DataHLS.exec(body);
    if (!m || !m[1].includes('.m3u8')) throw new Error('黄果2播放页无媒体地址: ' + key);
    const src = huangguo2Abs(m[1]);
    if (!isProviderHTTPMediaURL(src)) throw new Error('黄果2播放地址无效: ' + key);
    return { src, referer: huangguo2SiteBase + '/' };
  }
}


export class Huangguo2Provider extends HuangguoProvider {}

export const platformCats = huangguo2Cats;

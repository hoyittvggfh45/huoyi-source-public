

import { atoiDefault, cleanText, mapString, parsePlayScheme } from '../../core/util.js';
import { xingxingAPIBase, xingxingCommonQuery } from '../consts.js';
import { truncate } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';


export function queryEscape(s) {
  return encodeURIComponent(String(s ?? ''))
    .replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`)
    .replace(/%20/g, '+');
}


export function queryUnescape(s) {
  return decodeURIComponent(String(s ?? '').replace(/\+/g, '%20'));
}

const xingxingCats = [
  { id: 'jingxuan', name: '精选', resourceID: '1287' },
  { id: 'remen', name: '热门', resourceID: '1288' },
  { id: 'xinju', name: '新剧', resourceID: '1289' },
];

export const platformCats = xingxingCats.map((c) => ({ ID: c.id, Name: c.name }));

function xingxingResource(cat) {
  let hit = xingxingCats[0];
  for (const c of xingxingCats) {
    if (c.id === cat) {
      hit = c;
      break;
    }
  }
  return [hit.resourceID, hit.name];
}

export class XingxingProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async call(path) {
    const headers = {
      Accept: 'application/json, text/plain, */*',
      'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.87 Safari/537.36',
    };
    const { raw, status } = await this.client.fetchWithHeaders('GET', xingxingAPIBase + path, headers);
    if (status >= 400) {
      throw new Error(`星星接口 HTTP ${status}`);
    }
    if (raw.length === 0) {
      throw new Error('星星接口空响应');
    }
    return JSON.parse(raw.toString('utf8'));
  }

  card(item, catName) {
    const id = mapString(item, 'id');
    const title = cleanText(mapString(item, 'name'));
    if (id === '' || title === '') return null;
    const intro = cleanText(mapString(item, 'introduction'));
    const card = {
      vod_id: `${id}@${queryEscape(title)}@${queryEscape(intro)}`,
      vod_name: title,
      vod_class: catName,
      vod_content: truncate(intro, 400),
      vod_score: '',
    };
    const cover = mapString(item, 'icon');
    if (cover !== '') card.vod_pic = this.media.imgProxyURL(cover, `${xingxingAPIBase}/`);
    let heat = mapString(item, 'heat');
    if (heat === '') heat = '0';
    card.vod_remarks = `${heat}万播放`;
    return card;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    const [resourceID, display] = xingxingResource(cat);
    const path = `/novel-api/app/pageModel/getResourceById?${xingxingCommonQuery}&resourceId=${queryEscape(resourceID)}&pageNum=${page}&pageSize=20`;
    const body = await this.call(path);
    const items = body?.data?.datalist;
    if (!Array.isArray(items)) {
      throw new Error('星星列表解析失败');
    }
    if (page > 1 && items.length === 0) {
      return [];
    }
    const cards = [];
    const seen = new Set();
    for (const item of items) {
      const card = this.card(item, display);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('星星列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    throw new Error('星星接口未提供搜索');
  }

  async chapters(bookID) {
    const path = `/novel-api/basedata/book/getChapterList?${xingxingCommonQuery}&bookId=${queryEscape(bookID)}`;
    const body = await this.call(path);
    const data = body?.data;
    if (!Array.isArray(data)) {
      throw new Error('星星详情解析失败');
    }
    if (data.length === 0) {
      throw new Error('星星详情无剧集: ' + bookID);
    }
    return data;
  }

  async Detail(id) {
    id = String(id || '').trim();
    if (id === '') {
      throw new Error('无效的星星剧集 ID');
    }
    const parts = id.split('@');
    const bookID = parts[0];
    let name = '';
    if (parts.length > 1) {
      try {
        name = cleanText(queryUnescape(parts[1]));
      } catch {}
    }
    let desc = '';
    if (parts.length > 2) {
      try {
        desc = cleanText(queryUnescape(parts[2]));
      } catch {}
    }
    const items = await this.chapters(bookID);
    const detail = {
      vod_id: id,
      vod_name: name,
      vod_content: truncate(desc, 400),
      vod_class: '星星',
      vod_pic: '',
      episodes: [],
      episode_count: 0,
    };
    for (let i = 0; i < items.length; i++) {
      const seq = i + 1;
      if (xingxingShortPlayURL(items[i]) === '') continue;
      detail.episodes.push({ no: seq, name: `第${seq}集`, url: `xingxing://${bookID}/${seq}` });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.episodes.length === 0) {
      throw new Error('星星详情无剧集: ' + bookID);
    }
    if (detail.vod_name === '') {
      detail.vod_name = '星星短剧 ' + bookID;
    }
    return detail;
  }

  async Play(playURL) {
    const scheme = parsePlayScheme(playURL, 'xingxing://');
    if (!scheme || scheme.id === '') {
      throw new Error('星星播放参数无效');
    }
    const bookID = scheme.id;
    let seq = atoiDefault(scheme.extra, 1);
    if (seq < 1) seq = 1;
    const items = await this.chapters(bookID);
    if (seq > items.length) {
      throw new Error(`星星详情缺第${seq}集`);
    }
    const src = xingxingShortPlayURL(items[seq - 1]);
    if (!isProviderHTTPMediaURL(src)) {
      throw new Error(`星星第${seq}集暂无播放地址`);
    }
    return { src, referer: `${xingxingAPIBase}/` };
  }
}

export function xingxingShortPlayURL(item) {
  if (!item || typeof item !== 'object') return '';
  const list = item.shortPlayList;
  if (!Array.isArray(list) || list.length === 0) return '';
  const first = list[0];
  if (!first || typeof first !== 'object') return '';
  const chapters = first.chapterShortPlayVoList;
  if (!Array.isArray(chapters) || chapters.length === 0) return '';
  const chapter = chapters[0];
  if (!chapter || typeof chapter !== 'object') return '';
  return mapString(chapter, 'shortPlayUrl');
}

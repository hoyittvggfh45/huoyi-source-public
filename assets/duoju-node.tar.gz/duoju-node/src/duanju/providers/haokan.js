

import { atoiDefault, cleanText, encodeQuery, mapString, parsePlayScheme } from '../../core/util.js';
import { haokanSiteBase } from '../consts.js';
import { truncate } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';

export const haokanQuery = 'log=vhk&tn=1020970b&ctn=1008350n&blur=1';

export const haokanUserAgent = 'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36';

const haokanCats = [
  { id: 'reboduanju', name: '热播剧' },
  { id: 'xinju', name: '新剧' },
  { id: 'zhanshen', name: '战神' },
  { id: 'shenhao', name: '神豪' },
  { id: 'shenyi', name: '神医' },
  { id: 'tianchong', name: '甜宠' },
  { id: 'zhuixu', name: '赘婿' },
  { id: 'chuanyue', name: '穿越重生' },
  { id: 'yineng', name: '异能' },
  { id: 'nuelian', name: '虐恋' },
  { id: 'gongdou', name: '宫斗宅斗' },
  { id: 'xuanhuan', name: '玄幻' },
];

export const platformCats = haokanCats.map((c) => ({ ID: c.id, Name: c.name }));

const haokanTagIDs = {
  reboduanju: '1',
  xinju: '2',
  zhanshen: '1001',
  shenhao: '2001',
  shenyi: '1002',
  tianchong: '1007',
  zhuixu: '1003',
  chuanyue: '2004',
  yineng: '2005',
  nuelian: '1006',
  gongdou: '2006',
  xuanhuan: '2009',
};

function haokanTagID(cat) {
  const value = haokanTagIDs[String(cat || '').trim()];
  return value !== undefined ? value : haokanTagIDs.reboduanju;
}

function haokanCatName(cat) {
  cat = String(cat || '').trim();
  for (const item of haokanCats) {
    if (item.id === cat) return item.name;
  }
  return haokanCats[0].name;
}

export function mapStringList(raw) {
  if (!Array.isArray(raw)) return [];
  const out = [];
  for (const item of raw) {
    const text = mapString({ v: item }, 'v').trim();
    if (text !== '') out.push(text);
  }
  return out;
}

export function bestClarityURL(raw) {
  if (!Array.isArray(raw)) return '';
  let best = '';
  let bestQuality = -1;
  for (const item of raw) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) continue;
    const src = mapString(item, 'url');
    if (src === '') continue;
    const quality = atoiDefault(mapString(item, 'video_quality'), 0);
    if (quality > bestQuality) {
      best = src;
      bestQuality = quality;
    }
  }
  return best;
}

export function playletDetailData(raw) {
  let envelope;
  try {
    envelope = JSON.parse(typeof raw === 'string' ? raw : Buffer.from(raw).toString('utf8'));
  } catch {
    throw new Error('playlet 详情解析失败');
  }
  const data = envelope && typeof envelope === 'object' ? envelope.data : undefined;
  if (data === undefined || data === null || typeof data !== 'object' || Array.isArray(data)) {
    throw new Error('playlet 详情解析失败');
  }
  return data;
}

export function playletRelateURL(raw) {
  let top;
  try {
    top = JSON.parse(typeof raw === 'string' ? raw : Buffer.from(raw).toString('utf8'));
  } catch {
    return '';
  }
  if (!top || typeof top !== 'object') return '';
  let payload = top['video/relate'];
  if (payload === undefined) return '';
  if (typeof payload === 'string') {
    try {
      payload = JSON.parse(payload);
    } catch {
      return '';
    }
  }
  const curVideo = payload && payload.data ? payload.data.cur_video : null;
  return bestClarityURL(curVideo ? curVideo.clarityUrl : undefined);
}



export function providerSchemeArg(raw, prefix) {
  raw = String(raw || '').trim();
  if (!raw.startsWith(prefix)) {
    throw new Error('播放地址前缀不匹配');
  }
  const scheme = parsePlayScheme(raw, prefix);
  if (scheme) return scheme.id;
  const value = raw.slice(prefix.length).trim();
  if (value === '' || value.includes('/')) {
    throw new Error('播放地址参数无效');
  }
  return value;
}

export function splitHaokanID(id) {
  const parts = String(id || '').trim().split('@');
  const playletID = parts[0].trim();
  const vid = parts.length === 2 ? parts[1].trim() : '';
  return [playletID, vid];
}

export class HaokanProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async call(target, form) {
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'User-Agent': haokanUserAgent,
    };
    const { raw, status } = await this.client.fetchWithHeaders('POST', target, headers, encodeQuery(form));
    if (status >= 400) {
      throw new Error(`好看接口 HTTP ${status}`);
    }
    return JSON.parse(raw.toString('utf8'));
  }

  async listItems(cat, page) {
    if (page < 1) page = 1;
    const form = { tag_id: haokanTagID(cat), pn: String(page), rn: '12' };
    const target = `${haokanSiteBase}/haokan/ui-feed/playletTagsFeed?${haokanQuery}`;
    const raw = await this.call(target, form);
    const list = raw?.data?.list;
    if (!Array.isArray(list)) {
      throw new Error('好看列表解析失败');
    }
    return list;
  }

  card(item, catName) {
    const id = mapString(item, 'playlet_id');
    const title = cleanText(mapString(item, 'playlet_title'));
    if (id === '' || title === '') return null;
    const card = { vod_id: id, vod_name: title, vod_class: catName };
    if (item.vod_score === undefined) card.vod_score = '';
    if (item.vod_content === undefined) card.vod_content = '';
    const cover = mapString(item, 'playlet_poster');
    if (cover !== '') card.vod_pic = this.media.imgProxyURL(cover, `${haokanSiteBase}/`);
    const num = atoiDefault(mapString(item, 'episodes_num'), 0);
    if (num > 0) card.vod_remarks = `更新${num}集`;
    return card;
  }

  async List(cat, page) {
    const items = await this.listItems(cat, page);
    if (page > 1 && items.length === 0) {
      return [];
    }
    const catName = haokanCatName(cat);
    const cards = [];
    const seen = new Set();
    for (const item of items) {
      const card = this.card(item, catName);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('好看列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    throw new Error('好看接口未提供搜索');
  }

  async detail(playletID, vid) {
    playletID = String(playletID || '').trim();
    if (playletID === '') {
      throw new Error('无效的好看剧集 ID');
    }
    if (vid === '') vid = 'undefined';
    const form = { playlet_id: playletID, vid };
    const target = `${haokanSiteBase}/haokan/ui-video/playlet/rec/detail?${haokanQuery}`;
    const raw = await this.call(target, form);
    return playletDetailData(JSON.stringify(raw));
  }

  async Detail(id) {
    const [playletID, vid] = splitHaokanID(id);
    if (playletID === '') {
      throw new Error('无效的好看剧集 ID');
    }
    const data = await this.detail(playletID, vid);
    const vids = mapStringList(data.vid_list);
    if (vids.length === 0) {
      throw new Error('好看详情无剧集: ' + playletID);
    }
    const detail = {
      vod_id: playletID,
      vod_name: cleanText(mapString(data, 'playlet_title')),
      vod_pic: '',
      vod_content: '',
      vod_class: '好看',
      episodes: [],
      episode_count: 0,
    };
    detail.vod_content = truncate(cleanText(mapString(data, 'description')), 400);
    const cover = mapString(data, 'playlet_poster');
    if (cover !== '') detail.vod_pic = this.media.imgProxyURL(cover, `${haokanSiteBase}/`);
    for (let i = 0; i < vids.length; i++) {
      const no = i + 1;
      detail.episodes.push({ no, name: `第${no}集`, url: 'haokan://' + vids[i] });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') {
      detail.vod_name = '好看短剧 ' + playletID;
    }
    return detail;
  }

  async relate(vid) {
    vid = String(vid || '').trim();
    if (vid === '') {
      throw new Error('好看播放 vid 为空');
    }
    const form = { method: 'post', vid };
    const target = `${haokanSiteBase}/appui/api?cmd=video/relate&${haokanQuery}`;
    const raw = await this.call(target, form);
    const src = playletRelateURL(JSON.stringify(raw));
    if (src === '') {
      throw new Error(`好看剧集无播放地址: ${vid}`);
    }
    return src;
  }

  async Play(playURL) {
    let vid;
    try {
      vid = providerSchemeArg(playURL, 'haokan://');
    } catch {
      throw new Error('好看播放参数无效');
    }
    const src = await this.relate(vid);
    if (!isProviderHTTPMediaURL(src)) {
      throw new Error(`好看剧集无播放地址: ${vid}`);
    }
    return { src, referer: `${haokanSiteBase}/` };
  }
}

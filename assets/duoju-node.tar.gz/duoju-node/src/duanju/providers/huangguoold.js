


import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { mapString, firstNonEmpty, cleanText, atoiDefault, resolveURL, parsePlayScheme, encodeQuery } from '../../core/util.js';
import { truncate } from '../shared.js';
import {
  legacyAPIBase,
  legacyCDNBase,
  legacyCoverHost,
  legacyCoverHost2,
  legacyDefaultDevID,
  legacyDevIDHolder,
  legacyFrontendBase,
  legacyXUserAgent,
} from '../consts.js';
import { withTimeout } from './nine.js';

const legacyAPIFallbacks = [
  legacyAPIBase,
  'https://d18ka9rqpfd3lo.cloudfront.net',
  'https://d37n0wjehmw08f.cloudfront.net',
];

const legacyTabIDs = [
  '6a928dfedb2cc815f75d7213',
  '6a928de7db2cc815f75d720f',
  '6a928dccdb2cc815f75d720b',
  '6a928d54db2cc815f75d7201',
];

const legacyCats = [
  { id: 'tab-0', name: '黄果原创' },
  { id: 'tab-1', name: 'AI成人短剧' },
  { id: 'tab-2', name: 'AI成人漫剧' },
  { id: 'tab-3', name: 'AI魔改' },
];

const reLegacyScript = /<script\b[^>]*\bsrc=["']([^"']+)["']/gi;
const reLegacyCFHost = /https:\/\/[a-z0-9]+\.cloudfront\.net/g;
const reLegacyQuoteRe = /["']([A-Za-z]+)["']\s*[:,]\s*["']([^"'\r\n]+)["']/g;

function legacyPad(raw) {
  const pad = 16 - (raw.length % 16);
  const out = Buffer.alloc(raw.length + pad);
  raw.copy(out);
  out.fill(pad, raw.length);
  return out;
}

function legacyUnpad(raw) {
  if (raw.length === 0 || raw.length % 16 !== 0) return raw;
  const pad = raw[raw.length - 1];
  if (pad <= 0 || pad > 16 || pad > raw.length) return raw;
  for (let i = raw.length - pad; i < raw.length; i++) {
    if (raw[i] !== pad) return raw;
  }
  return raw.subarray(0, raw.length - pad);
}

class LegacyTokenError extends Error {
  constructor(code, msg) {
    super('黄果旧版令牌失效（' + code + '）');
    this.name = 'LegacyTokenError';
    this.code = code;
    this.msg = msg;
  }
}

function legacySessionPath() {
  let dir = '';
  if (process.platform === 'win32') {
    dir = process.env.LOCALAPPDATA || '';
  } else {
    dir = process.env.XDG_CACHE_HOME || (os.homedir() ? path.join(os.homedir(), '.cache') : '');
  }
  if (!dir) return '';
  return path.join(dir, 'duoju-lite', 'huangguoold-session.json');
}

function legacyValidDevID(value) {
  if (typeof value !== 'string' || value.length !== 29) return false;
  if (!/^[0-9a-fA-F]{16}$/.test(value.slice(0, 16))) return false;
  return /^[+-]?[0-9]+$/.test(value.slice(16));
}

function legacyValidToken(value) {
  return typeof value === 'string' && value !== '' && value.length <= 4096 && !/[\r\n\t ]/.test(value);
}

function legacyNewDevID() {
  try {
    return randomBytes(8).toString('hex').toUpperCase() + String(Date.now());
  } catch {
    return '';
  }
}


function plainString(m, key) {
  if (!m) return '';
  const v = m[key];
  return typeof v === 'string' ? v : '';
}

function legacyCoverURL(raw) {
  raw = String(raw ?? '').trim();
  if (!raw) return '';
  if (raw.startsWith('//')) raw = 'https:' + raw;
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  raw = raw.replace(/^\/+/, '');
  if (raw.includes('..')) return '';
  if (raw.startsWith('upload/') || raw.startsWith('upload_01/')) return legacyCoverHost2 + '/' + raw;
  return legacyCoverHost + '/' + raw;
}

function legacyTagNames(detail) {
  const raw = detail.tagNames;
  if (Array.isArray(raw)) {
    const names = [];
    for (const item of raw) {
      if (typeof item === 'string') {
        const text = item.trim();
        if (text) names.push(text);
      }
    }
    if (names.length > 0) return names.join(',');
  }
  return mapString(detail, 'anchor');
}

function legacyParseChapters(raw) {
  if (raw === undefined || raw === null) return [];
  const valid = (arr) =>
    Array.isArray(arr) &&
    arr.length > 0 &&
    arr.every((x) => x && typeof x === 'object' && !Array.isArray(x) && (x.currentEpisode === undefined || typeof x.currentEpisode === 'number'));
  if (valid(raw)) return raw;
  if (raw && typeof raw === 'object' && !Array.isArray(raw) && valid(raw.list)) return raw.list;
  return [];
}

function legacyFindChapter(chapters, episode) {
  for (let index = 0; index < chapters.length; index++) {
    const chapter = chapters[index];
    let no = typeof chapter.currentEpisode === 'number' ? chapter.currentEpisode : 0;
    if (no <= 0) no = index + 1;
    if (no === episode) return chapter;
  }
  if (episode >= 1 && episode <= chapters.length) return chapters[episode - 1];
  return null;
}

function legacyCatName(cat) {
  for (const c of legacyCats) {
    if (c.id === cat) return c.name;
  }
  return '';
}

export class HuangguoOldProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
    this.protocol = { interfaceKey: '', paramKey: '', paramIV: '' };
    this.protoAt = 0;
    this.devID = '';
    this.token = '';
    this.loaded = false;
    this.apiBase = '';
    this.apiFail = {};
    this.tabs = [];
    this.tabsAt = 0;
    this.details = new Map();
  }

  legacyEncryptParams(params) {
    const proto = this.protocol;
    if ((proto.paramKey || '').length !== 16 || (proto.paramIV || '').length !== 16) {
      throw new Error('黄果旧版接口协议未就绪');
    }
    const ordered = Object.keys(params).sort();
    let buf = '{';
    ordered.forEach((k, i) => {
      if (i > 0) buf += ',';
      buf += JSON.stringify(k) + ':' + JSON.stringify(params[k]);
    });
    buf += '}';
    const plain = legacyPad(Buffer.from(buf, 'utf8'));
    const cipher = createCipheriv('aes-128-cbc', Buffer.from(proto.paramKey, 'utf8'), Buffer.from(proto.paramIV, 'utf8'));
    cipher.setAutoPadding(false);
    return Buffer.concat([cipher.update(plain), cipher.final()]).toString('base64');
  }

  legacyDecryptResponse(data) {
    const proto = this.protocol;
    if (!proto.interfaceKey) throw new Error('黄果旧版接口协议未就绪');
    const text = String(data ?? '').trim();
    if (!/^[A-Za-z0-9+/]+={0,2}$/.test(text)) throw new Error('黄果旧版响应体格式异常');
    const blob = Buffer.from(text, 'base64');
    if (blob.length < 12) throw new Error('黄果旧版响应体格式异常');
    const nonce = blob.subarray(0, 12);
    const joined = Buffer.concat([Buffer.from(proto.interfaceKey, 'utf8'), nonce]);
    const half = Math.floor(joined.length / 2);
    const seed = createHash('sha256').update(joined).digest();
    const mixed = seed.subarray(8, 24);
    const first = Buffer.concat([mixed, joined.subarray(0, half)]);
    const second = Buffer.concat([joined.subarray(half), mixed]);
    const d = createHash('sha256').update(first).digest();
    const f = createHash('sha256').update(second).digest();
    const key = Buffer.concat([d.subarray(0, 8), f.subarray(8, 24), d.subarray(24)]);
    const iv = Buffer.concat([f.subarray(0, 4), d.subarray(12, 20), f.subarray(28)]);
    let body = blob.subarray(12);
    body = body.subarray(0, body.length - (body.length % 16));
    const decipher = createDecipheriv('aes-256-cbc', key, iv);
    decipher.setAutoPadding(false);
    const out = Buffer.concat([decipher.update(body), decipher.final()]);
    return legacyUnpad(out);
  }

  async legacyFetchText(target, referer) {
    const resp = await this.client.fetchBytes(target, referer);
    const body = await resp.buffer();
    if (body.length === 0) throw new Error('黄果旧版空响应: ' + target);
    return body.toString('utf8');
  }

  async legacyEnsureProtocol() {
    const ready = this.protocol.interfaceKey !== '' && this.protocol.paramKey.length === 16 && this.protocol.paramIV.length === 16;
    const fresh = Date.now() - this.protoAt < 24 * 60 * 60 * 1000;
    if (ready && fresh) return;
    let page;
    try {
      page = await this.legacyFetchText(legacyFrontendBase + '/', legacyFrontendBase + '/');
    } catch (err) {
      throw new Error('获取黄果旧版官网失败: ' + err.message);
    }
    for (const m of page.matchAll(reLegacyScript)) {
      const src = m[1].trim();
      if (!src.includes('/main-') || !src.endsWith('.js')) continue;
      let script;
      try {
        script = await this.legacyFetchText(resolveURL(legacyFrontendBase + '/', src), legacyFrontendBase + '/');
      } catch (err) {
        throw new Error('获取黄果旧版协议脚本失败: ' + err.message);
      }
      const values = {};
      for (const kv of script.matchAll(reLegacyQuoteRe)) {
        if (!(kv[1] in values)) values[kv[1]] = kv[2];
      }
      const proto = {
        interfaceKey: values.interfaceKey || '',
        paramKey: values.parameterKey || '',
        paramIV: values.parameterIv || '',
      };
      if (proto.interfaceKey === '' || proto.paramKey.length !== 16 || proto.paramIV.length !== 16) {
        throw new Error('黄果旧版官网协议已变化，无法识别接口参数');
      }
      this.protocol = proto;
      this.protoAt = Date.now();
      return;
    }
    throw new Error('黄果旧版官网未提供可识别的接口脚本');
  }

  legacyLoadSession() {
    if (this.loaded) return;
    this.loaded = true;
    const filePath = legacySessionPath();
    if (!filePath) return;
    let raw;
    try {
      raw = fs.readFileSync(filePath);
    } catch {
      return;
    }
    let state;
    try {
      state = JSON.parse(raw.toString('utf8'));
    } catch {
      return;
    }
    if (!state || typeof state !== 'object') return;
    if (!legacyValidDevID(state.devID) || !legacyValidToken(state.token)) return;
    this.devID = state.devID;
    this.token = state.token;
    this.apiBase = typeof state.apiBase === 'string' ? state.apiBase : '';
  }

  legacySaveSession() {
    const filePath = legacySessionPath();
    if (!filePath) return;
    const state = { devID: this.devID, token: this.token, apiBase: this.apiBase };
    try {
      fs.mkdirSync(path.dirname(filePath), { recursive: true, mode: 0o700 });
      fs.writeFileSync(filePath, JSON.stringify(state), { mode: 0o600 });
    } catch {}
  }

  legacyDevID() {
    this.legacyLoadSession();
    if (this.devID === '') {
      this.devID = legacyDefaultDevID;
      this.legacySaveSession();
      return legacyDefaultDevID;
    }
    return this.devID;
  }

  legacyRotateDevID() {
    const fresh = legacyNewDevID();
    if (!fresh) return;
    this.devID = fresh;
    this.token = '';
    this.legacySaveSession();
  }

  async legacyAPIBaseFor() {
    if (this.apiBase !== '') return this.apiBase;
    let lastErr = null;
    for (const candidate of legacyAPIFallbacks) {
      const until = this.apiFail[candidate] || 0;
      if (until && Date.now() < until) continue;
      let body = null;
      try {
        const resp = await withTimeout(
          this.client.fetchBytes(candidate + '/api/app/ping/check', legacyFrontendBase + '/'),
          6 * 1000,
        );
        body = await resp.buffer();
      } catch (err) {
        lastErr = err;
        continue;
      }
      let env = null;
      try {
        env = JSON.parse(body.toString('utf8'));
      } catch {
        env = null;
      }
      if (!env || typeof env !== 'object' || Array.isArray(env) || env.code !== 200) {
        lastErr = new Error(candidate + ' 健康检查失败');
        continue;
      }
      this.apiBase = candidate;
      return candidate;
    }
    if (!lastErr) lastErr = new Error('候选域名均在冷却中');
    throw new Error('黄果旧版接口域名不可用: ' + (lastErr.message || String(lastErr)));
  }

  legacyInvalidateAPICall(base) {
    this.apiFail[base] = Date.now() + 60 * 1000;
    if (this.apiBase === base) this.apiBase = '';
  }

  async legacyRaw(method, target0, params, token) {
    await this.legacyEnsureProtocol();
    const base = await this.legacyAPIBaseFor();
    let target = base + target0;
    let body;
    const headers = {
      'Accept': 'application/json',
      'Temp': 'test',
      'Origin': legacyFrontendBase,
      'Referer': legacyFrontendBase + '/',
    };
    const devID = this.legacyDevID();
    headers['X-User-Agent'] = legacyXUserAgent.replace('DevID=' + legacyDevIDHolder, 'DevID=' + devID);
    if (token) headers['Authorization'] = token;
    if (params != null) {
      const encrypted = this.legacyEncryptParams(params);
      if (method === 'GET') {
        const sep = target.includes('?') ? '&' : '?';
        target += sep + 'data=' + encodeURIComponent(encrypted);
      } else {
        body = JSON.stringify({ data: encrypted });
        headers['Content-Type'] = 'application/json';
      }
    }
    const { raw, status } = await this.client.fetchWithHeaders(method, target, headers, body);
    if (status >= 500) {
      this.legacyInvalidateAPICall(base);
      throw new Error('黄果旧版接口 HTTP ' + status);
    }
    let env;
    try {
      env = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('黄果旧版接口响应无法解析');
    }
    if (!env || typeof env !== 'object' || Array.isArray(env)) {
      throw new Error('黄果旧版接口响应无法解析');
    }
    const code = typeof env.code === 'number' ? env.code : 0;
    if (code !== 200) {
      const codeStr = String(code);
      if (codeStr === '5005' || codeStr === '5009') throw new LegacyTokenError(codeStr, env.msg || '');
      const msg = env.msg ? String(env.msg) : codeStr;
      throw new Error('黄果旧版接口返回错误: ' + msg);
    }
    let data = env.data === undefined ? null : env.data;
    if (env.hash === true) {
      const cipher = typeof env.data === 'string' ? env.data : '';
      if (cipher) {
        const plain = this.legacyDecryptResponse(cipher);
        data = JSON.parse(plain.toString('utf8'));
      }
    }
    return data;
  }

  async legacyLogin(devID) {
    const data = await this.legacyRaw('POST', '/api/app/mine/login/h5', { devID, sysType: 'ios', isAppStore: false }, '');
    let payload = {};
    if (data && typeof data === 'object' && !Array.isArray(data)) payload = data;
    if (!legacyValidToken(payload.token)) throw new Error('黄果旧版访客登录未返回令牌');
    return payload.token;
  }

  async legacyEnsureToken(force) {
    this.legacyLoadSession();
    if (force) this.token = '';
    if (this.token) return this.token;
    const devID = this.legacyDevID();
    let token;
    try {
      token = await this.legacyLogin(devID);
    } catch (err) {
      if (devID !== legacyDefaultDevID) throw new Error('黄果旧版访客登录失败: ' + err.message);
      this.legacyRotateDevID();
      try {
        token = await this.legacyLogin(this.legacyDevID());
      } catch (err2) {
        throw new Error('黄果旧版访客登录失败: ' + err2.message);
      }
    }
    this.token = token;
    this.legacySaveSession();
    return token;
  }

  async legacyCall(method, target0, params) {
    const token = await this.legacyEnsureToken(false);
    let data;
    try {
      data = await this.legacyRaw(method, target0, params, token);
      return data;
    } catch (err) {
      if (!(err instanceof LegacyTokenError)) throw err;
    }
    const freshToken = await this.legacyEnsureToken(true);
    return this.legacyRaw(method, target0, params, freshToken);
  }

  async legacyTabs() {
    if (this.tabs.length > 0 && Date.now() - this.tabsAt < 10 * 60 * 1000) return this.tabs;
    const data = await this.legacyCall('GET', '/api/app/playlet-tab/all', null);
    const list = data && typeof data === 'object' && !Array.isArray(data) && Array.isArray(data.list) ? data.list : [];
    if (list.length === 0) throw new Error('黄果旧版接口未返回分类');
    const tabs = [];
    for (const tab of list) {
      if (tab && typeof tab === 'object' && String(tab.id ?? '').trim() !== '') {
        tabs.push({ id: String(tab.id), name: String(tab.name ?? '') });
      }
    }
    if (tabs.length === 0) throw new Error('黄果旧版接口未返回分类');
    this.tabs = tabs;
    this.tabsAt = Date.now();
    return tabs;
  }

  async legacyTabID(cat) {
    cat = String(cat ?? '').trim();
    if (!cat) cat = legacyCats[0].id;
    if (cat.startsWith('tab:')) return cat.slice(4);
    let index = 0;
    if (cat.startsWith('tab-')) {
      const n = atoiDefault(cat.slice(4), -1);
      if (n >= 0) index = n;
    }
    let tabs = null;
    try {
      tabs = await this.legacyTabs();
    } catch {
      tabs = null;
    }
    if (tabs && index < tabs.length) return tabs[index].id;
    if (index < legacyTabIDs.length) return legacyTabIDs[index];
    throw new Error('黄果旧版分类不存在: ' + cat);
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    const tabID = await this.legacyTabID(cat);
    let data;
    try {
      data = await this.legacyCall(
        'GET',
        '/api/app/playlet/home/tab/' + encodeURIComponent(tabID),
        { pageNumber: String(page), pageSize: '24', tabSortType: '1' },
      );
    } catch (err) {
      if (page > 1) return [];
      throw err;
    }
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('黄果旧版列表解析失败');
    const list = Array.isArray(data.list) ? data.list : [];
    const cards = [];
    const seen = new Set();
    const catName = legacyCatName(cat);
    for (const item of list) {
      if (!item || typeof item !== 'object' || Array.isArray(item)) continue;
      const card = this.legacyCard(item, catName);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      if (page > 1) return [];
      throw new Error('黄果旧版列表无内容');
    }
    return cards;
  }

  legacyCard(item, catName) {
    const id = mapString(item, 'id');
    const title = firstNonEmpty(mapString(item, 'title'), mapString(item, 'name'));
    if (!id || !title) return null;
    const card = {
      vod_id: id,
      vod_name: cleanText(title),
      vod_pic: '',
      vod_remarks: '',
      vod_class: '',
      vod_score: '',
      vod_content: '',
    };
    const cover = legacyCoverURL(firstNonEmpty(plainString(item, 'cover'), plainString(item, 'horizontalCover'), plainString(item, 'coverUrl')));
    if (cover) card.vod_pic = this.media.imgProxyURL(cover, legacyFrontendBase + '/');
    card.vod_class = firstNonEmpty(plainString(item, 'tagNames'), mapString(item, 'anchor'), catName);
    card.vod_content = truncate(cleanText(mapString(item, 'summary')), 200);
    const total = atoiDefault(mapString(item, 'totalEpisode'), 0);
    if (total > 0) {
      const updated = atoiDefault(mapString(item, 'updateEpisode'), 0);
      if (updated > 0 && updated < total) card.vod_remarks = '更新至' + updated + '集/共' + total + '集';
      else card.vod_remarks = '共' + total + '集';
    }
    return card;
  }

  async legacyChapters(id) {
    const cached = this.details.get(id);
    if (cached && Date.now() - cached.at < 3 * 60 * 1000) return cached;
    const data = await this.legacyCall('GET', '/api/app/playlet/detail/' + encodeURIComponent(id), null);
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('黄果旧版详情解析失败');
    const entry = {
      title: cleanText(firstNonEmpty(mapString(data, 'title'), mapString(data, 'name'))),
      cover: legacyCoverURL(firstNonEmpty(plainString(data, 'cover'), plainString(data, 'horizontalCover'), plainString(data, 'coverUrl'))),
      desc: truncate(cleanText(mapString(data, 'summary')), 400),
      tags: legacyTagNames(data),
      chapters: [],
      at: Date.now(),
    };
    if (data.chapters !== undefined) {
      entry.chapters = legacyParseChapters(data.chapters);
    }
    if (entry.chapters.length === 0) {
      try {
        const list = await this.legacyCall('GET', '/api/app/playlet-chapter/list/' + encodeURIComponent(id), null);
        entry.chapters = legacyParseChapters(list);
      } catch {}
    }
    if (entry.chapters.length === 0) throw new Error('黄果旧版详情无分集: ' + id);
    this.details.set(id, entry);
    return entry;
  }

  async Detail(id) {
    id = String(id ?? '').trim();
    if (!id) throw new Error('无效的黄果旧版剧集 ID');
    const entry = await this.legacyChapters(id);
    const detail = {
      vod_id: id,
      vod_name: entry.title,
      vod_content: entry.desc,
      vod_class: entry.tags,
      vod_pic: '',
      episodes: [],
    };
    if (entry.cover) detail.vod_pic = this.media.imgProxyURL(entry.cover, legacyFrontendBase + '/');
    const seen = new Set();
    entry.chapters.forEach((chapter, index) => {
      let no = typeof chapter.currentEpisode === 'number' ? chapter.currentEpisode : 0;
      if (no <= 0) no = atoiDefault(chapter.title, 0);
      if (no <= 0) no = index + 1;
      while (seen.has(no)) no++;
      seen.add(no);
      let name = cleanText(chapter.title);
      if (!name) name = '第' + no + '集';
      detail.episodes.push({ no, name, url: 'huangguoold://' + id + '/' + no });
    });
    if (detail.episodes.length === 0) throw new Error('黄果旧版详情无分集: ' + id);
    detail.episodes.sort((a, b) => a.no - b.no);
    detail.episode_count = detail.episodes.length;
    if (!detail.vod_name) detail.vod_name = '黄果旧版 ' + id;
    return detail;
  }

  async Search() {
    throw new Error('黄果旧版接口未提供搜索');
  }

  async Play(playURL) {
    const parsed = parsePlayScheme(playURL, 'huangguoold://');
    if (!parsed || !parsed.id) throw new Error('黄果旧版播放参数无效');
    let episode = atoiDefault(parsed.extra, 1);
    if (episode < 1) episode = 1;
    const entry = await this.legacyChapters(parsed.id);
    const chapter = legacyFindChapter(entry.chapters, episode);
    if (!chapter) throw new Error('黄果旧版第' + episode + '集不存在');
    if (String(chapter.videoUrl ?? '').trim() === '') throw new Error('黄果旧版该分集没有播放地址');
    const token = await this.legacyEnsureToken(false);
    const base = await this.legacyAPIBaseFor();
    const target = base + '/api/app/vid/h5/m3u8/' + encodeURIComponent(String(chapter.videoUrl).replace(/^\/+|\/+$/g, '')) +
      '?' + encodeQuery({ token, c: legacyCDNBase });
    return { src: this.media.proxyURL(target, legacyFrontendBase + '/', ''), referer: legacyFrontendBase + '/' };
  }
}

export const platformCats = legacyCats.map((c) => ({ ...c }));

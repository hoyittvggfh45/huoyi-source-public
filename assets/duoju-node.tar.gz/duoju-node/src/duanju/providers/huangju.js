

import { mapString, firstNonEmpty, resolveURL } from '../../core/util.js';
import { truncate, huangjuNewestCat } from '../shared.js';
import { isProviderHTTPMediaURL, providerCoverAddress } from '../web_shared.js';
import { uuidLike, httpStatusSwitch, Mirror, withMirror } from './nine.js';

const huangjuUserAgent = 'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36';

const reHuangjuSignedCookie = /(?:^|[,;\s])CloudFront-(Policy|Signature|Key-Pair-Id)\s*=\s*([^;,\s"']+)/g;

const huangjuHosts = ['huangju.net', 'yanyushorttv.cc', 'yanyushorttv.top'];

function huangjuSiteOf(host) {
  if (!host) host = huangjuHosts[0];
  return 'https://' + host;
}

function huangjuAPIOf(host) {
  if (!host) host = huangjuHosts[0];
  return 'https://api.' + host;
}


function validHuangjuIDStrict(value) {
  if (typeof value !== 'string' || value === '' || value.length > 450) return false;
  if (value.trim() !== value || value === '.' || value === '..') return false;
  for (const ch of value) {
    if ('/\\:?#%|"<>'.includes(ch)) return false;
    const code = ch.charCodeAt(0);
    if (code <= 31 || code === 127) return false;
  }
  return true;
}

function huangjuInteger(value, maximum) {
  const text = mapString({ v: value }, 'v');
  if (!/^[+-]?[0-9]+$/.test(text)) return [0, false];
  const number = parseInt(text, 10);
  return [number, Number.isFinite(number) && number >= 0 && number <= maximum];
}

function huangjuCategoryNames(row) {
  const names = [];
  const seen = new Set();
  const add = (value) => {
    let name = '';
    if (value && typeof value === 'object' && !Array.isArray(value)) name = mapString(value, 'name');
    else if (typeof value === 'string') name = value;
    name = name.trim();
    if (name !== '' && [...name].length <= 48 && !seen.has(name) && names.length < 24) {
      seen.add(name);
      names.push(name);
    }
  };
  add(row ? row.category : undefined);
  if (row && Array.isArray(row.categories)) {
    for (const entry of row.categories) add(entry);
  }
  return names;
}

function huangjuPayload(value) {
  if (value && typeof value === 'object' && !Array.isArray(value) && value.data != null && value.id == null && value.items == null && value.url == null) {
    return value.data;
  }
  return value;
}

function jsonValid(data) {
  try {
    JSON.parse(data.toString('utf8'));
    return true;
  } catch {
    return false;
  }
}

function huangjuExpiration(value) {
  const text = mapString({ v: value }, 'v');
  if (/^[+-]?[0-9]+$/.test(text)) {
    const stamp = Number(text);
    if (Number.isSafeInteger(stamp) && stamp > 0 && stamp <= 253402300799000) {
      return stamp > 100000000000 ? stamp : stamp * 1000;
    }
    return null;
  }
  const parsed = Date.parse(text);
  return Number.isFinite(parsed) ? parsed : null;
}

function huangjuMediaCookie(headers, expiresAt) {
  const expires = huangjuExpiration(expiresAt);
  if (expires !== null && Date.now() >= expires) {
    throw new Error('黄剧媒体凭证已过期，请检查设备时间后重试');
  }
  const cookies = {};
  let setCookies = headers ? headers['set-cookie'] : undefined;
  if (setCookies === undefined || setCookies === null) setCookies = [];
  else if (!Array.isArray(setCookies)) setCookies = [setCookies];
  for (const header of setCookies) {
    for (const m of String(header).matchAll(reHuangjuSignedCookie)) {
      cookies['CloudFront-' + m[1]] = m[2];
    }
  }
  const values = [];
  for (const name of ['CloudFront-Policy', 'CloudFront-Signature', 'CloudFront-Key-Pair-Id']) {
    const value = cookies[name] || '';
    let ascii = true;
    for (const ch of value) {
      const code = ch.charCodeAt(0);
      if (code <= 32 || code >= 127) { ascii = false; break; }
    }
    if (value === '' || value.length > 8192 || /[,;"\\]/.test(value) || !ascii) {
      throw new Error('黄剧未返回完整的媒体凭证，请重试');
    }
    values.push(name + '=' + value);
  }
  return values.join('; ');
}

function huangjuCards(value, site) {
  const payload = huangjuPayload(value);
  const row = payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
  const list = Array.isArray(row.items) ? row.items : [];
  if (list.length === 0) throw new Error('黄剧目录没有返回内容');
  const cards = [];
  const seen = new Set();
  for (const entry of list) {
    const item = entry && typeof entry === 'object' && !Array.isArray(entry) ? entry : {};
    const id = mapString(item, 'id');
    const slug = mapString(item, 'slug');
    const title = mapString(item, 'title');
    if (!validHuangjuIDStrict(id) || !validHuangjuIDStrict(slug) || title === '') continue;
    const sourceID = slug + '-' + id;
    if (seen.has(sourceID)) continue;
    seen.add(sourceID);
    const card = {
      vod_id: sourceID,
      vod_name: truncate(title, 256),
      vod_pic: providerCoverAddress(item.coverUrl, site + '/'),
      vod_remarks: '',
      vod_class: firstNonEmpty(...huangjuCategoryNames(item)),
      vod_score: mapString(item, 'score'),
      vod_content: truncate(mapString(item, 'description'), 500),
    };
    switch (mapString(item, 'status')) {
      case 'completed': card.vod_remarks = '完结'; break;
      case 'ongoing': card.vod_remarks = '连载中'; break;
    }
    const [episodes, ok] = huangjuInteger(item.totalEpisodes, 100000);
    if (ok && episodes > 0) {
      if (card.vod_remarks !== '') card.vod_remarks += ' ';
      card.vod_remarks += '全' + episodes + '集';
    }
    cards.push(card);
  }
  if (cards.length === 0) throw new Error('黄剧目录中没有可识别的剧集');
  return cards;
}

export class HuangjuProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media || null;
    this.deviceID = '';
    this.token = '';
    this.host = '';
    this.mirror = new Mirror('黄剧', huangjuHosts, client, (host) => this.probe(host));
  }

  use(host) {
    this.host = host;
  }

  siteURL() {
    return huangjuSiteOf(this.host);
  }

  apiURL() {
    return huangjuAPIOf(this.host);
  }

  async probe(host) {
    let result;
    try {
      result = await this.client.fetchWithHeaders('GET', huangjuSiteOf(host) + '/', { 'User-Agent': huangjuUserAgent }, null);
    } catch (err) {
      return err;
    }
    const sw = httpStatusSwitch(result.status, null);
    if (sw) return sw;
    if (result.raw.length < 512) throw new Error('黄剧镜像响应过短');
  }

  async request(method, address, body, token) {
    const headers = {
      'User-Agent': huangjuUserAgent,
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'zh-CN,zh;q=0.9',
      'Referer': this.siteURL() + '/',
      'Origin': this.siteURL(),
    };
    if (body && body.length > 0) headers['Content-Type'] = 'application/json';
    if (token) headers['Authorization'] = 'Bearer ' + token;
    return this.client.doCustom(method, address, body, headers);
  }

  clearToken(token) {
    if (this.token === token) this.token = '';
  }

  async guestToken() {
    if (this.token) return this.token;
    if (!this.deviceID) this.deviceID = uuidLike();
    const deviceID = this.deviceID;
    const body = JSON.stringify({ deviceId: deviceID });
    const resp = await this.request('POST', this.apiURL() + '/auth/guest', body, '');
    let data;
    try {
      data = await resp.buffer();
    } catch (err) {
      throw new Error('读取黄剧授权响应失败: ' + err.message);
    }
    if (data.length > (64 << 10) + 1) data = data.subarray(0, (64 << 10) + 1);
    if (resp.status < 200 || resp.status >= 300) {
      throw new Error('黄剧授权 HTTP ' + resp.status + ': ' + truncate(data.toString('utf8'), 200));
    }
    let decoded;
    try {
      decoded = JSON.parse(data.toString('utf8'));
    } catch {
      throw new Error('黄剧授权响应格式无效');
    }
    const row = decoded && typeof decoded === 'object' && !Array.isArray(decoded) ? decoded : {};
    let token = mapString(row, 'token');
    if (token === '') {
      const nested = row.data;
      if (nested && typeof nested === 'object' && !Array.isArray(nested)) token = mapString(nested, 'token');
    }
    let printable = true;
    for (const ch of token) {
      const code = ch.charCodeAt(0);
      if (code <= 32 || code >= 127) { printable = false; break; }
    }
    if (token === '' || token.length > 8192 || !printable) {
      throw new Error('黄剧未返回有效的访客授权');
    }
    this.token = token;
    return token;
  }

  async get(route, query, limit) {
    for (let attempt = 0; attempt < 2; attempt++) {
      const token = await this.guestToken();
      let address = this.apiURL() + route;
      if (query && Object.keys(query).length > 0) {
        const keys = Object.keys(query).sort();
        address += '?' + keys.map((k) => encodeURIComponent(k) + '=' + encodeURIComponent(query[k])).join('&');
      }
      const resp = await this.request('GET', address, null, token);
      let data;
      let readErr = false;
      try {
        data = await resp.buffer();
      } catch {
        readErr = true;
        data = Buffer.alloc(0);
      }
      if (attempt === 0 && (resp.status === 401 || resp.status === 403) && !readErr && data.length <= limit && jsonValid(data)) {
        this.clearToken(token);
        continue;
      }
      if (resp.status < 200 || resp.status >= 300) {
        throw new Error('黄剧 HTTP ' + resp.status + ': ' + truncate(data.toString('utf8'), 200));
      }
      if (readErr || data.length > limit) throw new Error('黄剧返回的数据过大或读取失败');
      let decoded;
      try {
        decoded = JSON.parse(data.toString('utf8'));
      } catch {
        throw new Error('黄剧返回的数据格式无效');
      }
      return { value: decoded, headers: resp.headers };
    }
    throw new Error('黄剧访客授权已失效，请重试');
  }

  async List(cat, page) {
    return withMirror(this.mirror, async (host) => {
      this.use(host);
      return this.list(cat, page);
    });
  }

  async list(cat, page) {
    if (page < 1) page = 1;
    const values = { page: String(page) };
    if (!cat || cat === 'all') values.sort = 'hot';
    else if (cat === huangjuNewestCat) values.sort = 'new';
    else values.category = cat;
    const { value } = await this.get('/dramas', values, 4 << 20);
    return huangjuCards(value, this.siteURL());
  }

  async Search(wd, page) {
    return withMirror(this.mirror, async (host) => {
      this.use(host);
      return this.search(wd, page);
    });
  }

  async search(wd, page) {
    if (page < 1) page = 1;
    const { value } = await this.get('/dramas', { page: String(page), q: wd }, 4 << 20);
    return huangjuCards(value, this.siteURL());
  }

  async Detail(id) {
    return withMirror(this.mirror, async (host) => {
      this.use(host);
      return this.detail(id);
    });
  }

  async detail(id) {
    id = String(id ?? '').trim();
    if (!validHuangjuIDStrict(id) || !id.includes('-')) throw new Error('无效的黄剧剧集 ID');
    const { value } = await this.get('/dramas/' + encodeURIComponent(id), null, 8 << 20);
    const payload = huangjuPayload(value);
    const row = payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
    const dramaID = mapString(row, 'id');
    if (!validHuangjuIDStrict(dramaID) || !id.endsWith('-' + dramaID)) {
      throw new Error('黄剧详情与请求剧集不符');
    }
    const detail = {
      vod_id: id,
      vod_name: truncate(firstNonEmpty(mapString(row, 'title'), id), 256),
      vod_pic: providerCoverAddress(row.coverUrl, this.siteURL() + '/'),
      vod_content: truncate(mapString(row, 'description'), 12000),
      vod_class: firstNonEmpty(...huangjuCategoryNames(row)),
      episodes: [],
    };
    const episodes = Array.isArray(row.episodes) ? row.episodes : [];
    episodes.forEach((entry, index) => {
      const episode = entry && typeof entry === 'object' && !Array.isArray(entry) ? entry : {};
      if (typeof episode.playable === 'boolean' && !episode.playable) return;
      const episodeID = mapString(episode, 'id');
      if (!validHuangjuIDStrict(episodeID)) return;
      let number = index + 1;
      const [epNo, ok] = huangjuInteger(episode.epNo, 100000);
      if (ok && epNo > 0) number = epNo;
      detail.episodes.push({
        no: number,
        name: '第 ' + number + ' 集',
        url: 'huangju://' + encodeURIComponent(episodeID),
      });
    });
    if (detail.episodes.length === 0) throw new Error('黄剧详情没有返回剧集列表');
    detail.episodes.sort((a, b) => a.no - b.no);
    detail.episode_count = detail.episodes.length;
    return detail;
  }

  async Play(playURL) {
    return withMirror(this.mirror, async (host) => {
      this.use(host);
      return this.play(playURL);
    });
  }

  async play(playURL) {
    let episodeID = String(playURL ?? '').replace(/^huangju:\/\//, '');
    try {
      episodeID = decodeURIComponent(episodeID);
    } catch {}
    if (!validHuangjuIDStrict(episodeID)) throw new Error('黄剧播放参数无效');
    const { value, headers } = await this.get('/play/' + encodeURIComponent(episodeID), null, 64 << 10);
    const payload = huangjuPayload(value);
    const row = payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
    const cookie = huangjuMediaCookie(headers, row.expiresAt);
    let media = mapString(row, 'url');
    if (media === '') throw new Error('黄剧未返回播放地址');
    if (!media.startsWith('http://') && !media.startsWith('https://')) {
      media = resolveURL(this.siteURL() + '/', media);
    }
    if (!isProviderHTTPMediaURL(media)) throw new Error('黄剧播放地址无效');
    return { src: media, referer: this.siteURL() + '/', cookie };
  }

  async categories() {
    return withMirror(this.mirror, async (host) => {
      this.use(host);
      return this.categoriesAt();
    });
  }

  async categoriesAt() {
    const { value } = await this.get('/categories', null, 256 << 10);
    const payload = huangjuPayload(value);
    const rows = Array.isArray(payload) ? payload : [];
    const cats = [{ id: huangjuNewestCat, name: '最新' }];
    const seen = new Set([huangjuNewestCat]);
    for (const entry of rows) {
      const row = entry && typeof entry === 'object' && !Array.isArray(entry) ? entry : {};
      const id = mapString(row, 'slug');
      const name = mapString(row, 'name');
      if (id === '' || id === 'hot' || name === '' || [...name].length > 48 || seen.has(id)) continue;
      seen.add(id);
      cats.push({ id, name });
    }
    cats.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
    return cats;
  }
}

export const platformCats = [{ id: huangjuNewestCat, name: '最新' }];

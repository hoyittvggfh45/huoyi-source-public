
import crypto from 'node:crypto';
import { atoiDefault, cleanText, firstNonEmpty, parsePlayScheme } from '../../core/util.js';
import { pkcs7Pad, pkcs7Unpad } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import {
  niuniuAPIBase,
  niuniuCSJBase,
  niuniuSiteID,
  niuniuDeviceSerial,
  niuniuLoginAESKey,
  niuniuLoginNonce,
  niuniuLoginSalt,
  niuniuBizAESKey,
  niuniuBizNonce,
  niuniuBizSalt,
  niuniuHMACKey,
} from '../consts.js';

const niuniuUA = 'okhttp/4.12.0';
const niuniuCSJUA = 'okhttp/3.12.11';
const niuniuPageSize = 40;

const niuniuCats = [
  { ID: '', Name: '全部' },
  { ID: '现言', Name: '现言' },
  { ID: '古言', Name: '古言' },
  { ID: '历史', Name: '历史' },
  { ID: '都市', Name: '都市' },
  { ID: '亲情', Name: '亲情' },
  { ID: '玄幻', Name: '玄幻' },
  { ID: '热血', Name: '热血' },
  { ID: '动作', Name: '动作' },
  { ID: '喜剧', Name: '喜剧' },
  { ID: '悬疑', Name: '悬疑' },
  { ID: '军事', Name: '军事' },
  { ID: '二次元', Name: '二次元' },
  { ID: '其他剧情', Name: '其他剧情' },
];

export const platformCats = niuniuCats.map((c) => ({ ID: c.ID, Name: c.Name }));

function niuniuNewDeviceID() {
  try {
    const buf = crypto.randomBytes(16);
    buf[6] = (buf[6] & 0x0f) | 0x40;
    buf[8] = (buf[8] & 0x3f) | 0x80;
    const h = buf.toString('hex');
    return h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' + h.slice(16, 20) + '-' + h.slice(20, 32);
  } catch {
    return niuniuDeviceSerial;
  }
}

function hmacSHA256Hex(msg, key) {
  return crypto.createHmac('sha256', Buffer.from(String(key ?? ''), 'utf8')).update(Buffer.from(String(msg ?? ''), 'utf8')).digest('hex');
}

function aesECBEncryptBase64(plain, key) {
  const keyBuf = Buffer.from(String(key ?? ''), 'utf8');
  const padded = pkcs7Pad(Buffer.from(String(plain ?? ''), 'utf8'), 16);
  const cipher = crypto.createCipheriv(`aes-${keyBuf.length * 8}-ecb`, keyBuf, null);
  cipher.setAutoPadding(false);
  return Buffer.concat([cipher.update(padded), cipher.final()]).toString('base64');
}


function base64DecodeStrict(s) {
  const str = String(s ?? '');
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(str) || str.length % 4 !== 0) {
    throw new Error('base64 解码失败');
  }
  return Buffer.from(str, 'base64');
}

function aesECBDecryptBase64(cipherB64, key) {
  const cipherText = base64DecodeStrict(cipherB64);
  const keyBuf = Buffer.from(String(key ?? ''), 'utf8');
  if (cipherText.length === 0 || cipherText.length % 16 !== 0) {
    throw new Error('AES-ECB 密文长度不是块大小的整数倍');
  }
  const decipher = crypto.createDecipheriv(`aes-${keyBuf.length * 8}-ecb`, keyBuf, null);
  decipher.setAutoPadding(false);
  const out = Buffer.concat([decipher.update(cipherText), decipher.final()]);
  return pkcs7Unpad(out, 16);
}

function niuniuCSJBody(shortplayID, index) {
  let idx = Math.trunc(Number(index));
  if (!Number.isFinite(idx) || idx < 1) idx = 1;
  idx = String(idx);
  let b = 'not_include=0' +
    '&lock_free=1' +
    '&type=1' +
    '&clientVersion=v5.2.5' +
    '&uuid=6IDYUSASPQY5BBVACWQW3LLTPV4V7DE26UOCX5TZTVUGX4VUJNXQ01' +
    '&resolution=1080*2320' +
    '&openudid=82f4175d577a2939' +
    '&dt=22021211RC' +
    '&os_api=31' +
    '&install_id=1496879012031075' +
    '&sdk_version=1.1.3.0' +
    '&siteid=' + niuniuSiteID +
    '&dev_log_aid=667431' +
    '&oaid=abec0dfff623201b' +
    '&timestamp=' + String(Math.floor(Date.now() / 1000)) +
    '&direction=0' +
    '&ac=mobile' +
    '&os=Android' +
    '&vod_version=1.10.21.6-tob' +
    '&os_version=12' +
    '&count=1' +
    '&index=' + idx +
    '&lock_index=' + idx;
  if (shortplayID !== '') {
    b += '&shortplay_id=' + shortplayID;
  }
  b += '&sha1=46121F77CE2FCAD3DBC3B9EC8A24908C1A8AD6D9' +
    '&device_brand=Redmi' +
    '&package_name=com.niuniu.ztdh.app';
  return b;
}

function niuniuCSJUnlockBody(shortplayID, index) {
  let idx = Math.trunc(Number(index));
  if (!Number.isFinite(idx) || idx < 1) idx = 1;
  return 'ac=mobile' +
    '&os=Android' +
    '&vod_version=1.10.21.6-tob' +
    '&os_version=12' +
    '&lock_ad=1' +
    '&lock_free=1' +
    '&type=1' +
    '&clientVersion=v5.2.5' +
    '&uuid=6IDYUSASPQY5BBVACWQW3LLTPV4V7DE26UOCX5TZTVUGX4VUJNXQ01' +
    '&resolution=1080*2320' +
    '&openudid=82f4175d577a2939' +
    '&shortplay_id=' + shortplayID +
    '&dt=22021211RC' +
    '&sha1=46121F77CE2FCAD3DBC3B9EC8A24908C1A8AD6D9' +
    '&lock_index=' + String(idx) +
    '&os_api=31' +
    '&install_id=1496879012031075' +
    '&device_brand=Redmi' +
    '&sdk_version=1.1.3.0' +
    '&package_name=com.niuniu.ztdh.app' +
    '&siteid=' + niuniuSiteID +
    '&dev_log_aid=667431' +
    '&oaid=abec0dfff623201b' +
    '&timestamp=' + String(Math.floor(Date.now() / 1000));
}

function niuniuCSJLoginBody() {
  return 'ac=wifi&os=Android&vod_version=1.10.21.6-tob&os_version=9&type=1' +
    '&clientVersion=v5.2.5' +
    '&uuid=Y4WNZ3SAWK7MAJMH7CXCDHJ4VMPVFRZQTBSIA4XTYO4AWEUHIK6Q01' +
    '&resolution=1280*2618' +
    '&openudid=889edced38f1069b&dt=Pixel%204' +
    '&sha1=46121F77CE2FCAD3DBC3B9EC8A24908C1A8AD6D9' +
    '&os_api=28&install_id=1549688030634536&device_brand=google' +
    '&sdk_version=1.1.3.0&package_name=com.niuniu.ztdh.app' +
    '&siteid=' + niuniuSiteID +
    '&dev_log_aid=667431&oaid=' +
    '&timestamp=' + String(Math.floor(Date.now() / 1000));
}


function nnCode(raw) {
  let head = null;
  try {
    head = JSON.parse(raw.toString('utf8'));
  } catch {
    return -1;
  }
  if (!head || typeof head !== 'object' || Array.isArray(head)) return -1;
  if (head.code === undefined || head.code === null) return 0;
  if (typeof head.code === 'number' && Number.isFinite(head.code)) return Math.trunc(head.code);
  return -1;
}


function nnAnyText(v) {
  if (typeof v === 'string') return v.trim();
  if (typeof v === 'number' && Number.isFinite(v)) {
    if (Number.isInteger(v) && Math.abs(v) < 1e21) return String(Math.trunc(v));
    return String(v);
  }
  return '';
}

function nnIDNum(id) {
  const s = String(id ?? '');
  if (s === '') return s;
  if (/^[+-]?\d{1,15}$/.test(s)) {
    return Number(s);
  }
  return s;
}

function nnScoreText(v) {
  return nnAnyText(v);
}

function niuniuDescText(classify, score, intro) {
  const segs = [
    ['类型：', classify],
    ['评分：', score],
    ['简介：', intro],
  ];
  const parts = [];
  for (const [label, value] of segs) {
    if (value === '') continue;
    parts.push(label + value);
  }
  return parts.join('\n');
}

function nnCard(r) {
  const id = String(r?.id ?? '').trim();
  if (id === '' || id === '0') return null;
  const name = cleanText(r?.name);
  if (name === '') return null;
  let remarks = String(r?.type ?? '').trim();
  let total = Math.trunc(Number(r?.totalEpisode));
  if (!Number.isFinite(total) || total < 0) total = 0;
  if (total > 0) {
    const ep = `共${total}集`;
    if (remarks !== '') remarks += ' · ' + ep;
    else remarks = ep;
  }
  return {
    vod_id: id,
    vod_name: name,
    vod_pic: String(r?.cover ?? '').trim(),
    vod_remarks: remarks,
    vod_class: '牛牛短剧',
  };
}

export class NiuniuProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
    this.token = '';
    this.deviceID = '';
    this.csjToken = '';
    this.csjTokenAt = 0;
    this._lock = Promise.resolve();
  }

  
  async withLock(fn) {
    const prev = this._lock;
    let release;
    this._lock = new Promise((resolve) => { release = resolve; });
    try {
      await prev;
      return await fn();
    } finally {
      release();
    }
  }

  async ensureToken(force) {
    return await this.withLock(async () => {
      if (!force && this.token !== '') {
        return this.token;
      }
      if (this.deviceID === '') {
        this.deviceID = niuniuNewDeviceID();
      }
      let raw = null;
      let status = 0;
      try {
        const resp = await this.client.fetchWithHeaders('GET', niuniuAPIBase + '/api/v1/app/user/visitorInfo', {
          deviceid: this.deviceID,
          token: '',
          client: 'app',
          devicetype: 'Android',
          'User-Agent': niuniuUA,
        });
        raw = resp.raw;
        status = resp.status;
      } catch (err) {
        throw err;
      }
      if (status >= 400) {
        throw new Error(`牛牛游客接口 HTTP ${status}`);
      }
      let resp = null;
      try {
        resp = JSON.parse(raw.toString('utf8'));
      } catch {
        throw new Error('牛牛游客接口响应无法解析');
      }
      const token = String(resp?.data?.token ?? '');
      if (token === '') {
        throw new Error(`牛牛游客接口没拿到 token（${toInt(resp?.code, 0)} ${resp?.msg ?? ''}）`);
      }
      this.token = token;
      return token;
    });
  }

  async nnPost(path, body) {
    for (let attempt = 0; attempt < 2; attempt++) {
      const token = await this.ensureToken(attempt > 0);
      const payload = await this.nnDoPost(path, body, token);
      if (nnCode(payload) === 2006 && attempt === 0) {
        continue;
      }
      return payload;
    }
    throw new Error('牛牛接口重试后仍失败');
  }

  async nnDoPost(path, body, token) {
    const deviceID = await this.withLock(async () => this.deviceID);
    let raw = null;
    let status = 0;
    try {
      const resp = await this.client.fetchWithHeaders('POST', niuniuAPIBase + path, {
        token,
        deviceid: deviceID,
        'content-type': 'application/json;charset=UTF-8',
        'User-Agent': niuniuUA,
      }, JSON.stringify(body ?? null));
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      throw err;
    }
    if (status >= 400) {
      throw new Error(`牛牛接口 HTTP ${status}`);
    }
    return raw;
  }

  async ensureCSJToken(force) {
    return await this.withLock(async () => {
      if (!force && this.csjToken !== '' && Date.now() - this.csjTokenAt < 30 * 60 * 1000) {
        return this.csjToken;
      }
      const ts = String(Math.floor(Date.now() / 1000));
      const body = niuniuCSJLoginBody();
      const enc = aesECBEncryptBase64(body, niuniuLoginAESKey);
      let raw = null;
      let status = 0;
      try {
        const resp = await this.client.fetchWithHeaders('POST',
          niuniuCSJBase + '/csj_sp/api/v1/user/login?siteid=' + niuniuSiteID, {
            'X-Salt': niuniuLoginSalt,
            'X-Nonce': niuniuLoginNonce,
            'X-Timestamp': ts,
            'X-Signature': hmacSHA256Hex(ts + niuniuLoginNonce + body, niuniuHMACKey),
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': niuniuUA,
          }, enc);
        raw = resp.raw;
        status = resp.status;
      } catch (err) {
        throw err;
      }
      if (status >= 400) {
        throw new Error(`牛牛CSJ登录 HTTP ${status}`);
      }
      let plain = null;
      try {
        plain = aesECBDecryptBase64(raw.toString('utf8'), niuniuLoginAESKey);
      } catch (err) {
        throw new Error('牛牛CSJ登录解密失败: ' + (err instanceof Error ? err.message : String(err)));
      }
      let resp = null;
      try {
        resp = JSON.parse(plain.toString('utf8'));
      } catch {
        resp = null;
      }
      const accessToken = String(resp?.data?.access_token ?? '');
      if (!resp || accessToken === '') {
        throw new Error('牛牛CSJ登录没拿到 access_token');
      }
      this.csjToken = accessToken;
      this.csjTokenAt = Date.now();
      return accessToken;
    });
  }

  async csjPost(path, shortplayID, index) {
    return await this.csjPostBody(path, niuniuCSJBody(shortplayID, index));
  }

  async csjUnlock(shortplayID, index) {
    return await this.csjPostBody('/csj_sp/api/v1/pay/ad_unlock?siteid=' + niuniuSiteID,
      niuniuCSJUnlockBody(shortplayID, index));
  }

  async csjPostBody(path, body) {
    let lastErr = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      const token = await this.ensureCSJToken(attempt > 0);
      const ts = String(Math.floor(Date.now() / 1000));
      const enc = aesECBEncryptBase64(body, niuniuBizAESKey);
      let raw = null;
      let status = 0;
      try {
        const resp = await this.client.fetchWithHeaders('POST', niuniuCSJBase + path, {
          'X-Salt': niuniuBizSalt,
          'X-Nonce': niuniuBizNonce,
          'X-Timestamp': ts,
          'X-Access-Token': token,
          'X-Signature': hmacSHA256Hex(ts + niuniuBizNonce + body, niuniuHMACKey),
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': niuniuCSJUA,
        }, enc);
        raw = resp.raw;
        status = resp.status;
      } catch (err) {
        throw err;
      }
      if (status >= 400) {
        lastErr = new Error(`牛牛CSJ接口 HTTP ${status}`);
        continue;
      }
      let plain = null;
      try {
        plain = aesECBDecryptBase64(raw.toString('utf8'), niuniuBizAESKey);
      } catch (err) {
        throw new Error('牛牛CSJ响应解密失败: ' + (err instanceof Error ? err.message : String(err)));
      }
      let resp = null;
      try {
        resp = JSON.parse(plain.toString('utf8'));
      } catch {
        throw new Error('牛牛CSJ响应无法解析');
      }
      if (!resp || typeof resp !== 'object' || Array.isArray(resp)) {
        throw new Error('牛牛CSJ响应无法解析');
      }
      const ret = toInt(resp.ret, 0);
      const code = toInt(resp.code, 0);
      const msg = String(resp.msg ?? '');
      const ok = (ret === 0 || ret === 200) && (code === 0 || code === 200);
      if (!ok) {
        const errText = `牛牛CSJ返回 ret=${ret} code=${code} ${msg}`;
        if (attempt === 0) {
          lastErr = new Error(errText);
          continue;
        }
        throw new Error(errText);
      }
      return resp;
    }
    if (!lastErr) {
      lastErr = new Error('牛牛CSJ请求失败');
    }
    throw lastErr;
  }

  async List(cat, page) {
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    let c = String(cat ?? '').trim();
    
    const validCatNames = niuniuCats.map((x) => x.Name).filter((n) => n !== '全部');
    if (c === '全部' || c === 'all' || (c !== '' && !validCatNames.includes(c))) c = '';
    const raw = await this.nnPost('/api/v1/app/screen/screenMovie', {
      condition: { classify: c, typeId: 'S1' },
      pageNum: p,
      pageSize: niuniuPageSize,
    });
    let resp = null;
    try {
      resp = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('牛牛列表响应无法解析');
    }
    const code = toInt(resp?.code, 0);
    if (code !== 0 && code !== 200) {
      throw new Error(`牛牛列表返回 ${code} ${resp?.msg ?? ''}`);
    }
    const records = Array.isArray(resp?.data?.records) ? resp.data.records : [];
    const cards = [];
    const seen = new Set();
    for (const r of records) {
      const card = nnCard(r);
      if (!card || card.vod_id === '' || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0 && p > 1) {
      return [];
    }
    return cards;
  }

  async Search(wd, page) {
    const kw = String(wd ?? '').trim();
    if (kw === '') throw new Error('牛牛搜索关键词为空');
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    const raw = await this.nnPost('/api/v1/app/search/searchMovie', {
      condition: { typeId: 'S1', value: kw },
      pageNum: p,
      pageSize: niuniuPageSize,
    });
    let resp = null;
    try {
      resp = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('牛牛搜索响应无法解析');
    }
    const code = toInt(resp?.code, 0);
    if (code !== 0 && code !== 200) {
      throw new Error(`牛牛搜索返回 ${code} ${resp?.msg ?? ''}`);
    }
    const records = Array.isArray(resp?.data?.records) ? resp.data.records : [];
    const cards = [];
    const seen = new Set();
    for (const r of records) {
      const card = nnCard(r);
      if (!card || card.vod_id === '' || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    return cards;
  }

  async Detail(id) {
    let tid = String(id ?? '').trim();
    const ci = tid.indexOf(':');
    if (ci >= 0) tid = tid.slice(ci + 1);
    if (tid === '') throw new Error('无效的牛牛剧集 ID');

    let descData = null;
    try {
      const descRaw = await this.nnPost('/api/v1/app/play/movieDesc', { id: nnIDNum(tid), typeId: 'S1' });
      const desc = JSON.parse(descRaw.toString('utf8'));
      if (desc && typeof desc.data === 'object' && desc.data !== null && !Array.isArray(desc.data)) {
        descData = desc.data;
      }
    } catch {
      descData = null; 
    }

    const detRaw = await this.nnPost('/api/v1/app/play/movieDetails', {
      id: nnIDNum(tid), source: 0, typeId: 'S1', userId: '546932',
    });
    let det = null;
    try {
      det = JSON.parse(detRaw.toString('utf8'));
    } catch {
      throw new Error('牛牛详情响应无法解析');
    }
    if (!det || typeof det !== 'object' || Array.isArray(det)) {
      throw new Error('牛牛详情响应无法解析');
    }
    const detCode = toInt(det.code, 0);
    if (detCode !== 0 && detCode !== 200) {
      throw new Error(`牛牛详情返回 ${detCode} ${det?.msg ?? ''}`);
    }
    const detData = det.data && typeof det.data === 'object' && !Array.isArray(det.data) ? det.data : {};
    const detail = {
      vod_id: tid,
      vod_name: '',
      vod_pic: '',
      vod_content: '',
      vod_class: '',
      episodes: [],
      episode_count: 0,
    };
    detail.vod_name = cleanText(firstNonEmpty(descData?.name, detData.name));
    detail.vod_pic = String(firstNonEmpty(descData?.cover, detData.cover) ?? '').trim();
    detail.vod_content = niuniuDescText(
      String(descData?.classify ?? ''),
      nnScoreText(descData?.score),
      cleanText(firstNonEmpty(descData?.introduce, detData.introduce)),
    );
    if (detail.vod_name === '') {
      detail.vod_name = '牛牛短剧 ' + tid;
    }
    const third = String(detData.thirdPlayId ?? '').trim();
    const episodeList = Array.isArray(detData.episodeList) ? detData.episodeList : [];
    if (episodeList.length === 0 && third !== '' && third !== '0') {
      let cs = null;
      try {
        cs = await this.csjPost('/csj_sp/api/v1/shortplay/detail?siteid=' + niuniuSiteID, third, 1);
      } catch {
        cs = null; 
      }
      if (cs) {
        const csData = cs.data && typeof cs.data === 'object' && !Array.isArray(cs.data) ? cs.data : {};
        niuniuEpisodes(detail, tid, [], third, csData.episode_right_list);
        const csList = Array.isArray(csData.list) ? csData.list : [];
        for (const it of csList) {
          if (detail.vod_pic === '') {
            const u = String(it?.cover_image ?? '').trim();
            if (isProviderHTTPMediaURL(u)) {
              detail.vod_pic = u;
            }
          }
          if (detail.vod_content === '') {
            detail.vod_content = cleanText(it?.desc);
          }
          break;
        }
      }
    } else {
      niuniuEpisodes(detail, tid, episodeList, '', null);
    }
    if (detail.episodes.length === 0) {
      throw new Error('牛牛详情无剧集: ' + tid);
    }
    detail.episode_count = detail.episodes.length;
    detail.vod_class = '牛牛短剧';
    return detail;
  }

  async Play(playURL) {
    const parsed = niuniuSplitPlay(playURL);
    if (!parsed) {
      throw new Error('牛牛播放参数无效');
    }
    const [id, mode, seq] = parsed;
    if (mode === 'free') {
      const raw = await this.nnPost('/api/v1/app/play/movieDetails', {
        id: nnIDNum(seq), source: 0, typeId: 'S1', userId: '546932',
        episodeId: nnIDNum(id),
      });
      let resp = null;
      try {
        resp = JSON.parse(raw.toString('utf8'));
      } catch {
        throw new Error('牛牛播放响应无法解析');
      }
      const media = String(resp?.data?.url ?? '').trim();
      if (media === '' || !isProviderHTTPMediaURL(media)) {
        throw new Error('牛牛播放未返回有效地址');
      }
      return { src: media, userAgent: niuniuUA };
    }

    try {
      await this.csjUnlock(id, atoiDefault(seq, 1)); 
    } catch {
      
    }
    const cs = await this.csjPost('/csj_sp/api/v1/shortplay/detail?siteid=' + niuniuSiteID, id, atoiDefault(seq, 1));
    let media = '';
    const csData = cs?.data && typeof cs.data === 'object' && !Array.isArray(cs.data) ? cs.data : {};
    const csList = Array.isArray(csData.list) ? csData.list : [];
    for (const it of csList) {
      const raw = String(it?.video_model?.video_list?.video_1?.main_url ?? '').trim();
      if (raw === '') continue;
      try {
        const dec = base64DecodeStrict(raw);
        const u = dec.toString('utf8').trim();
        if (isProviderHTTPMediaURL(u)) {
          media = u;
          break;
        }
      } catch {
        continue; 
      }
    }
    if (media === '') {
      throw new Error('牛牛第三方播放未解析出地址');
    }
    return { src: media, userAgent: niuniuUA };
  }
}

function toInt(v, fallback) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.trunc(n);
}


function niuniuEpisodes(detail, movieID, eps, thirdPlayID, rights) {
  if (Array.isArray(eps) && eps.length > 0) {
    for (let i = 0; i < eps.length; i++) {
      const e = eps[i];
      if (!e || typeof e !== 'object' || Array.isArray(e)) continue;
      const epID = String(e.id ?? '').trim();
      if (epID === '') continue;
      let name = nnAnyText(e.episode);
      if (name === '') {
        name = `第${i + 1}集`;
      } else if (!name.includes('集')) {
        name = '第' + name + '集';
      }
      detail.episodes.push({
        no: detail.episodes.length + 1,
        name,
        url: `niuniu://${movieID}/f${epID}`,
      });
    }
    return;
  }
  if (thirdPlayID !== '') {
    for (const r of Array.isArray(rights) ? rights : []) {
      if (!r || typeof r !== 'object' || Array.isArray(r)) continue;
      const idx = toInt(r.index, 0);
      if (idx < 1) continue;
      detail.episodes.push({
        no: idx,
        name: `第${idx}集`,
        url: `niuniu://${thirdPlayID}/t${idx}`,
      });
    }
  }
}


function niuniuSplitPlay(playURL) {
  const parsed = parsePlayScheme(String(playURL ?? '').trim(), 'niuniu://');
  if (!parsed || parsed.id === '' || parsed.extra === '') {
    return null;
  }
  const rawID = parsed.id;
  const extra = parsed.extra;
  const head = extra[0];
  if (head === 'f' || head === 'F') {
    const seq = extra.slice(1).trim();
    if (seq === '') return null;
    return [rawID, 'free', seq];
  }
  if (head === 't' || head === 'T') {
    const seq = extra.slice(1).trim();
    if (seq === '') return null;
    
    const n = /^[+-]?\d+$/.test(seq) ? parseInt(seq, 10) : NaN;
    if (!Number.isFinite(n) || n < 1) return null;
    return [rawID, 'third', seq];
  }
  return null;
}

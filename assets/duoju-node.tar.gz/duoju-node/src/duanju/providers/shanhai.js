
import { createDecipheriv, createCipheriv } from 'node:crypto';
import { anyList, atoiDefault, cleanText, firstNonEmpty, mapString, nestedMap, parsePlayScheme } from '../../core/util.js';
import { shanhaiAPIBase, shanhaiGCMKey, shanhaiLoginKey, shanhaiLoginURL } from '../consts.js';
import { pkcs7Pad, truncate } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { queryEscape } from './xingxing.js';

const shanhaiPageSize = 24;

const shanhaiCatList = [
  { id: 'jingxuan', name: '精选', class: '0' },
  { id: 'renqi', name: '人气', class: '1' },
  { id: 'xinju', name: '新剧', class: '51' },
  { id: 'tianchong', name: '甜宠', class: '46' },
  { id: 'nixi', name: '逆袭', class: '6' },
  { id: 'qiangzhe', name: '强者回归', class: '50' },
  { id: 'qihuan', name: '奇幻', class: '44' },
  { id: 'fuchou', name: '复仇', class: '49' },
  { id: 'zhongguomeng', name: '中国梦', class: '41' },
  { id: 'jiating', name: '家庭', class: '9' },
];

export const platformCats = shanhaiCatList.map((c) => ({ ID: c.id, Name: c.name }));

function shanhaiClass(cat) {
  for (const item of shanhaiCatList) {
    if (item.id === cat) return [item.class, item.name];
  }
  const fallback = shanhaiCatList[0];
  return [fallback.class, fallback.name];
}

function shanhaiDetailPath(id) {
  return '/shanhai-theater/v2/theater_parent/detail?theater_parent_id=' + queryEscape(id);
}


function aesECBEncrypt(plain, key) {
  const size = 16;
  const padded = pkcs7Pad(plain, size);
  const out = Buffer.alloc(padded.length);
  const cipher = createCipheriv(`aes-${key.length * 8}-ecb`, key, null);
  cipher.setAutoPadding(false);
  return Buffer.concat([cipher.update(padded), cipher.final()]);
}

function aesGCMDecrypt(cipherHex, nonceHex) {
  let blob;
  const hexTrim = String(cipherHex ?? '').trim();
  if (hexTrim === '' || hexTrim.length % 2 !== 0 || !/^[0-9a-fA-F]+$/.test(hexTrim)) {
    throw new Error('山海响应密文无效');
  }
  blob = Buffer.from(hexTrim, 'hex');
  const nonceTrim = String(nonceHex ?? '').trim();
  if (nonceTrim === '' || nonceTrim.length % 2 !== 0 || !/^[0-9a-fA-F]+$/.test(nonceTrim)) {
    throw new Error('山海响应 nonce 无效');
  }
  const nonce = Buffer.from(nonceTrim, 'hex');
  try {
    
    const tag = blob.subarray(blob.length - 16);
    const data = blob.subarray(0, blob.length - 16);
    const d = createDecipheriv(`aes-${Buffer.from(shanhaiGCMKey, 'utf8').length * 8}-gcm`, Buffer.from(shanhaiGCMKey, 'utf8'), nonce);
    d.setAuthTag(tag);
    return Buffer.concat([d.update(data), d.final()]);
  } catch {
    throw new Error('山海响应解密失败');
  }
}

export class ShanhaiProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
    this.token = '';
    this.tokenPromise = null;
  }

  async login() {
    const payload = {
      device: '22ebfeec0a5ad3c0397bae448b8658cc3',
      install_first_open: true,
      first_install_time: 1751687627754,
      last_update_time: 1751687627754,
      report_link_url: '',
      android_id: '8f7db6f23d745890',
      package_name: 'com.shanhai.duanju',
      authorization: '',
      timestamp: Date.now(),
    };
    const sealed = aesECBEncrypt(Buffer.from(JSON.stringify(payload), 'utf8'), Buffer.from(shanhaiLoginKey, 'utf8'));
    const body = Buffer.from(sealed.toString('base64'), 'utf8');
    const headers = { 'content-type': 'application/json; charset=utf-8' };
    const { raw, status } = await this.client.fetchWithHeaders('POST', shanhaiLoginURL, headers, body);
    if (status >= 400) {
      throw new Error(`山海登录接口 HTTP ${status}`);
    }
    let token = '';
    try {
      const envelope = JSON.parse(raw.toString('utf8'));
      token = String(envelope?.data?.token ?? '').trim();
    } catch {}
    if (token === '') {
      throw new Error('山海登录未返回 token');
    }
    return token;
  }

  async authToken() {
    if (this.token !== '') return this.token;
    if (!this.tokenPromise) {
      this.tokenPromise = this.login()
        .then((token) => {
          this.token = token;
          this.tokenPromise = null;
          return token;
        })
        .catch((err) => {
          this.tokenPromise = null;
          throw err;
        });
    }
    return this.tokenPromise;
  }

  resetToken() {
    this.token = '';
  }

  async api(path) {
    try {
      return await this.apiOnce(path);
    } catch {
      this.resetToken();
      return this.apiOnce(path);
    }
  }

  async apiOnce(path) {
    const token = await this.authToken();
    const headers = { authorization: token };
    const { raw, status } = await this.client.fetchWithHeaders('GET', shanhaiAPIBase + path, headers);
    if (status >= 400) {
      throw new Error(`山海接口 HTTP ${status}`);
    }
    let envelope;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('山海接口响应无法解析');
    }
    const inner = envelope?.data ?? {};
    const dataText = String(inner?.data ?? '').trim();
    if (dataText === '') {
      const code = envelope?.code ?? '';
      if (code !== '' && code !== 'ok') {
        throw new Error(`山海接口返回错误: ${code}`);
      }
      throw new Error('山海接口无数据');
    }
    const plain = aesGCMDecrypt(inner.data, inner.nonce);
    let data;
    try {
      data = JSON.parse(plain.toString('utf8'));
    } catch {
      throw new Error('山海接口响应无法解析');
    }
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      throw new Error('山海接口响应无法解析');
    }
    return data;
  }

  card(theater, cat) {
    const id = mapString(theater, 'id');
    const title = cleanText(mapString(theater, 'title'));
    if (id === '' || title === '') return null;
    const card = { vod_id: id, vod_name: title, vod_class: cat, vod_score: '', vod_content: '' };
    const cover = mapString(theater, 'cover_url');
    if (cover !== '') card.vod_pic = this.media.imgProxyURL(cover, `${shanhaiAPIBase}/`);
    const total = atoiDefault(mapString(theater, 'total'), 0);
    if (total > 0) card.vod_remarks = `共${total}集`;
    return card;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    const [classID, catName] = shanhaiClass(cat);
    const path = `/shanhai-theater/v2/theater_parent/cloud/v2/theater/home_page?theater_class_id=1&type=1&class2_ids=${queryEscape(classID)}&page_num=${page}&page_size=${shanhaiPageSize}`;
    const data = await this.api(path);
    const items = anyList(data.items);
    if (page > 1 && items.length === 0) {
      return [];
    }
    const cards = [];
    const seen = new Set();
    for (const raw of items) {
      if (!raw || typeof raw !== 'object' || Array.isArray(raw)) continue;
      const card = this.card(nestedMap(raw, 'theater'), catName);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('山海列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    wd = String(wd || '').trim();
    if (wd === '') {
      throw new Error('山海搜索关键词为空');
    }
    const token = await this.authToken();
    const body = Buffer.from(JSON.stringify({ text: wd }), 'utf8');
    const { raw, status } = await this.client.fetchWithHeaders('POST', `${shanhaiAPIBase}/v3/search`, {
      authorization: token,
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'User-Agent': 'okhttp/4.10.0',
    }, body);
    if (status >= 400) {
      throw new Error(`山海搜索 HTTP ${status}`);
    }
    let envelope;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('山海搜索响应无法解析');
    }
    const theater = nestedMap(envelope?.data, 'theater');
    const cards = [];
    const seen = new Set();
    for (const rawItem of anyList(theater ? theater.search_data : undefined)) {
      if (!rawItem || typeof rawItem !== 'object' || Array.isArray(rawItem)) continue;
      const card = this.card(rawItem, '');
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('山海搜索无结果: ' + wd);
    }
    return cards;
  }

  async Detail(id) {
    id = String(id || '').trim();
    if (id === '') {
      throw new Error('无效的山海剧集 ID');
    }
    const data = await this.api(shanhaiDetailPath(id));
    const detail = {
      vod_id: id,
      vod_name: cleanText(mapString(data, 'title')),
      vod_class: shanhaiTags(data),
      vod_content: truncate(cleanText(mapString(data, 'introduction')), 400),
      vod_pic: '',
      episodes: [],
      episode_count: 0,
    };
    const cover = mapString(data, 'cover_url');
    if (cover !== '') detail.vod_pic = this.media.imgProxyURL(cover, `${shanhaiAPIBase}/`);
    const theaters = anyList(data.theaters);
    for (let i = 0; i < theaters.length; i++) {
      const theater = theaters[i];
      if (!theater || typeof theater !== 'object' || Array.isArray(theater)) continue;
      const no = i + 1;
      detail.episodes.push({
        no,
        name: firstNonEmpty(cleanText(mapString(theater, 'son_title')), `第${no}集`),
        url: `shanhai://${id}/${no}`,
      });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.episodes.length === 0) {
      throw new Error('山海详情无剧集: ' + id);
    }
    if (detail.vod_name === '') {
      detail.vod_name = '山海短剧 ' + id;
    }
    return detail;
  }

  async Play(playURL) {
    const scheme = parsePlayScheme(playURL, 'shanhai://');
    if (!scheme || scheme.id === '') {
      throw new Error('山海播放参数无效');
    }
    const id = scheme.id;
    const seq = atoiDefault(scheme.extra, 0);
    if (seq < 1) {
      throw new Error('山海播放参数无效');
    }
    const data = await this.api(shanhaiDetailPath(id));
    const theaters = anyList(data.theaters);
    if (seq > theaters.length) {
      throw new Error(`山海详情缺第${seq}集`);
    }
    const theater = theaters[seq - 1];
    if (!theater || typeof theater !== 'object' || Array.isArray(theater)) {
      throw new Error(`山海详情缺第${seq}集`);
    }
    const src = mapString(theater, 'son_video_url');
    if (!isProviderHTTPMediaURL(src)) {
      throw new Error(`山海第${seq}集暂无播放地址`);
    }
    return { src, referer: `${shanhaiAPIBase}/` };
  }
}

function shanhaiTags(data) {
  const tags = [];
  for (const raw of anyList(data?.desc_tags)) {
    if (typeof raw === 'string' && raw.trim() !== '') {
      tags.push(cleanText(raw));
    }
  }
  return tags.join(' ');
}


import { atoiDefault, cleanText, mapString, anyList, nestedMap, sleep } from '../../core/util.js';
import { truncate } from '../shared.js';
import { MEDIA_NO_REFERER } from '../../core/media.js';
import { damangAPIBase, damangPlayAPIBase, damangDeviceID } from '../consts.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { queryEscape } from './xingxing.js';
import { providerSchemeArg } from './haokan.js';

const damangPageSize = 12;
const damangPlayRetry = 5;
const damangPlayRetryWait = 1200; 
const damangMediaUA = 'libmpv';

const damangCatList = [
  { ID: 'aiqing', Name: '爱情', TagName: '爱情', TagID: '1273154' },
  { ID: 'dushi', Name: '都市', TagName: '都市', TagID: '1279863' },
  { ID: 'guzhuang', Name: '古装', TagName: '古装', TagID: '1273153' },
  { ID: 'yanqing', Name: '言情', TagName: '言情', TagID: '1273190' },
  { ID: 'qihuan', Name: '奇幻', TagName: '奇幻', TagID: '2924543' },
  { ID: 'zhenrenxiu', Name: '真人秀', TagName: '真人秀', TagID: '1657120' },
  { ID: 'xuanyi', Name: '悬疑', TagName: '悬疑', TagID: '1310272' },
  { ID: 'wangju', Name: '网剧', TagName: '网剧', TagID: '2844459' },
  { ID: 'qingchun', Name: '青春', TagName: '青春', TagID: '2836677' },
];

export const platformCats = damangCatList.map((item) => ({ ID: item.ID, Name: item.Name }));

function damangClass(cat) {
  for (const item of damangCatList) {
    if (item.ID === cat) return [item.TagName, item.TagID];
  }
  const fallback = damangCatList[0];
  return [fallback.TagName, fallback.TagID];
}

export class DamangProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async getJSON(target) {
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders('GET', target, {
        Accept: 'application/json, text/plain, */*',
        Referer: damangAPIBase + '/',
      });
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    if (terr) throw terr;
    if (status >= 400) {
      throw new Error(`大芒接口 HTTP ${status}`);
    }
    let envelope = null;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('大芒接口响应无法解析');
    }
    if (!envelope || typeof envelope !== 'object' || Array.isArray(envelope)) {
      throw new Error('大芒接口响应无法解析');
    }
    if (envelope.code !== undefined) {
      const codeText = typeof envelope.code === 'string' ? envelope.code : String(envelope.code ?? '');
      if (atoiDefault(codeText, 0) !== 200) {
        throw new Error('大芒接口返回错误: ' + mapString(envelope, 'msg'));
      }
    }
    return envelope;
  }

  card(item, catName) {
    const id = String(mapString(item, 'albumId')).trim();
    const title = cleanText(mapString(item, 'albumTitle', 'title'));
    if (id === '' || title === '') return null;
    const card = { vod_id: id, vod_name: title, vod_pic: '', vod_remarks: '', vod_class: catName };
    const cover = mapString(item, 'verticalImg');
    if (cover !== '') {
      card.vod_pic = this.media.imgProxyURL(cover, damangAPIBase + '/');
    }
    card.vod_remarks = cleanText(mapString(item, 'albumUpdateSerialNoDesc'));
    return card;
  }

  damangCardList(items, catName) {
    const cards = [];
    const seen = new Set();
    for (const rawItem of anyList(items)) {
      if (!rawItem || typeof rawItem !== 'object' || Array.isArray(rawItem)) continue;
      const card = this.card(rawItem, catName);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    return cards;
  }

  async List(cat, page) {
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    const [tagName, tagID] = damangClass(cat);
    const target = `${damangAPIBase}/newbee/manage/page/film/library/v3?did=${damangDeviceID}&pageSize=${damangPageSize}&pageNum=${p}&tagName=${queryEscape(tagName)}&tagId=${queryEscape(tagID)}`;
    const envelope = await this.getJSON(target);
    const data = nestedMap(envelope, 'data');
    const cards = this.damangCardList(anyList(data?.list), tagName);
    if (cards.length === 0) {
      if (p > 1) return [];
      throw new Error('大芒列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    const kw = String(wd ?? '').trim();
    if (kw === '') throw new Error('大芒搜索关键词为空');
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    const target = `${damangAPIBase}/newbee/search/key/words?keyWords=${queryEscape(kw)}&screenType=1&pageNum=${p}&pageSize=${damangPageSize}`;
    const envelope = await this.getJSON(target);
    const data = nestedMap(envelope, 'data');
    const cards = this.damangCardList(anyList(data?.videos), '');
    if (cards.length === 0) {
      throw new Error('大芒搜索无结果: ' + kw);
    }
    return cards;
  }

  async album(id) {
    const target = `${damangAPIBase}/newbee/play/page/detail?did=${damangDeviceID}&albumId=${queryEscape(id)}&vid=`;
    const envelope = await this.getJSON(target);
    const album = nestedMap(nestedMap(envelope, 'data'), 'album');
    if (!album || Object.keys(album).length === 0) {
      throw new Error('大芒详情无数据: ' + id);
    }
    return album;
  }

  async Detail(id) {
    const tid = String(id ?? '').trim();
    if (tid === '') throw new Error('无效的大芒剧集 ID');
    const album = await this.album(tid);
    const detail = {
      vod_id: tid,
      vod_name: cleanText(mapString(album, 'albumTitle')),
      vod_pic: '',
      vod_content: truncate(cleanText(mapString(album, 'albumBrief')), 400),
      vod_class: '',
      episodes: [],
      episode_count: 0,
    };
    const cover = mapString(album, 'verticalImg');
    if (cover !== '') {
      detail.vod_pic = this.media.imgProxyURL(cover, damangAPIBase + '/');
    }
    const tags = [];
    for (const rawTag of anyList(album.tagList)) {
      if (!rawTag || typeof rawTag !== 'object' || Array.isArray(rawTag)) continue;
      const name = cleanText(mapString(rawTag, 'tagName'));
      if (name !== '') tags.push(name);
    }
    detail.vod_class = tags.join(' · ');

    const seen = new Set();
    const anthologies = anyList(album.anthologies);
    for (let i = 0; i < anthologies.length; i++) {
      const rawEp = anthologies[i];
      if (!rawEp || typeof rawEp !== 'object' || Array.isArray(rawEp)) continue;
      const vid = String(mapString(rawEp, 'vid')).trim();
      if (vid === '') continue;
      let seq = atoiDefault(mapString(rawEp, 'serialno'), 0);
      if (seq < 1) seq = i + 1;
      if (seen.has(seq)) continue;
      seen.add(seq);
      detail.episodes.push({ no: seq, name: `第${seq}集`, url: `damang://${vid}` });
    }
    detail.episodes.sort((a, b) => a.no - b.no);
    detail.episode_count = detail.episodes.length;
    if (detail.episodes.length === 0) {
      throw new Error('大芒详情无剧集: ' + tid);
    }
    if (detail.vod_name === '') {
      detail.vod_name = '大芒短剧 ' + tid;
    }
    return detail;
  }

  async Play(playURL) {
    let id = '';
    try {
      id = providerSchemeArg(String(playURL ?? ''), 'damang://');
    } catch {
      id = '';
    }
    if (id === '') throw new Error('大芒播放参数无效');
    const target = `${damangPlayAPIBase}/v8/video/getSource?playType=28&fileSourceType=2&seekSourceType=2&definition=3&_support=10100001&osVersion=10&videoId=${queryEscape(id)}`;
    let lastErr = null;
    for (let attempt = 0; attempt < damangPlayRetry; attempt++) {
      let callErr = null;
      let envelope = null;
      try {
        envelope = await this.getJSON(target);
      } catch (err) {
        callErr = err;
      }
      if (!callErr) {
        const src = damangPlayURL(nestedMap(envelope, 'data'));
        if (src !== '') {
          return { src, referer: MEDIA_NO_REFERER, userAgent: damangMediaUA };
        }
        lastErr = new Error('大芒暂无播放地址: ' + id);
      } else {
        lastErr = callErr;
      }
      await sleep(damangPlayRetryWait);
    }
    if (!lastErr) {
      lastErr = new Error('大芒暂无播放地址: ' + id);
    }
    throw lastErr;
  }
}

function damangPlayURL(data) {
  for (const rawSource of anyList(data?.videoSources)) {
    if (!rawSource || typeof rawSource !== 'object' || Array.isArray(rawSource)) continue;
    const info = mapString(nestedMap(rawSource, 'disp'), 'info');
    if (isProviderHTTPMediaURL(info)) {
      return info;
    }
  }
  return '';
}



import { parsePlayScheme, atoiDefault } from '../../core/util.js';
import { dj51SiteBase } from '../consts.js';
import { loadNuxtTable, loadNuxtBusinessData } from './nine.js';

const dj51Cats = [
  { id: 'rank', name: '总榜', path: '/rank/' },
  { id: 'new', name: '最新剧场', path: '/new-theater-category/' },
  { id: 'tag:51原创', name: '51原创', path: '/tag/51原创/' },
  { id: 'tag:AI短剧', name: 'AI短剧', path: '/tag/AI短剧/' },
  { id: 'tag:成人', name: '成人', path: '/tag/成人/' },
  { id: 'tag:原创', name: '原创', path: '/tag/原创/' },
];

const reDJ51Play = /<a\b[^>]*href="\/play\/(\d+)\/1\/"[^>]*>/gi;
const reDJ51Label = /aria-label="([^"]*)"/i;
const reDJ51Alt = /\balt="([^"]*)"/gi;
const reDJ51Img = /(?:data-src|src)="(\/_img\/[^"]+|https?:\/\/[^"]*pic[^"]*)"/i;
const reDJ51M3U8 = /https?:\/\/[^\s"'<>\\]{10,200}\.m3u8[^\s"'<>\\]{0,200}/i;

export function dj51Path(cat) {
  for (const c of dj51Cats) {
    if (c.id === cat) return c.path;
  }
  return dj51Cats[0].path;
}

export class Dj51Provider {
  constructor(client, media) {
    this.client = client;
    this.media = media || null;
  }

  imgProxy(cover) {
    cover = String(cover ?? '').trim();
    if (cover === '') return '';
    if (!cover.startsWith('http://') && !cover.startsWith('https://')) {
      cover = dj51SiteBase + '/' + cover.replace(/^\/+/, '');
    }
    if (!this.media) return cover;
    return this.media.imgProxyURL(cover, dj51SiteBase + '/');
  }

  async fetch(path) {
    const resp = await this.client.fetchBytes(dj51SiteBase + path, dj51SiteBase + '/');
    const body = await resp.buffer();
    if (body.length === 0) throw new Error('51短剧空响应: ' + path);
    return body.toString('utf8');
  }

  dj51Cards(pageHTML, covers) {
    const cards = [];
    const seen = new Set();
    for (const m of pageHTML.matchAll(reDJ51Play)) {
      const id = m[1];
      if (seen.has(id)) continue;
      const tag = m[0];
      let title = '';
      const lm = reDJ51Label.exec(tag);
      if (lm && lm.length > 1) {
        const cand = lm[1].trim();
        if (cand !== '' && !cand.includes('播放') && cand !== '立即看剧') title = cand;
      }
      const start = Math.max(0, m.index - 1200);
      const end = Math.min(pageHTML.length, m.index + m[0].length + 1200);
      const block = pageHTML.slice(start, end);
      if (title === '') {
        for (const am of block.matchAll(reDJ51Alt)) {
          const cand = am[1].trim();
          if (cand !== '' && !cand.includes('封面') && cand !== 'logo') {
            title = cand;
            break;
          }
        }
      }
      if (title === '') continue;
      seen.add(id);
      const card = {
        vod_id: id,
        vod_name: title,
        vod_pic: '',
        vod_remarks: '',
        vod_class: '',
        vod_score: '',
        vod_content: '',
      };
      const cover = covers ? covers[id] : '';
      if (cover) {
        card.vod_pic = this.imgProxy(cover);
      } else {
        const im = reDJ51Img.exec(block);
        if (im && im.length > 1) card.vod_pic = this.imgProxy(im[1].trim());
      }
      cards.push(card);
    }
    return cards;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    if (!cat) cat = dj51Cats[0].id;
    const base = dj51Path(cat);
    let path = base;
    if (page > 1) path = base.replace(/\/$/, '') + '/page/' + page + '/';
    let body;
    try {
      body = await this.fetch(path);
    } catch (err) {
      if (page > 1 && String(err.message).includes('404')) return [];
      throw err;
    }
    const cards = this.dj51Cards(body, dj51Covers(body));
    if (cards.length === 0) {
      if (page > 1) return [];
      throw new Error('51短剧列表无内容: ' + path);
    }
    return cards;
  }

  async Search(wd, page) {
    if (page < 1) page = 1;
    const word = String(wd ?? '').trim();
    let path = '/search/?keyword=' + encodeURIComponent(word).replace(/%20/g, '+');
    if (page > 1) path += '&page=' + page;
    const body = await this.fetch(path);
    const all = this.dj51Cards(body, dj51Covers(body));
    const lower = word.toLowerCase();
    const hit = [];
    for (const c of all) {
      if (String(c.vod_name).toLowerCase().includes(lower)) hit.push(c);
    }
    if (hit.length === 0) throw new Error('51短剧搜索无结果（该站搜索为客户端渲染）');
    return hit;
  }

  async Detail(id) {
    id = String(id ?? '').trim();
    const slash = id.lastIndexOf('/');
    if (slash >= 0) id = id.slice(slash + 1);
    if (!/^[+-]?[0-9]+$/.test(id)) throw new Error('无效的 51短剧 ID: ' + id);
    const body = await this.fetch('/play/' + encodeURIComponent(id) + '/1/');
    const table = loadNuxtTable(body);
    if (!table) throw new Error('51短剧详情页无 SSR 数据: ' + id);
    const detail = {
      vod_id: id,
      vod_name: '',
      vod_pic: '',
      vod_content: '',
      vod_class: '',
      episodes: [],
    };
    for (const row of table.rows) {
      if (!row || Array.isArray(row) || typeof row !== 'object') continue;
      if (!('drama_name' in row)) continue;
      detail.vod_name = table.str(row, 'drama_name', 'video_title');
      detail.vod_pic = this.imgProxy(table.str(row, 'cover_img', 'cover'));
      detail.vod_content = table.str(row, 'description');
      const t = table.str(row, 'tags');
      if (t !== '') detail.vod_class = t;
      break;
    }
    if (detail.vod_class === '') {
      for (const row of table.rows) {
        if (!row || Array.isArray(row) || typeof row !== 'object') continue;
        if (!('drama_name' in row)) continue;
        const v = table.resolve(row.tags);
        if (v != null && Array.isArray(v)) {
          const names = [];
          for (const a of v) {
            if (typeof a === 'string') names.push(a);
          }
          detail.vod_class = names.join(',');
        }
        break;
      }
    }
    const bySort = new Map();
    for (const row of table.rows) {
      if (!row || Array.isArray(row) || typeof row !== 'object') continue;
      if (!('episode_title' in row)) continue;
      const seq = table.num(row, 'sort');
      if (seq < 1) continue;
      const old = bySort.get(seq);
      if (old && old.label !== '') continue;
      bySort.set(seq, { seq, label: table.str(row, 'episode_title') });
    }
    if (bySort.size === 0) throw new Error('51短剧详情页无剧集: ' + id);
    const seqs = [...bySort.keys()].sort((a, b) => a - b);
    for (const s of seqs) {
      let label = bySort.get(s).label;
      if (label === '') label = '第' + s + '集';
      detail.episodes.push({ no: s, name: label, url: 'dj51://' + id + '/' + s });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') detail.vod_name = '51短剧 ' + id;
    return detail;
  }

  async Play(playURL) {
    let parsed = parsePlayScheme(playURL, 'dj51://');
    let id = parsed ? parsed.id : '';
    let extra = parsed ? parsed.extra : '';
    let ok = !!parsed;
    if (!ok && String(playURL).includes('/play/')) {
      const raw = String(playURL);
      const rest = raw.slice(raw.indexOf('/play/') + '/play/'.length).replace(/^\/+|\/+$/g, '');
      const parts = rest.split('/');
      if (parts.length >= 1 && parts[0] !== '') {
        id = parts[0];
        if (parts.length >= 2) extra = parts[1];
        ok = true;
      }
    }
    if (!ok || id === '') throw new Error('51短剧播放参数无效');
    let seq = atoiDefault(extra, 1);
    if (seq < 1) seq = 1;
    const path = '/play/' + encodeURIComponent(id) + '/' + seq + '/';
    const body = await this.fetch(path);
    let media = '';
    const table = loadNuxtTable(body);
    if (table) {
      for (const row of table.rows) {
        if (!row || Array.isArray(row) || typeof row !== 'object') continue;
        if (!('episode_title' in row)) continue;
        if (table.num(row, 'sort') !== seq) continue;
        const v = table.str(row, 'video_url');
        if (v.includes('.m3u8')) {
          media = v;
          break;
        }
      }
    }
    if (media === '') {
      const normalized = String(body).replaceAll('\\u0026', '&').replaceAll('\\/', '/');
      const m = reDJ51M3U8.exec(normalized);
      if (m) media = m[0];
    }
    if (media === '') throw new Error('51短剧播放页无媒体地址: ' + path);
    return { src: media, referer: dj51SiteBase + '/' };
  }
}


function dj51Covers(pageHTML) {
  const table = loadNuxtTable(pageHTML);
  if (!table) return null;
  let biz = null;
  try {
    biz = loadNuxtBusinessData(pageHTML);
  } catch {
    return null;
  }
  if (!biz) return null;
  const out = {};
  const list = table.derefList(biz.list) || [];
  for (const item of list) {
    const m = table.derefMap(item);
    if (!m) continue;
    let id = '';
    const n = table.num(m, 'video_id');
    if (n > 0) id = String(n);
    else id = table.str(m, 'id');
    const cover = table.str(m, 'cover', 'cover_img');
    if (id !== '' && cover !== '') out[id] = cover;
  }
  if (Object.keys(out).length === 0) return null;
  return out;
}

export const platformCats = dj51Cats.map((c) => ({ id: c.id, name: c.name }));

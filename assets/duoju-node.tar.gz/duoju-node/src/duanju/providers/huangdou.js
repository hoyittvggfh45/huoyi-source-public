

import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes } from 'node:crypto';
import { gzipSync, gunzipSync } from 'node:zlib';
import { mapString, firstNonEmpty, resolveURL, parsePlayScheme } from '../../core/util.js';
import { truncate, legacyUserAgent } from '../shared.js';
import {
  huangdouBaseURL,
  huangdouFallbackURL,
  huangdouPlatformKey,
  huangdouDeviceType,
} from '../consts.js';
import { uuidLike, withTimeout } from './nine.js';

const huangdouVersion = '2.0.0';
const huangdouMaxBody = 16 << 20;

class HuangdouAPIError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'HuangdouAPIError';
    this.code = code;
  }
}

function isHuangdouAccessError(code) {
  return code === '813004' || code === '813005' || code === '813006' || code === '813103' || code === 'preview';
}

function huangdouKey(rid) {
  const clean = rid.replaceAll('-', '');
  const b = Buffer.from(clean, 'hex');
  if (b.length * 2 !== clean.length) throw new Error('encoding/hex: invalid byte');
  return createHmac('sha256', huangdouPlatformKey).update(b).digest();
}



function huangdouPad(src) {
  const pad = 16 - (src.length % 16);
  const out = Buffer.alloc(src.length + pad);
  src.copy(out);
  out.fill(pad, src.length);
  return out;
}

function huangdouUnpad(src) {
  if (src.length === 0 || src.length % 16 !== 0) throw new Error('黄豆解密结果无效');
  const pad = src[src.length - 1];
  if (pad <= 0 || pad > 16 || pad > src.length) throw new Error('黄豆解密结果无效');
  for (let i = src.length - pad; i < src.length; i++) {
    if (src[i] !== pad) throw new Error('黄豆解密结果无效');
  }
  return src.subarray(0, src.length - pad);
}

function huangdouEncrypt(plain, key, iv) {
  const c = createCipheriv(`aes-${key.length * 8}-cbc`, key, iv);
  c.setAutoPadding(false);
  return Buffer.concat([c.update(huangdouPad(plain)), c.final()]);
}

function huangdouDecrypt(cipherText, key, iv) {
  if (cipherText.length % 16 !== 0) throw new Error('黄豆密文不是块对齐的');
  const d = createDecipheriv(`aes-${key.length * 8}-cbc`, key, iv);
  d.setAutoPadding(false);
  return huangdouUnpad(Buffer.concat([d.update(cipherText), d.final()]));
}

function huangdouDecode(blob, key) {
  try {
    return JSON.parse(blob.toString('utf8'));
  } catch {}
  if (blob.length < 16 * 2) throw new Error('黄豆响应太短或格式异常');
  const plain = huangdouDecrypt(blob.subarray(16), key, blob.subarray(0, 16));
  let data = plain;
  if (plain.length >= 2 && plain[0] === 0x1f && plain[1] === 0x8b) {
    data = gunzipSync(plain);
    if (data.length > huangdouMaxBody) throw new Error('黄豆解压后响应过大');
  }
  return JSON.parse(data.toString('utf8'));
}

function huangdouDataMap(v) {
  const m = v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  const data = m.data;
  if (data && typeof data === 'object' && !Array.isArray(data)) return data;
  return m;
}

function huangdouMapSlice(list) {
  const out = [];
  for (const v of list) {
    if (v && typeof v === 'object' && !Array.isArray(v)) out.push(v);
  }
  return out;
}

function huangdouEpisodes(data) {
  if (Array.isArray(data.episodes)) return huangdouMapSlice(data.episodes);
  for (const key of ['sort', 'chapters', 'list']) {
    const sub = data[key];
    if (sub && typeof sub === 'object' && !Array.isArray(sub)) return huangdouEpisodes(sub);
    if (Array.isArray(sub)) return huangdouMapSlice(sub);
  }
  return [];
}

function huangdouPreviewOnly(data, media, host) {
  const flag = mapString(data, 'is_preview', 'isPreview').toLowerCase();
  if (flag === 'true' || flag === '1' || flag === 'y') return true;
  const preview = firstNonEmpty(mapString(data, 'preview_m3u8'), mapString(data, 'preview_url'));
  if (preview !== '' && (media === '' || resolveURL(host + '/', media) === resolveURL(host + '/', preview))) {
    return true;
  }
  let path;
  try {
    path = new URL(media, 'http://localhost/').pathname.toLowerCase();
  } catch {
    return false;
  }
  return path === 'preview.mp4' || path === 'preview.m3u8' || path.endsWith('/preview.mp4') || path.endsWith('/preview.m3u8');
}

export class HuangdouProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media || null;
    this.host = '';
    this.sessionID = '';
    this.deviceID = '';
  }

  ensureSession() {
    if (!this.sessionID) {
      const id = uuidLike();
      this.sessionID = id;
      this.deviceID = id;
    }
    if (!this.host) this.host = huangdouBaseURL;
  }

  setHost(host) {
    this.host = host;
  }

  currentHost() {
    return this.host;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    if (!cat) cat = 'all';
    const decoded = await this.call('/drama/rank', { page: String(page), tab: cat });
    const data = huangdouDataMap(decoded);
    const list = Array.isArray(data.list) ? data.list : null;
    if (!list || list.length === 0) throw new Error('黄豆榜单没有返回内容');
    const cards = [];
    for (const v of list) {
      const row = v && typeof v === 'object' && !Array.isArray(v) ? v : null;
      if (!row) continue;
      const id = firstNonEmpty(mapString(row, 'id'), mapString(row, 'drama_id')).replace(/^rp_/, '');
      if (!id) continue;
      let remark = firstNonEmpty(mapString(row, 'update_label'), mapString(row, 'corner'));
      if (remark === '') {
        const eps = mapString(row, 'episode_count');
        if (eps !== '') remark = '全' + eps + '集';
      }
      cards.push({
        vod_id: id,
        vod_name: firstNonEmpty(mapString(row, 'name', 'title', 't'), id),
        vod_pic: firstNonEmpty(mapString(row, 'img_y', 'img_x', 'img', 'cover', 'pic')),
        vod_remarks: remark,
        vod_class: firstNonEmpty(mapString(row, 'category', 'category_name', 'categoryName')),
        vod_score: mapString(row, 'hot_rate'),
        vod_content: firstNonEmpty(mapString(row, 'description'), mapString(row, 'summary')),
      });
    }
    if (cards.length === 0) throw new Error('黄豆榜单中没有可识别的剧集');
    return cards;
  }

  async Search() {
    throw new Error('黄豆平台暂不支持关键词搜索');
  }

  async Detail(id) {
    id = String(id ?? '').trim().replace(/^rp_/, '');
    if (!id) throw new Error('无效的黄豆剧集 ID');
    const decoded = await this.call('/drama/detail', { id });
    const data = huangdouDataMap(decoded);
    if (firstNonEmpty(mapString(data, 'id'), mapString(data, 'drama_id')).replace(/^rp_/, '') !== id) {
      throw new Error('黄豆详情返回了其他剧集');
    }
    const detail = { vod_id: id };
    detail.vod_name = firstNonEmpty(mapString(data, 'name', 'title', 't'), id);
    const cover = firstNonEmpty(mapString(data, 'img_y', 'img_x', 'img', 'cover', 'pic'));
    if (cover !== '') detail.vod_pic = cover;
    const desc = firstNonEmpty(mapString(data, 'description'), mapString(data, 'summary'));
    if (desc !== '') detail.vod_content = desc;
    const category = firstNonEmpty(mapString(data, 'category', 'category_name', 'categoryName'));
    if (category !== '') detail.vod_class = category;
    const episodes = huangdouEpisodes(data);
    if (episodes.length === 0) {
      throw new Error(
        '黄豆详情没有返回剧集列表（episode_count=' + mapString(data, 'episode_count') +
        ', keys=[' + Object.keys(data).join(' ') + ']）',
      );
    }
    const seen = new Set();
    detail.episodes = [];
    for (const ep of episodes) {
      const seqRaw = firstNonEmpty(mapString(ep, 'seq', 'episode', 'ep'));
      const seq = parseInt(seqRaw, 10);
      if (!Number.isFinite(seq) || seq < 1 || seen.has(seq)) continue;
      seen.add(seq);
      detail.episodes.push({
        no: seq,
        name: firstNonEmpty(mapString(ep, 'name', 'title'), '第' + seq + '集'),
        url: 'huangdou://' + id + '/' + seq,
      });
    }
    if (detail.episodes.length === 0) throw new Error('黄豆详情没有返回有效集数');
    detail.episode_count = detail.episodes.length;
    return detail;
  }

  async Play(playURL) {
    const parsed = parsePlayScheme(playURL, 'huangdou://');
    const seq = parsed ? parseInt(parsed.extra, 10) : NaN;
    if (!parsed || !parsed.id || !Number.isFinite(seq) || seq <= 0) {
      throw new Error('黄豆播放参数无效');
    }
    const id = parsed.id;
    const decoded = await this.call('/drama/play', { id, seq: String(seq) });
    const data = huangdouDataMap(decoded);
    const host = this.currentHost();
    let media = firstNonEmpty(mapString(data, 'm3u8'), mapString(data, 'url'), mapString(data, 'play_url'), mapString(data, 'playUrl'));
    if (huangdouPreviewOnly(data, media, host)) {
      const free = host + '/api/drama/hls/' + encodeURIComponent(id) + '/' + seq + '/play.m3u8?line=free';
      try {
        const resp = await this.client.fetchMediaBytes(free, host + '/home', '');
        const body = await resp.buffer();
        if (body.toString('utf8').trim().startsWith('#EXTM3U')) {
          return { src: free, referer: host + '/home' };
        }
      } catch {}
      throw new Error('黄豆仅提供试看，未取得该集正片');
    }
    if (media === '') {
      media = host + '/api/drama/hls/' + encodeURIComponent(id) + '/' + seq + '/play.m3u8?line=free';
      try {
        const resp = await this.client.fetchMediaBytes(media, host + '/home', '');
        const body = await resp.buffer();
        if (!body.toString('utf8').trim().startsWith('#EXTM3U')) {
          throw new Error('黄豆未提供有效的播放地址，备用播放列表也不可用');
        }
      } catch (err) {
        if (err.message === '黄豆未提供有效的播放地址，备用播放列表也不可用') throw err;
        throw new Error('黄豆未提供有效的播放地址，备用播放列表也不可用');
      }
    }
    if (!media.startsWith('http://') && !media.startsWith('https://')) {
      media = resolveURL(host + '/', media);
    }
    if (!media.startsWith('http://') && !media.startsWith('https://')) {
      throw new Error('黄豆播放地址不是 HTTP/HTTPS URL');
    }
    return { src: media, referer: host + '/home' };
  }

  async call(path, data) {
    this.ensureSession();
    const attempted = new Set();
    let attempts = 0;
    for (;;) {
      const host = this.currentHost();
      if (attempted.has(host)) break;
      attempted.add(host);
      attempts++;
      try {
        return await this.callOnce(path, data);
      } catch (err) {
        if (err instanceof HuangdouAPIError && isHuangdouAccessError(err.code)) throw err;
        if (attempts >= 2 || host !== huangdouBaseURL) throw err;
        this.setHost(huangdouFallbackURL);
      }
    }
    throw new Error('黄豆平台不可用：所有候选域名均已尝试');
  }

  async callOnce(path, data) {
    path = '/' + path.replace(/^\/+/, '');
    const rid = uuidLike();
    const key = huangdouKey(rid);
    const iv = randomBytes(16);
    const plain = Buffer.from(JSON.stringify({ data, deviceId: this.deviceID, token: '' }), 'utf8');
    const gz = gzipSync(plain);
    const cipherText = huangdouEncrypt(gz, key, iv);
    const body = Buffer.concat([iv, cipherText]);
    const host = this.currentHost();
    const requestURL = host.replace(/\/+$/, '') + '/api' + path;
    const timestamp = String(Math.floor(Date.now() / 1000));
    const signRaw = 'Dart|' + this.sessionID + '|' + rid + '|' + timestamp + '|' + path;
    const signSum = createHash('sha256').update(signRaw, 'utf8').digest('hex');
    const headers = {
      'User-Agent': legacyUserAgent,
      'Accept': '*/*',
      'Origin': host,
      'Referer': host + '/home',
      'Content-Type': 'application/octet-stream',
      'version': huangdouVersion,
      'deviceType': huangdouDeviceType,
      'requestId': rid,
      'sessionId': this.sessionID,
      'time': timestamp,
      'sign': signSum + '-' + timestamp,
    };
    const result = await withTimeout(
      (async () => {
        const resp = await this.client.doCustom('POST', requestURL, body, headers);
        const blob = await resp.buffer();
        return { blob, status: resp.status };
      })(),
      25 * 1000,
    );
    const { blob, status } = result;
    if (blob.length > huangdouMaxBody) throw new Error('黄豆响应过大');
    if (status < 200 || status >= 300) {
      throw new Error('黄豆 HTTP ' + status + ': ' + truncate(blob.toString('utf8'), 200));
    }
    return huangdouDecode(blob, key);
  }
}

export const platformCats = [
  { id: 'all', name: '总榜' },
  { id: 'mogai', name: '魔改榜' },
  { id: 'search', name: '搜索榜' },
  { id: 'favorite', name: '收藏榜' },
  { id: 'finish', name: '完结榜' },
];

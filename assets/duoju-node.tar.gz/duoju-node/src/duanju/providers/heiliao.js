

import { cleanText, encodeQuery } from '../../core/util.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { decodeHTML } from './provider_utils.js';

const heiliaoSiteBase = 'https://heiliao.com';
const heiliaoUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36';
const heiliaoMaxEps = 999;

const heiliaoCats = [
  { ID: 'ysdj', Name: '成人短剧' },
  { ID: 'hlcg', Name: '最新黑料' },
  { ID: 'jrrs', Name: '今日热瓜' },
  { ID: 'jqrm', Name: '热门黑料' },
  { ID: 'lsdg', Name: '经典黑料' },
  { ID: 'xycg', Name: '校园黑料' },
  { ID: 'fczq', Name: '反差专区' },
  { ID: 'whhl', Name: '网红黑料' },
  { ID: 'mxcw', Name: '明星丑闻' },
  { ID: 'mrds', Name: '每日大赛' },
  { ID: 'ycsq', Name: '原创社区' },
  { ID: 'djbl', Name: '独家爆料' },
  { ID: 'yqby', Name: '有求必应' },
  { ID: 'ttsq', Name: '推特社区' },
  { ID: 'shxw', Name: '社会新闻' },
  { ID: 'jqxs', Name: '黑料小说' },
  { ID: 'thzq', Name: '探花专区' },
  { ID: 'whhj', Name: '网黄合集' },
  { ID: 'cpcd', Name: '厕拍抄底' },
  { ID: 'gchl', Name: '官场爆料' },
  { ID: 'qqqw', Name: '全球奇闻' },
  { ID: 'ttzz', Name: '成人动漫' },
  { ID: 'hlkt', Name: '黑料课堂' },
  { ID: 'hlbg', Name: '黑料爆改' },
  { ID: 'syzy', Name: '深夜综艺' },
  { ID: 'sjb', Name: '体育直播' },
  { ID: 'mrrb', Name: '日榜黑料' },
  { ID: 'zbjx', Name: '周榜精选' },
  { ID: 'ybrg', Name: '月榜热瓜' },
];

export const platformCats = heiliaoCats.map((c) => ({ ID: c.ID, Name: c.Name }));


export function noSwitch(err) {
  if (!err) return null;
  const e = err instanceof Error ? err : new Error(String(err));
  e.noSwitch = true;
  return e;
}

export function httpStatusSwitch(status, err) {
  if (!err && status >= 200 && status < 300) return null;
  if (status >= 400 && status < 500) return noSwitch(new Error('站点返回 ' + status));
  if (err) return err;
  return new Error('站点返回 ' + status);
}

const reHeiliaoCatOK = /^[a-z]{2,6}$/;
const reHeiliaoCardLink = /href="\/archives\/(\d+)\/"/;
const reHeiliaoCardTitle = /class="title"[^>]*>([^<]+)</;
const reHeiliaoCardImg = /z-image-loader-url="([^"]+)"/;
const reHeiliaoCardDate = /class="date-xxx"[^>]*>([^<]+)</;
const reHeiliaoTitle = /<title>([^<]+)<\/title>/i;
const reHeiliaoMeta = /name="description"[^>]*content="([^"]+)"/i;
const reHeiliaoDPlayer = /<div class="dplayer"[^>]*?data-video_id="(\d+)_(\d+)"[^>]*?config='([^\n]+?)'/g;
const reHeiliaoH2 = /<h2>([^<]+)<\/h2>/g;
const reHeiliaoTail = /[-|]\s*黑料网.*$/;
const reHeiliaoArch = /archives\/(\d+)/;
const reHeiliaoEp = /[?&]ep=(\d+)/;

function heiliaoIDString(v) {
  if (v === undefined || v === null) return '';
  if (typeof v === 'string') return v.trim();
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : String(Math.trunc(v));
  if (typeof v === 'object') {
    if (typeof v.toString === 'function') {
      const s = v.toString();
      if (s !== '[object Object]') return s.trim();
    }
    return '';
  }
  return String(v).trim();
}

export class HeiliaoProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  headers() {
    return { 'User-Agent': heiliaoUA, Referer: `${heiliaoSiteBase}/` };
  }

  async fetch(path) {
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders('GET', heiliaoSiteBase + path, this.headers());
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    const err = httpStatusSwitch(status, terr);
    if (err) throw err;
    if (!raw || raw.length === 0) {
      throw new Error('黑料空响应: ' + path);
    }
    return raw.toString('utf8');
  }

  imgProxy(cover) {
    cover = String(cover ?? '').trim();
    if (cover === '') return '';
    if (!cover.startsWith('http://') && !cover.startsWith('https://')) {
      cover = `${heiliaoSiteBase}/${cover.replace(/^\/+/, '')}`;
    }
    if (!this.media) return cover;
    return this.media.imgProxyURL(cover, `${heiliaoSiteBase}/`);
  }

  cards(page) {
    const blocks = page.split('class="video-item"');
    const cards = [];
    const seen = new Set();
    for (const block of blocks.slice(1)) {
      const m = reHeiliaoCardLink.exec(block);
      if (!m) continue;
      const vid = m[1];
      if (seen.has(vid)) continue;
      const tm = reHeiliaoCardTitle.exec(block);
      if (!tm) continue;
      const name = cleanText(decodeHTML(tm[1]));
      if (name === '') continue;
      seen.add(vid);
      let pic = '';
      const im = reHeiliaoCardImg.exec(block);
      if (im) pic = decodeHTML(im[1]).trim();
      let remark = '';
      const rm = reHeiliaoCardDate.exec(block);
      if (rm) remark = rm[1].trim();
      cards.push({
        vod_id: vid, vod_name: name, vod_pic: this.imgProxy(pic),
        vod_remarks: remark, vod_class: '黑料', vod_score: '', vod_content: '',
      });
    }
    return cards;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    cat = String(cat || '').trim();
    if (!reHeiliaoCatOK.test(cat)) {
      cat = 'ysdj';
    }
    let path = `/${cat}/`;
    if (page > 1) {
      path = `/${cat}/page/${page}/`;
    }
    let body;
    try {
      body = await this.fetch(path);
    } catch (err) {
      if (page > 1) return [];
      throw err;
    }
    return this.cards(body);
  }

  async Search(wd, page) {
    wd = String(wd || '').trim();
    if (wd === '') {
      throw new Error('黑料搜索关键词为空');
    }
    if (page < 1) page = 1;
    const form = { word: wd, page: String(page), oauth_type: 'web' };
    const headers = {
      ...this.headers(),
      'X-Requested-With': 'XMLHttpRequest',
      'Content-Type': 'application/x-www-form-urlencoded',
    };
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders('POST', `${heiliaoSiteBase}/index/search_article`, headers, encodeQuery(form));
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    const err = httpStatusSwitch(status, terr);
    if (err) throw err;
    let parsed;
    try {
      parsed = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('黑料搜索响应非 JSON');
    }
    if ((parsed?.code ?? 0) !== 0) {
      throw new Error('黑料搜索接口错误: ' + (parsed?.msg ?? ''));
    }
    const list = parsed?.data?.list;
    const cards = [];
    for (const it of Array.isArray(list) ? list : []) {
      const vid = heiliaoIDString(it?.id);
      const name = cleanText(decodeHTML(String(it?.title ?? '')));
      if (vid === '' || name === '') continue;
      cards.push({
        vod_id: vid, vod_name: name, vod_pic: this.imgProxy(String(it?.thumb ?? '')),
        vod_remarks: String(it?.created_date ?? '').trim(), vod_class: '黑料', vod_score: '', vod_content: '',
      });
    }
    return cards;
  }

  async Detail(id) {
    id = String(id || '').trim();
    if (!/^\d+$/.test(id)) {
      throw new Error('无效的黑料剧集 ID');
    }
    const body = await this.fetch(`/archives/${id}/`);
    const detail = {
      vod_id: id,
      vod_name: '',
      vod_pic: '',
      vod_content: '',
      vod_class: '',
      episodes: [],
      episode_count: 0,
    };
    const tm = reHeiliaoTitle.exec(body);
    if (tm) {
      detail.vod_name = cleanText(decodeHTML(tm[1]).replace(reHeiliaoTail, ''));
    }
    let pic = '';
    reHeiliaoDPlayer.lastIndex = 0;
    const dm = reHeiliaoDPlayer.exec(body);
    if (dm) {
      try {
        const conf = JSON.parse(dm[3]);
        pic = String(conf?.video?.pic ?? '').trim();
      } catch {}
    }
    if (pic === '') {
      const im = reHeiliaoCardImg.exec(body);
      if (im) pic = decodeHTML(im[1]).trim();
    }
    detail.vod_pic = this.imgProxy(pic);
    const meta = reHeiliaoMeta.exec(body);
    if (meta) {
      detail.vod_content = cleanText(decodeHTML(meta[1]));
    }
    const blocks = heiliaoBlocks(body);
    if (blocks.length === 0) {
      throw new Error('黑料详情页没有可播放剧集: ' + id);
    }
    const names = heiliaoEpNames(body);
    const seen = new Set();
    for (let n = 0; n < blocks.length; n++) {
      const b = blocks[n];
      let no = b.ep;
      if (no < 1 || no > heiliaoMaxEps || seen.has(no)) {
        no = n + 1;
        while (seen.has(no)) no++;
      }
      seen.add(no);
      let name = n < names.length ? names[n] : '';
      if (name === '') name = `第${no}集`;
      detail.episodes.push({ no, name, url: `heiliao://archives/${b.vid}?ep=${no}` });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') {
      detail.vod_name = '黑料 ' + id;
    }
    return detail;
  }

  async Play(playURL) {
    const raw = String(playURL || '').trim();
    const m = reHeiliaoArch.exec(raw);
    if (!m) {
      throw new Error('黑料播放参数无效');
    }
    let ep = 1;
    const em = reHeiliaoEp.exec(raw);
    if (em) {
      const n = parseInt(em[1], 10);
      if (Number.isFinite(n) && n > 0) ep = n;
    }
    const body = await this.fetch(`/archives/${m[1]}/`);
    const blocks = heiliaoBlocks(body);
    if (blocks.length === 0) {
      throw new Error('黑料播放器数据缺失: ' + m[1]);
    }
    if (ep < 1 || ep > blocks.length) {
      ep = 1;
    }
    let conf;
    try {
      conf = JSON.parse(blocks[ep - 1].configRaw);
    } catch {
      throw new Error('黑料播放配置解析失败: ' + m[1]);
    }
    let src = String(conf?.video?.url ?? '').trim();
    if (src === '') {
      for (const alt of Array.isArray(conf?.video?.urls) ? conf.video.urls : []) {
        const v = String(alt?.url ?? '').trim();
        if (v !== '') {
          src = v;
          break;
        }
      }
    }
    if (!isProviderHTTPMediaURL(src)) {
      throw new Error('黑料播放地址无效: ' + m[1]);
    }
    return { src, referer: `${heiliaoSiteBase}/`, userAgent: heiliaoUA };
  }
}

export function heiliaoBlocks(page) {
  const out = [];
  reHeiliaoDPlayer.lastIndex = 0;
  let m;
  let n = 0;
  while ((m = reHeiliaoDPlayer.exec(page)) !== null) {
    const vid = m[1];
    let ep = parseInt(m[2], 10);
    if (!Number.isFinite(ep) || ep < 1) ep = n + 1;
    out.push({ vid, ep, configRaw: m[3] });
    n++;
  }
  return out;
}

export function heiliaoEpNames(page) {
  const names = [];
  let prev = 0;
  reHeiliaoDPlayer.lastIndex = 0;
  let m;
  while ((m = reHeiliaoDPlayer.exec(page)) !== null) {
    const seg = page.slice(prev, m.index);
    prev = m.index + m[0].length;
    let name = '';
    reHeiliaoH2.lastIndex = 0;
    let one;
    while ((one = reHeiliaoH2.exec(seg)) !== null) {
      name = cleanText(decodeHTML(one[1]));
    }
    names.push(name);
  }
  return names;
}

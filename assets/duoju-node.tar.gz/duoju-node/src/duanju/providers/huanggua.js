

import { cleanText, atoiDefault, parsePlayScheme } from '../../core/util.js';
import { truncate, stripTagsSimple } from '../shared.js';
import { huangguaSiteBase, huangguaMirrorHosts } from '../consts.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { Mirror, withMirror, withTimeout, httpStatusSwitch, unescapeHTML, nuxtDramaList } from './nine.js';

const huangguaFetchTimeout = 12 * 1000;

const huangguaCats = [
  { id: 'recommend', name: '推荐', path: '/' },
  { id: 'yuanchuang', name: '原创', path: '/yuanchuang' },
  { id: 'mogai', name: '魔改', path: '/mogai' },
  { id: 'manju', name: 'AI漫剧', path: '/manju' },
  { id: 'zhenren', name: '真人短剧', path: '/zhenren' },
  { id: 'aiduanju', name: 'AI短剧', path: '/aiduanju' },
  { id: 'browse', name: '全部', path: '/browse' },
  { id: 'browse-new', name: '最新', path: '/browse?sort=new' },
];

const reHGEpLinkAny = /<a\b[^>]*href="\/play\/([0-9a-zA-Z\-]+)\/(\d+)"[^>]*>/gi;
const reHGM3U8 = /https?:\/\/[^\s"'<>\\]{10,200}\.m3u8[^\s"'<>\\]{0,300}/gi;
const reHGUMirrorHost = /(https?:\/\/[a-z0-9\-]{2,24}\.[a-z0-9]{5,20}\.cc)/gi;
const reHGUTitleTag = /<title>([\s\S]*?)<\/title>/is;
const reHGUDesc = /<meta\s+name="description"\s+content="([^"]*)"/is;
const reHGH1 = /<h1[^>]*>([\s\S]*?)<\/h1>/is;

const huangguaMarker = 'data-xpch="card-drama"';

function huangguaMirrorList() {
  const out = [];
  for (const part of String(huangguaMirrorHosts).split(',')) {
    let host = part.trim();
    if (!host) continue;
    if (!host.startsWith('http://') && !host.startsWith('https://')) host = 'https://' + host;
    out.push(host.replace(/\/$/, ''));
  }
  return out;
}


function huangguaNormalize(body) {
  return String(body).replace(/\\u0026|\\u002F|\\\//g, (m) => (m === '\\u0026' ? '&' : '/'));
}

function huangguaCatPath(cat) {
  for (const c of huangguaCats) {
    if (c.id === cat) return c.path;
  }
  return huangguaCats[0].path;
}

function huangguaCatName(cat) {
  for (const c of huangguaCats) {
    if (c.id === cat) return c.name;
  }
  return '';
}

function huangguaValidSlug(id) {
  return typeof id === 'string' && id !== '' && id.length <= 64 && /^[A-Za-z0-9_-]+$/.test(id);
}

export class HuangguaProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
    this.mirror = new Mirror('黄瓜短剧', huangguaMirrorList(), client, (host) => this.probe(host));
  }

  async probe(host) {
    let result;
    try {
      result = await withTimeout(
        this.client.fetchWithHeaders('GET', host + '/', { Referer: host + '/' }, null),
        huangguaFetchTimeout,
      );
    } catch (err) {
      return err;
    }
    const sw = httpStatusSwitch(result.status, null);
    if (sw) return sw;
    if (!result.raw.toString('utf8').includes(huangguaMarker)) {
      throw new Error('黄瓜短剧镜像不是真站: ' + host);
    }
  }

  currentHost() {
    return this.mirror.current();
  }

  async discoverAsync() {
    const candidates = [huangguaSiteBase];
    try {
      const resp = await withTimeout(
        this.client.fetchBytes(huangguaSiteBase + '/', huangguaSiteBase + '/'),
        huangguaFetchTimeout,
      );
      const body = await resp.buffer();
      if (body.length > 0) {
        const page = body.toString('utf8');
        const seen = new Set([huangguaSiteBase.replace(/\/$/, '')]);
        for (const m of page.matchAll(reHGUMirrorHost)) {
          const host = m[1].trim().replace(/\/$/, '');
          if (host.includes('hgdju') || seen.has(host)) continue;
          seen.add(host);
          candidates.push(host);
        }
      }
    } catch {}
    return candidates;
  }

  fetchVia(mirror, path) {
    return withMirror(mirror, async (host) => {
      const result = await withTimeout(
        this.client.fetchWithHeaders('GET', host + path, { Referer: host + '/' }, null),
        huangguaFetchTimeout,
      );
      const sw = httpStatusSwitch(result.status, null);
      if (sw) throw sw;
      if (result.raw.length === 0) throw new Error('黄瓜短剧空响应: ' + path);
      return result.raw.toString('utf8');
    });
  }

  async fetch(path) {
    const m = this.mirror;
    let body;
    try {
      body = await this.fetchVia(m, path);
      return body;
    } catch (err) {
      const hosts = await this.discoverAsync();
      if (hosts.length <= 1) throw err;
      this.mirror = new Mirror('黄瓜短剧', hosts, this.client, (host) => this.probe(host));
      return this.fetchVia(this.mirror, path);
    }
  }

  imgProxy(raw) {
    raw = String(raw ?? '').trim();
    if (raw === '') return '';
    if (!raw.startsWith('http://') && !raw.startsWith('https://')) {
      raw = this.currentHost() + '/' + raw.replace(/^\/+/, '');
    }
    return this.media.imgProxyURL(raw, this.currentHost() + '/');
  }

  huangguaCards(pageHTML, catName) {
    const cards = nuxtDramaList(pageHTML, (u) => this.imgProxy(u));
    if (!catName) return cards;
    for (const card of cards) {
      if (card.vod_class === '') card.vod_class = catName;
    }
    return cards;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    if (!cat) cat = huangguaCats[0].id;
    const base = huangguaCatPath(cat);
    let path = base;
    if (page > 1) path = base.replace(/\/$/, '') + '?page=' + page;
    let pageHTML;
    try {
      pageHTML = await this.fetch(path);
    } catch (err) {
      if (page > 1 && String(err.message).includes('HTTP 404')) return [];
      throw err;
    }
    const cards = this.huangguaCards(pageHTML, huangguaCatName(cat));
    if (cards.length === 0) {
      if (page > 1) return [];
      throw new Error('黄瓜短剧列表无内容: ' + path);
    }
    return cards;
  }

  async Search(wd) {
    wd = String(wd ?? '').trim();
    if (wd === '') throw new Error('黄瓜短剧搜索关键词为空');
    const pageHTML = await this.fetch('/search?q=' + encodeURIComponent(wd).replace(/%20/g, '+'));
    const cards = this.huangguaCards(pageHTML, '');
    if (cards.length === 0) throw new Error('黄瓜短剧搜索无结果: ' + wd);
    return cards;
  }

  async Detail(id) {
    id = String(id ?? '').trim();
    const slash = id.lastIndexOf('/');
    if (slash >= 0) id = id.slice(slash + 1);
    if (!huangguaValidSlug(id)) throw new Error('无效的黄瓜短剧 ID: ' + id);
    const pageHTML = await this.fetch('/drama/' + encodeURIComponent(id));
    const detail = {
      vod_id: id,
      vod_name: '',
      vod_pic: '',
      vod_content: '',
      vod_class: '',
      episodes: [],
    };
    const h1 = reHGH1.exec(pageHTML);
    if (h1 && h1.length > 1) detail.vod_name = cleanText(unescapeHTML(stripTagsSimple(h1[1])));
    if (detail.vod_name === '') {
      const t = reHGUTitleTag.exec(pageHTML);
      if (t && t.length > 1) detail.vod_name = cleanText(unescapeHTML(stripTagsSimple(t[1])));
    }
    const desc = reHGUDesc.exec(pageHTML);
    if (desc && desc.length > 1) detail.vod_content = truncate(cleanText(unescapeHTML(desc[1])), 400);
    const seen = new Set();
    for (const m of pageHTML.matchAll(reHGEpLinkAny)) {
      if (m[1] !== id) continue;
      const seq = atoiDefault(m[2], 0);
      if (seq < 1 || seen.has(seq)) continue;
      seen.add(seq);
      detail.episodes.push({ no: seq, name: '第' + seq + '集', url: 'huanggua://' + id + '/' + seq });
    }
    detail.episodes.sort((a, b) => a.no - b.no);
    detail.episode_count = detail.episodes.length;
    if (detail.episodes.length === 0) throw new Error('黄瓜短剧详情页无剧集: ' + id);
    if (detail.vod_name === '') detail.vod_name = '黄瓜短剧 ' + id;
    return detail;
  }

  async Play(playURL) {
    let parsed = parsePlayScheme(playURL, 'huanggua://');
    let id = parsed ? parsed.id : '';
    let extra = parsed ? parsed.extra : '';
    let ok = !!parsed;
    if (!ok) {
      const raw = String(playURL);
      const i = raw.indexOf('/play/');
      if (i >= 0) {
        const parts = raw.slice(i + '/play/'.length).replace(/^\/+|\/+$/g, '').split('/');
        if (parts.length >= 1 && parts[0] !== '') {
          id = parts[0];
          if (parts.length >= 2) extra = parts[1];
          ok = true;
        }
      }
    }
    if (!ok || id === '') throw new Error('黄瓜短剧播放参数无效');
    let seq = atoiDefault(extra, 1);
    if (seq < 1) seq = 1;
    const pageHTML = await this.fetch('/play/' + encodeURIComponent(id) + '/' + seq);
    const normalized = huangguaNormalize(pageHTML);
    let media = '';
    for (const m of normalized.matchAll(reHGM3U8)) {
      const cand = unescapeHTML(m[0].trim());
      if (cand.includes('.m3u8')) {
        media = cand;
        break;
      }
    }
    if (media === '' || !isProviderHTTPMediaURL(media)) {
      throw new Error('黄瓜短剧第' + seq + '集暂无播放地址');
    }
    return { src: media, referer: this.currentHost() + '/' };
  }
}

export const platformCats = huangguaCats.map((c) => ({ id: c.id, name: c.name }));

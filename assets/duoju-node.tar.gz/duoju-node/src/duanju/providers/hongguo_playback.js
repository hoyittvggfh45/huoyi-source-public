


import { createDecipheriv } from 'node:crypto';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { pkcs7Unpad } from '../shared.js';
import { hongguoContentKey, decodeHongguoBase64 } from './hongguo.js';
import { hongguoNumericID } from './hongguo.js';

export const hongguoPlaybackAPI = 'https://djapi.999888456.xyz/api/hongguo/play';
export const hongguoPlaybackReferer = 'https://novel.snssdk.com/';

export function hongguoPlaybackReference(seriesID, videoID) {
  return JSON.stringify({
    content_type: 1004,
    from_video_id: '',
    series_id: seriesID,
    vid: videoID,
    video_platform: 3,
  });
}

export async function resolveHongguoPlayback(client, seriesID, videoID) {
  if (!hongguoNumericID.test(seriesID) || !hongguoNumericID.test(videoID)) {
    throw new Error('红果播放请求缺少有效的剧集 ID');
  }
  const idParam = Buffer.from(hongguoPlaybackReference(seriesID, videoID), 'utf8').toString('base64');
  
  let body;
  try {
    const resp = await client.fetchWith(`${hongguoPlaybackAPI}?id=${encodeURIComponent(idParam)}`, 'https://hongguo.dj51.cc/');
    body = (await resp.buffer()).toString('utf8');
  } catch (err) {
    const resp = await client.fetchWith(`${hongguoPlaybackAPI.replace('https://', 'http://')}?id=${encodeURIComponent(idParam)}`, 'https://hongguo.dj51.cc/');
    body = (await resp.buffer()).toString('utf8');
  }
  const decoded = decodeHongguoPlaybackBody(body);
  let response;
  try {
    response = JSON.parse(decoded.toString('utf8'));
  } catch {
    throw new Error('红果备用播放接口返回了无效数据');
  }
  for (const flag of [response.parse, response.jx]) {
    const text = String(flag ?? '').trim();
    if (text !== '' && text !== 'null' && text !== 'false' && text !== '0' && text !== '"0"' && text !== '""') {
      throw new Error('红果备用播放接口没有返回直接媒体地址');
    }
  }
  const options = Array.isArray(response.key_urls) ? response.key_urls : [];
  const variants = [];
  let best = null;
  let bestQuality = -1;
  let keyErr = null;
  for (const option of options) {
    if (!option || typeof option !== 'object') continue;
    const mediaURL = String(option.src ?? '').trim();
    if (mediaURL.length > 8192 || !isProviderHTTPMediaURL(mediaURL)) continue;
    let key;
    try {
      key = hongguoContentKey(String(option.spade_a ?? ''));
    } catch (err) {
      keyErr = err;
      continue;
    }
    const qm = /[0-9]+/.exec(String(option.name ?? ''));
    const quality = qm ? parseInt(qm[0], 10) : 0;
    const media = { url: mediaURL, referer: hongguoPlaybackReferer, key: key.toString('hex'), quality };
    variants.push(media);
    if (quality > bestQuality) {
      best = media;
      bestQuality = quality;
    }
  }
  if (best) {
    best.variants = variants;
    return best;
  }
  if (keyErr) throw keyErr;
  throw new Error('红果备用播放接口未返回该集可用的媒体和密钥，请稍后重试或确认该集是否仍可访问');
}

const HONGGUO_PLAYBACK_MASK = Buffer.from([
  104, 64, 70, 166, 190, 168, 143, 130, 225, 254, 251, 217, 196, 34, 45, 60, 29, 20, 103, 105,
]);

export function decodeHongguoPlaybackBody(body) {
  const text = String(body ?? '').trim();
  if (!text.startsWith('v2.')) return Buffer.from(text, 'utf8');
  const parts = text.split('.');
  if (parts.length !== 3 || parts[1].length <= 4 || parts[1].length > 1028) {
    throw new Error('红果备用接口响应密钥无效');
  }
  const hexPart = parts[1].slice(4);
  if (!/^[0-9a-fA-F]*$/.test(hexPart) || hexPart.length % 2 !== 0) {
    throw new Error('红果备用接口响应密钥无效');
  }
  const encoded = Buffer.from(hexPart, 'hex');
  if (encoded.length < 32) throw new Error('红果备用接口响应密钥无效');
  const material = Buffer.alloc(encoded.length);
  for (let index = 0; index < encoded.length; index++) {
    const current = encoded[index];
    const previous = index > 0 ? encoded[index - 1] : 109;
    const slot = index % HONGGUO_PLAYBACK_MASK.length;
    const salt = HONGGUO_PLAYBACK_MASK[slot] ^ ((90 + 13 * slot) & 0xff) ^ 85;
    const shifted = (current + 215 - 11 * index) & 0xff;
    const rotated = (((shifted << 3) | (shifted >>> 5)) & 0xff) >>> 0;
    material[index] = (previous ^ salt ^ rotated) & 0xff;
  }
  const ciphertext = decodeHongguoBase64(parts[2]);
  if (ciphertext.length === 0 || ciphertext.length % 16 !== 0) {
    throw new Error('红果备用接口加密响应无效');
  }
  const cipher = createDecipheriv('aes-128-cbc', material.subarray(0, 16), material.subarray(16, 32));
  cipher.setAutoPadding(false);
  const plain = Buffer.concat([cipher.update(ciphertext), cipher.final()]);
  return pkcs7Unpad(plain, 16);
}

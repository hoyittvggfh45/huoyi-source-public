
import {
  firstNonEmpty, mapString, anyList, nestedMap, parsePlayScheme, parseRouterData, routerLoaderMap, resolveURL, encodeQuery,
} from '../../core/util.js';
import { hongguoBaseURL, hongguoAppBaseURL, hongguoAppReferer } from '../consts.js';
import { resolveHongguoPlayback } from './hongguo_playback.js';
import { resolveHongguoAppMedia } from './hongguo_device.js';

export const hongguoNumericID = /^[0-9]{1,32}$/;


export const platformCats = [
  { id: 'rank-hot', name: '总热播榜' },
  { id: 'rank-real', name: '真人剧榜' },
  { id: 'rank-comic', name: '漫剧榜' },
  { id: 'rank-ai', name: 'AI剧榜' },
  { id: 'real-drama', name: '真人剧' },
  { id: 'comic-drama', name: '漫剧' },
  { id: 'ai-drama', name: 'AI剧' },
];

export const hongguoAppUA = 'com.phoenix.read/71332 (Linux; U; Android 16; zh_CN; 25053RT47C; Build/BP2A.250605.031.A3; Cronet/TTNetVersion:04657795 2026-01-23 QuicVersion:c67e9834 2025-09-08)';



export class HongguoAppClient {
  constructor(client) {
    this.client = client;
    this.deviceID = '829902912863503360';
    this.installID = '250404579274111008';
  }

  async videoModel(videoID) {
    
    let lastErr = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      if (attempt > 0) await new Promise((r) => setTimeout(r, attempt * 600));
      try {
        return await this.videoModelOnce(videoID);
      } catch (err) {
        lastErr = err;
      }
    }
    throw lastErr || new Error('红果 App 接口请求失败');
  }

  async videoModelOnce(videoID) {
    const params = {
      aid: '8662', app_name: 'novelread', version_code: '71332', version_name: '7.1.3.32',
      manifest_version_code: '71332', update_version_code: '71332', channel: 'update_64',
      device_platform: 'android', os: 'android', ssmix: 'a', device_type: '25053RT47C',
      device_brand: 'Redmi', language: 'zh', os_api: '36', os_version: '16',
      resolution: '1280*2772', dpi: '520', ac: 'wifi', device_id: this.deviceID, iid: this.installID,
    };
    params._rticket = String(Date.now());
    
    const rawQuery = Object.keys(params).sort().map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(params[k])}`).join('&');
    const payload = JSON.stringify({
      biz_param: {
        detail_page_version: 0, device_level: 3, disable_digg_stat: false,
        need_all_video_definition: true, need_mp4_align: false,
        use_os_player: false, use_server_dns: false, video_platform: 1024,
      },
      mixed_video_id_map: { '1004': [videoID] },
    });
    const requestURL = `${hongguoAppBaseURL}/novel/player/multi_video_model/v1/?${rawQuery}`;
    const headers = {
      'User-Agent': hongguoAppUA,
      Accept: 'application/json',
      'X-XS-From-Web': '0',
      'Sdk-Version': '2',
      'Content-Type': 'application/json; charset=utf-8',
    };
    const resp = await this.client.doCustom('POST', requestURL, Buffer.from(payload, 'utf8'), headers);
    const content = await resp.buffer();
    if (resp.status !== 200) throw new Error(`红果 App 接口 HTTP ${resp.status}`);
    let envelope;
    try {
      envelope = JSON.parse(content.toString('utf8'));
    } catch {
      throw new Error('红果 App 接口返回格式异常');
    }
    if (envelope.code !== 0) throw new Error(`红果 App 接口暂不可用（${envelope.code}）`);
    let raw = null;
    for (const key of Object.keys(envelope.data || {})) {
      const entry = envelope.data[key];
      if (entry && entry.video_model) {
        raw = entry.video_model;
        break;
      }
    }
    if (!raw) throw new Error('红果 App 接口未返回播放信息');
    if (typeof raw === 'string') {
      try {
        raw = JSON.parse(raw);
      } catch {
        throw new Error('红果 App 播放信息格式异常');
      }
    }
    return raw;
  }

  async playMedia(videoID) {
    const model = await this.videoModel(videoID);
    return hongguoSelectAppMedia(model);
  }
}

export function hongguoSelectAppMedia(model) {
  let variants = anyList(model.video_list);
  const rows = model.video_list;
  if (rows && typeof rows === 'object' && !Array.isArray(rows) && variants.length === 0) {
    const keys = Object.keys(rows).sort();
    for (const key of keys) variants.push(rows[key]);
  }
  const choices = [];
  let keyErr = null;
  for (const row of variants) {
    const variant = row && typeof row === 'object' ? row : null;
    if (!variant) continue;
    const meta = nestedMap(variant, 'video_meta') || {};
    const codec = String(mapString(meta, 'codec_type')).toLowerCase();
    if (codec === 'bytevc2' || String(mapString(variant, 'gear_des_key')).toLowerCase().includes('bytevc2')) continue;
    const addresses = hongguoMediaAddresses(variant);
    if (addresses.length === 0) continue;
    const encryption = nestedMap(variant, 'encrypt_info') || {};
    const spade = mapString(encryption, 'spade_a');
    let key = '';
    if (spade !== '' || encryption.encrypt === true || mapString(encryption, 'encryption_method') === 'cenc-aes-ctr') {
      try {
        const derived = hongguoContentKey(spade);
        key = derived.toString('hex');
      } catch (err) {
        keyErr = err;
        continue;
      }
    }
    let height = parseInt(mapString(meta, 'vheight'), 10) || 0;
    const defMatch = /[0-9]+/.exec(mapString(meta, 'definition'));
    const definition = defMatch ? parseInt(defMatch[0], 10) : NaN;
    if (Number.isFinite(definition) && definition > 0) {
      height = definition;
    } else {
      const width = parseInt(mapString(meta, 'vwidth'), 10) || 0;
      if (width > 0 && (height === 0 || width < height)) height = width;
    }
    let score = height * 10;
    if (codec === 'h264' || codec === 'avc1') score += 1;
    for (const address of addresses) {
      choices.push({ media: { url: address, key, quality: height }, score });
    }
  }
  if (choices.length > 0) {
    choices.sort((a, b) => b.score - a.score);
    return choices[0].media;
  }
  if (keyErr) throw new Error('红果 App 媒体密钥不可用: ' + keyErr.message);
  throw new Error('红果 App 未返回兼容的媒体');
}

export function hongguoMediaAddresses(info) {
  const addresses = [];
  const seen = new Set();
  const add = (value) => {
    if (typeof value === 'string') {
      let address = value.trim();
      if (address.length > 8192) return;
      if (!address.startsWith('http://') && !address.startsWith('https://')) {
        let decoded;
        try {
          decoded = decodeHongguoBase64(address);
        } catch {
          return;
        }
        address = decoded.toString('utf8').trim();
      }
      if ((address.startsWith('http://') || address.startsWith('https://')) && !seen.has(address)) {
        seen.add(address);
        addresses.push(address);
      }
    } else if (Array.isArray(value)) {
      for (const item of value) add(item);
    }
  };
  for (const key of ['main_url', 'backup_url', 'backup_url_1', 'backup_url_2', 'backup_urls', 'url_list']) {
    add(info[key]);
  }
  return addresses;
}

export function decodeHongguoBase64(value) {
  const v = String(value ?? '').trim();
  if (/^[A-Za-z0-9+/]+={0,2}$/.test(v)) return Buffer.from(v, 'base64');
  return Buffer.from(v.replace(/=+$/, ''), 'base64');
}


export function hongguoContentKey(value) {
  if (!value || value.length > 1024) throw new Error('红果媒体密钥数据过长');
  const raw = decodeHongguoBase64(value);
  if (raw.length < 3) throw new Error('红果媒体密钥编码无效');
  const tagLength = (raw[0] ^ raw[1] ^ raw[2]) - 48;
  const contentLength = raw.length - tagLength - 1;
  if (tagLength < 1 || contentLength < 33 || contentLength >= raw.length) {
    throw new Error('红果媒体密钥结构无效');
  }
  const seed = raw[raw.length - tagLength - 2] ^ raw[raw.length - tagLength - 1];
  const tag = Buffer.alloc(tagLength);
  for (let index = 0; index < tagLength; index++) {
    tag[index] = raw[raw.length - tagLength + index] ^ seed;
  }
  const tagStr = tag.toString('latin1');
  if (tagStr === 'app_v2' || tagStr === 'web_v2') {
    throw new Error('红果媒体密钥版本暂不支持');
  }
  const decoded = Buffer.alloc(contentLength);
  let previousEven = 250;
  let previousOdd = 85;
  for (let index = 0; index < contentLength; index++) {
    const current = raw[1 + index];
    let previous;
    if (index % 2 === 0) {
      previous = previousEven;
      previousEven = current;
    } else {
      previous = previousOdd;
      previousOdd = current;
    }
    decoded[index] = ((previous ^ current) - 21 - bitCount(index)) & 0xff;
  }
  const padding = parseInt(String.fromCharCode(decoded[0]), 36);
  if (!Number.isFinite(padding) || contentLength - padding - 1 !== 32) {
    throw new Error('红果媒体密钥内容无效');
  }
  const keyHex = decoded.toString('latin1', 1, 33);
  if (!/^[0-9a-fA-F]{32}$/.test(keyHex)) {
    throw new Error('红果媒体密钥不是有效的 AES-128 密钥');
  }
  return Buffer.from(keyHex, 'hex');
}

function bitCount(n) {
  let count = 0;
  while (n) {
    n &= n - 1;
    count++;
  }
  return count;
}



export const hongguoRankBoards = {
  'rank-hot': { path: 'hot-drama', name: '总热播榜' },
  'rank-real': { path: 'hot-real-drama', name: '真人剧榜' },
  'rank-comic': { path: 'hot-comic-drama', name: '漫剧榜' },
  'rank-ai': { path: 'hot-ai-drama', name: 'AI剧榜' },
};

const RANK_CACHE_TTL = 5 * 60 * 1000;
const RANK_STALE_LIMIT = 24 * 60 * 60 * 1000;
const hongguoRankCache = new Map();

const rankScriptTagRe = /<script\b[^>]*\bdata-fn-args\s*=[^>]*>/gis;

function tagAttr(tag, name) {
  const esc = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  let m = new RegExp(`\\b${esc}\\s*=\\s*"([^"]*)"`, 'is').exec(tag);
  if (!m) m = new RegExp(`\\b${esc}\\s*=\\s*'([^']*)'`, 'is').exec(tag);
  if (!m) return '';
  return m[1]
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}

function rankCardsFromContent(content, board, page) {
  if (!content || typeof content !== 'object') return null;
  const rows = anyList(content.rankList);
  if (rows.length === 0) return null;
  const pagination = content.pagination && typeof content.pagination === 'object' ? content.pagination : {};
  const pageNum = parseInt(mapString(pagination, 'pageNum'), 10) || 0;
  let totalPages = parseInt(mapString(pagination, 'totalPages'), 10) || 0;
  if (pageNum !== 0 && pageNum !== page) {
    throw new Error('红果榜单分页数据与请求页不符');
  }
  if (totalPages < 1) totalPages = 1;
  const cards = [];
  for (const r of rows) {
    const row = r && typeof r === 'object' ? r : {};
    const id = firstNonEmpty(mapString(row, 'seriesId', 'id'));
    if (!hongguoNumericID.test(id)) continue;
    cards.push({
      vod_id: id,
      vod_name: mapString(row, 'title'),
      vod_pic: mapString(row, 'cover'),
      vod_remarks: mapString(row, 'heatText'),
      vod_class: board.name,
      vod_score: mapString(row, 'scoreText').replace(/^评分/, ''),
      vod_content: mapString(row, 'description'),
    });
  }
  if (cards.length === 0) {
    throw new Error('红果榜单数据尚未完整返回，请稍后重试');
  }
  return { cards, totalPages };
}

function parseHongguoRank(body, board, page) {
  const route = `rank_${board.path}/page`;
  const tags = body.match(rankScriptTagRe) || [];
  for (const tag of tags) {
    const fnName = tagAttr(tag, 'data-fn-name');
    const argsRaw = tagAttr(tag, 'data-fn-args');
    if (!argsRaw) continue;
    let args;
    try {
      args = JSON.parse(argsRaw);
    } catch {
      continue;
    }
    if (!Array.isArray(args) || args.length < 2) continue;
    if (String(args[0]) !== route) continue;
    if (fnName === 'r' && args.length >= 3) {
      const found = rankCardsFromContent(args[2], board, page);
      if (found) return found;
      continue;
    }
    const fields = Array.isArray(args[1]) ? args[1] : [];
    for (const f of fields) {
      const field = f && typeof f === 'object' ? f : null;
      if (!field || field.key !== 'content') continue;
      const fnArgs = Array.isArray(field.routerDataFnArgs) ? field.routerDataFnArgs : [];
      if (fnArgs.length === 0) continue;
      let raw = fnArgs[0];
      for (let i = 0; i < 3; i++) {
        if (typeof raw !== 'string') { raw = null; break; }
        try {
          raw = JSON.parse(raw);
        } catch {
          raw = null;
          break;
        }
      }
      const found = rankCardsFromContent(raw, board, page);
      if (found) return found;
    }
  }
  throw new Error('红果榜单数据尚未完整返回，请稍后重试');
}



export class HongguoProvider {
  constructor(client) {
    this.client = client;
    this.app = new HongguoAppClient(client);
  }

  async List(cat, page) {
    
    
    const validBoard = cat && hongguoRankBoards[cat];
    const validCatNames = ['real-drama', 'comic-drama', 'ai-drama', 'variety', 'movie', 'tv'];
    if (!cat || cat === 'all' || (!validBoard && !validCatNames.includes(cat))) {
      cat = 'real-drama';
    }
    if (page < 1) page = 1;
    if (hongguoRankBoards[cat]) return this.hongguoRankList(cat, page);
    const target = `${hongguoBaseURL}/category/${encodeURIComponent(cat)}?page=${page}`;
    const resp = await this.client.fetchBytes(target, `${hongguoBaseURL}/`);
    const body = (await resp.buffer()).toString('utf8');
    const pageMap = routerLoaderMap(parseRouterData(body), 'category_page', 'category_');
    if (!pageMap || !pageMap || pageMap.isSuccess === false) {
      throw new Error(`红果分类数据不可用（页面结构可能变化）: ${target}`);
    }
    const rows = anyList(pageMap.recommendList);
    const cards = [];
    for (const row of rows) {
      const card = hongguoCard(row, cat);
      if (card.vod_id) cards.push(card);
    }
    if (cards.length === 0) throw new Error(`红果分类页无卡片: ${target}`);
    return cards;
  }

  async hongguoRankList(cat, page) {
    const board = hongguoRankBoards[cat];
    if (!board) throw new Error(`未知红果榜单: ${cat}`);
    if (page < 1) page = 1;
    const key = `${cat}:${page}`;
    const cached = hongguoRankCache.get(key);
    const firstPage = hongguoRankCache.get(`${cat}:1`);
    if (cached && Date.now() - cached.fetchedAt < RANK_CACHE_TTL) return cached.cards;
    if (firstPage && page > firstPage.totalPages) return [];

    let lastErr = null;
    for (let attempt = 0; attempt < 4; attempt++) {
      if (attempt > 0) {
        await new Promise((r) => setTimeout(r, attempt * attempt * 350));
      }
      let target = `${hongguoBaseURL}/rank/${board.path}`;
      if (page > 1) target += `?page=${page}`;
      try {
        const resp = await this.client.fetchBytes(target, `${hongguoBaseURL}/`);
        const body = (await resp.buffer()).toString('utf8');
        const { cards, totalPages } = parseHongguoRank(body, board, page);
        hongguoRankCache.set(key, { cards, totalPages, fetchedAt: Date.now() });
        return cards;
      } catch (err) {
        if (String(err.message).includes('404')) return [];
        lastErr = err;
      }
    }
    if (cached && Date.now() - cached.fetchedAt < RANK_STALE_LIMIT) return cached.cards;
    if (firstPage && page > firstPage.totalPages) return [];
    throw lastErr;
  }

  async Search(wd, page) {
    if (page < 1) page = 1;
    if (page > 1) return [];
    
    
    const query = encodeQuery({ query: String(wd || ''), offset: String((page - 1) * 20), count: '20', aid: '8662' });
    const target = `${hongguoBaseURL}/api/search/result/?${query}`;
    const resp = await this.client.fetchBytes(target, `${hongguoBaseURL}/`);
    const body = (await resp.buffer()).toString('utf8');
    let payload;
    try {
      payload = JSON.parse(body);
    } catch {
      throw new Error('红果搜索返回格式异常');
    }
    if (payload && typeof payload === 'object' && payload.code && payload.code !== '0') {
      throw new Error(`红果搜索未返回有效结果（${String(payload.code).slice(0, 30)}）`);
    }
    const rows = anyList(payload && payload.searchList);
    const cards = [];
    for (const row of rows) {
      const card = hongguoCard(row, '短剧');
      if (card.vod_id) cards.push(card);
    }
    if (rows.length > 0 && cards.length === 0) {
      throw new Error('红果搜索结果中没有可识别的剧集');
    }
    return cards;
  }

  async Detail(id) {
    const target = `${hongguoBaseURL}/detail?series_id=${encodeURIComponent(id)}`;
    const resp = await this.client.fetchBytes(target, `${hongguoBaseURL}/`);
    const body = (await resp.buffer()).toString('utf8');
    const pageMap = routerLoaderMap(parseRouterData(body), 'detail_page', 'detail_') || {};
    const detail = pageMap.seriesDetail && typeof pageMap.seriesDetail === 'object' ? pageMap.seriesDetail : null;
    if (!detail || Object.keys(detail).length === 0) {
      throw new Error('红果详情为空（页面结构可能变化）');
    }
    const title = firstNonEmpty(mapString(detail, 'series_name', 'series_title', 'name'), id);
    const vids = anyList(detail.vid_list);
    const result = { vod_id: id, vod_name: title, vod_pic: '', vod_content: '', vod_class: '', episodes: [], episode_count: 0 };
    const seen = new Set();
    for (const v of vids) {
      const vid = String(v ?? '').trim();
      if (!vid || vid === '<nil>' || vid === 'null' || seen.has(vid)) continue;
      seen.add(vid);
      result.episodes.push({
        no: result.episodes.length + 1,
        name: `第${result.episodes.length + 1}集`,
        url: `hongguo://${id}/${vid}`,
      });
    }
    if (result.episodes.length === 0) {
      throw new Error('红果详情没有返回剧集 ID');
    }
    result.episode_count = result.episodes.length;
    const cover = firstNonEmpty(mapString(detail, 'series_cover', 'cover'));
    if (cover) result.vod_pic = cover;
    const desc = firstNonEmpty(mapString(detail, 'series_intro', 'video_desc'));
    if (desc) result.vod_content = desc;
    return result;
  }

  async Play(playURL) {
    let seriesID = '';
    let videoID = '';
    const scheme = parsePlayScheme(playURL, 'hongguo://');
    if (scheme) {
      seriesID = scheme.id;
      videoID = scheme.extra;
    } else {
      let parsed;
      try {
        parsed = new URL(playURL);
      } catch {
        throw new Error('红果播放参数无效');
      }
      if (!parsed.pathname.startsWith('/player/')) throw new Error('红果播放参数无效');
      const parts = parsed.pathname.slice('/player/'.length).split('/');
      if (parts.length !== 2) throw new Error('红果播放参数无效');
      seriesID = parts[0];
      videoID = parts[1];
    }
    if (!hongguoNumericID.test(seriesID) || !hongguoNumericID.test(videoID)) {
      throw new Error('红果章节 ID 无效');
    }
    try {
      const media = await resolveHongguoAppMedia(this.client, videoID, (vid) => this.app.playMedia(vid));
      return { src: media.url, referer: media.referer || hongguoAppReferer, key: media.key, m3u8: true };
    } catch (err) {
      console.error(`[hongguo] 取流失败 videoID=${videoID}: ${err.message}`);
    }
    try {
      const media = await resolveHongguoPlayback(this.client, seriesID, videoID);
      return { src: media.url, referer: media.referer || hongguoAppReferer, key: media.key, m3u8: true };
    } catch (err) {
      console.error(`[hongguo] 备用播放接口失败 seriesID=${seriesID} videoID=${videoID}: ${err.message}`);
    }
    const target = `${hongguoBaseURL}/player/${encodeURIComponent(seriesID)}/${encodeURIComponent(videoID)}`;
    const resp = await this.client.fetchBytes(target, `${hongguoBaseURL}/`);
    const body = (await resp.buffer()).toString('utf8');
    const pageMap = routerLoaderMap(parseRouterData(body), 'player_page', 'player_') || {};
    if (mapString(pageMap, 'vid') !== videoID || mapString(pageMap, 'series_id') !== seriesID) {
      throw new Error('红果未返回所请求的剧集，可能仅允许网页试看');
    }
    const info = pageMap.video_player_info && typeof pageMap.video_player_info === 'object' ? pageMap.video_player_info : {};
    const mediaURL = mapString(info, 'main_url');
    if (!mediaURL.startsWith('http://') && !mediaURL.startsWith('https://')) {
      throw new Error('红果该集未提供公开播放地址，可能需要登录或 App 授权');
    }
    return { src: mediaURL, referer: `${hongguoBaseURL}/`, key: '', m3u8: false };
  }
}

export function hongguoCard(v, cat) {
  const m = v && typeof v === 'object' ? v : {};
  let vd = m.video_data && typeof m.video_data === 'object' ? m.video_data : null;
  if (!vd || Object.keys(vd).length === 0) vd = m;
  const sourceID = firstNonEmpty(mapString(vd, 'series_id_str', 'series_id'), mapString(m, 'series_id_str', 'series_id'));
  if (!hongguoNumericID.test(sourceID)) return { vod_id: '' };
  const card = { vod_id: sourceID, vod_class: cat, vod_name: '', vod_pic: '', vod_remarks: '', vod_score: '', vod_content: '' };
  card.vod_name = firstNonEmpty(mapString(vd, 'series_title', 'series_name', 'title'), mapString(m, 'series_name', 'name'), sourceID);
  card.vod_pic = firstNonEmpty(mapString(vd, 'series_cover', 'cover'), mapString(m, 'series_cover'));
  card.vod_content = firstNonEmpty(mapString(vd, 'series_intro', 'video_desc'), mapString(m, 'series_intro'));
  const count = firstNonEmpty(mapString(vd, 'episode_cnt'), mapString(m, 'episode_cnt'));
  let remark = firstNonEmpty(mapString(vd, 'episode_right_text'), mapString(m, 'episode_right_text'));
  if (remark === '' && count !== '') remark = `共${count}集`;
  card.vod_remarks = remark;
  const genre = firstNonEmpty(mapString(vd, 'category_name', 'category'), mapString(m, 'category'));
  if (genre) card.vod_class = genre;
  return card;
}

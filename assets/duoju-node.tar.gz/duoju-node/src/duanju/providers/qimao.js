
import { createHash } from 'node:crypto';
import { anyList, atoiDefault, cleanText, mapString, parsePlayScheme } from '../../core/util.js';
import { qimaoKeys, qimaoReadBase, qimaoSearchTrackID, qimaoStoreBase } from '../consts.js';
import { stripTagsSimple, truncate } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { decodeHTML } from './provider_utils.js';
import { queryEscape } from './xingxing.js';

const qimaoCharMap = {
  '+': 'P', '/': 'X', '0': 'M', '1': 'U', '2': 'l', '3': 'E', '4': 'r', '5': 'Y', '6': 'W', '7': 'b', '8': 'd', '9': 'J',
  A: '9', B: 's', C: 'a', D: 'I', E: '0', F: 'o', G: 'y', H: '_', I: 'H', J: 'G', K: 'i', L: 't',
  M: 'g', N: 'N', O: 'A', P: '8', Q: 'F', R: 'k', S: '3', T: 'h', U: 'f', V: 'R', W: 'q', X: 'C',
  Y: '4', Z: 'p', a: 'm', b: 'B', c: 'O', d: 'u', e: 'c', f: '6', g: 'K', h: 'x', i: '5', j: 'T',
  k: '-', l: '2', m: 'z', n: 'S', o: 'Z', p: '1', q: 'V', r: 'v', s: 'j', t: 'Q', u: '7', v: 'D',
  w: 'w', x: 'n', y: 'L', z: 'e',
};

const qimaoCatList = [
  { ID: '0', Name: '推荐' },
  { ID: '-1', Name: '新剧' },
  { ID: '1273', Name: '都市情感' },
  { ID: '1272', Name: '古装' },
  { ID: '571', Name: '都市' },
  { ID: '1286', Name: '玄幻仙侠' },
  { ID: '570', Name: '奇幻' },
  { ID: '590', Name: '乡村' },
  { ID: '573', Name: '民国' },
  { ID: '572', Name: '年代' },
  { ID: '1288', Name: '青春校园' },
  { ID: '371', Name: '武侠' },
  { ID: '594', Name: '科幻' },
  { ID: '556', Name: '末世' },
  { ID: '1289', Name: '二次元' },
  { ID: '400', Name: '逆袭' },
  { ID: '373', Name: '穿越' },
  { ID: '795', Name: '复仇' },
  { ID: '787', Name: '系统' },
  { ID: '790', Name: '权谋' },
  { ID: '784', Name: '重生' },
  { ID: '1294', Name: '女性成长' },
  { ID: '716', Name: '打脸虐渣' },
  { ID: '480', Name: '闪婚' },
  { ID: '402', Name: '强者回归' },
  { ID: '715', Name: '追妻火葬场' },
  { ID: '670', Name: '家庭' },
  { ID: '558', Name: '马甲' },
  { ID: '724', Name: '职场' },
  { ID: '343', Name: '宫斗' },
  { ID: '1299', Name: '高手下山' },
  { ID: '1295', Name: '娱乐明星' },
  { ID: '727', Name: '异能' },
  { ID: '342', Name: '宅斗' },
  { ID: '712', Name: '替身' },
  { ID: '338', Name: '穿书' },
  { ID: '723', Name: '商战' },
  { ID: '1291', Name: '种田经商' },
  { ID: '1293', Name: '伦理' },
  { ID: '1290', Name: '社会话题' },
  { ID: '492', Name: '致富' },
  { ID: '1258', Name: '偷听心声' },
  { ID: '526', Name: '脑洞' },
  { ID: '624', Name: '豪门总裁' },
  { ID: '356', Name: '萌宝' },
  { ID: '527', Name: '战神' },
  { ID: '812', Name: '真假千金' },
  { ID: '36', Name: '赘婿' },
  { ID: '1269', Name: '神医' },
  { ID: '37', Name: '神豪' },
  { ID: '1296', Name: '小人物' },
  { ID: '545', Name: '团宠' },
  { ID: '464', Name: '欢喜冤家' },
  { ID: '617', Name: '女帝' },
  { ID: '1297', Name: '银发' },
  { ID: '28', Name: '兵王' },
  { ID: '16', Name: '虐恋' },
  { ID: '21', Name: '甜宠' },
  { ID: '27', Name: '悬疑' },
  { ID: '793', Name: '搞笑' },
  { ID: '1287', Name: '灵异' },
];

export const platformCats = qimaoCatList.map((c) => ({ ID: c.ID, Name: c.Name }));

function qimaoTag(cat) {
  cat = String(cat || '').trim();
  if (cat === '') return qimaoCatList[0].ID;
  for (const item of qimaoCatList) {
    if (item.ID === cat) return item.ID;
  }
  return qimaoCatList[0].ID;
}

function qimaoMD5(s) {
  return createHash('md5').update(Buffer.from(s, 'utf8')).digest('hex');
}

function qimaoHeaders() {
  
  const device = {
    static_score: '0.8',
    uuid: '00000000-7fc7-08dc-0000-000000000000',
    'device-id': '20250220125449b9b8cac84c2dd3d035c9052a2572f7dd0122edde3cc42a70',
    mac: '',
    sourceuid: 'aa7de295aad621a6',
    'refresh-type': '0',
    model: '22021211RC',
    'wlb-imei': '',
    'client-id': 'aa7de295aad621a6',
    brand: 'Redmi',
    oaid: '',
    'oaid-no-cache': '',
    'sys-ver': '12',
    'trusted-id': '',
    'phone-level': 'H',
    imei: '',
    'wlb-uid': 'aa7de295aad621a6',
    'session-id': String(Date.now()),
  };
  const raw = JSON.stringify(device);
  const b64 = Buffer.from(raw, 'utf8').toString('base64');
  let qmParams = '';
  for (const ch of b64) {
    qmParams += Object.prototype.hasOwnProperty.call(qimaoCharMap, ch) ? qimaoCharMap[ch] : ch;
  }
  const qmp = qmParams;
  const sign = qimaoMD5('AUTHORIZATION=app-version=10001application-id=com.duoduo.readchannel=unknown'
    + 'is-white=net-env=5platform=androidqm-params=' + qmp + 'reg=' + qimaoKeys);
  return {
    'net-env': '5',
    reg: '',
    channel: 'unknown',
    'is-white': '',
    platform: 'android',
    'application-id': 'com.duoduo.read',
    authorization: '',
    'app-version': '10001',
    'qm-params': qmp,
    sign,
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.87 Safari/537.36',
  };
}

export class QimaoProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async get(target) {
    const headers = qimaoHeaders();
    const { raw, status } = await this.client.fetchWithHeaders('GET', target, headers);
    if (status >= 400) {
      throw new Error(`七猫接口 HTTP ${status}`);
    }
    let envelope;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('七猫接口响应无法解析');
    }
    if (envelope && typeof envelope === 'object' && !Array.isArray(envelope)
      && envelope.data && typeof envelope.data === 'object' && !Array.isArray(envelope.data)) {
      return envelope.data;
    }
    return envelope;
  }

  card(item) {
    const id = mapString(item, 'playlet_id', 'id');
    const title = cleanText(decodeHTML(stripTagsSimple(mapString(item, 'title'))));
    if (id === '' || title === '') return null;
    const card = { vod_id: id, vod_name: title, vod_score: '', vod_content: '' };
    const cover = mapString(item, 'image_link');
    if (cover !== '') card.vod_pic = this.media.imgProxyURL(cover, `${qimaoStoreBase}/`);
    const parts = [];
    const tags = cleanText(mapString(item, 'tags'));
    if (tags !== '') parts.push(tags);
    const n = atoiDefault(mapString(item, 'total_episode_num', 'total_num'), 0);
    if (n > 0) parts.push(`${n}集`);
    const hot = cleanText(mapString(item, 'hot_value'));
    if (hot !== '' && hot !== '0') parts.push(hot);
    card.vod_remarks = parts.join(' · ');
    card.vod_class = cleanText(mapString(item, 'tags'));
    return card;
  }

  collectCards(items) {
    const cards = [];
    const seen = new Set();
    for (const rawItem of items) {
      if (!rawItem || typeof rawItem !== 'object' || Array.isArray(rawItem)) continue;
      const card = this.card(rawItem);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    return cards;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    const tag = qimaoTag(cat);
    let target;
    if (page === 1) {
      const sign = qimaoMD5('operation=1playlet_privacy=1tag_id=' + tag + qimaoKeys);
      target = `${qimaoStoreBase}/api/v1/playlet/index?tag_id=${queryEscape(tag)}&playlet_privacy=1&operation=1&sign=${sign}`;
    } else {
      const next = String(page);
      const sign = qimaoMD5('next_id=' + next + 'operation=1playlet_privacy=1tag_id=' + tag + qimaoKeys);
      target = `${qimaoStoreBase}/api/v1/playlet/index?tag_id=${queryEscape(tag)}&next_id=${next}&playlet_privacy=1&operation=1&sign=${sign}`;
    }
    const data = await this.get(target);
    const items = anyList(data?.list);
    const cards = this.collectCards(items);
    if (cards.length === 0) {
      if (page > 1) return [];
      throw new Error('七猫列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    wd = String(wd || '').trim();
    if (wd === '') {
      throw new Error('七猫搜索关键词为空');
    }
    if (page < 1) page = 1;
    const pageStr = String(page);
    const sign = qimaoMD5('extend=page=' + pageStr + 'read_preference=0track_id=' + qimaoSearchTrackID
      + 'wd=' + wd + qimaoKeys);
    const target = `${qimaoStoreBase}/api/v1/playlet/search?extend=&page=${pageStr}&wd=${queryEscape(wd)}&read_preference=0&track_id=${qimaoSearchTrackID}&sign=${sign}`;
    const data = await this.get(target);
    const items = anyList(data?.list);
    const cards = this.collectCards(items);
    if (cards.length === 0) {
      throw new Error('七猫搜索无结果: ' + wd);
    }
    return cards;
  }

  async detail(id) {
    const sign = qimaoMD5('playlet_id=' + id + qimaoKeys);
    const target = `${qimaoReadBase}/player/api/v1/playlet/info?playlet_id=${queryEscape(id)}&sign=${sign}`;
    const data = await this.get(target);
    if (!data || typeof data !== 'object' || Array.isArray(data) || Object.keys(data).length === 0) {
      throw new Error('七猫详情无数据: ' + id);
    }
    return data;
  }

  async Detail(id) {
    id = String(id || '').trim();
    if (id === '') {
      throw new Error('无效的七猫剧集 ID');
    }
    const data = await this.detail(id);
    const detail = {
      vod_id: id,
      vod_name: cleanText(mapString(data, 'title')),
      vod_content: truncate(cleanText(mapString(data, 'intro')), 400),
      vod_class: cleanText(mapString(data, 'tags')),
      vod_pic: '',
      episodes: [],
      episode_count: 0,
    };
    const cover = mapString(data, 'image_link');
    if (cover !== '') detail.vod_pic = this.media.imgProxyURL(cover, `${qimaoStoreBase}/`);
    const seen = new Set();
    for (const rawItem of anyList(data.play_list)) {
      if (!rawItem || typeof rawItem !== 'object' || Array.isArray(rawItem)) continue;
      const seq = atoiDefault(mapString(rawItem, 'sort'), 0);
      if (seq < 1 || seen.has(seq)) continue;
      seen.add(seq);
      detail.episodes.push({ no: seq, name: `第${seq}集`, url: `qimao://${id}/${seq}` });
    }
    detail.episodes.sort((a, b) => a.no - b.no);
    detail.episode_count = detail.episodes.length;
    if (detail.episodes.length === 0) {
      throw new Error('七猫详情无分集: ' + id);
    }
    if (detail.vod_name === '') {
      detail.vod_name = '七猫短剧 ' + id;
    }
    return detail;
  }

  async Play(playURL) {
    const scheme = parsePlayScheme(playURL, 'qimao://');
    if (!scheme || scheme.id === '') {
      throw new Error('七猫播放参数无效');
    }
    const id = scheme.id;
    const seq = atoiDefault(scheme.extra, 1);
    const data = await this.detail(id);
    for (const rawItem of anyList(data.play_list)) {
      if (!rawItem || typeof rawItem !== 'object' || Array.isArray(rawItem)) continue;
      if (atoiDefault(mapString(rawItem, 'sort'), -1) !== seq) continue;
      const src = mapString(rawItem, 'video_url');
      if (!isProviderHTTPMediaURL(src)) {
        throw new Error(`七猫第${seq}集暂无播放地址`);
      }
      return { src, referer: `${qimaoStoreBase}/` };
    }
    throw new Error(`七猫详情缺第${seq}集`);
  }
}

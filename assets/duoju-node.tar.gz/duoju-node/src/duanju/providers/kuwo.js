
import { cleanText, parsePlayScheme } from '../../core/util.js';
import { kuwoAPIBase, kuwoPlayURL } from '../consts.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { queryEscape } from './xingxing.js';

const kuwoUA = 'okhttp/5.1.0';
const kuwoPageSize = 12;
const kuwoMaxPages = 60;
const kuwoSearchPg = 2;
const kuwoSearchPara = 6;
const kuwoSearchMax = 30;

const kuwoCats = [
  { ID: '10', Name: '猜你想看' },
  { ID: '11', Name: '土味爱情' },
  { ID: '12', Name: '更多精彩' },
  { ID: '13', Name: '霸道总裁的人生' },
  { ID: '14', Name: '赘婿当道' },
  { ID: '15', Name: '漫漫追妻路' },
  { ID: '16', Name: '家庭情感' },
];

export const platformCats = kuwoCats.map((c) => ({ ID: c.ID, Name: c.Name }));


const reKuwoPlayURL = /^\s*url=(\S+)\s*$/gm;

export class KuwoProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async getJSON(target) {
    let raw = null;
    let status = 0;
    try {
      const resp = await this.client.fetchWithHeaders('GET', target, {
        'User-Agent': kuwoUA,
        Accept: 'application/json',
      });
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      throw err; 
    }
    if (status >= 400) {
      throw new Error(`酷我接口 HTTP ${status}`);
    }
    if (!raw || raw.length === 0) {
      throw new Error('酷我接口空响应');
    }
    try {
      return JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('酷我接口响应无法解析');
    }
  }

  async List(cat, page) {
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    if (p > kuwoMaxPages) return [];
    let c = String(cat ?? '').trim();
    
    const validIDs = kuwoCats.map((x) => x.ID);
    if (c === '' || c === 'all' || !validIDs.includes(c)) c = kuwoCats[0].ID;
    const resp = await this.getJSON(kuwoModuleURL(c, p));
    const code = toInt(resp?.code, 0);
    if (code !== 0 && code !== 200) {
      throw new Error(`酷我接口返回 ${code} ${resp?.msg ?? ''}`);
    }
    const list = Array.isArray(resp?.data?.list) ? resp.data.list : [];
    const cards = [];
    const seen = new Set();
    for (const a of list) {
      const card = kuwoCard(a);
      if (card.vod_id === '' || card.vod_name === '' || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      if (p > 1) return [];
      throw new Error('酷我分类无内容: ' + c);
    }
    return cards;
  }

  async Search(wd, page) {
    const kw = String(wd ?? '').trim();
    if (kw === '') throw new Error('酷我搜索关键词为空');
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    const lower = kw.toLowerCase();
    const tasks = [];
    for (let mi = 0; mi < kuwoCats.length; mi++) {
      for (let pg = 1; pg <= kuwoSearchPg; pg++) {
        tasks.push({ mi, mod: kuwoCats[mi].ID, pg });
      }
    }
    const hits = [];
    const seen = new Set();
    let next = 0;
    const workers = Array.from({ length: Math.min(kuwoSearchPara, tasks.length) }, async () => {
      while (next < tasks.length) {
        const task = tasks[next++];
        let resp = null;
        try {
          resp = await this.getJSON(kuwoModuleURL(task.mod, task.pg));
        } catch {
          continue; 
        }
        const list = Array.isArray(resp?.data?.list) ? resp.data.list : [];
        for (const a of list) {
          const card = kuwoCard(a);
          if (card.vod_id === '' || card.vod_name === '') continue;
          if (!card.vod_name.toLowerCase().includes(lower)) continue;
          if (!seen.has(card.vod_id) && seen.size < kuwoSearchMax) {
            seen.add(card.vod_id);
            hits.push({ mod: task.mi, card });
          }
        }
      }
    });
    await Promise.all(workers);
    if (hits.length === 0) return [];
    hits.sort((a, b) => a.mod - b.mod); 
    let out = hits.map((h) => h.card);
    if (p > 1) {
      const start = (p - 1) * kuwoPageSize;
      if (start >= out.length) return [];
      const end = Math.min(start + kuwoPageSize, out.length);
      return out.slice(start, end);
    }
    if (out.length > kuwoSearchMax) {
      out = out.slice(0, kuwoSearchMax);
    }
    return out;
  }

  async Detail(id) {
    let tid = String(id ?? '').trim();
    const i = tid.indexOf(':');
    if (i >= 0) tid = tid.slice(i + 1);
    tid = tid.replace(/^\/+|\/+$/g, '');
    if (tid === '') throw new Error('无效的酷我剧集 ID');
    const target = `${kuwoAPIBase}/videoList?albumId=${queryEscape(tid)}`;
    const resp = await this.getJSON(target);
    const code = toInt(resp?.code, 0);
    if (code !== 0 && code !== 200) {
      throw new Error(`酷我详情返回 ${code} ${resp?.msg ?? ''}`);
    }
    const detail = {
      vod_id: tid,
      vod_name: '',
      vod_pic: '',
      vod_content: '',
      vod_class: '',
      episodes: [],
      episode_count: 0,
    };
    const si = resp?.data?.shortinfo;
    if (si && typeof si === 'object' && !Array.isArray(si)) {
      detail.vod_name = cleanText(si.title);
      detail.vod_pic = String(si.cover ?? '').trim();
    }
    const list = Array.isArray(resp?.data?.list) ? resp.data.list : [];
    for (let idx = 0; idx < list.length; idx++) {
      const it = list[idx];
      if (!it || typeof it !== 'object' || Array.isArray(it)) continue;
      const vidNum = Number(it?.mvpayinfo?.vid);
      const vid = it?.mvpayinfo && typeof it.mvpayinfo === 'object' && Number.isFinite(vidNum) && vidNum > 0
        ? String(Math.trunc(vidNum))
        : '';
      if (vid === '') continue;
      let name = cleanText(it.name);
      if (name === '') name = `第${idx + 1}集`;
      detail.episodes.push({ no: idx + 1, name, url: `kuwo://${tid}/${vid}` });
    }
    if (detail.episodes.length === 0) {
      throw new Error('酷我详情无剧集: ' + tid);
    }
    if (detail.vod_name === '') {
      detail.vod_name = '酷我短剧 ' + tid;
    }
    detail.episode_count = detail.episodes.length;
    detail.vod_class = '酷我短剧';
    return detail;
  }

  async Play(playURL) {
    const vid = kuwoSplitPlay(playURL);
    if (vid === null) {
      throw new Error('酷我播放参数无效');
    }
    const target = `${kuwoPlayURL}?f=web&type=get_url_by_vid&vid=${queryEscape(vid)}`;
    let raw = null;
    let status = 0;
    try {
      const resp = await this.client.fetchWithHeaders('GET', target, {
        'User-Agent': kuwoUA,
      });
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      throw err;
    }
    if (status >= 400) {
      throw new Error(`酷我解析接口 HTTP ${status}`);
    }
    const body = raw ? raw.toString('utf8') : '';
    let media = '';
    reKuwoPlayURL.lastIndex = 0;
    const m = reKuwoPlayURL.exec(body);
    if (m && m.length > 1) {
      media = m[1].trim();
    }
    if (media === '') {
      const i = body.indexOf('url=');
      if (i >= 0) {
        let rest = body.slice(i + 4).trim();
        const j = rest.search(/[\r\n \t]/);
        if (j >= 0) rest = rest.slice(0, j);
        media = rest.trim();
      }
    }
    if (media === '') {
      throw new Error('酷我解析未返回播放地址');
    }
    if (!isProviderHTTPMediaURL(media)) {
      throw new Error('酷我播放地址无效');
    }
    return { src: media, userAgent: kuwoUA };
  }
}

function toInt(v, fallback) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.trunc(n);
}

function kuwoModuleURL(moduleID, page) {
  let p = Math.trunc(Number(page));
  if (!Number.isFinite(p) || p < 1) p = 1;
  return `${kuwoAPIBase}/moduleMore?currentPage=${p}&moduleId=${queryEscape(moduleID)}&rn=${kuwoPageSize}`;
}

function kuwoCard(a) {
  const id = String(a?.url ?? '').trim();
  if (id === '') return { vod_id: '', vod_name: '', vod_pic: '', vod_remarks: '', vod_class: '' };
  let name = cleanText(a?.title);
  if (name === '') name = cleanText(a?.subTitle);
  let remarks = cleanText(a?.currrentDesc).trim();
  if (remarks === '') {
    const songNum = toInt(a?.songNum, 0);
    if (songNum > 0) remarks = String(songNum) + '集全';
  }
  return {
    vod_id: id,
    vod_name: name,
    vod_pic: String(a?.img ?? '').trim(),
    vod_remarks: remarks,
    vod_class: '酷我短剧',
  };
}


function kuwoSplitPlay(playURL) {
  const raw = String(playURL ?? '').trim();
  if (raw === '') return null;
  if (raw.startsWith('kuwo://')) {
    const parsed = parsePlayScheme(raw, 'kuwo://');
    if (!parsed) return null;
    const vid = String(parsed.extra ?? '').trim();
    return vid !== '' ? vid : null;
  }
  const i = raw.indexOf('vid=');
  if (i >= 0) {
    let vid = raw.slice(i + 4).trim();
    const j = vid.search(/[&?#]/);
    if (j >= 0) vid = vid.slice(0, j);
    return vid !== '' ? vid : null;
  }
  for (const ch of raw) {
    if (ch < '0' || ch > '9') return null;
  }
  return raw;
}

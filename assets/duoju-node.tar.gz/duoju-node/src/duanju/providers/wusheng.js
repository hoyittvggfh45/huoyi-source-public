
import { atoiDefault, cleanText, mapString, anyList, nestedMap, encodeQuery } from '../../core/util.js';
import { truncate } from '../shared.js';
import { wushengBase, wushengToken } from '../consts.js';

const wushengUA = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.87 Safari/537.36';
const wushengProductID = '2a8c14d1-72e7-498b-af23-381028eb47c0';
const wushengVestID = '2be070e0-c824-4d0e-a67a-8f688890cadb';
const wushengChannel = 'oppo19';
const wushengOSType = 'android';
const wushengVersion = '20';
const wushengPageSize = 20;
const wushengDescMax = 200;
const wushengMaxEpisodes = 200;

const wushengCats = [
  { ID: '1287', Name: '甜宠' },
  { ID: '1288', Name: '逆袭' },
  { ID: '1289', Name: '热血' },
  { ID: '1290', Name: '现代' },
  { ID: '1291', Name: '古代' },
];

export const platformCats = wushengCats.map((c) => ({ ID: c.ID, Name: c.Name }));

function wushengBaseQuery() {
  return {
    productId: wushengProductID,
    vestId: wushengVestID,
    channel: wushengChannel,
    osType: wushengOSType,
    version: wushengVersion,
    token: wushengToken,
  };
}

function wushengCat(cat) {
  const c = String(cat ?? '').trim();
  for (const item of wushengCats) {
    if (item.ID === c) return item.ID;
  }
  return wushengCats[0].ID;
}

function wushengCatName(catID) {
  for (const item of wushengCats) {
    if (item.ID === catID) return item.Name;
  }
  return '';
}

function wushengSplitID(id) {
  const s = String(id ?? '').trim();
  const i = s.indexOf('@');
  if (i > 0) {
    return [s.slice(0, i).trim(), s.slice(i + 1).trim()];
  }
  return [s, ''];
}

export class WushengProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async getJSON(path, q) {
    let target = wushengBase + path;
    const entries = Object.entries(q || {});
    if (entries.length > 0) {
      target += '?' + encodeQuery(Object.fromEntries(entries));
    }
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders('GET', target, {
        'User-Agent': wushengUA,
        Accept: 'application/json, text/plain, */*',
      });
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    if (terr) throw terr;
    if (status >= 400) {
      throw new Error(`悟圣接口 HTTP ${status}`);
    }
    let envelope = null;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('悟圣接口响应无法解析');
    }
    if (!envelope || typeof envelope !== 'object' || Array.isArray(envelope)) {
      throw new Error('悟圣接口响应无法解析');
    }
    if (envelope.code !== undefined) {
      const codeText = typeof envelope.code === 'string' ? envelope.code : String(envelope.code ?? '');
      const code = atoiDefault(codeText, 0);
      if (code !== 0 && code !== 200) {
        throw new Error('悟圣接口返回错误: ' + mapString(envelope, 'msg'));
      }
    }
    return envelope;
  }

  card(item, catName) {
    const id = String(mapString(item, 'id')).trim();
    const name = cleanText(mapString(item, 'name'));
    if (id === '' || name === '') return null;
    const card = { vod_id: id + '@' + name, vod_name: name, vod_pic: '', vod_remarks: '', vod_class: catName, vod_content: '' };
    const cover = mapString(item, 'icon');
    if (cover !== '') {
      card.vod_pic = this.media.imgProxyURL(cover, wushengBase + '/');
    }
    card.vod_remarks = cleanText(mapString(item, 'heat')) + '万播放';
    const desc = cleanText(mapString(item, 'introduction'));
    if (desc !== '') {
      card.vod_content = truncate(desc, wushengDescMax);
    }
    return card;
  }

  cardList(items, catName) {
    const cards = [];
    const seen = new Set();
    for (const rawItem of anyList(items)) {
      if (!rawItem || typeof rawItem !== 'object' || Array.isArray(rawItem)) continue;
      const card = this.card(rawItem, catName);
      if (!card) continue;
      const [bookID] = wushengSplitID(card.vod_id);
      if (seen.has(bookID)) continue;
      seen.add(bookID);
      cards.push(card);
    }
    return cards;
  }

  async List(cat, page) {
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    const catID = wushengCat(cat);
    const q = wushengBaseQuery();
    q.resourceId = catID;
    q.pageNum = String(p);
    q.pageSize = String(wushengPageSize);
    const envelope = await this.getJSON('/novel-api/app/pageModel/getResourceById', q);
    const data = nestedMap(envelope, 'data');
    const cards = this.cardList(anyList(data?.datalist), wushengCatName(catID));
    if (cards.length === 0) {
      if (p > 1) return [];
      throw new Error('悟圣列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    throw new Error('悟圣未提供搜索');
  }

  async Detail(id) {
    const [bookID, name] = wushengSplitID(id);
    if (bookID === '') {
      throw new Error('无效的悟圣剧集 ID');
    }
    const q = wushengBaseQuery();
    q.bookId = bookID;
    const envelope = await this.getJSON('/novel-api/basedata/book/getChapterList', q);
    const chapters = anyList(envelope.data);
    const detail = {
      vod_id: String(id ?? ''),
      vod_name: name,
      vod_pic: '',
      vod_content: '',
      vod_class: '悟圣',
      episodes: [],
      episode_count: 0,
    };
    const seen = new Set();
    for (let i = 0; i < chapters.length; i++) {
      if (detail.episodes.length >= wushengMaxEpisodes) break;
      const rawChapter = chapters[i];
      if (!rawChapter || typeof rawChapter !== 'object' || Array.isArray(rawChapter)) continue;
      const src = wushengEpURL(rawChapter);
      if (src === '') continue;
      let no = atoiDefault(mapString(rawChapter, 'chapterIndex'), 0);
      if (no < 1) no = i + 1;
      if (seen.has(no)) continue;
      seen.add(no);
      let epName = cleanText(mapString(rawChapter, 'chapterName'));
      if (epName === '') epName = `第${no}集`;
      detail.episodes.push({ no, name: epName, url: src });

      if (detail.vod_pic === '') {
        const cover = mapString(rawChapter, 'iconUrl');
        if (cover.startsWith('http') && trimSuffix(cover, '/') !== wushengBase) {
          detail.vod_pic = this.media.imgProxyURL(cover, wushengBase + '/');
        }
      }
    }
    detail.episodes.sort((a, b) => a.no - b.no);
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') {
      detail.vod_name = '悟圣短剧 ' + bookID;
    }
    if (detail.episodes.length === 0) {
      throw new Error('悟圣详情无剧集: ' + bookID);
    }
    return detail;
  }

  async Play(playURL) {
    const target = String(playURL ?? '').trim();
    if (target === '' || !target.startsWith('http')) {
      throw new Error('悟圣播放参数无效');
    }
    return { src: target, referer: wushengBase + '/', userAgent: wushengUA };
  }
}

function wushengEpURL(chapter) {
  for (const rawList of anyList(chapter?.shortPlayList)) {
    if (!rawList || typeof rawList !== 'object' || Array.isArray(rawList)) continue;
    for (const rawVo of anyList(rawList.chapterShortPlayVoList)) {
      if (!rawVo || typeof rawVo !== 'object' || Array.isArray(rawVo)) continue;
      const u = String(mapString(rawVo, 'shortPlayUrl')).trim();
      if (u !== '') return u;
    }
  }
  return '';
}

function trimSuffix(s, suffix) {
  return s.endsWith(suffix) ? s.slice(0, -suffix.length) : s;
}




import { HongguoProvider, platformCats as hongguoPlatformCats } from './hongguo.js';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));


const PROVIDER_MANIFEST = [
  { key: 'hongguo', name: '红果', className: 'HongguoProvider' },
  { key: 'huangguo', name: '黄果', file: 'huangguo.js', className: 'HuangguoProvider' },
  { key: 'huangguo2', name: '黄果2', file: 'huangguo.js', className: 'Huangguo2Provider' },
  { key: 'huangdou', name: '黄豆', file: 'huangdou.js', className: 'HuangdouProvider' },
  { key: 'huangguoold', name: '黄果旧版', file: 'huangguoold.js', className: 'HuangguoOldProvider' },
  { key: 'huangju', name: '黄剧', file: 'huangju.js', className: 'HuangjuProvider' },
  { key: 'dj51', name: '51短剧', file: 'dj51.js', className: 'Dj51Provider' },
  { key: 'chengguo', name: '橙果', file: 'chengguo.js', className: 'ChengguoProvider' },
  { key: 'huanggua', name: '黄瓜', file: 'huanggua.js', className: 'HuangguaProvider' },
  { key: 'huangdou2', name: '黄豆2', file: 'nine.js', className: 'Huangdou2Provider' },
  { key: 'dj91', name: '91短剧', file: 'nine.js', className: 'Dj91Provider' },
  { key: 'md2048', name: '2048短剧', file: 'md2048.js', className: 'Md2048Provider' },
  { key: 'souju', name: '搜剧AI', file: 'souju.js', className: 'SoujuProvider' },
  { key: 'yizk', name: '一直看', file: 'yizk.js', className: 'YizkProvider' },
  { key: 'heiliao', name: '黑料', file: 'heiliao.js', className: 'HeiliaoProvider' },
  { key: 'bday', name: '不打烊', file: 'bday.js', className: 'BdayProvider' },
  { key: 'weiguan', name: '围观', file: 'weiguan.js', className: 'WeiguanProvider' },
  { key: 'hema', name: '河马', file: 'hema.js', className: 'HemaProvider' },
  { key: 'shanhai', name: '山海', file: 'shanhai.js', className: 'ShanhaiProvider' },
  { key: 'haokan', name: '好看', file: 'haokan.js', className: 'HaokanProvider' },
  { key: 'baidu', name: '百度', file: 'baidu.js', className: 'BaiduProvider' },
  { key: 'xingya', name: '星芽', file: 'xingya.js', className: 'XingyaProvider' },
  { key: 'xifan', name: '西饭', file: 'xifan.js', className: 'XifanProvider' },
  { key: 'xingxing', name: '星星', file: 'xingxing.js', className: 'XingxingProvider' },
  { key: 'yimi', name: '薏米', file: 'yimi.js', className: 'YimiProvider' },
  { key: 'qimao', name: '七猫', file: 'qimao.js', className: 'QimaoProvider' },
  { key: 'damang', name: '大芒', file: 'damang.js', className: 'DamangProvider' },
  { key: 'wusheng', name: '悟圣', file: 'wusheng.js', className: 'WushengProvider' },
  { key: 'qixing', name: '七星', file: 'qixing.js', className: 'QixingProvider' },
  { key: 'kuwo', name: '酷我', file: 'kuwo.js', className: 'KuwoProvider' },
  { key: 'niuniu', name: '牛牛', file: 'niuniu.js', className: 'NiuniuProvider' },
  { key: 'xifu', name: '喜福', file: 'xifu.js', className: 'XifuProvider' },
  { key: 'wuwu', name: '五五', file: 'wuwu.js', className: 'WuwuProvider' },
];


const loadedModules = new Map();
loadedModules.set('hongguo', { module: { HongguoProvider, platformCats: hongguoPlatformCats }, className: 'HongguoProvider' });
for (const entry of PROVIDER_MANIFEST) {
  if (!entry.file || loadedModules.has(entry.key)) continue;
  try {
    const mod = await import(pathToFileURL(path.join(__dirname, entry.file)).href);
    const Cls = mod[entry.className];
    if (typeof Cls === 'function') {
      loadedModules.set(entry.key, { module: mod, className: entry.className });
    }
  } catch {
    
  }
}

export function loadedProviderKeys() {
  return [...loadedModules.keys()];
}

export function getRegisterProviders() {
  return {
    registerAll(router, client, media) {
      for (const entry of PROVIDER_MANIFEST) {
        const hit = loadedModules.get(entry.key);
        if (!hit || router.providers[entry.key]) continue;
        try {
          router.providers[entry.key] = new hit.module[hit.className](client, media);
        } catch (err) {
          console.error(`[duanju] 注册平台 ${entry.key} 失败:`, err.message);
          continue;
        }
        if (!router.platforms.find((p) => p.key === entry.key)) {
          
          const rawCats = hit.module.platformCats || [];
          const cats = rawCats
            .map((c) => ({ id: c?.id ?? c?.ID ?? '', name: c?.name ?? c?.Name ?? '' }))
            .filter((c) => c.id !== '');
          router.platforms.push({ key: entry.key, name: entry.name, cats });
        }
      }
    },
  };
}


import { atoiDefault, cleanText, firstNonEmpty } from '../../core/util.js';
import { truncate, stripTagsSimple } from '../shared.js';
import { wuwuHost, wuwuReferer } from '../consts.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { decodeHTML } from './provider_utils.js';

const wuwuUA = 'okhttp/4.10.0';

const wuwuCats = [
  { ID: '全部', Name: '全部' },
  { ID: '男频', Name: '男频' },
  { ID: '女频', Name: '女频' },
  { ID: '都市', Name: '都市' },
  { ID: '虐渣', Name: '虐渣' },
  { ID: '励志', Name: '励志' },
  { ID: '逆袭', Name: '逆袭' },
  { ID: '古风', Name: '古风' },
  { ID: '复仇', Name: '复仇' },
  { ID: '家庭', Name: '家庭' },
  { ID: '悬疑', Name: '悬疑' },
  { ID: '奇幻', Name: '奇幻' },
];

export const platformCats = wuwuCats.map((c) => ({ ID: c.ID, Name: c.Name }));

const wuwuListPatterns = [
  { name: 'SecondList_bookName', img: 'SecondList_bookImage', rem: 'SecondList_totalChapterNum' },
  { name: 'TagBookList_bookName', img: 'TagBookList_bookImageBox', rem: 'TagBookList_totalChapterNum' },
  { name: 'BrowseList_bookName', img: 'BrowseList_imageBox', rem: 'BrowseList_totalChapterNum' },
];

const reWuwuTitle = /<title>(.*?)<\/title>/gis;
const reWuwuCover = /<img[^>]*class="[^"]*\bDramaDetail_bookCover\b[^"]*"[^>]*\bsrc="([^"]+)"/gis;
const reWuwuOgImage = /property="og:image"[^>]+content="([^"]+)"/gi;
const reWuwuDesc = /class="[^"]*(?:detail-content|vod-content|content|descr|intro)[^"]*"[^>]*>(.*?)<\/div>/gis;
const reWuwuBox = /<div class="pcDrama_contentBox.*?<\/ul>/gis;
const reWuwuBoxName = /pcDrama_titleText">(.*?)<\/h3>/gis; 
const reWuwuEp = /<a[^>]*class="[^"]*\bpcDrama_catalogItem\b[^"]*"[^>]*href="([^"]*vod\/play\/id\/\d+\/sid\/\d+\/nid\/(\d+)\.html)"[^>]*>(.*?)<\/a>/gis;
const reWuwuPlayer = /var\s+player_\w+\s*=\s*\{.*?"url"\s*:\s*"([^"]*)"/gis;
const reWuwuAnyURL = /["']url["']\s*:\s*["']([^"']+)["']/gi;
const reWuwuMedia = /(?:https?:)?\/\/[^\s"'<>]+\.(?:m3u8|mp4)/gi;
const reWuwuIframe = /<iframe[^>]+src=["']([^"']+)["']/gi; 
const reWuwuB64 = /^[A-Za-z0-9+/=]{16,}$/;

function pathEscape(s) {
  return encodeURIComponent(String(s ?? '')).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
}

function wuwuAbs(raw) {
  raw = decodeHTML(String(raw ?? '').trim());
  if (raw === '') return '';
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  if (raw.startsWith('//')) return 'https:' + raw;
  if (!raw.startsWith('/')) raw = '/' + raw;
  return wuwuHost + raw;
}

function firstMatch(re, text) {
  re.lastIndex = 0;
  const m = re.exec(text);
  re.lastIndex = 0;
  return m;
}

function wuwuKnownCat(cat) {
  if (cat === '') return false;
  for (const c of wuwuCats) {
    if (c.ID === cat) return true;
  }
  return false;
}

function wuwuListURL(cat, page) {
  let c = String(cat ?? '').trim();
  if (!wuwuKnownCat(c)) c = '全部';
  let base = wuwuHost + '/index.php/vod/type/id/1.html';
  if (c !== '全部') {
    base = wuwuHost + '/index.php/vod/show/class/' + pathEscape(c) + '/id/1.html';
  }
  if (page > 1) {
    base += '?page=' + String(page);
  }
  return base;
}

function wuwuParseList(page) {
  const items = new Map();
  const order = [];
  for (const pat of wuwuListPatterns) {
    const reName = new RegExp(`<a[^>]*class="[^"]*\\b${pat.name}\\b[^"]*"[^>]*href="[^"]*vod/detail/id/(\\d+)\\.html"[^>]*>(.*?)</a>`, 'gis');
    let m;
    while ((m = reName.exec(page)) !== null) {
      const id = m[1];
      let it = items.get(id);
      if (!it) {
        it = { id, name: '', pic: '', rem: '' };
        items.set(id, it);
        order.push(id);
      }
      if (it.name !== '') continue;
      const inner = m[2];
      const sm = /<span[^>]*>([^<]+)<\/span>/is.exec(inner);
      if (sm) {
        it.name = cleanText(decodeHTML(sm[1]));
      } else {
        it.name = cleanText(decodeHTML(stripTagsSimple(inner)));
      }
    }
    const reImg = new RegExp(`<a[^>]*class="[^"]*\\b${pat.img}\\b[^"]*"[^>]*href="[^"]*vod/detail/id/(\\d+)\\.html"[^>]*>(.*?)</a>`, 'gis');
    while ((m = reImg.exec(page)) !== null) {
      const it = items.get(m[1]);
      if (!it || it.pic !== '') continue;
      const im = /<img[^>]*\bsrc="([^"]+)"/is.exec(m[2]);
      if (im) {
        it.pic = wuwuAbs(im[1]);
      }
    }
    const reRem = new RegExp(`<a[^>]*class="[^"]*\\b${pat.rem}\\b[^"]*"[^>]*href="[^"]*vod/detail/id/(\\d+)\\.html"[^>]*>(.*?)</a>`, 'gis');
    while ((m = reRem.exec(page)) !== null) {
      const it = items.get(m[1]);
      if (!it || it.rem !== '') continue;
      it.rem = cleanText(decodeHTML(stripTagsSimple(m[2])));
    }
  }
  const out = [];
  for (const id of order) {
    const it = items.get(id);
    if (it.name === '') continue;
    out.push(it);
  }
  return out;
}

function wuwuBoxEpisodes(box) {
  const seen = new Set();
  const eps = [];
  let m;
  reWuwuEp.lastIndex = 0;
  while ((m = reWuwuEp.exec(box)) !== null) {
    const no = atoiDefault(m[2], 0);
    if (no < 1 || seen.has(no)) continue;
    seen.add(no);
    let name = cleanText(decodeHTML(stripTagsSimple(m[3])));
    if (name === '') name = `第${no}集`;
    eps.push({ no, name, url: wuwuAbs(m[1]) });
  }
  reWuwuEp.lastIndex = 0;
  eps.sort((a, b) => a.no - b.no);
  return eps;
}

function wuwuExtractSrc(page) {
  const pm = firstMatch(reWuwuPlayer, page);
  if (pm) {
    const raw = String(pm[1] ?? '').replaceAll('\\/', '/');
    if (isProviderHTTPMediaURL(raw)) {
      return raw;
    }
  }
  const am = firstMatch(reWuwuAnyURL, page);
  if (am) {
    let cand = String(am[1] ?? '').trim();
    if (reWuwuB64.test(cand)) {
      let dec = null;
      try {
        
        if (!/^[A-Za-z0-9+/]+={0,2}$/.test(cand) || cand.length % 4 !== 0) throw new Error('bad');
        dec = Buffer.from(cand, 'base64');
      } catch {
        try {
          
          if (!/^[A-Za-z0-9+/]+$/.test(cand) || cand.length % 4 === 1) throw new Error('bad');
          dec = Buffer.from(cand, 'base64');
        } catch {
          dec = null;
        }
      }
      if (dec !== null) cand = dec.toString('utf8');
    }
    if (isProviderHTTPMediaURL(cand)) {
      return cand;
    }
  }
  reWuwuMedia.lastIndex = 0;
  const mm = reWuwuMedia.exec(page);
  reWuwuMedia.lastIndex = 0;
  if (mm && mm[0] !== '') {
    let media = mm[0];
    if (media.startsWith('//')) media = 'https:' + media;
    if (isProviderHTTPMediaURL(media)) {
      return media;
    }
  }
  return '';
}

export class WuwuProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async get(rawURL) {
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders('GET', rawURL, {
        'User-Agent': wuwuUA,
        Referer: wuwuReferer,
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      });
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    if (terr) throw terr;
    if (status >= 400) {
      throw new Error(`五五接口 HTTP ${status}`);
    }
    return raw ? raw.toString('utf8') : '';
  }

  card(it, cat) {
    const card = { vod_id: it.id, vod_name: it.name, vod_pic: '', vod_remarks: it.rem, vod_class: cat };
    if (it.pic !== '') {
      card.vod_pic = this.media.imgProxyURL(it.pic, wuwuReferer);
    }
    return card;
  }

  async List(cat, page) {
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    const body = await this.get(wuwuListURL(cat, p));
    const items = wuwuParseList(body);
    const cards = [];
    for (const it of items) {
      cards.push(this.card(it, firstNonEmpty(String(cat ?? ''), '全部')));
    }
    if (cards.length === 0) {
      throw new Error('五五列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    const kw = String(wd ?? '').trim();
    if (kw === '') throw new Error('五五搜索关键词为空');
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    let u = wuwuHost + '/index.php/vod/search/wd/' + pathEscape(kw) + '.html';
    if (p > 1) {
      u += '?page=' + String(p);
    }
    const body = await this.get(u);
    const items = wuwuParseList(body);
    const cards = [];
    for (const it of items) {
      cards.push(this.card(it, '搜索'));
    }
    if (cards.length === 0) {
      throw new Error('五五搜索无结果: ' + kw);
    }
    return cards;
  }

  async Detail(id) {
    const tid = String(id ?? '').trim();
    if (tid === '') throw new Error('无效的五五剧集 ID');
    const page = await this.get(wuwuHost + '/index.php/vod/detail/id/' + pathEscape(tid) + '.html');
    const detail = {
      vod_id: tid,
      vod_name: '',
      vod_pic: '',
      vod_content: '',
      vod_class: '五五',
      episodes: [],
      episode_count: 0,
    };
    const tm = firstMatch(reWuwuTitle, page);
    if (tm) {
      const title = cleanText(decodeHTML(tm[1]));
      detail.vod_name = String(title.split('-', 2)[0] ?? '').trim();
    }
    const cm = firstMatch(reWuwuCover, page);
    if (cm) {
      detail.vod_pic = this.media.imgProxyURL(wuwuAbs(cm[1]), wuwuReferer);
    } else {
      const om = firstMatch(reWuwuOgImage, page);
      if (om) detail.vod_pic = this.media.imgProxyURL(wuwuAbs(om[1]), wuwuReferer);
    }
    const dm = firstMatch(reWuwuDesc, page);
    if (dm) {
      detail.vod_content = truncate(cleanText(decodeHTML(stripTagsSimple(dm[1]))), 400);
    }
    reWuwuBox.lastIndex = 0;
    let boxMatch;
    while ((boxMatch = reWuwuBox.exec(page)) !== null) {
      const eps = wuwuBoxEpisodes(boxMatch[0]);
      if (eps.length === 0) continue;
      detail.episodes = eps;
      break;
    }
    reWuwuBox.lastIndex = 0;
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') {
      detail.vod_name = '五五短剧 ' + tid;
    }
    if (detail.episodes.length === 0) {
      throw new Error('五五详情无剧集: ' + tid);
    }
    return detail;
  }

  async Play(playURL) {
    let target = String(playURL ?? '').trim();
    if (target === '') throw new Error('五五播放参数无效');
    if (!target.startsWith('http')) {
      target = wuwuAbs(target);
    }
    const page = await this.get(target);
    const src = wuwuExtractSrc(page);
    if (src !== '') {
      return { src, referer: wuwuReferer, userAgent: wuwuUA };
    }
    throw new Error('五五播放地址解析失败');
  }
}

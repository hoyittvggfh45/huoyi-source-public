




import { randomBytes } from 'node:crypto';
import { mapString, atoiDefault, cleanText, extractFirstJSON } from '../../core/util.js';
import { truncate } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';




export function atoiStrict(s) {
  const t = String(s ?? '').trim();
  if (!/^[+-]?[0-9]+$/.test(t)) return null;
  const n = parseInt(t, 10);
  return Number.isFinite(n) ? n : null;
}

export function escapeRegExp(s) {
  return String(s ?? '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}


export async function readLimited(stream, limit) {
  const chunks = [];
  let size = 0;
  for await (const chunk of stream) {
    chunks.push(chunk);
    size += chunk.length;
    if (size >= limit + 1) break;
  }
  const buf = Buffer.concat(chunks);
  return buf.length > limit + 1 ? buf.subarray(0, limit + 1) : buf;
}

export function randomHex(n) {
  return randomBytes(n).toString('hex');
}


export function uuidLike() {
  const raw = randomHex(16);
  if (raw.length !== 32) return raw;
  return raw.slice(0, 8) + '-' + raw.slice(8, 12) + '-' + raw.slice(12, 16) + '-' + raw.slice(16, 20) + '-' + raw.slice(20);
}


export function httpStatusSwitch(status, err) {
  if (!err && status >= 200 && status < 300) return null;
  if (status >= 400 && status < 500) return noSwitch(new Error('站点返回 ' + status));
  if (err) return err;
  return new Error('站点返回 ' + status);
}

export function noSwitch(err) {
  if (err) err.noSwitch = true;
  return err;
}

export function mirrorSwitchable(err) {
  return !!err && err.noSwitch !== true;
}

export function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('请求超时')), ms);
    promise.then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); },
    );
  });
}


export function isNonImageAsset(low) {
  return (
    low.endsWith('.js') || low.endsWith('.css') ||
    low.includes('.js?') || low.includes('.css?') ||
    low.includes('googletagmanager') || low.includes('/gtag/js') ||
    low.includes('analytics') || low.includes('hm.baidu') ||
    low.includes('/beacon') || low.includes('pixel.gif')
  );
}


const NAMED_ENTITIES = {
  amp: '&', AMP: '&', lt: '<', LT: '<', gt: '>', GT: '>', quot: '"', QUOT: '"', apos: "'",
  nbsp: ' ', copy: '©', COPY: '©', reg: '®', REG: '®', trade: '™', hellip: '…',
  mdash: '—', ndash: '–', lsquo: '\u2018', rsquo: '\u2019', ldquo: '\u201C', rdquo: '\u201D',
  middot: '·', laquo: '«', raquo: '»', times: '×', deg: '°', plusmn: '±',
  sup2: '²', sup3: '³', micro: 'µ', para: '¶', sect: '§', bull: '•', dagger: '†',
  permil: '‰', prime: '′', Prime: '″', larr: '←', uarr: '↑', rarr: '→', darr: '↓',
  harr: '↔', minus: '−', infin: '∞', ne: '≠', le: '≤', ge: '≥', asymp: '≈',
  euro: '€', pound: '£', yen: '¥', cent: '¢', frac12: '½', frac14: '¼', frac34: '¾',
  alpha: 'α', beta: 'β', gamma: 'γ', pi: 'π', Pi: 'Π', omega: 'ω', Omega: 'Ω', mu: 'μ',
  ensp: '\u2002', emsp: '\u2003', thinsp: '\u2009', zwnj: '\u200C', zwj: '\u200D', shy: '\u00AD',
};

export function unescapeHTML(s) {
  return String(s ?? '').replace(
    /&(#[xX][0-9a-fA-F]+|#[0-9]+|[a-zA-Z][a-zA-Z0-9]{1,31});?/g,
    (all, body) => {
      if (body.charCodeAt(0) === 0x23) {
        let code;
        if (body.length > 1 && (body[1] === 'x' || body[1] === 'X')) code = parseInt(body.slice(2), 16);
        else code = parseInt(body.slice(1), 10);
        if (!Number.isFinite(code) || code < 0 || code > 0x10ffff) return all;
        if (code >= 0xd800 && code <= 0xdfff) return '\uFFFD';
        try { return String.fromCodePoint(code); } catch { return all; }
      }
      if (Object.prototype.hasOwnProperty.call(NAMED_ENTITIES, body)) return NAMED_ENTITIES[body];
      const lower = body.toLowerCase();
      if (Object.prototype.hasOwnProperty.call(NAMED_ENTITIES, lower)) return NAMED_ENTITIES[lower];
      return all;
    },
  );
}



const MIRROR_PICK_TTL = 10 * 60 * 1000;

export class Mirror {
  constructor(name, hosts, client, probe) {
    this.name = name;
    this.hosts = Array.isArray(hosts) ? hosts : [];
    this.client = client;
    this.probe = probe;
    this.best = this.hosts.length > 0 ? this.hosts[0] : '';
    this.at = 0;
  }

  current() {
    if (this.best !== '') return this.best;
    return this.hosts.length > 0 ? this.hosts[0] : '';
  }

  order() {
    const out = [];
    if (this.best !== '') out.push(this.best);
    for (const host of this.hosts) {
      if (host !== this.best) out.push(host);
    }
    return out;
  }

  favorite(host) {
    if (!host) return;
    if (this.best !== host) this.best = host;
    this.at = Date.now();
  }

  invalidate() {
    this.at = 0;
  }

  
  async ensure() {
    const fresh = this.best !== '' && Date.now() - this.at < MIRROR_PICK_TTL;
    if (fresh || !this.probe || this.hosts.length === 0) return null;
    const results = await Promise.all(this.hosts.map(async (host) => {
      try {
        await withTimeout(Promise.resolve(this.probe(host)), 14000);
        return { host, err: null };
      } catch (err) {
        return { host, err };
      }
    }));
    let first = null;
    for (const r of results) {
      if (!r.err) {
        this.favorite(r.host);
        return null;
      }
      if (!first) first = r.err;
    }
    return first;
  }
}


export async function withMirror(mirror, fn) {
  if (!mirror || mirror.hosts.length === 0) throw new Error('镜像池为空');
  try { await mirror.ensure(); } catch {}
  let last = null;
  for (const host of mirror.order()) {
    try {
      const value = await fn(host);
      mirror.favorite(host);
      return value;
    } catch (err) {
      last = err;
      if (!mirrorSwitchable(err)) break;
    }
  }
  mirror.invalidate();
  if (!last) last = new Error(mirror.name + ' 无可用镜像');
  throw last;
}



export const reNuxtDataTag = /<script[^>]*id="__NUXT_DATA__"[^>]*>/is;

const NUXT_WRAPPER_TAGS = new Set([
  'Reactive', 'ShallowReactive', 'Ref', 'ShallowRef', 'EmptyRef', 'EmptyShallowRef',
]);

export class NuxtTable {
  constructor(rows) {
    this.rows = rows;
  }

  
  static wrapperIndex(v) {
    if (!Array.isArray(v) || v.length !== 2) return null;
    if (typeof v[0] !== 'string' || !NUXT_WRAPPER_TAGS.has(v[0])) return null;
    if (typeof v[1] !== 'number' || !Number.isInteger(v[1])) return null;
    return v[1];
  }

  resolve(v) {
    return this.resolveDepth(v, 0);
  }

  resolveDepth(v, depth) {
    if (depth > 24) return null;
    if (typeof v === 'number') {
      if (!Number.isInteger(v) || v < 0 || v >= this.rows.length) return v;
      const target = this.rows[v];
      if (target && typeof target === 'object') return this.resolveDepth(target, depth + 1);
      return target;
    }
    if (v && typeof v === 'object') {
      if (Array.isArray(v)) {
        const n = NuxtTable.wrapperIndex(v);
        if (n !== null) {
          if (n < 0 || n >= this.rows.length) return null;
          return this.resolveDepth(this.rows[n], depth + 1);
        }
        return v.map((val) => this.resolveDepth(val, depth + 1));
      }
      const out = {};
      for (const k of Object.keys(v)) out[k] = this.resolveDepth(v[k], depth + 1);
      return out;
    }
    return v;
  }

  deref(v) {
    for (let i = 0; i < 8; i++) {
      if (typeof v === 'number') {
        if (!Number.isInteger(v) || v < 0 || v >= this.rows.length) return v;
        const target = this.rows[v];
        if (Array.isArray(target)) {
          const idx = NuxtTable.wrapperIndex(target);
          if (idx !== null) {
            if (idx < 0 || idx >= this.rows.length) return null;
            v = this.rows[idx];
            continue;
          }
        }
        return target;
      }
      if (Array.isArray(v)) {
        const idx = NuxtTable.wrapperIndex(v);
        if (idx === null) return v;
        if (idx < 0 || idx >= this.rows.length) return null;
        v = this.rows[idx];
        continue;
      }
      return v;
    }
    return null;
  }

  derefMap(v) {
    const m = this.deref(v);
    return m && typeof m === 'object' && !Array.isArray(m) ? m : null;
  }

  derefList(v) {
    const l = this.deref(v);
    return Array.isArray(l) ? l : null;
  }

  field(m, key) {
    if (!m || !(key in m)) return null;
    return this.deref(m[key]);
  }

  str(m, ...keys) {
    for (const key of keys) {
      if (!m || !(key in m)) continue;
      const r = this.resolve(m[key]);
      if (typeof r === 'string' && r.trim() !== '') return r.trim();
    }
    return '';
  }

  num(m, key) {
    if (!m || !(key in m)) return 0;
    const r = this.resolve(m[key]);
    if (typeof r === 'number') return Number.isFinite(r) ? Math.trunc(r) : 0; 
    if (typeof r === 'string') return /^[+-]?[0-9]+$/.test(r) ? parseInt(r, 10) : 0;
    return 0;
  }

  
  collectNuxtDramaItems(node, out, depth) {
    if (node == null || depth > 8 || out.length > 400) return;
    if (Array.isArray(node)) {
      for (const it of node) this.collectNuxtDramaItems(it, out, depth + 1);
      return;
    }
    if (typeof node !== 'object') return;
    for (const k of Object.keys(node)) {
      const val = node[k];
      if (k === 'items') {
        const list = this.derefList(val);
        if (list && list.length > 0) {
          for (const it of list) {
            const m = this.derefMap(it);
            if (m && this.str(m, 'slug') !== '') out.push(m);
          }
          continue;
        }
      }
      this.collectNuxtDramaItems(this.deref(val), out, depth + 1);
    }
  }
}

export function loadNuxtTable(pageHTML) {
  const m = reNuxtDataTag.exec(pageHTML);
  if (!m) return null;
  const text = extractFirstJSON(pageHTML.slice(m.index + m[0].length));
  if (!text) return null;
  let rows;
  try {
    rows = JSON.parse(text);
  } catch {
    return null;
  }
  if (!Array.isArray(rows) || rows.length === 0) return null;
  return new NuxtTable(rows);
}


export function loadNuxtBusinessData(pageHTML) {
  const table = loadNuxtTable(pageHTML);
  if (!table) throw new Error('页面无 __NUXT_DATA__');
  let root = null;
  for (const row of table.rows) {
    if (!row || Array.isArray(row) || typeof row !== 'object') continue;
    if (!('data' in row)) continue;
    if (!('state' in row)) continue;
    root = row;
    break;
  }
  if (!root) throw new Error('__NUXT_DATA__ 缺少根状态');
  const wrapper = table.derefMap(root.data);
  if (!wrapper) throw new Error('根状态 data 不是对象');
  for (const v of Object.values(wrapper)) {
    const payload = table.derefMap(v);
    if (!payload) continue;
    const inner = table.derefMap(payload.data);
    if (inner) return inner;
    return payload;
  }
  throw new Error('__NUXT_DATA__ 缺少业务数据');
}


export function nuxtDramaData(pageHTML) {
  const table = loadNuxtTable(pageHTML);
  if (!table) return null;
  let root = null;
  for (const row of table.rows) {
    if (!row || Array.isArray(row) || typeof row !== 'object') continue;
    if (!('data' in row)) continue;
    if (!('state' in row)) continue;
    root = row;
    break;
  }
  if (!root) return null;
  const wrapper = table.derefMap(root.data);
  if (!wrapper) return null;
  const descend = (m, depth) => {
    if (!m || depth > 4) return null;
    if ('items' in m) return m;
    for (const v of Object.values(m)) {
      if (typeof v === 'number') {
        const inner = table.derefMap(v);
        if (inner) {
          const got = descend(inner, depth + 1);
          if (got) return got;
        }
      }
    }
    return null;
  };
  const data = descend(wrapper, 0);
  return data ? { table, data } : null;
}


export function nuxtDramaList(pageHTML, proxyImg) {
  const got = nuxtDramaData(pageHTML);
  if (!got) return [];
  const { table, data } = got;
  const items = [];
  table.collectNuxtDramaItems(data, items, 0);
  const cards = [];
  const seen = new Set();
  for (const m of items) {
    const slug = table.str(m, 'slug').trim();
    const title = table.str(m, 'title').trim();
    if (slug === '' || title === '' || seen.has(slug)) continue;
    seen.add(slug);
    const card = { vod_id: slug, vod_name: title, vod_pic: '', vod_remarks: '', vod_class: '', vod_score: '', vod_content: '' };
    const cover = table.derefMap(m.cover);
    if (cover) {
      let u = table.str(cover, 'url').trim();
      if (u === '') u = table.str(cover, 'fallback_url').trim();
      if (u !== '' && !isNonImageAsset(u.toLowerCase())) card.vod_pic = proxyImg(u);
    }
    const ch = table.derefMap(m.channel);
    if (ch) card.vod_class = table.str(ch, 'name').trim();
    let total = 0;
    for (const k of ['latest_episode_number', 'published_episode_count', 'total_episode_count']) {
      const n = table.num(m, k);
      if (n > 0) {
        total = n;
        break;
      }
    }
    if (total > 0 && table.str(m, 'serial_status').trim().toLowerCase() === 'completed') {
      card.vod_remarks = `全${total}集`;
    } else if (total > 0) {
      card.vod_remarks = `更新至${total}集`;
    }
    cards.push(card);
  }
  return cards;
}



const reNineH1 = /<h1[^>]*>([\s\S]*?)<\/h1>/is;
const reNineEpsFlag = /class="eps-flag"[^>]*>([\s\S]*?)<\/span>/i;
const reNineHd2Score = /class="card-score"[^>]*>([\s\S]*?)<\/em>/is;
const reNineDj91Score = /class="score"[^>]*>([^<]*)</i;
const reNineHd2Meta = /class="meta"[^>]*>([\s\S]*?)<\/div>/i;
const reNineHd2Desc = /class="hover-panel"[^>]*>\s*<span>([\s\S]*?)<\/span>/i;
const reNineBadge = /class="badge[^"]*"[^>]*>([^<]*)</i;
const reNineTagStrip = /<[^>]*>/gs;
const reNineEpTotal = /data-total="(\d+)"/i;
const reNineEpTitle = /title="第\s*(\d+)\s*集"/gi;
const reNineAltText = /\balt="([^"]*)"/i;
const reNineRankMeta = /class="rank-(?:row|runner)-(?:meta|metric)"[^>]*>([^<]*)</i;
const reNineRankDesc = /class="rank-(?:row|runner)-desc"[^>]*>([^<]*)</i;
const reNineRankCopyP = /class="rank-row-copy"[^>]*>[\s\S]*?<p[^>]*>([^<]*)<\/p>/is;
const reNineDigitsOnly = /^\d+$/;
const reNinePicCover = /\b(?:data-src|data-original|src)="(https?:\/\/pic\.[^"]+)"/i;
const reNineImgAttr = /\b(?:data-src|data-original|data-lazy-src|src)="([^"]+)"/gi;

export const NINE_SITES = {
  huangdou2: {
    key: 'huangdou2',
    name: '黄豆2',
    hosts: ['https://aihuangdou.com'],
    nodes: [
      { id: 'home', name: '首页' },
      { id: 'ai-duanju', name: 'AI短剧' },
      { id: 'ai-manju', name: 'AI漫剧' },
      { id: 'rankings', name: '榜单' },
    ],
    starts: [
      /<article\s+class="[^"]*\bdrama-card\b[^"]*"/gi,
      /<(?:article|li|div)\s+class="[^"]*(?:rank-runner|rank-row)(?:"|\s)/gi,
    ],
    detailRe: /href="(?:https?:\/\/[^/"]+)?(\/drama\/\d+\/)"/i,
    playPrefix: '/video/',
    pageStyle: 'suffix',
    alwaysSeq: false,
    scoreRe: reNineHd2Score,
    playDataID: 'ninePlayData',
  },
  dj91: {
    key: 'dj91',
    name: '91',
    hosts: [
      'https://91crdj.com',
      'https://0303.lwbcbync.cc',
      'https://j6bmio.lwbcbync.cc',
    ],
    nodes: [
      { id: 'duanju', name: '短剧' },
      { id: 'manju', name: '漫剧' },
      { id: 'zhenrenju', name: '真人剧' },
      { id: 'shipin', name: '视频' },
      { id: 'paihang', name: '排行' },
      { id: 'biaoqian:aiduanju', name: 'AI短剧' },
    ],
    starts: [
      /<a\s+class="[^"]*\bcard\b[^"]*"/gi,
    ],
    detailRe: /href="(?:https?:\/\/[^/"]+)?(\/(?:duanju|manju|zhenrenju|shipin|paihang)\/\d+-[^"/]+\/)"/i,
    playPrefix: '',
    pageStyle: 'page',
    alwaysSeq: true,
    scoreRe: reNineDj91Score,
    playDataID: 'playInitialData',
  },
};

function nineStrip(s) {
  return cleanText(String(s ?? '').replace(reNineTagStrip, ' '));
}

function nineAttr(block, name) {
  const re = new RegExp(`\\b${escapeRegExp(name)}="([^"]*)"`, 'i');
  const m = re.exec(block);
  return m ? m[1].trim() : '';
}

function nineFirstImage(block) {
  for (const m of block.matchAll(reNineImgAttr)) {
    const raw = m[1].trim();
    const low = raw.toLowerCase();
    if (raw === '' || low.startsWith('data:') ||
      low.includes('placeholder') || low.includes('loading') ||
      isNonImageAsset(low)) {
      continue;
    }
    return raw;
  }
  return '';
}

function nineCleanAlt(alt) {
  alt = String(alt ?? '').trim();
  const i = alt.indexOf('》');
  if (i > 0 && alt.startsWith('《')) return alt.slice(1, i).trim();
  if (alt.endsWith('封面')) alt = alt.slice(0, -2);
  return alt.trim();
}

function nineLeaf(id) {
  id = String(id ?? '').replace(/^\/+|\/+$/g, '');
  const i = id.lastIndexOf('/');
  return i >= 0 ? id.slice(i + 1) : id;
}

function nineLongestAnchorText(block, detailPath) {
  const source = `<a\\b[^>]*href="[^"]*${escapeRegExp(detailPath)}"[^>]*>([\\s\\S]*?)</a>`;
  let best = '';
  for (const m of block.matchAll(new RegExp(source, 'gis'))) {
    const text = nineStrip(m[1]);
    if (text === '' || reNineDigitsOnly.test(text)) continue;
    if (text.length > best.length) best = text;
  }
  return best;
}


function siteAbsURL(host, raw) {
  raw = String(raw ?? '').trim();
  if (raw === '') return '';
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  return host + '/' + raw.replace(/^\/+/, '');
}

export class NineProvider {
  constructor(site, client, media) {
    this.site = site;
    this.client = client;
    this.media = media;
    this.host = '';
    this.mirror = new Mirror(site.name, site.hosts, client, (host) => this.probe(host));
  }

  hostURL() {
    if (this.host !== '') return this.host;
    return this.site.hosts.length > 0 ? this.site.hosts[0] : '';
  }

  use(host) {
    this.host = host;
  }

  async probe(host) {
    let raw = null;
    let status = 0;
    let err = null;
    try {
      ({ raw, status } = await this.client.fetchWithHeaders('GET', host + '/', {}, null));
    } catch (e) {
      err = e;
    }
    const switchErr = httpStatusSwitch(status, err);
    if (switchErr) throw switchErr;
    if (!raw || raw.length < 512) throw new Error(this.site.name + '镜像响应过短');
  }

  catPath(cat) {
    if (cat === '') return '/' + this.site.nodes[0].id + '/';
    if (String(cat).startsWith('biaoqian:')) {
      return '/biaoqian/' + encodeURIComponent(String(cat).slice('biaoqian:'.length)) + '/';
    }
    if (cat === 'home') return '/';
    return '/' + cat + '/';
  }

  async fetch(path) {
    return withMirror(this.mirror, async (host) => {
      let raw = null;
      let status = 0;
      let err = null;
      try {
        ({ raw, status } = await this.client.fetchWithHeaders('GET', host + path, { Referer: host + '/' }, null));
      } catch (e) {
        err = e;
      }
      const switchErr = httpStatusSwitch(status, err);
      if (switchErr) throw switchErr;
      if (!raw || raw.length === 0) throw new Error(this.site.name + '空响应: ' + path);
      this.use(host);
      return raw.toString('utf8');
    });
  }

  nineCards(pageHTML, catName) {
    const locs = [];
    for (const re of this.site.starts) {
      for (const m of pageHTML.matchAll(re)) locs.push([m.index, m.index + m[0].length]);
    }
    locs.sort((a, b) => a[0] - b[0]);
    const cards = [];
    const seen = new Set();
    for (let i = 0; i < locs.length; i++) {
      const start = locs[i][0];
      const end = i + 1 < locs.length ? locs[i + 1][0] : pageHTML.length;
      const block = pageHTML.slice(start, end);
      const dm = this.site.detailRe.exec(block);
      if (!dm) continue;
      const id = dm[1].replace(/^\/+|\/+$/g, '');
      if (id === '' || seen.has(id)) continue;
      let name = nineAttr(block, 'data-track-item-name');
      if (name === '') name = nineLongestAnchorText(block, dm[1]);
      if (name === '') {
        const alt = reNineAltText.exec(block);
        if (alt) name = nineCleanAlt(alt[1]);
      }
      if (name === '') {
        const h = /<h[23][^>]*>([\s\S]*?)<\/h[23]>/is.exec(block);
        if (h) name = nineStrip(h[1]);
      }
      if (name === '') continue;
      seen.add(id);
      const card = { vod_id: id, vod_name: name, vod_pic: '', vod_remarks: '', vod_class: '', vod_score: '', vod_content: '' };
      const cover = nineFirstImage(block);
      if (cover !== '') {
        card.vod_pic = this.media.imgProxyURL(siteAbsURL(this.hostURL(), cover), this.hostURL() + '/');
      }
      const flag = reNineEpsFlag.exec(block);
      if (flag) card.vod_remarks = nineStrip(flag[1]);
      if (this.site.scoreRe) {
        const sm = this.site.scoreRe.exec(block);
        if (sm) card.vod_score = nineStrip(sm[1]);
      }
      for (const re of [reNineHd2Meta, reNineRankMeta, reNineRankCopyP]) {
        const mm = re.exec(block);
        if (mm) {
          card.vod_class = nineStrip(mm[1]);
          break;
        }
      }
      if (card.vod_class === '') {
        const bm = reNineBadge.exec(block);
        if (bm) card.vod_class = bm[1].trim();
      }
      for (const re of [reNineHd2Desc, reNineRankDesc]) {
        const dmr = re.exec(block);
        if (dmr) {
          card.vod_content = truncate(nineStrip(dmr[1]), 200);
          break;
        }
      }
      if (card.vod_class === '') card.vod_class = catName;
      cards.push(card);
    }
    return cards;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    const base = this.catPath(cat);
    let path = base;
    if (page > 1) {
      const trimmed = base.endsWith('/') ? base.slice(0, -1) : base;
      path = this.site.pageStyle === 'page'
        ? `${trimmed}/page/${page}/`
        : `${trimmed}/${page}/`;
    }
    let catName = '';
    for (const node of this.site.nodes) {
      if (node.id === cat) catName = node.name;
    }
    let body;
    try {
      body = await this.fetch(path);
    } catch (err) {
      if (page > 1 && String(err && err.message).includes('404')) return [];
      throw err;
    }
    const cards = this.nineCards(body, catName);
    if (cards.length === 0) {
      if (page > 1) return [];
      throw new Error(this.site.name + '列表无内容: ' + path);
    }
    return cards;
  }

  async Search(wd, page) {
    wd = String(wd ?? '').trim();
    if (wd === '') throw new Error(this.site.name + '搜索关键词为空');
    if (page < 1) page = 1;
    let path = '/search/?q=' + encodeURIComponent(wd);
    if (page > 1) path += '&page=' + page;
    const body = await this.fetch(path);
    const cards = this.nineCards(body, '');
    if (cards.length === 0) throw new Error(this.site.name + '搜索无结果: ' + wd);
    return cards;
  }

  ninePlayPath(id, seq) {
    let base = '/' + String(id ?? '').replace(/^\/+|\/+$/g, '');
    if (this.site.playPrefix !== '') base = this.site.playPrefix + nineLeaf(id);
    if (seq > 1 || this.site.alwaysSeq) return `${base}/${seq}/`;
    return base + '/';
  }

  async Detail(id) {
    id = String(id ?? '').replace(/^\/+|\/+$/g, '');
    if (id === '') throw new Error('无效的' + this.site.name + '剧集 ID');
    const body = await this.fetch('/' + id + '/');
    const detail = { vod_id: id, vod_name: '', vod_pic: '', vod_content: '', vod_class: '', episodes: [], episode_count: 0 };
    const h1 = reNineH1.exec(body);
    if (h1) detail.vod_name = nineStrip(h1[1]);
    const desc = /<meta[^>]*name="description"[^>]*content="([^"]*)"/is.exec(body);
    if (desc) detail.vod_content = cleanText(desc[1]);
    const pic = reNinePicCover.exec(body);
    if (pic) detail.vod_pic = this.media.imgProxyURL(pic[1], this.hostURL() + '/');
    const badge = reNineBadge.exec(body);
    if (badge) detail.vod_class = badge[1].trim();

    const seqs = new Map();
    const totalMatch = reNineEpTotal.exec(body);
    if (totalMatch) {
      const total = atoiDefault(totalMatch[1], 0);
      if (total > 0 && total <= 2000) {
        for (let n = 1; n <= total; n++) seqs.set(n, true);
      }
    }
    if (seqs.size === 0) {
      for (const m of body.matchAll(reNineEpTitle)) {
        const n = atoiDefault(m[1], 0);
        if (n > 0) seqs.set(n, true);
      }
    }
    if (seqs.size === 0) {
      const prefix = '/' + id + '/';
      for (const m of body.matchAll(/href="([^"]+)"/gi)) {
        let raw = m[1];
        try {
          const u = new URL(raw, 'http://localhost/');
          if (u.pathname) raw = u.pathname;
        } catch {}
        raw = raw.replace(/^\/+|\/+$/g, '');
        if (!('/' + raw + '/').startsWith(prefix)) continue;
        const tail = ('/' + raw + '/').slice(prefix.length).replace(/^\/+|\/+$/g, '');
        const n = atoiDefault(tail, 0);
        if (n > 0) seqs.set(n, true);
      }
    }
    if (seqs.size === 0) throw new Error(this.site.name + '详情页无剧集: ' + id);
    const list = [...seqs.keys()].sort((a, b) => a - b);
    for (const n of list) {
      detail.episodes.push({
        no: n,
        name: `第${n}集`,
        url: `${this.site.key}://${id}/${n}`,
      });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') detail.vod_name = this.site.name + ' ' + id;
    return detail;
  }

  ninePlayDataFromBody(body) {
    const re = new RegExp(`<script[^>]*id="${escapeRegExp(this.site.playDataID)}"[^>]*>([\\s\\S]*?)<\\/script>`, 'is');
    const m = re.exec(body);
    if (!m) throw new Error(this.site.name + '播放页无播放数据');
    let data;
    try {
      data = JSON.parse(m[1].trim());
    } catch {
      throw new Error(this.site.name + '播放数据解析失败');
    }
    let current = data && typeof data === 'object' && !Array.isArray(data) &&
      data.current && typeof data.current === 'object' && !Array.isArray(data.current) ? data.current : null;
    if (!current && data && typeof data === 'object' && !Array.isArray(data) &&
      data.episode && typeof data.episode === 'object' && !Array.isArray(data.episode)) {
      current = data.episode;
    }
    if (!current) throw new Error(this.site.name + '播放数据缺少当前集');
    const src = mapString(current, 'src', 'videoUrl', 'playUrl', 'url');
    if (src !== '') return src;
    const srcHevc = mapString(current, 'srcHevc');
    if (srcHevc.includes('.m3u8')) return srcHevc;
    throw new Error(this.site.name + '播放数据无媒体地址');
  }

  async Play(playURL) {
    const prefix = this.site.key + '://';
    let rest = String(playURL ?? '').trim().replace(/^\/+|\/+$/g, '');
    if (rest.startsWith(prefix)) {
      rest = rest.slice(prefix.length).replace(/^\/+|\/+$/g, '');
    } else {
      const hostURL = this.hostURL();
      const i = rest.indexOf(hostURL);
      if (i < 0) throw new Error(this.site.name + '播放参数无效');
      rest = rest.slice(i + hostURL.length).replace(/^\/+|\/+$/g, '');
    }
    const cut = rest.lastIndexOf('/');
    if (cut <= 0 || cut >= rest.length - 1) throw new Error(this.site.name + '播放参数无效');
    const id = rest.slice(0, cut);
    const seq = atoiDefault(rest.slice(cut + 1), 0);
    if (seq < 1) throw new Error(this.site.name + '播放参数无效');
    const body = await this.fetch(this.ninePlayPath(id, seq));
    const src = this.ninePlayDataFromBody(body);
    if (!isProviderHTTPMediaURL(src)) throw new Error(this.site.name + '播放地址无效');
    return { src, referer: this.hostURL() + '/' };
  }
}

export class Huangdou2Provider extends NineProvider {
  constructor(client, media) {
    super(NINE_SITES.huangdou2, client, media);
  }
}

export class Dj91Provider extends NineProvider {
  constructor(client, media) {
    super(NINE_SITES.dj91, client, media);
  }
}


export const platformCats = NINE_SITES.huangdou2.nodes.map((n) => ({ id: n.id, name: n.name }));

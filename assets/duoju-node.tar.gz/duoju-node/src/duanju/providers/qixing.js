
import crypto from 'node:crypto';
import { atoiDefault, cleanText, mapString, anyList, nestedMap, firstNonEmpty, encodeQuery } from '../../core/util.js';
import { truncate, pkcs7Pad } from '../shared.js';
import { qixingBase, qixingAuthBase, qixingAESKey, qixingDevice, qixingAndroidID } from '../consts.js';

const qixingUA = 'Mozilla/5.0 (Linux; Android 9; V1938T Build/PQ3A.190705.08211809; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Safari/537.36';
const qixingPackage = 'com.jz.xydj';
const qixingVersionName = '3.8.3.1';
const qixingPageSize = 24;
const qixingDescMax = 200;
const qixingMaxEpisodes = 300;
const qixingTokenTTL = 30 * 60 * 1000; 

const qixingCats = [
  { ID: '1', Name: '剧场' },
  { ID: '3', Name: '新剧' },
  { ID: '2', Name: '热播' },
  { ID: '7', Name: '星选' },
  { ID: '5', Name: '阳光' },
];

export const platformCats = qixingCats.map((c) => ({ ID: c.ID, Name: c.Name }));

function aesECBEncryptBase64(plain, key) {
  const keyBuf = Buffer.from(String(key ?? ''), 'utf8');
  const padded = pkcs7Pad(Buffer.from(String(plain ?? ''), 'utf8'), 16);
  const cipher = crypto.createCipheriv(`aes-${keyBuf.length * 8}-ecb`, keyBuf, null);
  cipher.setAutoPadding(false);
  return Buffer.concat([cipher.update(padded), cipher.final()]).toString('base64');
}

function qixingLoginPayload() {
  return JSON.stringify({
    device: qixingDevice,
    package_name: qixingPackage,
    android_id: qixingAndroidID,
    install_first_open: true,
    first_install_time: 1752505243345,
    last_update_time: 1752505243345,
    report_link_url: '',
    authorization: '',
    timestamp: Date.now(),
  });
}

function qixingOK(envelope) {
  if (!envelope || typeof envelope !== 'object' || !('code' in envelope)) return true;
  const raw = envelope.code;
  if (typeof raw === 'boolean') return raw;
  if (typeof raw === 'number') return raw === 0 || raw === 200;
  if (typeof raw === 'string') {
    const s = raw.trim();
    if (s.toLowerCase() === 'ok') return true;
    if (/^[+-]?\d+$/.test(s)) {
      const n = parseInt(s, 10);
      return n === 0 || n === 200;
    }
    return false;
  }
  const s = String(raw ?? '').trim();
  if (/^[+-]?\d+$/.test(s)) {
    const n = parseInt(s, 10);
    return n === 0 || n === 200;
  }
  return false;
}

function qixingCatName(cat) {
  for (const c of qixingCats) {
    if (c.ID === cat) return c.Name;
  }
  return '';
}

function qixingCat(cat) {
  const c = String(cat ?? '').trim();
  for (const item of qixingCats) {
    if (item.ID === c) return item.ID;
  }
  return qixingCats[0].ID;
}

export class QixingProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
    this.token = '';
    this.tokenAt = 0;
  }

  async login() {
    const body = aesECBEncryptBase64(qixingLoginPayload(), qixingAESKey);
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders('POST', qixingAuthBase + '/user/v3/account/login', {
        platform: '1',
        user_agent: qixingUA,
        'content-type': 'application/json; charset=utf-8',
      }, body);
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    if (terr) throw terr;
    if (status >= 400) {
      throw new Error(`七星登录 HTTP ${status}`);
    }
    let envelope = null;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('七星登录响应无法解析');
    }
    if (!envelope || typeof envelope !== 'object' || Array.isArray(envelope)) {
      throw new Error('七星登录响应无法解析');
    }
    if (!qixingOK(envelope)) {
      throw new Error('七星登录失败: ' + mapString(envelope, 'msg', 'message'));
    }
    const token = mapString(nestedMap(envelope, 'data'), 'token');
    if (token === '') {
      throw new Error('七星登录没拿到 token');
    }
    return token;
  }

  async auth() {
    if (this.token !== '' && Date.now() - this.tokenAt < qixingTokenTTL) {
      return this.token;
    }
    const tok = await this.login();
    this.token = tok;
    this.tokenAt = Date.now();
    return tok;
  }

  invalidate() {
    this.token = '';
    this.tokenAt = 0;
  }

  async getJSON(target, retry) {
    const token = await this.auth();
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders('GET', target, {
        authorization: token,
        platform: '1',
        version_name: qixingVersionName,
        'User-Agent': qixingUA,
      });
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    if (terr) throw terr;
    if (status === 401 || status === 403) {
      if (retry) {
        this.invalidate();
        return await this.getJSON(target, false);
      }
      throw new Error(`七星接口鉴权失败 HTTP ${status}`);
    }
    if (status >= 400) {
      throw new Error(`七星接口 HTTP ${status}`);
    }
    let envelope = null;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('七星接口响应无法解析');
    }
    if (!envelope || typeof envelope !== 'object' || Array.isArray(envelope)) {
      throw new Error('七星接口响应无法解析');
    }
    if (!qixingOK(envelope)) {
      const msg = mapString(envelope, 'msg', 'message');
      if (retry && (msg.includes('token') || msg.includes('登录') || msg.toLowerCase().includes('auth'))) {
        this.invalidate();
        return await this.getJSON(target, false);
      }
      throw new Error('七星接口返回错误: ' + msg);
    }
    return envelope;
  }

  card(item, catName) {
    const id = String(mapString(item, 'id')).trim();
    const name = cleanText(mapString(item, 'title'));
    if (id === '' || name === '') return null;
    const card = { vod_id: id, vod_name: name, vod_pic: '', vod_remarks: '', vod_class: catName, vod_content: '' };
    const cover = mapString(item, 'cover_url');
    if (cover !== '') {
      card.vod_pic = this.media.imgProxyURL(cover, qixingBase + '/');
    }
    card.vod_remarks = firstNonEmpty(cleanText(mapString(item, 'play_amount_str')), cleanText(mapString(item, 'score_str')));
    const desc = cleanText(mapString(item, 'introduction'));
    if (desc !== '') {
      card.vod_content = truncate(desc, qixingDescMax);
    }
    return card;
  }

  cardList(items, catName) {
    const cards = [];
    const seen = new Set();
    for (const rawItem of anyList(items)) {
      if (!rawItem || typeof rawItem !== 'object' || Array.isArray(rawItem)) continue;
      let item = rawItem;
      if (item.theater && typeof item.theater === 'object' && !Array.isArray(item.theater)) {
        item = item.theater;
      }
      const card = this.card(item, catName);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    return cards;
  }

  async List(cat, page) {
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    const catID = qixingCat(cat);
    const q = encodeQuery({
      theater_class_id: catID,
      page_num: String(p),
      page_size: String(qixingPageSize),
    });
    const envelope = await this.getJSON(`${qixingBase}/v1/theater/home_page?${q}`, true);
    const data = nestedMap(envelope, 'data');
    const cards = this.cardList(anyList(data?.list), qixingCatName(catID));
    if (cards.length === 0) {
      if (p > 1) return [];
      throw new Error('七星列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    const kw = String(wd ?? '').trim();
    if (kw === '') throw new Error('搜索关键字为空');
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    if (p > 1) return [];
    const token = await this.auth();
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders('POST', qixingBase + '/v3/search', {
        authorization: token,
        platform: '1',
        version_name: qixingVersionName,
        'User-Agent': qixingUA,
        'Content-Type': 'application/json',
      }, JSON.stringify({ text: kw }));
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    if (terr) throw terr;
    if (status >= 400) {
      throw new Error(`七星搜索 HTTP ${status}`);
    }
    let envelope = null;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('七星搜索响应无法解析');
    }
    if (!envelope || typeof envelope !== 'object' || Array.isArray(envelope)) {
      throw new Error('七星搜索响应无法解析');
    }
    if (!qixingOK(envelope)) {
      throw new Error('七星搜索失败');
    }
    const data = nestedMap(envelope, 'data');
    const cards = this.cardList(anyList(nestedMap(data, 'theater')?.search_data), '');
    if (cards.length === 0) return [];
    return cards;
  }

  async Detail(id) {
    const tid = String(id ?? '').trim();
    if (tid === '') throw new Error('无效的七星剧集 ID');
    const q = encodeQuery({ theater_parent_id: tid });
    const envelope = await this.getJSON(`${qixingBase}/v2/theater_parent/detail?${q}`, true);
    const data = nestedMap(envelope, 'data');
    const detail = {
      vod_id: tid,
      vod_name: cleanText(mapString(data, 'title')),
      vod_pic: '',
      vod_content: '',
      vod_class: '七星',
      episodes: [],
      episode_count: 0,
    };
    const cover = mapString(data, 'cover_url');
    if (cover !== '') {
      detail.vod_pic = this.media.imgProxyURL(cover, qixingBase + '/');
    }
    detail.vod_content = truncate(cleanText(firstNonEmpty(mapString(data, 'introduction'), mapString(data, 'descrip'))), qixingDescMax);
    const seen = new Set();
    const theaters = anyList(data?.theaters);
    for (let i = 0; i < theaters.length; i++) {
      if (detail.episodes.length >= qixingMaxEpisodes) break;
      const rawEp = theaters[i];
      if (!rawEp || typeof rawEp !== 'object' || Array.isArray(rawEp)) continue;
      const src = mapString(rawEp, 'son_video_url');
      if (src === '') continue;
      let no = atoiDefault(mapString(rawEp, 'num'), 0);
      if (no < 1) no = i + 1;
      if (seen.has(no)) continue;
      seen.add(no);
      let epName = cleanText(mapString(rawEp, 'son_title'));
      if (epName === '' || epName === detail.vod_name) {
        epName = `第${no}集`;
      }
      detail.episodes.push({ no, name: epName, url: src });
    }
    detail.episodes.sort((a, b) => a.no - b.no);
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') {
      detail.vod_name = '七星短剧 ' + tid;
    }
    if (detail.episodes.length === 0) {
      throw new Error('七星详情无剧集: ' + tid);
    }
    return detail;
  }

  async Play(playURL) {
    const target = String(playURL ?? '').trim();
    if (target === '' || !target.startsWith('http')) {
      throw new Error('七星播放参数无效');
    }
    return { src: target, userAgent: qixingUA };
  }
}

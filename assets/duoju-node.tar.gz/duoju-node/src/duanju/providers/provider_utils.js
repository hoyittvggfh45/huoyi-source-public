



export function isNonImageAsset(low) {
  if (typeof low !== 'string') return false;
  return /\.(mp4|m3u8|mp3|m4a|aac|ts|flv|avi|mov|webm|mkv|wmv|ogg|wav|srt|ass|vtt)(\?|#|$)/i.test(low);
}


const ENTITY_MAP = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ',
  ldquo: '\u201c', rdquo: '\u201d', lsquo: '\u2018', rsquo: '\u2019',
  middot: '\u00b7', hellip: '\u2026', mdash: '\u2014', ndash: '\u2013',
  copy: '\u00a9', reg: '\u00ae', trade: '\u2122',
};

export function decodeHTML(s) {
  const str = String(s ?? '');
  if (str.indexOf('&') === -1) return str;
  return str.replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z][a-zA-Z0-9]*);/g, (m, body) => {
    if (body[0] === '#') {
      const code = body[1] === 'x' || body[1] === 'X'
        ? parseInt(body.slice(2), 16)
        : parseInt(body.slice(1), 10);
      if (!Number.isFinite(code) || code < 0 || code > 0x10ffff) return m;
      try { return String.fromCodePoint(code); } catch { return m; }
    }
    const hit = ENTITY_MAP[body.toLowerCase()];
    return hit !== undefined ? hit : m;
  });
}

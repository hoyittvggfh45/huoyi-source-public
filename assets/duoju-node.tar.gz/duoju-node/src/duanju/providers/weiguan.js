
import { atoiDefault, cleanText, firstNonEmpty, mapString, parsePlayScheme } from '../../core/util.js';
import { weiguanAPIBase } from '../consts.js';
import { truncate } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { queryEscape } from './xingxing.js';

const weiguanCats = [{ id: 'all', name: '全部' }];

export const platformCats = weiguanCats.map((c) => ({ ID: c.id, Name: c.name }));

function humanCount(raw) {
  const n = atoiDefault(raw, 0);
  if (n >= 10000) {
    
    return (n / 10000).toFixed(1).replace(/\.0$/, '') + '万';
  }
  return String(n);
}

export function weiguanPlayURL(ep) {
  let raw = ep?.playSetting !== undefined ? ep.playSetting : undefined;
  if (raw === undefined || raw === null) raw = ep?.videoClarityList;
  if (typeof raw === 'string') {
    const text = raw.trim();
    if (text === '') return '';
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      return firstNonEmpty(mapString(ep, 'playUrl'), text);
    }
    raw = parsed;
  }
  if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
    return firstNonEmpty(
      mapString(raw, 'super'), mapString(raw, 'high'), mapString(raw, 'normal'),
      mapString(raw, 'url'), mapString(raw, 'playUrl'),
    );
  }
  if (Array.isArray(raw)) {
    let best = null;
    for (const item of raw) {
      if (!item || typeof item !== 'object' || Array.isArray(item)) continue;
      if (best === null) best = item;
      const clarity = mapString(item, 'clarity');
      if (clarity === '1080P' || clarity === '1080p' || clarity === 'super' || clarity === '超清') {
        best = item;
      }
    }
    if (best !== null) {
      return firstNonEmpty(mapString(best, 'url'), mapString(best, 'playUrl'));
    }
  }
  return firstNonEmpty(mapString(ep, 'playUrl'), '');
}

export class WeiguanProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async call(method, path, payload) {
    const target = weiguanAPIBase + path;
    const headers = {
      Accept: 'application/json, text/plain, */*',
      Origin: weiguanAPIBase,
      Referer: `${weiguanAPIBase}/`,
      'User-Agent': 'okhttp/4.10.0',
    };
    let body;
    if (payload !== undefined && payload !== null) {
      body = JSON.stringify(payload);
      headers['Content-Type'] = 'application/json; charset=utf-8';
    }
    const { raw, status } = await this.client.fetchWithHeaders(method, target, headers, body);
    if (status >= 400) {
      throw new Error(`围观接口 HTTP ${status}`);
    }
    let envelope;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('围观接口响应无法解析');
    }
    const data = envelope?.data;
    if (data === undefined || data === null) {
      const msg = envelope?.msg ?? '';
      if (msg !== '') {
        throw new Error(`围观接口返回错误: ${msg}`);
      }
      throw new Error('围观接口无数据');
    }
    return data;
  }

  async listItems(wd, page) {
    if (page < 1) page = 1;
    const payload = {
      audience: '全部受众',
      page,
      pageSize: 30,
      searchWord: wd,
      subject: '全部主题',
    };
    const data = await this.call('POST', '/drama/home/search?version_code=1500&os_type=1', payload);
    if (!Array.isArray(data)) {
      throw new Error('围观列表解析失败');
    }
    return data;
  }

  card(item) {
    const id = mapString(item, 'oneId');
    const title = cleanText(mapString(item, 'title'));
    if (id === '' || title === '') return null;
    const card = { vod_id: id, vod_name: title, vod_class: '全部', vod_score: '', vod_content: '' };
    const cover = firstNonEmpty(mapString(item, 'vertPoster'), mapString(item, 'horizonPoster'));
    if (cover !== '') card.vod_pic = this.media.imgProxyURL(cover, `${weiguanAPIBase}/`);
    const parts = [];
    const n = atoiDefault(mapString(item, 'episodeCount'), 0);
    if (n > 0) parts.push(`共${n}集`);
    const view = mapString(item, 'viewCount');
    if (view !== '' && view !== '0') {
      parts.push(humanCount(view) + '播放');
    }
    card.vod_remarks = parts.join(' · ');
    return card;
  }

  async List(cat, page) {
    const items = await this.listItems('', page);
    if (page > 1 && items.length === 0) {
      return [];
    }
    const cards = [];
    const seen = new Set();
    for (const item of items) {
      const card = this.card(item);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('围观列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    wd = String(wd || '').trim();
    if (wd === '') {
      throw new Error('围观搜索关键词为空');
    }
    const items = await this.listItems(wd, page);
    const cards = [];
    const seen = new Set();
    for (const item of items) {
      const card = this.card(item);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('围观搜索无结果: ' + wd);
    }
    return cards;
  }

  async episodes(oneID) {
    const path = `/drama/home/shortVideoDetail?version_code=1000&os_type=1&oneId=${queryEscape(oneID)}&page=1&pageSize=1000`;
    const data = await this.call('GET', path, null);
    if (!Array.isArray(data)) {
      throw new Error('围观详情解析失败');
    }
    if (data.length === 0) {
      throw new Error('围观详情无剧集: ' + oneID);
    }
    return data;
  }

  async Detail(id) {
    id = String(id || '').trim();
    if (id === '') {
      throw new Error('无效的围观剧集 ID');
    }
    const items = await this.episodes(id);
    const first = items[0];
    const detail = {
      vod_id: id,
      vod_name: cleanText(mapString(first, 'title')),
      vod_content: truncate(cleanText(mapString(first, 'description', 'desc')), 400),
      vod_pic: '',
      vod_class: '围观',
      episodes: [],
      episode_count: 0,
    };
    const cover = firstNonEmpty(mapString(first, 'vertPoster'), mapString(first, 'horizonPoster'));
    if (cover !== '') detail.vod_pic = this.media.imgProxyURL(cover, `${weiguanAPIBase}/`);
    const seen = new Set();
    for (let i = 0; i < items.length; i++) {
      const ep = items[i];
      let order = atoiDefault(mapString(ep, 'playOrder'), 0);
      if (order < 1) order = atoiDefault(mapString(ep, 'episode'), 0);
      if (order < 1) order = i + 1;
      if (seen.has(order)) continue;
      seen.add(order);
      detail.episodes.push({ no: order, name: `第${order}集`, url: `weiguan://${id}/${order}` });
    }
    detail.episodes.sort((a, b) => a.no - b.no);
    detail.episode_count = detail.episodes.length;
    if (detail.episodes.length === 0) {
      throw new Error('围观详情无剧集: ' + id);
    }
    if (detail.vod_name === '') {
      detail.vod_name = '围观短剧 ' + id;
    }
    return detail;
  }

  async Play(playURL) {
    const scheme = parsePlayScheme(playURL, 'weiguan://');
    if (!scheme || scheme.id === '') {
      throw new Error('围观播放参数无效');
    }
    const id = scheme.id;
    const seq = atoiDefault(scheme.extra, 1);
    const items = await this.episodes(id);
    for (let i = 0; i < items.length; i++) {
      const ep = items[i];
      let order = atoiDefault(mapString(ep, 'playOrder'), 0);
      if (order < 1) order = atoiDefault(mapString(ep, 'episode'), 0);
      if (order < 1) order = i + 1;
      if (order !== seq) continue;
      const src = weiguanPlayURL(ep);
      if (!isProviderHTTPMediaURL(src)) {
        throw new Error(`围观第${seq}集暂无播放地址`);
      }
      return { src, referer: `${weiguanAPIBase}/` };
    }
    throw new Error(`围观详情缺第${seq}集`);
  }
}

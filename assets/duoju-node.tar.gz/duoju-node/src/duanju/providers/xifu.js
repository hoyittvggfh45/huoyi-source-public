
import crypto from 'node:crypto';
import { atoiDefault, mapString, parsePlayScheme } from '../../core/util.js';
import { xifuHost, xifuOrigin, xifuReferer } from '../consts.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { queryEscape } from './xingxing.js';

const xifuUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36';

const xifuCats = [
  { ID: '3', Name: '爽剧' },
  { ID: '6', Name: '甜宠' },
  { ID: '5', Name: '逆袭' },
  { ID: '1', Name: '现代言情' },
  { ID: '4', Name: '都市' },
  { ID: '23', Name: '玄幻' },
  { ID: '16', Name: '古代言情' },
];

export const platformCats = xifuCats.map((c) => ({ ID: c.ID, Name: c.Name }));

function xifuCatIDs() {
  return xifuCats.map((c) => c.ID);
}

function xifuKnownCat(cat) {
  if (cat === '') return false;
  for (const c of xifuCats) {
    if (c.ID === cat) return true;
  }
  return false;
}

function xifuAlbumID(item) {
  const raw = item?.albumId;
  if (typeof raw === 'string') return raw.trim();
  if (typeof raw === 'number' && Number.isFinite(raw)) return String(Math.trunc(raw));
  return '';
}

function xifuTotal(item) {
  const v = item?.total;
  if (typeof v === 'number' && Number.isFinite(v)) return Math.trunc(v);
  if (typeof v === 'string') return atoiDefault(v, 0);
  return 0;
}


function xifuPercentEncode(s) {
  return queryEscape(s)
    .replace(/\+/g, '%2B')
    .replace(/\*/g, '%2A')
    .replace(/%7E/g, '~');
}


function base64DecodeStrict(s) {
  const str = String(s ?? '');
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(str) || str.length % 4 !== 0) {
    throw new Error('base64 解码失败');
  }
  return Buffer.from(str, 'base64');
}

export class XifuProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async get(rawURL) {
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders('GET', rawURL, {
        'User-Agent': xifuUA,
        Origin: xifuOrigin,
        Referer: xifuReferer,
        Accept: 'application/json, text/plain, */*',
      });
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    if (terr) throw terr;
    if (status >= 400) {
      throw new Error(`喜福接口 HTTP ${status}`);
    }
    let envelope = null;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('喜福接口响应无法解析');
    }
    if (!envelope || typeof envelope !== 'object' || Array.isArray(envelope)) {
      throw new Error('喜福接口响应无法解析');
    }
    if (envelope.data === undefined || envelope.data === null) {
      throw new Error('喜福接口无数据');
    }
    return envelope.data;
  }

  async fetchList(cid, page) {
    let u = `${xifuHost}/web/v1/drama/list?pageSize=24&currentPage=${page}`;
    if (cid !== '') {
      u += '&filterCategories[]=' + queryEscape(cid);
    }
    const data = await this.get(u);
    if (!data || typeof data !== 'object' || Array.isArray(data) || !Array.isArray(data.data)) {
      throw new Error('喜福列表解析失败');
    }
    return data.data;
  }

  async dramaList(cat, page) {
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    let c = String(cat ?? '').trim();
    if (!xifuKnownCat(c)) c = '';
    let items = null;
    let firstErr = null;
    try {
      items = await this.fetchList(c, p);
    } catch (err) {
      firstErr = err;
    }
    if (firstErr || !items || items.length === 0) {
      if (c !== '') {
        try {
          const fallback = await this.fetchList('', p);
          if (fallback && fallback.length > 0) return fallback;
        } catch {
          
        }
      }
    }
    if (firstErr) throw firstErr;
    return items || [];
  }

  card(item, cat) {
    const id = xifuAlbumID(item);
    if (id === '') return null;
    const name = String(mapString(item, 'title')).trim();
    if (name === '') return null;
    const total = xifuTotal(item);
    const card = { vod_id: id, vod_name: name, vod_pic: '', vod_remarks: '', vod_class: cat };
    const cover = String(mapString(item, 'coverUrl')).trim();
    if (cover !== '') {
      card.vod_pic = this.media.imgProxyURL(cover, xifuReferer);
    }
    if (total > 0) {
      card.vod_remarks = `共${total}集`;
    }
    return card;
  }

  async List(cat, page) {
    const items = await this.dramaList(String(cat ?? '').trim(), page);
    const cards = [];
    const seen = new Set();
    for (const it of items) {
      if (!it || typeof it !== 'object' || Array.isArray(it)) continue;
      const c = this.card(it, mapString(it, 'title'));
      if (!c || seen.has(c.vod_id)) continue;
      seen.add(c.vod_id);
      cards.push(c);
    }
    if (cards.length === 0) {
      throw new Error('喜福列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    throw new Error('喜福暂不支持搜索');
  }

  async Detail(id) {
    const tid = String(id ?? '').trim();
    if (tid === '') throw new Error('无效的喜福剧集 ID');
    for (const cid of ['', ...xifuCatIDs()]) {
      let items = null;
      try {
        items = await this.dramaList(cid, 1);
      } catch {
        continue;
      }
      for (const it of items) {
        if (!it || typeof it !== 'object' || Array.isArray(it)) continue;
        if (xifuAlbumID(it) !== tid) continue;
        let total = xifuTotal(it);
        const detail = {
          vod_id: tid,
          vod_name: String(mapString(it, 'title')).trim(),
          vod_pic: '',
          vod_content: '',
          vod_class: '喜福',
          episodes: [],
          episode_count: 0,
        };
        const cover = String(mapString(it, 'coverUrl')).trim();
        if (cover !== '') {
          detail.vod_pic = this.media.imgProxyURL(cover, xifuReferer);
        }
        if (total < 1) total = 1;
        for (let i = 1; i <= total; i++) {
          detail.episodes.push({ no: i, name: `第${i}集`, url: `xifu://${tid}/${i}` });
        }
        detail.episode_count = detail.episodes.length;
        if (detail.vod_name === '') {
          detail.vod_name = '喜福短剧 ' + tid;
        }
        return detail;
      }
    }

    const detail = {
      vod_id: tid,
      vod_name: '喜福短剧 ' + tid,
      vod_pic: '',
      vod_content: '',
      vod_class: '喜福',
      episodes: [{ no: 1, name: '第1集', url: `xifu://${tid}/1` }],
      episode_count: 1,
    };
    return detail;
  }

  async Play(playURL) {
    const parsed = parsePlayScheme(String(playURL ?? ''), 'xifu://');
    if (!parsed || parsed.id === '') {
      throw new Error('喜福播放参数无效');
    }
    const id = parsed.id;
    let seq = atoiDefault(parsed.extra, 1);
    if (seq < 1) seq = 1;
    const u = `${xifuHost}/web/v1/drama/play_auth?albumId=${queryEscape(id)}&seq=${seq}`;
    const data = await this.get(u);
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      throw new Error('喜福播放凭证获取失败');
    }
    const vid = String(data.vid ?? '');
    const playAuth = String(data.playAuth ?? '');
    if (vid === '' || playAuth === '') {
      throw new Error('喜福播放凭证获取失败');
    }
    const src = await xifuVodPlayURL(this.client, vid, playAuth);
    return { src, referer: xifuReferer, userAgent: xifuUA };
  }
}

async function xifuVodPlayURL(client, vid, playAuth) {
  let raw = null;
  try {
    raw = base64DecodeStrict(playAuth);
  } catch {
    throw new Error('喜福凭证解码失败');
  }
  let cred = null;
  try {
    cred = JSON.parse(raw.toString('utf8'));
  } catch {
    cred = null;
  }
  if (!cred || typeof cred !== 'object' || Array.isArray(cred) || String(cred.AccessKeyId ?? '') === '') {
    throw new Error('喜福凭证解析失败');
  }
  const accessKeyId = String(cred.AccessKeyId ?? '');
  const accessKeySecret = String(cred.AccessKeySecret ?? '');
  const securityToken = String(cred.SecurityToken ?? '');
  const authInfo = String(cred.AuthInfo ?? '');
  let region = String(cred.Region ?? '');
  if (region === '') region = 'cn-shanghai';

  const params = {
    Action: 'GetPlayInfo',
    Version: '2017-03-21',
    Format: 'JSON',
    AccessKeyId: accessKeyId,
    SecurityToken: securityToken,
    VideoId: vid,
    AuthInfo: authInfo,
    Timestamp: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
    SignatureMethod: 'HMAC-SHA1',
    SignatureVersion: '1.0',
    SignatureNonce: (BigInt(Date.now()) * 1000000n).toString(), 
  };
  if (cred.PlayConfig !== undefined && cred.PlayConfig !== null) {
    try {
      params.PlayConfig = JSON.stringify(cred.PlayConfig);
    } catch {
      
    }
  }
  const keys = Object.keys(params).sort();
  const canonical = keys.map((k) => `${xifuPercentEncode(k)}=${xifuPercentEncode(params[k])}`).join('&');
  const stringToSign = 'GET&%2F&' + xifuPercentEncode(canonical);
  const sig = crypto.createHmac('sha1', Buffer.from(accessKeySecret + '&', 'utf8'))
    .update(Buffer.from(stringToSign, 'utf8'))
    .digest('base64');
  const target = `https://vod.${region}.aliyuncs.com/?${canonical}&Signature=${xifuPercentEncode(sig)}`;

  let body = null;
  let status = 0;
  let terr = null;
  try {
    const resp = await client.fetchWithHeaders('GET', target, {
      'User-Agent': xifuUA,
      Accept: '*/*',
      Origin: xifuOrigin,
      Referer: xifuReferer,
    });
    body = resp.raw;
    status = resp.status;
  } catch (err) {
    terr = err;
  }
  if (terr) throw terr;
  if (status >= 400) {
    throw new Error(`喜福播放接口 HTTP ${status}`);
  }
  let res = null;
  try {
    res = JSON.parse(body.toString('utf8'));
  } catch {
    throw new Error('喜福播放响应解析失败');
  }
  const playInfo = res?.PlayInfoList?.PlayInfo;
  if (Array.isArray(playInfo)) {
    for (const info of playInfo) {
      const u2 = String(info?.PlayURL ?? '');
      if (isProviderHTTPMediaURL(u2)) {
        return u2;
      }
    }
  }
  throw new Error('喜福播放地址为空');
}

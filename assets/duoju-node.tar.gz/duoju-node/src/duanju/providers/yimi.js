
import { createSign } from 'node:crypto';
import { atoiDefault, cleanText, mapString, parsePlayScheme } from '../../core/util.js';
import { yimiAPIBase, yimiCommonQuery, yimiDetailSec, yimiListSec } from '../consts.js';
import { truncate } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { queryEscape } from './xingxing.js';

const yimiPrivateKeyPEM = `-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDwCPsMptVn80Im4VVfJ2uAkjs7NpJzzsyGxleK1uN9ux/KTiY2o8kiXcRIcAYVChfdX4ywUs0jrjh8iTcC91r6qgeBaDS8wWsL5bZrn7O/8sqq2hbizV4AvvsqhxVJzRUJZjbNOcMZOPJoeL5K4U4YsiOyV8a9lt5C6zEC4Qy0xjscvOTGyVTqtWeJedEedXtiKLQxAiy6OKJxyHQqdwMHUfAgAbLzAHcVpg1RSXwud+5vtTJNXOXT98FHoFDcRIEcHiiqfU9dskzAhG2nPbFujO+YFq9tZBrWmrhPaXcHfXZqtEYePM4vuvMYjhmANdG4Ehl6pN9nuEaLZ+L35/3nAgMBAAECggEBAOe+M+s2E2ll8WMqQEs6+s5J4Ee9201Vxh8E1TYlW8Ni60FdjAVKwgCc+Mla5nRfp0TCYElH1+hv5vdNXsBNYhgKGm701Z27O4dkA2gK6vcSCFtFbb0Qu4YK3OFlQ8dZ6cqGVbhz4Qmz8k2s7UPMHKM5Mb+YgTc/tlxzR4FZF/RaY8MDpv6iMcXPY27xJzZAV1jROCXjZTZNYbgjsKDAbthRDkjMyuKCIdq7rAHrEyFSx3n7/uxnZYh42bXzWyyWudbkAJoq1ZYx+NyYj5TsN/WNoYbCPcX0Ko+CNnpkC/6qtQbHrBiMprnld67qdLCVhWpmOBYukXVPwFMJjOFlYKkCgYEA+WDh3LpitYSO6hn7mhnbqEQba13cutbJW9RQa0BjGf1OGXdqXpimcWK7viZYAKhLlyGWQmoWduDq4bjSRx7ZxY8pMtpIUWoVkKItD7D2yvmYN1guHNRpHlUIAsSH3HGwQIeXy36hJcB5gC+3XgRVPz/juTMWJDC0usECNFz17bsCgYEA9miWi6JPnZ1ffQzAyE+P6vGC/Vrl7Uyr9gqxI/OkZa8bUqfZtGo5UDGSaGRUsoTsYiEJ8m5blPY0X4xr5x1kO6rfk0gHxn1OXlCP42yT2+CqQvjNO2DHOnWNryKjmAqaAITbmC2lgj0PiiPO32ZT3aXTOgwxTKbFP3LBDmwA18UCgYAQuEgsbmqz1OFoHLnbySQLEhXsiuyDsmbpu0BxEG4UjgEwf+sn0IBIVeBUjWmVEbOPvHbAmTBMZCQbYjLnBdCACGswt6Xln4E2o0j2Jl1Fmpp0C3t7/1nU6MqStO6O/yhcCztIL4NKbq82wvw+V3gHt5bjEePIJWPYqZwmOp1ahQKBgCqfHKs6gBr7RbETq6T6XiJ9c/Lu7iaFxJjicJGPazhLeaZqcjXKye8dI/36nMvkQh8XJ+lPPXgeviBo4aEwbE4F2HZZVz72HcAin0DvXwQBcHH1J0rGCrAJ9V/91d5OtySv1mwUOTS16yIx3260/HyyWj8ILN7dWfEHoG0mMV8hAoGBAI0KBzR9WfzxNKI4ZqRD9/sN+SH4oxymo2oJ+FnOW7hk1E0EyrsGzIDCrS/f7MPzLJI7F4DULsrU5RIQyouIybZra29Vqe4L8kdIae5O0R4Y2r7gt/yWo4cWnW53Q0f5o7mzV10Dc8ewuT1DyJrt25dMWsGsP8rQ/0pVUBLEf93b
-----END PRIVATE KEY-----`;

const yimiCats = [
  { id: 'jingxuan', name: '精选', key: 'channel_c6f50cd9' },
  { id: 'nixi', name: '逆袭', key: 'channel_a8e10abc' },
  { id: 'fuchou', name: '复仇', key: 'channel_d26dd434' },
  { id: 'lianai', name: '恋爱', key: 'channel_75afe84a' },
  { id: 'chongsheng', name: '重生', key: 'channel_2272aac5' },
  { id: 'gufeng', name: '古风', key: 'channel_73190d4f' },
  { id: 'shenyi', name: '神医', key: 'channel_2d7eae6b' },
  { id: 'yanqing', name: '言情', key: 'channel_614820bd' },
  { id: 'dushi', name: '都市', key: 'channel_13dfce8b' },
  { id: 'xuanyi', name: '悬疑', key: 'channel_861b9642' },
  { id: 'lishi', name: '历史', key: 'channel_18157927' },
];

export const platformCats = yimiCats.map((c) => ({ ID: c.id, Name: c.name }));

function yimiChannel(cat) {
  let hit = yimiCats[0];
  for (const c of yimiCats) {
    if (c.id === cat) {
      hit = c;
      break;
    }
  }
  return [hit.key, hit.name];
}

function yimiSign(query, path, timestamp, sec) {
  
  const message = `&${query}&${path}&${timestamp}&${sec}`;
  const s = createSign('RSA-SHA256');
  s.update(message);
  s.end();
  return s.sign(yimiPrivateKeyPEM, 'base64');
}

function yimiHeaders(query, path, sec) {
  const timestamp = Date.now();
  const sign = yimiSign(query, path, timestamp, sec);
  return {
    'x-appid': 'zy9351ae',
    'x-sig-timestamp': String(timestamp),
    'x-sig-alg': 'RSA-SHA256',
    'x-sig-sign': sign,
    'x-sig-ver': 'v1.1',
    'x-sig-sec': sec,
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 15; 22081212C Build/AQ3A.241006.001)',
  };
}

function yimiEpisodeOrder(ep, index) {
  const order = atoiDefault(mapString(ep, 'order'), 0);
  if (order > 0) return order;
  return index + 1;
}

function yimiFixPlayURL(raw) {
  raw = String(raw ?? '').trim();
  if (raw === '') return '';
  if (raw.includes('zhangyuecdn')) {
    const idx = raw.indexOf('com');
    if (idx >= 0) {
      return 'https://mother-t.d.ireader.com' + raw.slice(idx + 3);
    }
  }
  return raw;
}

export class YimiProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async call(path, query, sec) {
    const headers = yimiHeaders(query, path, sec);
    const { raw, status } = await this.client.fetchWithHeaders('GET', `${yimiAPIBase}${path}?${query}`, headers);
    if (status >= 400) {
      throw new Error(`薏米接口 HTTP ${status}`);
    }
    let envelope;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('薏米接口响应无法解析');
    }
    const body = envelope?.body;
    if (body === undefined || body === null) {
      throw new Error('薏米接口无数据');
    }
    return body;
  }

  card(item, catName) {
    const id = mapString(item, 'id');
    const title = cleanText(mapString(item, 'short_play_name'));
    if (id === '' || title === '') return null;
    const card = { vod_id: id, vod_name: title, vod_class: catName, vod_score: '', vod_content: '' };
    const cover = mapString(item, 'cover_url');
    if (cover !== '') card.vod_pic = this.media.imgProxyURL(cover, `${yimiAPIBase}/`);
    const favor = mapString(item, 'favor_count_format');
    if (favor !== '') card.vod_remarks = '热度值:' + favor;
    return card;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    const [key, display] = yimiChannel(cat);
    const path = '/bookstore/local/visual/channel/list';
    const query = `key=${queryEscape(key)}&${yimiCommonQuery}&page=${page}&pc=10&usr=tj1290623468&zyeid=4fc4c6737a87b603e1b8ce9210032bae`;
    const body = await this.call(path, query, yimiListSec);
    const list = body?.list;
    if (!Array.isArray(list)) {
      throw new Error('薏米列表解析失败');
    }
    const items = list.length > 0 && Array.isArray(list[0].short_plays) ? list[0].short_plays : [];
    if (page > 1 && items.length === 0) {
      return [];
    }
    const cards = [];
    const seen = new Set();
    for (const item of items) {
      const card = this.card(item, display);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('薏米列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    throw new Error('薏米接口未提供搜索');
  }

  async fetchAllEpisodes(playID) {
    const path = '/video/client/short_play/episode_list';
    const pageSize = 30;
    let start = 1;
    let total = 999999;
    let name = '';
    let intro = '';
    const episodes = [];
    while (start <= total) {
      const end = start + pageSize - 1;
      const query = `end_id=${end}&${yimiCommonQuery}&pc=10&play_id=${queryEscape(playID)}&start_id=${start}&usr=tj1290623468&zyeid=4fc4c6737a87b603e1b8ce9210032bae`;
      const body = await this.call(path, query, yimiDetailSec);
      let node;
      try {
        node = JSON.parse(JSON.stringify(body));
      } catch {
        throw new Error('薏米详情解析失败');
      }
      if (!node || typeof node !== 'object' || Array.isArray(node)) {
        throw new Error('薏米详情解析失败');
      }
      if (start === 1) {
        name = String(node.name ?? '');
        intro = String(node.introduce ?? '');
        const targetCount = Number(node.target_count ?? 0);
        if (Number.isFinite(targetCount) && targetCount > 0) {
          total = targetCount;
        }
      }
      const list = node.episode_list;
      if (!Array.isArray(list) || list.length === 0) {
        break;
      }
      episodes.push(...list);
      start += pageSize;
    }
    if (episodes.length === 0) {
      throw new Error('薏米详情无剧集: ' + playID);
    }
    return [name, intro, episodes];
  }

  async Detail(id) {
    id = String(id || '').trim();
    if (id === '') {
      throw new Error('无效的薏米剧集 ID');
    }
    const [name, intro, episodes] = await this.fetchAllEpisodes(id);
    const detail = {
      vod_id: id,
      vod_name: cleanText(name),
      vod_content: truncate(cleanText(intro), 400),
      vod_class: '薏米',
      vod_pic: '',
      episodes: [],
      episode_count: 0,
    };
    const seen = new Set();
    for (let i = 0; i < episodes.length; i++) {
      const ep = episodes[i];
      const order = yimiEpisodeOrder(ep, i);
      if (seen.has(order)) continue;
      seen.add(order);
      detail.episodes.push({ no: order, name: `第${order}集`, url: `yimi://${id}/${order}` });
    }
    detail.episodes.sort((a, b) => a.no - b.no);
    detail.episode_count = detail.episodes.length;
    if (detail.episodes.length === 0) {
      throw new Error('薏米详情无剧集: ' + id);
    }
    if (detail.vod_name === '') {
      detail.vod_name = '薏米短剧 ' + id;
    }
    return detail;
  }

  async Play(playURL) {
    const scheme = parsePlayScheme(playURL, 'yimi://');
    if (!scheme || scheme.id === '') {
      throw new Error('薏米播放参数无效');
    }
    const id = scheme.id;
    let order = atoiDefault(scheme.extra, 1);
    if (order < 1) order = 1;
    const [, , episodes] = await this.fetchAllEpisodes(id);
    for (let i = 0; i < episodes.length; i++) {
      const ep = episodes[i];
      if (yimiEpisodeOrder(ep, i) !== order) continue;
      const src = yimiFixPlayURL(mapString(ep, 'play_url', 'playUrl'));
      if (!isProviderHTTPMediaURL(src)) {
        throw new Error(`薏米第${order}集暂无播放地址`);
      }
      return { src, referer: `${yimiAPIBase}/` };
    }
    throw new Error(`薏米详情缺第${order}集`);
  }
}

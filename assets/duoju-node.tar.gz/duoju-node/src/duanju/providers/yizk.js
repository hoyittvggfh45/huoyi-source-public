
import { atoiDefault, cleanText, parsePlayScheme } from '../../core/util.js';
import { yizkEntryHosts, yizkLandingHosts, yizkSiteBase } from '../consts.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { isNonImageAsset } from './provider_utils.js';
import { httpStatusSwitch, noSwitch } from './heiliao.js';
import { queryEscape } from './xingxing.js';

const yizkUA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36';
const yizkPageSize = 24;
const yizkMaxPages = 100;
const yizkMaxEps = 999;

const yizkCats = [
  { ID: 'all', Name: '全部' },
  { ID: 'sqqsfvqirt0c', Name: '华语' },
  { ID: 'jr4jltgb5bct', Name: '东瀛' },
  { ID: '967tfsdaht5i', Name: '欧美' },
  { ID: 'ovamj5o7x0gs', Name: '三级' },
  { ID: 'fs7hmy32jqfm', Name: 'Ai短剧' },
];

export const platformCats = yizkCats.map((c) => ({ ID: c.ID, Name: c.Name }));

function trimSuffix(s, suffix) {
  return s.endsWith(suffix) ? s.slice(0, -suffix.length) : s;
}

function pathEscape(s) {
  return encodeURIComponent(String(s ?? '')).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
}


function mirrorSwitchable(err) {
  return !!err && !err.noSwitch;
}

const MIRROR_TTL_MS = 10 * 60 * 1000; 
const PROBE_TIMEOUT_MS = 14 * 1000;   

function probeWithTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('探活超时')), ms);
    promise.then(
      (value) => { clearTimeout(timer); resolve(value); },
      (err) => { clearTimeout(timer); reject(err); },
    );
  });
}


class MirrorPool {
  constructor(name, hosts, probe) {
    this.name = name;
    this.hosts = hosts || [];
    this.probe = probe;
    this.ttl = MIRROR_TTL_MS;
    this.best = this.hosts.length > 0 ? this.hosts[0] : '';
    this.at = 0; 
  }

  current() {
    if (this.best !== '') return this.best;
    if (this.hosts.length > 0) return this.hosts[0];
    return '';
  }

  order() {
    const out = [];
    if (this.best !== '') out.push(this.best);
    for (const host of this.hosts) {
      if (host !== this.best) out.push(host);
    }
    return out;
  }

  favorite(host) {
    if (host === '') return;
    if (this.best !== host) this.best = host;
    this.at = Date.now();
  }

  invalidate() {
    this.at = 0;
  }

  async ensure() {
    const fresh = this.best !== '' && Date.now() - this.at < this.ttl;
    if (fresh || !this.probe || this.hosts.length === 0) return;
    const outcomes = await Promise.all(this.hosts.map(async (host) => {
      try {
        await probeWithTimeout(Promise.resolve().then(() => this.probe(host)), PROBE_TIMEOUT_MS);
        return { host, err: null };
      } catch (err) {
        return { host, err: err instanceof Error ? err : new Error(String(err)) };
      }
    }));
    let first = null;
    for (const got of outcomes) {
      if (got.err === null) {
        this.favorite(got.host);
        return;
      }
      if (first === null) first = got.err;
    }
    throw first;
  }

  async run(fn) {
    if (this.hosts.length === 0) throw new Error('镜像池为空');
    try {
      await this.ensure();
    } catch {
      
    }
    let last = null;
    for (const host of this.order()) {
      try {
        const value = await fn(host);
        this.favorite(host);
        return value;
      } catch (err) {
        last = err;
        if (!mirrorSwitchable(err)) break;
      }
    }
    this.invalidate();
    if (last === null) last = new Error(this.name + ' 无可用镜像');
    throw last;
  }
}

function yizkHostList() {
  const out = [];
  for (const part of String(yizkLandingHosts).split(',')) {
    let host = part.trim();
    if (host === '') continue;
    if (!host.startsWith('http://') && !host.startsWith('https://')) {
      host = 'https://' + host;
    }
    out.push(trimSuffix(host, '/'));
  }
  return out;
}

function yizkPic(raw) {
  raw = String(raw ?? '').trim();
  if (raw === '') return '';
  const low = raw.toLowerCase();
  if (low.startsWith('data:') || isNonImageAsset(low)) {
    return '';
  }
  return raw;
}

function yizkCard(f) {
  const card = {
    vod_id: String(f?.token ?? ''),
    vod_name: cleanText(f?.title),
    vod_pic: yizkPic(f?.cover_url),
    vod_remarks: '',
    vod_class: '',
  };
  let count = Number(f?.episode_count);
  if (!Number.isFinite(count)) count = 0;
  if (count > 1) card.vod_remarks = `共${count}集`;
  const catName = f?.category?.name;
  if (catName) card.vod_class = cleanText(catName);
  return card;
}

function yizkCards(data) {
  const cards = [];
  const seen = new Set();
  const list = Array.isArray(data?.list) ? data.list : [];
  for (const f of list) {
    const token = String(f?.token ?? '');
    if (token === '' || seen.has(token)) continue;
    seen.add(token);
    cards.push(yizkCard(f));
  }
  return cards;
}

export class YizkProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
    let hosts = yizkHostList();
    if (hosts.length === 0) hosts = [yizkSiteBase];
    this.mirror = new MirrorPool('一直看', hosts, (host) => this.probe(host));
  }

  async probe(host) {
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders('GET', host + '/api/v1/system/public', {
        'User-Agent': yizkUA,
        Accept: 'application/json',
        Referer: host + '/',
      });
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    const err = httpStatusSwitch(status, terr);
    if (err) throw err;
    let resp = null;
    try {
      resp = JSON.parse(raw.toString('utf8'));
    } catch {
      resp = null;
    }
    if (!resp || typeof resp !== 'object' || Array.isArray(resp) || resp.code !== 0) {
      throw new Error('一直看镜像探活失败: ' + host);
    }
  }

  
  async api(method, path, payload, out) {
    const call = async (mirror) => mirror.run(async (host) => {
      const headers = {
        'User-Agent': yizkUA,
        Accept: 'application/json',
        Referer: host + '/',
      };
      if (payload != null) headers['Content-Type'] = 'application/json';
      let raw = null;
      let status = 0;
      let terr = null;
      try {
        const resp = await this.client.fetchWithHeaders(method, host + path, headers, payload);
        raw = resp.raw;
        status = resp.status;
      } catch (err) {
        terr = err;
      }
      const serr = httpStatusSwitch(status, terr);
      if (serr) throw serr;
      let envelope = null;
      try {
        envelope = JSON.parse(raw.toString('utf8'));
      } catch {
        throw new Error('一直看响应解析失败: ' + path);
      }
      if (envelope === null || envelope === undefined) return null; 
      if (typeof envelope !== 'object' || Array.isArray(envelope)) {
        throw new Error('一直看响应解析失败: ' + path);
      }
      const code = envelope.code === undefined || envelope.code === null ? 0 : Number(envelope.code);
      if (!Number.isFinite(code)) throw new Error('一直看响应解析失败: ' + path);
      if (code !== 0) {
        throw noSwitch(new Error(`一直看接口错误(${code}): ${envelope.message ?? ''}`));
      }
      if (out == null) return null;
      const data = envelope.data;
      if (data === undefined || data === null) return null;
      if (Array.isArray(out)) {
        if (!Array.isArray(data)) throw new Error('一直看数据解析失败: ' + path);
        return data;
      }
      if (typeof data !== 'object' || Array.isArray(data)) {
        throw new Error('一直看数据解析失败: ' + path);
      }
      return data;
    });
    let firstErr = null;
    try {
      return await call(this.mirror);
    } catch (err) {
      firstErr = err;
    }
    if (!mirrorSwitchable(firstErr)) throw firstErr;
    let hosts = null;
    try {
      hosts = await this.refreshHosts();
    } catch {
      hosts = null;
    }
    if (!hosts || hosts.length === 0) throw firstErr;
    this.mirror = new MirrorPool('一直看', hosts, (host) => this.probe(host));
    return await call(this.mirror);
  }

  async refreshHosts() {
    for (const entryRaw of String(yizkEntryHosts).split(',')) {
      const entry = entryRaw.trim();
      if (entry === '') continue;
      const base = 'https://' + trimSuffix(entry, '/');
      let raw = null;
      let status = 0;
      try {
        const resp = await this.client.fetchWithHeaders('GET', base + '/api/router/list', {
          'User-Agent': yizkUA,
          Referer: base + '/',
        });
        raw = resp.raw;
        status = resp.status;
      } catch {
        continue;
      }
      if (status >= 400 || !raw || raw.length === 0) continue;
      let resp = null;
      try {
        resp = JSON.parse(raw.toString('utf8'));
      } catch {
        continue;
      }
      const routes = resp?.data?.routes;
      if (!Array.isArray(routes)) continue;
      const hosts = [];
      for (const r of routes) {
        const d = String(r?.domain ?? '').trim();
        if (d === '') continue;
        hosts.push('https://' + trimSuffix(d, '/'));
      }
      if (hosts.length > 0) return hosts;
    }
    throw new Error('一直看线路列表拉取失败');
  }

  currentHost() {
    return this.mirror.current();
  }

  async List(cat, page) {
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    if (p > yizkMaxPages) return [];
    let path = '/api/v1/films';
    const c = String(cat ?? '').trim();
    if (c !== '' && c !== 'all') {
      path = '/api/v1/categories/' + pathEscape(c) + '/films';
    }
    path += `?page=${p}&pageSize=${yizkPageSize}`;
    const data = await this.api('GET', path, null, {});
    const cards = yizkCards(data);
    if (cards.length === 0 && p === 1) {
      throw new Error('一直看列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    const kw = String(wd ?? '').trim();
    if (kw === '') throw new Error('一直看搜索关键词为空');
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    const path = `/api/v1/films?keyword=${queryEscape(kw)}&page=${p}&pageSize=${yizkPageSize}`;
    const data = await this.api('GET', path, null, {});
    const cards = yizkCards(data);
    if (cards.length === 0) {
      throw new Error('一直看搜索无结果');
    }
    return cards;
  }

  async Detail(id) {
    let tid = String(id ?? '').trim();
    const cut = tid.search(/[/?#]/);
    if (cut >= 0) tid = tid.slice(0, cut);
    if (tid === '') throw new Error('无效的一直看剧集 ID');
    let f = await this.api('GET', '/api/v1/films/' + pathEscape(tid), null, {});
    if (!f || typeof f !== 'object') f = {};
    let token = String(f.token ?? '');
    if (token === '') token = tid;
    const detail = {
      vod_id: token,
      vod_name: cleanText(f.title),
      vod_pic: yizkPic(f.cover_url),
      vod_content: cleanText(f.description),
      vod_class: '',
      episodes: [],
      episode_count: 0,
    };
    const catName = f.category?.name;
    if (catName) detail.vod_class = cleanText(catName);
    let count = Number(f.episode_count);
    if (!Number.isFinite(count)) count = 0;
    if (count < 1) count = 1;
    if (count > yizkMaxEps) count = yizkMaxEps;
    count = Math.trunc(count);
    for (let n = 1; n <= count; n++) {
      detail.episodes.push({ no: n, name: `第${n}集`, url: `yizk://${token}/${n}` });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') {
      detail.vod_name = '一直看 ' + token;
    }
    return detail;
  }

  async Play(playURL) {
    const raw = String(playURL ?? '');
    const parsed = parsePlayScheme(raw, 'yizk://');
    let id = parsed ? parsed.id : '';
    let extra = parsed ? parsed.extra : '';
    let ok = parsed !== null;
    if (!ok) {
      const i = raw.indexOf('/film/');
      if (i >= 0) {
        id = raw.slice(i);
        if (id.startsWith('/film/')) id = id.slice('/film/'.length);
        const j = id.search(/[/?#]/);
        if (j >= 0) id = id.slice(0, j);
        ok = id !== '';
      }
    }
    id = String(id ?? '').trim();
    if (!ok || id === '') {
      throw new Error('一直看播放参数无效');
    }
    let episode = atoiDefault(extra, 1);
    if (episode < 1) episode = 1;
    const payload = JSON.stringify({ episode, source: 'direct' });
    const data = await this.api('POST', '/api/v1/films/' + pathEscape(id) + '/play', payload, {});
    const media = String(data?.playUrl ?? '').trim();
    if (media === '') {
      throw new Error('一直看拿不到播放地址');
    }
    
    const mediaAbs = media.startsWith('/') ? this.currentHost() + media : media;
    if (!isProviderHTTPMediaURL(mediaAbs)) {
      throw new Error('一直看播放地址无效');
    }
    return { src: mediaAbs, referer: this.currentHost() + '/' };
  }

  async categories() {
    const list = await this.api('GET', '/api/v1/categories', null, []);
    const cats = [{ ID: 'all', Name: '全部' }];
    const seen = new Set(['all']);
    for (const c of Array.isArray(list) ? list : []) {
      const token = String(c?.token ?? '');
      const name = String(c?.name ?? '');
      let parentID = 0;
      if (c?.parent_id !== undefined && c?.parent_id !== null) parentID = Number(c.parent_id);
      if (!Number.isFinite(parentID)) parentID = 0;
      if (token === '' || name === '' || parentID !== 0 || seen.has(token)) continue;
      seen.add(token);
      cats.push({ ID: token, Name: cleanText(name) });
    }
    return cats;
  }
}

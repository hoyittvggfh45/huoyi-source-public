
import { anyList, atoiDefault, cleanText, mapString, parsePlayScheme } from '../../core/util.js';
import { xingyaDevToken, xingyaDeviceID, xingyaLoginBody, xingyaLoginURL, xingyaSiteBase } from '../consts.js';
import { truncate } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { queryEscape } from './xingxing.js';

const xingyaUUID = 'randomUUID_914e7a9b-deac-4f80-9247-db56669187df';
const xingyaUserAgent = 'Mozilla/5.0 (Linux; Android 9; RMX1931 Build/PQ3A.190605.05081124; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Mobile Safari/537.36';

const xingyaCats = [
  { id: 'juchang', name: '剧场' },
  { id: 'reboduanju', name: '热播剧' },
  { id: 'huiyuan', name: '会员专享' },
  { id: 'xingxuan', name: '星选好剧' },
  { id: 'xinju', name: '新剧' },
  { id: 'yangguang', name: '阳光剧场' },
];

export const platformCats = xingyaCats.map((c) => ({ ID: c.id, Name: c.name }));

const xingyaClassIDs = {
  juchang: '1',
  reboduanju: '2',
  huiyuan: '8',
  xingxuan: '7',
  xinju: '3',
  yangguang: '5',
};

function xingyaLoginHeaders() {
  return {
    'User-Agent': 'okhttp/4.10.0',
    'Content-Type': 'application/x-www-form-urlencoded',
    'x-app-id': '7',
    platform: '1',
    version_name: '3.3.1',
    app_version: '3.3.1',
    device_platform: 'android',
    device_id: xingyaDeviceID,
    device_type: 'RMX1931',
    device_brand: 'realme',
    os_version: '9',
    channel: 'default',
    uuid: xingyaUUID,
  };
}

function xingyaClassID(cat) {
  const value = xingyaClassIDs[String(cat || '').trim()];
  return value !== undefined ? value : xingyaClassIDs.juchang;
}

function xingyaCatName(cat) {
  cat = String(cat || '').trim();
  for (const item of xingyaCats) {
    if (item.id === cat) return item.name;
  }
  return xingyaCats[0].name;
}

export class XingyaProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
    this.headers = null;
    this.headersPromise = null;
  }

  async login() {
    const { raw, status } = await this.client.fetchWithHeaders('POST', xingyaLoginURL, xingyaLoginHeaders(), xingyaLoginBody);
    if (status >= 400) {
      throw new Error(`星芽登录 HTTP ${status}`);
    }
    let token = '';
    try {
      const envelope = JSON.parse(raw.toString('utf8'));
      token = String(envelope?.data?.token ?? '').trim();
    } catch {}
    if (token === '') {
      throw new Error('星芽登录失败: 未取到 token');
    }
    const headers = xingyaLoginHeaders();
    headers.authorization = token;
    headers.dev_token = xingyaDevToken;
    headers.user_agent = xingyaUserAgent;
    headers.support_h265 = '1';
    return headers;
  }

  async ensureHeaders() {
    if (this.headers) return this.headers;
    if (!this.headersPromise) {
      this.headersPromise = this.login()
        .then((headers) => {
          this.headers = headers;
          this.headersPromise = null;
          return headers;
        })
        .catch((err) => {
          this.headersPromise = null;
          throw err;
        });
    }
    return this.headersPromise;
  }

  async call(method, target, body) {
    const headers = await this.ensureHeaders();
    const { raw, status } = await this.client.fetchWithHeaders(method, target, headers, body);
    if (status >= 400) {
      throw new Error(`星芽接口 HTTP ${status}`);
    }
    return JSON.parse(raw.toString('utf8'));
  }

  async getData(target) {
    const raw = await this.call('GET', target, null);
    const data = raw?.data;
    if (data === undefined || data === null) {
      throw new Error('星芽接口无数据');
    }
    return data;
  }

  async listItems(cat, page) {
    if (page < 1) page = 1;
    const target = `${xingyaSiteBase}/cloud/v2/theater/home_page?theater_class_id=${xingyaClassID(cat)}&type=1&class2_ids=0&page_num=${page}&page_size=24`;
    const data = await this.getData(target);
    const list = data?.list;
    if (!Array.isArray(list)) {
      throw new Error('星芽列表解析失败');
    }
    const items = [];
    for (const entry of list) {
      const theater = entry?.theater;
      if (theater !== undefined && theater !== null) items.push(theater);
    }
    return items;
  }

  card(item, catName) {
    const id = mapString(item, 'id');
    const title = cleanText(mapString(item, 'title'));
    if (id === '' || title === '') return null;
    const card = { vod_id: id, vod_name: title, vod_class: catName, vod_score: '', vod_content: '' };
    const cover = mapString(item, 'cover_url');
    if (cover !== '') card.vod_pic = this.media.imgProxyURL(cover, `${xingyaSiteBase}/`);
    const total = atoiDefault(mapString(item, 'total'), 0);
    if (total > 0) card.vod_remarks = `共${total}集`;
    return card;
  }

  async List(cat, page) {
    const items = await this.listItems(cat, page);
    if (page > 1 && items.length === 0) {
      return [];
    }
    const catName = xingyaCatName(cat);
    const cards = [];
    const seen = new Set();
    for (const item of items) {
      const card = this.card(item, catName);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('星芽列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    wd = String(wd || '').trim();
    if (wd === '') {
      throw new Error('星芽搜索关键词为空');
    }
    const headers = { ...(await this.ensureHeaders()) };
    headers['Content-Type'] = 'application/json';
    const body = Buffer.from(JSON.stringify({ text: wd }), 'utf8');
    const { raw, status } = await this.client.fetchWithHeaders('POST', `${xingyaSiteBase}/v3/search`, headers, body);
    if (status >= 400) {
      throw new Error(`星芽搜索 HTTP ${status}`);
    }
    let envelope;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('星芽搜索解析失败');
    }
    const searchData = envelope?.data?.theater?.search_data;
    const cards = [];
    const seen = new Set();
    for (const item of Array.isArray(searchData) ? searchData : []) {
      const card = this.card(item, '搜索');
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('星芽搜索无结果: ' + wd);
    }
    return cards;
  }

  async detail(id) {
    id = String(id || '').trim();
    if (id === '') {
      throw new Error('无效的星芽剧集 ID');
    }
    const target = `${xingyaSiteBase}/v2/theater_parent/detail?theater_parent_id=${queryEscape(id)}`;
    const data = await this.getData(target);
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      throw new Error('星芽详情解析失败');
    }
    return data;
  }

  async Detail(id) {
    id = String(id || '').trim();
    if (id === '') {
      throw new Error('无效的星芽剧集 ID');
    }
    const data = await this.detail(id);
    const theaters = anyList(data.theaters);
    if (theaters.length === 0) {
      throw new Error('星芽详情无剧集: ' + id);
    }
    const detail = {
      vod_id: id,
      vod_name: cleanText(mapString(data, 'title')),
      vod_content: truncate(cleanText(mapString(data, 'introduction')), 400),
      vod_class: '星芽',
      vod_pic: '',
      episodes: [],
      episode_count: 0,
    };
    const cover = mapString(data, 'cover_url');
    if (cover !== '') detail.vod_pic = this.media.imgProxyURL(cover, `${xingyaSiteBase}/`);
    const seen = new Set();
    for (let i = 0; i < theaters.length; i++) {
      const entry = theaters[i];
      if (!entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
      let no = atoiDefault(mapString(entry, 'num'), 0);
      if (no < 1) no = i + 1;
      if (seen.has(no)) continue;
      seen.add(no);
      let name = cleanText(mapString(entry, 'son_title'));
      if (name === '') name = `第${no}集`;
      detail.episodes.push({ no, name, url: `xingya://${id}/${no}` });
    }
    detail.episodes.sort((a, b) => a.no - b.no);
    detail.episode_count = detail.episodes.length;
    if (detail.episodes.length === 0) {
      throw new Error('星芽详情无剧集: ' + id);
    }
    if (detail.vod_name === '') {
      detail.vod_name = '星芽短剧 ' + id;
    }
    return detail;
  }

  async Play(playURL) {
    const scheme = parsePlayScheme(playURL, 'xingya://');
    if (!scheme || scheme.id === '') {
      throw new Error('星芽播放参数无效');
    }
    const id = scheme.id;
    const seq = atoiDefault(scheme.extra, 0);
    if (seq < 1) {
      throw new Error('星芽播放集号无效');
    }
    const data = await this.detail(id);
    for (const raw of anyList(data.theaters)) {
      const entry = raw;
      if (!entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
      if (atoiDefault(mapString(entry, 'num'), 0) !== seq) continue;
      const src = mapString(entry, 'son_video_url');
      if (!isProviderHTTPMediaURL(src)) {
        throw new Error(`星芽第${seq}集暂无播放地址`);
      }
      return { src, referer: `${xingyaSiteBase}/` };
    }
    throw new Error(`星芽详情缺第${seq}集`);
  }
}

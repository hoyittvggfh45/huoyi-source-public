
import { atoiDefault, cleanText, mapString, parsePlayScheme } from '../../core/util.js';
import { xifanAPIBase } from '../consts.js';
import { truncate } from '../shared.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { queryEscape } from './xingxing.js';

const xifanCats = [
  { id: 'all', name: '全部', area: '68@都市' },
  { id: 'dushi', name: '都市', area: '68@都市' },
  { id: 'qingchun', name: '青春', area: '68@青春' },
  { id: 'xiandaiyanqing', name: '现代言情', area: '81@现代言情' },
  { id: 'haomen', name: '豪门', area: '81@豪门' },
  { id: 'danvzhu', name: '大女主', area: '80@大女主' },
  { id: 'nixi', name: '逆袭', area: '79@逆袭' },
  { id: 'dalianuecha', name: '打脸虐渣', area: '79@打脸虐渣' },
  { id: 'chuanyue', name: '穿越', area: '81@穿越' },
];

export const platformCats = xifanCats.map((c) => ({ ID: c.id, Name: c.name }));

function xifanArea(cat) {
  let hit = xifanCats[0];
  for (const c of xifanCats) {
    if (c.id === cat) {
      hit = c;
      break;
    }
  }
  const parts = hit.area.split('@');
  const catID = parts[0];
  let catName = hit.name;
  if (parts.length > 1) catName = parts[1];
  return [catID, catName, hit.name];
}

function splitXifanID(id) {
  const parts = String(id || '').split('@');
  if (parts.length < 2) return [parts[0], ''];
  return [parts[0], parts[1]];
}

export class XifanProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async call(path) {
    const headers = {
      Accept: 'application/json, text/plain, */*',
      'User-Agent': 'okhttp/4.10.0',
    };
    const { raw, status } = await this.client.fetchWithHeaders('GET', xifanAPIBase + path, headers);
    if (status >= 400) {
      throw new Error(`西饭接口 HTTP ${status}`);
    }
    let envelope;
    try {
      envelope = JSON.parse(raw.toString('utf8'));
    } catch {
      throw new Error('西饭接口响应无法解析');
    }
    const result = envelope?.result;
    if (result === undefined || result === null) {
      const message = envelope?.message ?? '';
      if (message !== '') {
        throw new Error(`西饭接口返回错误: ${message}`);
      }
      throw new Error('西饭接口无数据');
    }
    return result;
  }

  card(dj, catName) {
    const id = mapString(dj, 'duanjuId', 'duanjuID');
    const title = cleanText(mapString(dj, 'title'));
    if (id === '' || title === '') return null;
    let key = id;
    const source = mapString(dj, 'source');
    if (source !== '') key = `${id}@${source}`;
    const card = { vod_id: key, vod_name: title, vod_class: catName, vod_score: '', vod_content: '' };
    const cover = mapString(dj, 'coverImageUrl');
    if (cover !== '') card.vod_pic = this.media.imgProxyURL(cover, `${xifanAPIBase}/`);
    const n = atoiDefault(mapString(dj, 'total'), 0);
    if (n > 0) card.vod_remarks = `共${n}集`;
    return card;
  }

  async listItems(cat, page) {
    if (page < 1) page = 1;
    const [catID, catName] = xifanArea(cat);
    const path = `/xifan/drama/portalPage?reqType=aggregationPage&offset=${(page - 1) * 30}&categoryId=${queryEscape(catID)}&categoryNames=${queryEscape(catName)}&pageID=page_theater&appId=drama`;
    const result = await this.call(path);
    const node = result?.elements;
    if (!Array.isArray(node)) {
      throw new Error('西饭列表解析失败');
    }
    const items = [];
    for (const element of node) {
      const contents = element?.contents;
      if (!Array.isArray(contents)) continue;
      for (const content of contents) {
        const vo = content?.duanjuVo;
        if (vo && typeof vo === 'object' && Object.keys(vo).length > 0) {
          items.push(vo);
        }
      }
    }
    return items;
  }

  async List(cat, page) {
    const [, , display] = xifanArea(cat);
    const items = await this.listItems(cat, page);
    if (page > 1 && items.length === 0) {
      return [];
    }
    const cards = [];
    const seen = new Set();
    for (const item of items) {
      const card = this.card(item, display);
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('西饭列表无内容');
    }
    return cards;
  }

  async Search(wd, page) {
    wd = String(wd || '').trim();
    if (wd === '') {
      throw new Error('西饭搜索关键词为空');
    }
    if (page < 1) page = 1;
    const path = `/xifan/search/getSearchList?reqType=search&offset=${(page - 1) * 30}&keyword=${queryEscape(wd)}&requestId=${Date.now()}aa498144140ef297&appId=drama`;
    const result = await this.call(path);
    const node = result?.elements;
    if (!Array.isArray(node)) {
      throw new Error('西饭搜索解析失败');
    }
    const cards = [];
    const seen = new Set();
    for (const element of node) {
      const card = this.card(element?.duanjuVo, '西饭');
      if (!card || seen.has(card.vod_id)) continue;
      seen.add(card.vod_id);
      cards.push(card);
    }
    if (cards.length === 0) {
      throw new Error('西饭搜索无结果: ' + wd);
    }
    return cards;
  }

  async detail(id, source) {
    const path = `/xifan/drama/getDuanjuInfo?duanjuId=${queryEscape(id)}&source=${queryEscape(source)}&appId=drama`;
    const result = await this.call(path);
    if (!result || typeof result !== 'object' || Array.isArray(result) || Object.keys(result).length === 0) {
      throw new Error('西饭详情解析失败');
    }
    return result;
  }

  async Detail(id) {
    id = String(id || '').trim();
    if (id === '') {
      throw new Error('无效的西饭剧集 ID');
    }
    const [duanjuID, source] = splitXifanID(id);
    const node = await this.detail(duanjuID, source);
    const detail = {
      vod_id: id,
      vod_name: cleanText(mapString(node, 'title')),
      vod_content: truncate(cleanText(mapString(node, 'desc', 'description')), 400),
      vod_pic: '',
      vod_class: '西饭',
      episodes: [],
      episode_count: 0,
    };
    const cover = mapString(node, 'coverImageUrl');
    if (cover !== '') detail.vod_pic = this.media.imgProxyURL(cover, `${xifanAPIBase}/`);
    const episodes = Array.isArray(node.episodeList) ? node.episodeList : [];
    const seen = new Set();
    for (let i = 0; i < episodes.length; i++) {
      const ep = episodes[i];
      if (!ep || typeof ep !== 'object') continue;
      let order = atoiDefault(mapString(ep, 'index'), 0);
      if (order < 1) order = i + 1;
      if (seen.has(order)) continue;
      seen.add(order);
      detail.episodes.push({ no: order, name: `第${order}集`, url: `xifan://${id}/${order}` });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.episodes.length === 0) {
      throw new Error('西饭详情无剧集: ' + id);
    }
    if (detail.vod_name === '') {
      detail.vod_name = '西饭短剧 ' + id;
    }
    return detail;
  }

  async Play(playURL) {
    const scheme = parsePlayScheme(playURL, 'xifan://');
    if (!scheme || scheme.id === '') {
      throw new Error('西饭播放参数无效');
    }
    const id = scheme.id;
    let seq = atoiDefault(scheme.extra, 1);
    if (seq < 1) seq = 1;
    const [duanjuID, source] = splitXifanID(id);
    const node = await this.detail(duanjuID, source);
    const episodes = Array.isArray(node.episodeList) ? node.episodeList : [];
    for (let i = 0; i < episodes.length; i++) {
      const ep = episodes[i];
      if (!ep || typeof ep !== 'object') continue;
      let order = atoiDefault(mapString(ep, 'index'), 0);
      if (order < 1) order = i + 1;
      if (order !== seq) continue;
      const src = mapString(ep, 'playUrl');
      if (!isProviderHTTPMediaURL(src)) {
        throw new Error(`西饭第${seq}集暂无播放地址`);
      }
      return { src, referer: `${xifanAPIBase}/` };
    }
    throw new Error(`西饭详情缺第${seq}集`);
  }
}

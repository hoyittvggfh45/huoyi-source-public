
import crypto from 'node:crypto';
import { atoiDefault, cleanText, parsePlayScheme } from '../../core/util.js';
import { soujuSiteBase, soujuSignKey } from '../consts.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';

const soujuUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
const soujuClientName = 'movie-search-frontend';
const soujuClientVer = '1.0.0';
const soujuBuildVer = 'aimovie-v2026.09.28.4-f41bc3c82d76-web';
const soujuProtoVer = '2026-07-05.library-v2.playback-v1';
const soujuPageSize = 24;
const soujuMaxPages = 20;
const soujuEpLimit = 100;
const soujuEpCacheMax = 240;

const soujuCats = [
  { ID: 'all', Name: '全部' },
  { ID: '脑洞悬疑', Name: '脑洞悬疑' },
  { ID: '古装仙侠', Name: '古装仙侠' },
  { ID: '现代都市', Name: '现代都市' },
  { ID: '女频恋爱', Name: '女频恋爱' },
  { ID: '言情总裁', Name: '言情总裁' },
  { ID: '年代穿越', Name: '年代穿越' },
  { ID: '现代言情', Name: '现代言情' },
  { ID: '反转爽剧', Name: '反转爽剧' },
  { ID: '重生民国', Name: '重生民国' },
];

export const platformCats = soujuCats.map((c) => ({ ID: c.ID, Name: c.Name }));

function pathEscape(s) {
  return encodeURIComponent(String(s ?? '')).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
}


function encodeQueryGo(obj) {
  return Object.keys(obj)
    .sort()
    .map((k) => `${queryEscapeStr(k)}=${queryEscapeStr(obj[k])}`)
    .join('&');
}

function queryEscapeStr(s) {
  return encodeURIComponent(String(s ?? ''))
    .replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`)
    .replace(/%20/g, '+');
}

function soujuNonce() {
  try {
    return crypto.randomBytes(16).toString('hex');
  } catch {
    return (BigInt(Date.now()) * 1000000n).toString(16).padStart(32, '0');
  }
}

function soujuSignHeaders(method, path) {
  const ts = String(Date.now());
  const nonce = soujuNonce();
  const mac = crypto.createHmac('sha256', Buffer.from(String(soujuSignKey ?? ''), 'utf8'))
    .update(Buffer.from(`${method}\n${path}\n${ts}\n${nonce}`, 'utf8'))
    .digest('hex');
  return {
    'User-Agent': soujuUA,
    Accept: 'application/json',
    'x-ai-movie-client-name': soujuClientName,
    'x-ai-movie-client-version': soujuClientVer,
    'x-ai-movie-build-version': soujuBuildVer,
    'x-ai-movie-protocol-version': soujuProtoVer,
    'x-ai-movie-timestamp': ts,
    'x-ai-movie-nonce': nonce,
    'x-ai-movie-signature': mac,
  };
}

function soujuAbsURL(raw) {
  raw = String(raw ?? '').trim();
  if (raw === '') return '';
  if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
  if (raw.startsWith('//')) return 'https:' + raw;
  if (raw.startsWith('/')) return soujuSiteBase + raw;
  return raw;
}

function soujuEpNo(e) {
  const num = Math.trunc(Number(e?.num));
  if (Number.isFinite(num) && num > 0) return num;
  return atoiDefault(String(e?.key ?? ''), 0);
}


function soujuPickLine(lines) {
  const selMP4 = { ok: false, line: null };
  const anyMP4 = { ok: false, line: null };
  const selAny = { ok: false, line: null };
  const any = { ok: false, line: null };
  for (const l of Array.isArray(lines) ? lines : []) {
    if (!l || typeof l !== 'object' || String(l.url ?? '') === '') continue;
    if (l.url_kind === 'mp4') {
      if (l.selected && !selMP4.ok) {
        selMP4.line = l;
        selMP4.ok = true;
      } else if (!anyMP4.ok) {
        anyMP4.line = l;
        anyMP4.ok = true;
      }
    }
    if (l.selected && !selAny.ok) {
      selAny.line = l;
      selAny.ok = true;
    }
    if (!any.ok) {
      any.line = l;
      any.ok = true;
    }
  }
  for (const slot of [selMP4, anyMP4, selAny, any]) {
    if (slot.ok) return slot.line;
  }
  return null;
}

function soujuCardToCard(c) {
  const title = String(c?.title ?? '');
  const id = String(c?.id ?? '');
  if (title === '' || id === '') return null;
  const card = {
    vod_id: id,
    vod_name: cleanText(title),
    vod_pic: soujuAbsURL(c?.poster_url),
    vod_remarks: '',
    vod_class: '',
  };
  const genres = Array.isArray(c?.genres) ? c.genres : [];
  if (genres.length > 0) {
    card.vod_class = genres.join('/');
  }
  const parts = [];
  const year = Math.trunc(Number(c?.year));
  if (Number.isFinite(year) && year > 0) {
    parts.push(String(year));
  }
  const r = cleanText(c?.remarks);
  if (r !== '') {
    parts.push(r);
  }
  card.vod_remarks = parts.join(' · ');
  return card;
}

function soujuBrowsePath(genre, wd, page) {
  let p = Math.trunc(Number(page));
  if (!Number.isFinite(p) || p < 1) p = 1;
  const q = {
    kind: 'short_drama',
    intent: 'latest_catalog',
  };
  if (wd !== '') {
    q.intent = 'catalog_search';
    q.query = wd;
  } else if (genre !== '' && genre !== 'all') {
    q.genre = genre;
  }
  q.page = String(p);
  q.limit = String(soujuPageSize);
  return '/v1/browse/catalog?' + encodeQueryGo(q);
}

export class SoujuProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
    this.epc = new Map();
  }

  async api(method, path, payload) {
    const headers = soujuSignHeaders(method, path);
    if (payload != null) {
      headers['Content-Type'] = 'application/json';
    }
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders(method, soujuSiteBase + path, headers, payload);
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    if (terr) throw terr;
    if (status >= 400) {
      throw new Error(`搜剧AI 接口 HTTP ${status}: ${path}`);
    }
    if (!raw || raw.length === 0) {
      throw new Error('搜剧AI 空响应: ' + path);
    }
    return raw;
  }

  async getJSON(path) {
    const body = await this.api('GET', path, null);
    let out = null;
    try {
      out = JSON.parse(body.toString('utf8'));
    } catch (err) {
      throw new Error('搜剧AI 响应解析失败: ' + (err instanceof Error ? err.message : String(err)));
    }
    return out;
  }

  async browse(path) {
    const resp = await this.getJSON(path);
    let list = Array.isArray(resp?.cards) && resp.cards.length > 0 ? resp.cards : (Array.isArray(resp?.items) ? resp.items : []);
    const seen = new Set();
    const cards = [];
    for (const c of list) {
      if (!c || typeof c !== 'object' || Array.isArray(c)) continue;
      if (String(c.id ?? '') === '' || seen.has(String(c.id))) continue;
      if (c.availability && typeof c.availability === 'object' && c.availability.disabled === true) continue;
      const card = soujuCardToCard(c);
      if (!card || card.vod_name === '') continue;
      seen.add(String(c.id));
      cards.push(card);
    }
    return cards;
  }

  async List(cat, page) {
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    if (p > soujuMaxPages) return [];
    let c = String(cat ?? '');
    if (c === '') c = 'all';
    const cards = await this.browse(soujuBrowsePath(c, '', p));
    return cards;
  }

  async Search(wd, page) {
    let p = Math.trunc(Number(page));
    if (!Number.isFinite(p) || p < 1) p = 1;
    const kw = String(wd ?? '').trim();
    if (kw === '') throw new Error('搜剧AI 搜索关键词为空');
    const cards = await this.browse(soujuBrowsePath('', kw, p));
    if (cards.length === 0) {
      throw new Error('搜剧AI 搜索无结果');
    }
    return cards;
  }

  async episodes(id) {
    const tid = String(id ?? '').trim();
    if (tid === '') throw new Error('无效的搜剧AI 剧集 ID');
    const cached = this.epc.get(tid);
    if (cached && cached.length > 0) {
      return cached;
    }

    const all = [];
    const seen = new Set();
    for (let offset = 0; offset < 2000; offset += soujuEpLimit) {
      const q = encodeQueryGo({
        limit: String(soujuEpLimit),
        offset: String(offset),
        order: 'asc',
      });
      const path = '/v1/catalog/' + pathEscape(tid) + '/episodes?' + q;
      let resp = null;
      try {
        resp = await this.getJSON(path);
      } catch (err) {
        if (all.length > 0) break;
        throw err;
      }
      const eps = Array.isArray(resp?.episodes) ? resp.episodes : [];
      for (const e of eps) {
        if (!e || typeof e !== 'object' || Array.isArray(e)) continue;
        const token = String(e.token ?? '');
        if (token === '' || seen.has(token)) continue;
        seen.add(token);
        all.push(e);
      }
      const pagination = resp?.episode_pagination ?? resp?.pagination ?? null;
      if (!pagination || typeof pagination !== 'object' || pagination.has_more !== true || eps.length === 0) {
        break;
      }
    }
    if (all.length === 0) {
      throw new Error('搜剧AI 无分集: ' + tid);
    }
    all.sort((a, b) => soujuEpNo(a) - soujuEpNo(b)); 

    if (this.epc.size >= soujuEpCacheMax) {
      this.epc.clear();
    }
    this.epc.set(tid, all);
    return all;
  }

  async Detail(id) {
    let tid = String(id ?? '').trim();
    const i = tid.lastIndexOf('/');
    if (i >= 0) tid = tid.slice(i + 1);
    if (tid === '') throw new Error('无效的搜剧AI 剧集 ID');
    const q = encodeQueryGo({
      episodes: 'window',
      episode_limit: '1',
    });
    const d = await this.getJSON('/v1/catalog/' + pathEscape(tid) + '?' + q);
    const detail = {
      vod_id: tid,
      vod_name: '',
      vod_pic: '',
      vod_content: '',
      vod_class: '',
      episodes: [],
      episode_count: 0,
    };
    detail.vod_name = cleanText(d?.title);
    detail.vod_pic = soujuAbsURL(d?.poster_url);
    let desc = cleanText(d?.overview);
    if (desc === '') {
      desc = cleanText(d?.description);
    }
    detail.vod_content = desc;
    const tag = [];
    const year = Math.trunc(Number(d?.year));
    if (Number.isFinite(year) && year > 0) {
      tag.push(String(year));
    }
    const area = cleanText(d?.area);
    if (area !== '') {
      tag.push(area);
    }
    const genres = Array.isArray(d?.genres) ? d.genres : [];
    for (const g of genres) {
      tag.push(String(g ?? ''));
    }
    detail.vod_class = tag.join('/');

    const eps = await this.episodes(tid);
    for (let idx = 0; idx < eps.length; idx++) {
      const e = eps[idx];
      let no = soujuEpNo(e);
      if (no <= 0) no = idx + 1;
      let name = cleanText(e?.title);
      if (name === '') name = `第${no}集`;
      detail.episodes.push({ no, name, url: `souju://${tid}/${no}` });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.episode_count === 0) {
      throw new Error('搜剧AI 详情页无剧集: ' + tid);
    }
    if (detail.vod_name === '') {
      detail.vod_name = '搜剧AI ' + tid;
    }
    return detail;
  }

  async resolveLine(line) {
    let raw = String(line?.url ?? '').trim();
    if (raw.startsWith('resolve://')) {
      const ticket = raw.slice('resolve://'.length);
      const payload = JSON.stringify({
        ticket,
        selection: {
          playback_source_id: String(line?.playback_source_id ?? ''),
          provider_id: String(line?.provider_id ?? ''),
        },
      });
      const body = await this.api('POST', '/v1/playback/resolve-line?view=compact', payload);
      let lr = null;
      try {
        lr = JSON.parse(body.toString('utf8'));
      } catch (err) {
        throw new Error('搜剧AI 线路解析失败: ' + (err instanceof Error ? err.message : String(err)));
      }
      raw = String(lr?.line?.url ?? '').trim();
    }
    if (raw === '') {
      throw new Error('搜剧AI 线路为空');
    }
    if (raw.startsWith('resolve://')) {
      throw new Error('搜剧AI 线路未解析');
    }
    return raw;
  }

  async Play(playURL) {
    const rawURL = String(playURL ?? '');
    const parsed = parsePlayScheme(rawURL, 'souju://');
    let id = parsed ? parsed.id : '';
    let extra = parsed ? parsed.extra : '';
    let ok = parsed !== null;
    let directToken = '';
    if (!ok) {
      const i = rawURL.indexOf('/short-drama/');
      if (i >= 0) {
        let rest = rawURL.slice(i + '/short-drama/'.length);
        const q = rest.indexOf('?');
        if (q >= 0) {
          directToken = new URLSearchParams(rest.slice(q + 1)).get('episode') ?? '';
          rest = rest.slice(0, q);
        }
        rest = rest.replace(/^\/+|\/+$/g, '');
        if (rest !== '') {
          id = rest;
          ok = true;
        }
      }
    }
    if (!ok || id === '') {
      throw new Error('搜剧AI 播放参数无效');
    }
    let seq = atoiDefault(extra, 1);
    if (seq < 1) seq = 1;

    let token = directToken;
    if (token === '') {
      const eps = await this.episodes(id);
      if (seq > eps.length) {
        seq = eps.length;
      }
      token = String(eps[seq - 1]?.token ?? '');
    }
    if (token === '') {
      throw new Error('搜剧AI 分集 token 缺失');
    }

    const rr = await this.getJSON('/v1/playback/resolve/' + pathEscape(token));
    const line = soujuPickLine(rr?.line_options);
    if (!line) {
      throw new Error('搜剧AI 无可用播放线路');
    }
    const media = await this.resolveLine(line);
    if (!isProviderHTTPMediaURL(media)) {
      throw new Error('搜剧AI 播放地址无效');
    }
    return { src: media, referer: soujuSiteBase + '/' };
  }
}


import { cleanText } from '../../core/util.js';
import { isProviderHTTPMediaURL } from '../web_shared.js';
import { httpStatusSwitch } from './heiliao.js';
import { decodeHTML } from './provider_utils.js';

const bdaySiteBase = 'https://d1p3a4hbhtwghy.cloudfront.net';
const bdayUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36';
const bdayMaxEps = 999;

const bdayCats = [
  { ID: 'swdj', Name: 'AI短剧' },
  { ID: '24hcg', Name: '今日看料' },
  { ID: 'youxuan', Name: '优选投放' },
  { ID: 'mrds', Name: '每日大赛' },
  { ID: 'mrrg', Name: '每日热瓜' },
  { ID: 'hlda', Name: '黑料大事' },
  { ID: 'rgtj', Name: '热门吃瓜' },
  { ID: 'fcns', Name: '反差女神' },
  { ID: 'xyrg', Name: '学院热瓜' },
  { ID: 'whhl', Name: '网红吃瓜' },
  { ID: 'lydt', Name: '撸友看片' },
  { ID: 'llsq', Name: '海角乱伦' },
  { ID: 'hlzt', Name: '黑料杂谈' },
  { ID: 'thdq', Name: '探花大全' },
  { ID: 'whzj', Name: '网黄专辑' },
  { ID: 'mxbg', Name: '明星吃瓜' },
  { ID: 'avjs', Name: 'av解说' },
  { ID: 'qgzq', Name: '原创投稿' },
  { ID: 'wyxs', Name: '性爱技巧' },
  { ID: 'chjlb', Name: '偷拍盗摄' },
  { ID: 'gcmw', Name: '官场秘闻' },
  { ID: 'mrst', Name: '禁播动漫' },
  { ID: 'pmv', Name: 'PMV混剪' },
];

export const platformCats = bdayCats.map((c) => ({ ID: c.ID, Name: c.Name }));

const reBdayCatOK = /^[a-z0-9]{2,8}$/;
const reBdayCardLink = /href="(?:https?:\/\/[^"]*)?\/archives\/(\d+)\.html"/;
const reBdayCardTitle = /class="post-card-bottom-text"[^>]*>\s*([^<]+?)\s*</s;
const reBdayCardImg = /z-image-loader-url="([^"]+)"/;
const reBdayCardDate = /itemprop="datePublished" content="(\d{4}-\d{2}-\d{2})/;
const reBdayVideo = /"video":\{"url":"([^"]+?\.m3u8[^"]*)"/g;
const reBdayH1 = /<h1[^>]*>([^<]+)<\/h1>/;
const reBdayMetaImg = /itemprop="image" content="([^"]+)"/;
const reBdayMetaDesc = /name="description"[^>]*content="([^"]+)"/i;
const reBdayArch = /archives\/(\d+)/;
const reBdayEp = /[?&]ep=(\d+)/;
const reBdayUesc = /\\u([0-9a-fA-F]{4})/g;
const reBdayDigitsOnly = /^\d+$/;

function bdayUnescapeURL(raw) {
  raw = String(raw ?? '').replaceAll('\\/', '/');
  return raw.replace(reBdayUesc, (m, hex) => {
    const n = parseInt(hex, 16);
    if (!Number.isFinite(n)) return m;
    return String.fromCharCode(n);
  });
}

export class BdayProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  headers() {
    return { 'User-Agent': bdayUA, Referer: `${bdaySiteBase}/` };
  }

  async fetch(path) {
    let raw = null;
    let status = 0;
    let terr = null;
    try {
      const resp = await this.client.fetchWithHeaders('GET', bdaySiteBase + path, this.headers());
      raw = resp.raw;
      status = resp.status;
    } catch (err) {
      terr = err;
    }
    const err = httpStatusSwitch(status, terr);
    if (err) throw err;
    if (!raw || raw.length === 0) {
      throw new Error('不打烊空响应: ' + path);
    }
    return raw.toString('utf8');
  }

  imgProxy(cover) {
    cover = String(cover ?? '').trim();
    if (cover === '') return '';
    if (!cover.startsWith('http://') && !cover.startsWith('https://')) {
      cover = `${bdaySiteBase}/${cover.replace(/^\/+/, '')}`;
    }
    if (!this.media) return cover;
    return this.media.imgProxyURL(cover, `${bdaySiteBase}/`);
  }

  cards(page) {
    const blocks = page.split('<article');
    const cards = [];
    const seen = new Set();
    for (const block of blocks.slice(1)) {
      let head = block;
      if (head.length > 200) head = head.slice(0, 200);
      if (head.includes('ad-item')) continue;
      const m = reBdayCardLink.exec(block);
      if (!m) continue;
      const vid = m[1];
      if (seen.has(vid)) continue;
      const tm = reBdayCardTitle.exec(block);
      if (!tm) continue;
      const name = cleanText(decodeHTML(tm[1]));
      if (name === '') continue;
      seen.add(vid);
      let pic = '';
      const im = reBdayCardImg.exec(block);
      if (im) pic = decodeHTML(im[1]).trim();
      let remark = '';
      const rm = reBdayCardDate.exec(block);
      if (rm && rm[1].length >= 10) {
        remark = rm[1].slice(5).replaceAll('-', '/');
      }
      cards.push({
        vod_id: vid, vod_name: name, vod_pic: this.imgProxy(pic),
        vod_remarks: remark, vod_class: '不打烊', vod_score: '', vod_content: '',
      });
    }
    return cards;
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    cat = String(cat || '').trim();
    if (!reBdayCatOK.test(cat)) {
      cat = 'swdj';
    }
    let path = `/category/${cat}/`;
    if (page > 1) {
      path = `/category/${cat}/${page}/`;
    }
    const body = await this.fetch(path);
    return this.cards(body);
  }

  async Search(wd, page) {
    wd = String(wd || '').trim();
    if (wd === '') {
      throw new Error('不打烊搜索关键词为空');
    }
    if (page < 1) page = 1;
    const esc = encodeURIComponent(wd).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
    let path = `/search/${esc}/`;
    if (page > 1) {
      path = `/search/${esc}/${page}/`;
    }
    const body = await this.fetch(path);
    return this.cards(body);
  }

  bdayVideoMatches(body) {
    const out = [];
    reBdayVideo.lastIndex = 0;
    let m;
    while ((m = reBdayVideo.exec(body)) !== null) {
      out.push(m);
    }
    return out;
  }

  async Detail(id) {
    id = String(id || '').trim();
    if (!reBdayDigitsOnly.test(id)) {
      throw new Error('无效的不打烊剧集 ID');
    }
    const body = await this.fetch(`/archives/${id}.html`);
    const detail = {
      vod_id: id,
      vod_name: '',
      vod_pic: '',
      vod_content: '',
      vod_class: '',
      episodes: [],
      episode_count: 0,
    };
    const hm = reBdayH1.exec(body);
    if (hm) {
      detail.vod_name = cleanText(decodeHTML(hm[1]));
    }
    let pic = '';
    const mi = reBdayMetaImg.exec(body);
    if (mi) pic = decodeHTML(mi[1]).trim();
    if (pic === '') {
      const im = reBdayCardImg.exec(body);
      if (im) pic = decodeHTML(im[1]).trim();
    }
    detail.vod_pic = this.imgProxy(pic);
    const md = reBdayMetaDesc.exec(body);
    if (md) {
      detail.vod_content = cleanText(decodeHTML(md[1]));
    }
    const urls = this.bdayVideoMatches(body);
    if (urls.length === 0) {
      throw new Error('不打烊详情页没有可播放剧集: ' + id);
    }
    const total = Math.min(urls.length, bdayMaxEps);
    for (let i = 1; i <= total; i++) {
      detail.episodes.push({ no: i, name: `第${i}集`, url: `bday://archives/${id}?ep=${i}` });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') {
      detail.vod_name = '不打烊 ' + id;
    }
    return detail;
  }

  async Play(playURL) {
    const raw = String(playURL || '').trim();
    const m = reBdayArch.exec(raw);
    if (!m) {
      throw new Error('不打烊播放参数无效');
    }
    let ep = 1;
    const em = reBdayEp.exec(raw);
    if (em) {
      const n = parseInt(em[1], 10);
      if (Number.isFinite(n) && n > 0) ep = n;
    }
    const body = await this.fetch(`/archives/${m[1]}.html`);
    const urls = this.bdayVideoMatches(body);
    if (urls.length === 0) {
      throw new Error('不打烊播放数据缺失: ' + m[1]);
    }
    if (ep < 1 || ep > urls.length) {
      ep = 1;
    }
    const src = bdayUnescapeURL(urls[ep - 1][1]).trim();
    if (!isProviderHTTPMediaURL(src)) {
      throw new Error('不打烊播放地址无效: ' + m[1]);
    }
    return { src, referer: `${bdaySiteBase}/`, userAgent: bdayUA };
  }
}

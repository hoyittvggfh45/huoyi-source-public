

import { cleanText, atoiDefault, parsePlayScheme } from '../../core/util.js';
import { stripTagsSimple } from '../shared.js';
import { chengguoSiteBase } from '../consts.js';
import { isNonImageAsset, unescapeHTML, nuxtDramaList } from './nine.js';

const chengguoCats = [
  { id: 'yuanchuang', name: '原创', path: '/yuanchuang' },
  { id: 'mogai', name: '魔改', path: '/mogai' },
  { id: 'manju', name: '漫剧', path: '/manju' },
  { id: 'zhenren', name: '真人', path: '/zhenren' },
  { id: 'aiduanju', name: 'AI短剧', path: '/aiduanju' },
  { id: 'browse', name: '全部', path: '/browse' },
];

const reCGDetailEP = /<a\b[^>]*href="\/play\/([0-9a-zA-Z\-]+)\/(\d+)"[^>]*>/gi;
const reCGM3U8 = /https?:\/\/[^\s"'<>\\]{10,200}\.m3u8[^\s"'<>\\]{0,300}/gi;
const reCGImg = /\b(?:z-image-loader-url|data-cover-fb|data-src|src)="([^"]+)"/i;
const reCGH1 = /<h1[^>]*>([\s\S]*?)<\/h1>/is;
const reCGTitle = /<title>([\s\S]*?)<\/title>/is;
const reCGMetaDesc = /<meta\s+name="description"\s+content="([^"]*)"/is;


function chengguoNormalize(body) {
  return String(body).replace(/\\u0026|\\u002F|\\\//g, (m) => (m === '\\u0026' ? '&' : '/'));
}

export function chengguoPath(cat) {
  for (const c of chengguoCats) {
    if (c.id === cat) return c.path;
  }
  if (typeof cat === 'string' && cat.startsWith('/')) return cat;
  return chengguoCats[0].path;
}

export class ChengguoProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  async fetch(path) {
    const resp = await this.client.fetchBytes(chengguoSiteBase + path, chengguoSiteBase + '/');
    const body = await resp.buffer();
    if (body.length === 0) throw new Error('橙果空响应: ' + path);
    return body.toString('utf8');
  }

  imgProxy(raw) {
    raw = String(raw ?? '').trim();
    if (raw === '') return '';
    if (!raw.startsWith('http://') && !raw.startsWith('https://')) {
      raw = chengguoSiteBase + '/' + raw.replace(/^\/+/, '');
    }
    return this.media.imgProxyURL(raw, chengguoSiteBase + '/');
  }

  async List(cat, page) {
    if (page < 1) page = 1;
    if (!cat) cat = chengguoCats[0].id;
    const base = chengguoPath(cat);
    let path = base;
    if (page > 1) path = base + '?page=' + page;
    let body;
    try {
      body = await this.fetch(path);
    } catch (err) {
      if (page > 1 && String(err.message).includes('404')) return [];
      throw err;
    }
    const cards = nuxtDramaList(body, (u) => this.imgProxy(u));
    if (cards.length === 0) {
      if (page > 1) return [];
      throw new Error('橙果列表无内容: ' + path);
    }
    return cards;
  }

  async Search(wd, page) {
    if (page < 1) page = 1;
    let path = '/search?q=' + encodeURIComponent(String(wd ?? '').trim()).replace(/%20/g, '+');
    if (page > 1) path += '&page=' + page;
    const body = await this.fetch(path);
    const cards = nuxtDramaList(body, (u) => this.imgProxy(u));
    if (cards.length === 0) throw new Error('橙果搜索无结果');
    return cards;
  }

  async Detail(id) {
    id = String(id ?? '').trim();
    const slash = id.lastIndexOf('/');
    if (slash >= 0) id = id.slice(slash + 1);
    if (id === '') throw new Error('无效的橙果剧集 ID');
    const body = await this.fetch('/drama/' + encodeURIComponent(id));
    const detail = {
      vod_id: id,
      vod_name: '',
      vod_pic: '',
      vod_content: '',
      vod_class: '',
      episodes: [],
    };
    const h1 = reCGH1.exec(body);
    if (h1 && h1.length > 1) detail.vod_name = cleanText(stripTagsSimple(h1[1]));
    if (detail.vod_name === '') {
      const t = reCGTitle.exec(body);
      if (t && t.length > 1) detail.vod_name = stripTagsSimple(t[1]).split('-', 2)[0].trim();
    }
    const meta = reCGMetaDesc.exec(body);
    if (meta && meta.length > 1) detail.vod_content = unescapeHTML(meta[1]).trim();
    const im = reCGImg.exec(body);
    if (im && im.length > 1) {
      const v = unescapeHTML(im[1]);
      const lv = v.toLowerCase();
      if (!lv.startsWith('data:') && !isNonImageAsset(lv)) detail.vod_pic = this.imgProxy(v);
    }
    const epsSeen = new Set();
    const nums = [];
    for (const m of body.matchAll(reCGDetailEP)) {
      if (m[1] !== id) continue;
      const n = parseInt(m[2], 10);
      if (!Number.isFinite(n) || n < 1 || epsSeen.has(n)) continue;
      epsSeen.add(n);
      nums.push(n);
    }
    if (epsSeen.size === 0) throw new Error('橙果详情页无剧集: ' + id);
    nums.sort((a, b) => a - b);
    for (const n of nums) {
      detail.episodes.push({ no: n, name: '第' + n + '集', url: 'chengguo://' + id + '/' + n });
    }
    detail.episode_count = detail.episodes.length;
    if (detail.vod_name === '') detail.vod_name = '橙果剧集 ' + id;
    return detail;
  }

  async Play(playURL) {
    let parsed = parsePlayScheme(playURL, 'chengguo://');
    let id = parsed ? parsed.id : '';
    let extra = parsed ? parsed.extra : '';
    let ok = !!parsed;
    if (!ok && String(playURL).includes('/play/')) {
      const raw = String(playURL);
      const rest = raw.slice(raw.indexOf('/play/') + '/play/'.length).replace(/^\/+|\/+$/g, '');
      const parts = rest.split('/');
      if (parts.length >= 1 && parts[0] !== '') {
        id = parts[0];
        if (parts.length >= 2) extra = parts[1];
        ok = true;
      }
    }
    if (!ok || id === '') throw new Error('橙果播放参数无效');
    let seq = atoiDefault(extra, 1);
    if (seq < 1) seq = 1;
    const path = '/play/' + encodeURIComponent(id) + '/' + seq;
    const body = await this.fetch(path);
    const normalized = chengguoNormalize(body);
    let media = '';
    for (const m of normalized.matchAll(reCGM3U8)) {
      const cand = unescapeHTML(m[0].trim());
      if (cand.includes('.m3u8')) {
        media = cand;
        break;
      }
    }
    if (media === '') throw new Error('橙果播放页无媒体地址: ' + path);
    return { src: media, referer: chengguoSiteBase + '/' };
  }
}

export const platformCats = chengguoCats.map((c) => ({ id: c.id, name: c.name }));

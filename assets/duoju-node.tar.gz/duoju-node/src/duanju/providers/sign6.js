



import { createHash, randomBytes, randomInt } from 'node:crypto';




function srcB(b, i) {
  return i >= 0 && i < b.length ? b[i] : 0;
}

function setByte(b, i, v) {
  if (i >= 0 && i < b.length) b[i] = v & 0xff;
}

function concat(...parts) {
  return Buffer.concat(parts);
}


function xorBytes(a, b) {
  const out = Buffer.from(a);
  for (let i = 0; i < out.length; i++) out[i] ^= b[i % b.length];
  return out;
}

function rotl32(x, n) {
  n &= 31;
  if (n === 0) return x >>> 0;
  return ((x << n) | (x >>> (32 - n))) >>> 0;
}

function ror32(x, n) {
  n &= 31;
  if (n === 0) return x >>> 0;
  return ((x >>> n) | (x << (32 - n))) >>> 0;
}


function rotl8(x) {
  return ((x << 4) | (x >> 4)) & 255;
}

function rotl8_3(x) {
  return ((x << 3) | (x >> 5)) & 255;
}

function reverseBits(value) {
  let r = 0;
  for (let i = 0; i < 8; i++) r = (r << 1) | ((value >>> i) & 1);
  return r;
}

function readLe32(b, off) {
  return (srcB(b, off) | (srcB(b, off + 1) << 8) | (srcB(b, off + 2) << 16) | (srcB(b, off + 3) << 24)) >>> 0;
}

function readBe32(b, off) {
  return ((srcB(b, off) << 24) | (srcB(b, off + 1) << 16) | (srcB(b, off + 2) << 8) | srcB(b, off + 3)) >>> 0;
}

function putLe32(b, off, v) {
  setByte(b, off, v);
  setByte(b, off + 1, v >>> 8);
  setByte(b, off + 2, v >>> 16);
  setByte(b, off + 3, v >>> 24);
}

function putBe32(b, off, v) {
  setByte(b, off, v >>> 24);
  setByte(b, off + 1, v >>> 16);
  setByte(b, off + 2, v >>> 8);
  setByte(b, off + 3, v);
}

function le32(v) {
  const b = Buffer.alloc(4);
  putLe32(b, 0, v >>> 0);
  return b;
}

function be32(v) {
  const b = Buffer.alloc(4);
  putBe32(b, 0, v >>> 0);
  return b;
}

function readU64Le(b, off) {
  let v = 0n;
  for (let i = 7; i >= 0; i--) v = (v << 8n) | BigInt(srcB(b, off + i));
  return v;
}

function putU64Le(b, off, v) {
  for (let i = 0; i < 8; i++) setByte(b, off + i, Number((v >> BigInt(8 * i)) & 0xffn));
}

const U64 = 0xffffffffffffffffn;


function rotr64(x, n) {
  n &= 63;
  if (n === 0) return x & U64;
  return ((x >> BigInt(n)) | (x << BigInt(64 - n))) & U64;
}

function md5Of(data) {
  return createHash('md5').update(data).digest();
}



const sm3IV = [
  0x7380166f, 0x4914b2b9, 0x172442d7, 0xda8a0600,
  0xa96f30bc, 0x163138aa, 0xe38dee4d, 0xb0fb0e4e,
];

function sm3P0(x) {
  return (x ^ rotl32(x, 9) ^ rotl32(x, 17)) >>> 0;
}

function sm3P1(x) {
  return (x ^ rotl32(x, 15) ^ rotl32(x, 23)) >>> 0;
}

function sm3(data) {
  const h = sm3IV.slice();
  const padLen = (56 - (data.length + 1)) % 64;
  const msg = concat(data, Buffer.from([0x80]), Buffer.alloc(padLen < 0 ? padLen + 64 : padLen));
  const lenBytes = Buffer.alloc(8);
  lenBytes.writeBigUInt64BE(BigInt(data.length) * 8n);
  const full = concat(msg, lenBytes);

  const w = new Array(68);
  const w1 = new Array(64);
  for (let off = 0; off < full.length; off += 64) {
    for (let j = 0; j < 16; j++) w[j] = readBe32(full, off + j * 4);
    for (let j = 16; j < 68; j++) {
      w[j] = (sm3P1((w[j - 16] ^ w[j - 9] ^ rotl32(w[j - 3], 15)) >>> 0) ^ rotl32(w[j - 13], 7) ^ w[j - 6]) >>> 0;
    }
    for (let j = 0; j < 64; j++) w1[j] = (w[j] ^ w[j + 4]) >>> 0;
    let [a, b, c, d, e, f, g, hh] = h;
    for (let j = 0; j < 64; j++) {
      const tj = j < 16 ? 0x79cc4519 : 0x7a879d8a;
      const ss1 = rotl32((rotl32(a, 12) + e + rotl32(tj, j)) >>> 0, 7);
      const ss2 = (ss1 ^ rotl32(a, 12)) >>> 0;
      let ff, gg;
      if (j < 16) {
        ff = (a ^ b ^ c) >>> 0;
        gg = (e ^ f ^ g) >>> 0;
      } else {
        ff = ((a & b) | (a & c) | (b & c)) >>> 0;
        gg = ((e & f) | (~e & g)) >>> 0;
      }
      const tt1 = (ff + d + ss2 + w1[j]) >>> 0;
      const tt2 = (gg + hh + ss1 + w[j]) >>> 0;
      d = c;
      c = rotl32(b, 9);
      b = a;
      a = tt1;
      hh = g;
      g = rotl32(f, 19);
      f = e;
      e = sm3P0(tt2);
    }
    h[0] = (h[0] ^ a) >>> 0;
    h[1] = (h[1] ^ b) >>> 0;
    h[2] = (h[2] ^ c) >>> 0;
    h[3] = (h[3] ^ d) >>> 0;
    h[4] = (h[4] ^ e) >>> 0;
    h[5] = (h[5] ^ f) >>> 0;
    h[6] = (h[6] ^ g) >>> 0;
    h[7] = (h[7] ^ hh) >>> 0;
  }
  const out = Buffer.alloc(32);
  for (let i = 0; i < 8; i++) putBe32(out, i * 4, h[i]);
  return out;
}



function varint(value) {
  let n = BigInt.asUintN(64, BigInt(value));
  const out = [];
  while (n > 127n) {
    out.push(Number((n & 127n) | 128n));
    n >>= 7n;
  }
  out.push(Number(n));
  return Buffer.from(out);
}

function zigzag(value) {
  return BigInt.asUintN(64, BigInt(value) < 0n ? BigInt.asUintN(64, -BigInt(value)) * 2n - 1n : BigInt(value) * 2n);
}


function protoField(tag, value, typ) {
  if (value === null || value === undefined) return null;
  switch (typ) {
    case 'bytes':
    case 'message': {
      const head = concat(varint(BigInt(tag) << 3n | 2n), varint(value.length));
      return concat(head, value);
    }
    case 'string': {
      if (value === '') return null;
      const body = Buffer.from(value, 'utf8');
      const head = concat(varint(BigInt(tag) << 3n | 2n), varint(body.length));
      return concat(head, body);
    }
    case 'float': {
      const body = Buffer.alloc(4);
      body.writeFloatLE(value, 0);
      return concat(varint(BigInt(tag) << 3n | 5n), body);
    }
    default: {
      const head = varint(BigInt(tag) << 3n);
      if (typ === 'sint') return concat(head, varint(zigzag(value)));
      return concat(head, varint(BigInt.asUintN(64, BigInt(value))));
    }
  }
}


function proto(fields) {
  const parts = [];
  for (const [tag, value, typ] of fields) {
    const p = protoField(tag, value, typ || 'string');
    if (p) parts.push(p);
  }
  return concat(...parts);
}




const sbox = Buffer.from(
  '+n0Ia5xZs0sEXznQOEqRmQBnpiCf9U2Ccybu3xhmgzOAAxn72f6uqqmwUsYL83klTni0NqxdGieeiNu9PGPsSRXBMB/cuFbUbM3KCUPINaPvHvSW0vwOcnuUhNHqRVpiAj/TEoE0K91+5ijypUYTATsh9mE3KSoN7Yyvv51cuyR2D3XkU4nhmI2xmmVwT1RMWKtub4sjxAcRDLrPoKSO2AU9FLLadMPX577Wf95IFj6FkKFVt3dCIsmGUC4X+WQxLJvxbRxEaOPpqJOXyzJX6+Vxaq3AzMfF/WAdoi1Hp+JRaV56zgpBtpWP97mH4DoGEIq1+FvV8LyS/3wvwugbQOwb2r26mJEMsiuDQTRn+wrYdrVGBVlhI3WQhyrjUBVMrLF5667llUcEaPCGPVGLD8qO5LlO8hKCvA7V9+8oJc9bXelqVQLhM76T5/WtnT45JKji+hdX0HoNCDDWuKON/QeaxB5uImSX0h2wv0VmP2zd2yeApxHcpsVS+MC2yFwAc2B7oBkTqsk1SEvTpM2fmfMQREBUfin0Bh+iq6EvPPavhWI2IX9e3yAas7Tm/3KEj2UmlFp36kN4x0rMLBRrxuh0U/zUHM4xcAMYjJY4MonxOl/X+alpt2M3WMI7w3HLnpIBigtNiJu7T21v4P6lSd5WFgntnMEt7oF92XzRLkJbTcGmXepE/UVOG6E/0YnhfS+q26utWcuxzpooyeD2cDlK1/8w9d28VzsRjbLuALbmGlp8+d7EzS6Au7lMpZ+ECMZvQmzwJ+eLOpxR+2chdUExp8ogQyq3v9l68rX4jCwjg0+PYKAEEzcU4wHFY2ZcdIHfWL1okD3SszT0GZMyKdZJrg1L2AeerB4tC0C4crp2EHGo5FYdSP7lwkeR2ocmnR+Ia8CYviUJlzOjhRZef9xuVOn3qcjow3fQgivsAmKKkg4+sA8F8/GWeDiGNhg8JM8KtFPMYWWkx5TVFX5t73kiNRJqjlIGVXtGZFCV4gzt0xcDopuZ6xz8r9Rzafpf9ywev8jh8592gHFIqpStZPuJxmDDMrNN0uBE3V+oscdoIzTJbRJ/t+sVvqnReJOgDJKk10fjisJwqyZBmnmn2BSFj8BvVtCMEbkuPOKdzw7eA11GPs04Qw8zWtkaZWwiO/wwpojqN6K0jY5RnNZA7vn4hPSul+nKCkVnVwQvg1zVxcSCtqORmB9KrJaBbssbCQivGJVJfVTt+hYxOtq4ZvWl8f4QAQZ0zGPffCgl9s6yT4vlvIdpu4YhBwA25wtQWZsc6GJYGWHyvSdeuh3mmUI9DSq13Fsp8C1MU3tqc04/df9LoTUXVXI5INOw/e8C7Hd+5CvbkMEFnnrUUmskEw==',
  'base64',
);


const branch2Orders = Buffer.from(
  '0f0704000908030a060b050d0e010c020f05080c0009020103070e060b0a0d04060500070c000a04080f010b0d09020e060b02050403080101070a000d0c090e0d070e0f0b0208030c0509010004060a0d0902060f0b0a040807000c0503010e0c090f07060f030e020d0405010b0a000c050a090e0802040407030f01060b000b0f0408020a0700090d06010e03050c0b060a0508020c03070f0e090d0001040906080f050800040a0b030d01020c0e090d0c0604070a03030f00080105020e01000d0f090a0b0e0402080703060c0501080a0c0f0905060b000304020e070d04080f000c0f0e0d0a01060207090503040205080d0b0a0606000e0f070c09030a08040f000b01060d0c0709030e05020a070b050f00020e0108030d0c0609040d070f08050f06040b0a0e0c090002030d0c020704010b0e0e08060f09050003',
  'hex',
);

const medusaSignKey = Buffer.from('8ebdfa3806ecc5cee79423e6029ed82540bc2218bb7eaef71cb691f7aa8aa2f5', 'hex');
const medusaAESKey = Buffer.from('f1593376766ea98d34f31b057a9d5be4', 'hex');
const medusaAESIV = Buffer.from('1fe109a4125283f418de9e051a969e12', 'hex');
const medusaMagic16 = Buffer.from('f7e85ffad7d7dc3bd62ac87057cf6118', 'hex');
const medusaMagic8 = Buffer.from('4001000000000000', 'hex');


let processNonce = randomBytes(18).toString('base64url');
let processStarted = Date.now();


const branch2SV = [
  0xa7aefe20, 0x7149f1d6, 0x47e4ca07, 0xe9b58f67, 0x93b924de, 0xc614d0f5, 0x38afe0ef, 0xb2bbad73,
  0xe24444c3, 0x9d3aec9b, 0xdf7b37e4, 0xd8b16d40, 0xf8ac31b8, 0x76b9a90b, 0x31d833ee, 0x953fce64,
  0x353595a4, 0x4609c13b, 0x36925008, 0x8c6d0925, 0x5df5c177, 0x1cfbf52b, 0x8a4fa7f0, 0x114ca35e,
  0x8193f984, 0x7a7a8733, 0x316ab4d5, 0x3c20cfc9, 0xa6d84453, 0x3a18500c, 0x798ec47a, 0x97a76b28,
  0x66c4ff96, 0x51716443, 0x0dd2fc3b, 0xb5696da7, 0xbbeb3ac5, 0x5c53d204, 0xd32608ce, 0x7279b9ec,
  0xf4188ecf, 0xf7d793db, 0x332cc491, 0xab76ae15, 0x9bebe727, 0x18a01384, 0x5be9f8a7, 0x5f90a754,
  0x39b663c0, 0x36673c83, 0x7c92f514, 0x9d7d94d7, 0xe2e8d9aa, 0x5f7e9ea9, 0x7abd4551, 0x569e05da,
  0x40a25632, 0x3df5a9a5, 0xbab37d80, 0x454286dc, 0x3f5d4e78, 0x03d7b75d, 0xb1fe4af7, 0xa5ab26a3,
];




function getIv(iv, data) {
  let value = iv >>> 0;
  for (let i = 0; i < data.length; i++) {
    const d = data[i];
    if ((i & 1) === 0) {
      value = ((value >>> 4) ^ value ^ (value << 6) ^ d) >>> 0;
    } else {
      value = ~((value >>> 7) ^ value ^ (d | (value << 12))) >>> 0;
    }
  }
  return value >>> 0;
}


function sumMd5(data) {
  let check = 0x20220420;
  for (let i = 0; i < 12; i++) {
    const temp = (((i & 1) === 0 ? check >>> 3 : check >>> 5) ^ check) >>> 0;
    if ((i & 1) === 0) {
      check = (srcB(data, i) ^ (check << 7)) >>> 0;
    } else {
      check = ~(srcB(data, i) | (check << 11)) >>> 0;
    }
    check = (check ^ temp) >>> 0;
  }
  return ((check | 4) ^ 0x1000000) >>> 0;
}

function md5V3Step(kind, a, b, c, d, m, shift, constant) {
  let f;
  if (kind === 0) f = ((b & c) | (~b & d)) >>> 0;
  else if (kind === 1) f = ((b & d) | (c & ~d)) >>> 0;
  else if (kind === 2) f = (b ^ c ^ d) >>> 0;
  else f = (c ^ (b | ~d)) >>> 0;
  return (b + rotl32((a + f + m + constant) >>> 0, shift)) >>> 0;
}


const md5V3Shifts = [
  [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22],
  [5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20],
  [4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23],
  [6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21],
];


function md5SumV3(message, countV2, orders, countV1) {
  const sv = new Array(64);
  for (let i = 0; i < 64; i++) sv[i] = ror32(branch2SV[i], countV1);
  const start = [
    ror32(0x79e0f2fb, countV2),
    ror32(0xc8b52570, countV2),
    ror32(0xebc2f8cd, countV2),
    ror32(0x7c104d93, countV2),
  ];
  const endCount = (countV2 + 6) & 255;
  const end = [
    ror32(0x19be4866, endCount),
    ror32(0xe85986b4, endCount),
    ror32(0xe19b326e, endCount),
    ror32(0x71d1d7d4, endCount),
  ];

  const m = new Array(16);
  for (let i = 0; i < 16; i++) m[i] = readLe32(message, i * 4);
  let a = start[0];
  let b = start[1];
  let c = start[2];
  let d = start[3];

  for (let kind = 0; kind < 4; kind++) {
    const shifts = md5V3Shifts[kind];
    const offset = kind * 16;
    for (let i = 0; i < 16; i++) {
      const phase = i & 3;
      const mm = m[orders[offset + i] & 0xff];
      const cc = sv[offset + i];
      if (phase === 0) a = md5V3Step(kind, a, b, c, d, mm, shifts[i], cc);
      else if (phase === 1) d = md5V3Step(kind, d, a, b, c, mm, shifts[i], cc);
      else if (phase === 2) c = md5V3Step(kind, c, d, a, b, mm, shifts[i], cc);
      else b = md5V3Step(kind, b, c, d, a, mm, shifts[i], cc);
    }
  }

  const ret = Buffer.alloc(16);
  putLe32(ret, 0, ((start[0] + a) >>> 0) ^ end[0]);
  putLe32(ret, 4, ((start[1] + b) >>> 0) ^ end[1]);
  putLe32(ret, 8, ((start[2] + c) >>> 0) ^ end[2]);
  putLe32(ret, 12, ((start[3] + d) >>> 0) ^ end[3]);
  return concat(ret, le32(sumMd5(ret)));
}


const branch2N1 = [0x8980f29b, 0xeb549c7f, 0xb08726db, 0xd40cb5e6, 0xe8f559e4];

function branch2F13(iv, querySm3, bodyMd5, tsBytes, khronos) {
  const v = ((iv & 13) * 86) >>> 0;
  const ivV0 = ((v >>> 15) & 255) + ((v >>> 8) & 255);
  const n1 = branch2N1[ivV0];
  const countV1 = (n1 + khronos + 1) & 255;
  const countV2 = (n1 + khronos) >>> 0;
  const shift = (countV2 + 5) & 7;
  const seed = [0x84, 0x96, 0x77, 0x9d, 0xd4, 0x15, 0x0b, 0xf8];
  const pad = Buffer.alloc(8);
  for (let i = 0; i < 8; i++) pad[i] = ((seed[i] | (seed[i] << 8)) >>> shift) & 255;
  const input = concat(querySm3, bodyMd5, tsBytes, pad, Buffer.from([0xa0, 0x01, 0x00, 0x00]));
  const from = ivV0 << 6;
  const orders = branch2Orders.subarray(from, from + 64);
  return md5SumV3(input, countV2, orders, countV1);
}


const hashF13IV1 = [0xc4a78580, 0xb3c0fd39, 0xc58c5686, 0xc9aa3ba7, 0xf5a7adf2, 0x963c2ed1];


const hashF13TT02 = [
  0xebb64faf, 0x07aadcc2, 0xcf3187bf, 0xe01138ff, 0x6d0bfcff, 0x5a30a3be, 0xb41ad638, 0x34180eb8,
  0xf233eb6f, 0xb1a584cc, 0xccc30dc7, 0x47d1db51, 0xd55653de, 0x70a84fa1, 0x57473c12, 0xf76f0288,
  0x2c077f0a, 0xda0dcad0, 0xfbb86f6c, 0xfdc4cf00, 0x688a020d, 0xe676c6a6, 0x8cd6338b, 0x1a3c8d0e,
  0xcce8b06b, 0x6ad0ed0b, 0xa0522717, 0xdc71ac83, 0x2285db71, 0xd5b4dda6, 0x736f8650, 0x6560306c,
  0x617ce2a6, 0xe423417e, 0x0a40e143, 0x544e4032, 0x88dffb2a, 0x716c1ae0, 0x4c467a88, 0x05b23bb3,
  0xe1d0b866, 0xbaa3dcb8, 0xae3374d3, 0xc3381a50, 0x1702f75b, 0xfe6da368, 0xf0b4cf48, 0x4e0ffbb8,
  0x72aad10d, 0x26c53a3d, 0xf2bce0f6, 0xb4557581, 0x4a257fdd, 0x8c3182a2, 0xab0b3b86, 0x3d5dfb14,
  0x4f103634, 0xd37b52d7, 0x444eff16, 0xeb0a33d1, 0x6ca86f6e, 0x0284ba7, 0x08387cfa, 0x5fb37586,
];


const hashF13InitRaw = [
  0x7aba4fc8, 0x67166507, 0x6403fa00, 0x340f512f,
  984304912, 3005047866, 2874125293, 2152413264,
];


const hashF13Chosen = [
  [101, 5, 7, 6, 3, 2, 1, 0, 5, 4, 3],
  [96, 0, 6, 7, 5, 3, 2, 1, 5, 4, 4],
  [96, 7, 6, 2, 1, 4, 0, 5, 4, 3, 5],
  [99, 3, 6, 2, 4, 5, 1, 0, 0, 7, 6],
  [96, 0, 5, 6, 7, 3, 1, 2, 5, 4, 4],
  [100, 2, 0, 3, 5, 4, 6, 7, 2, 1, 5],
];


function hashF13(querySm3, bodyMd5, tsBytes, khronos) {
  const iv = getIv(getIv(getIv(0x20230928, querySm3), bodyMd5), tsBytes);
  const low = iv & 15;
  const ivV0 = (low * 171) >> 9;
  const branch = low - ivV0 * 3;
  if (branch === 2) return branch2F13(iv, querySm3, bodyMd5, tsBytes, khronos);
  if (branch !== 0) {
    return concat(querySm3.subarray(0, 16), bodyMd5, le32(sumMd5(concat(querySm3, bodyMd5))));
  }

  const ivV1 = hashF13IV1[ivV0];
  const countV1 = (ivV1 + khronos + 1) & 255;
  const countV2 = (ivV1 + khronos) >>> 0;
  const tt = new Array(64);
  for (let i = 0; i < 64; i++) tt[i] = ror32(hashF13TT02[i], countV1);
  const n0 = (countV2 + 2) & 7;
  const seed = [0xfa, 0x45, 0x61, 0xd7];
  const pad = Buffer.alloc(4);
  for (let i = 0; i < 4; i++) pad[i] = ((seed[i] | (seed[i] << 8)) >>> n0) & 255;
  const data = concat(querySm3, bodyMd5, tsBytes, pad, Buffer.from([0, 0, 0, 0, 0, 0, 1, 0xa0]));

  const di = new Array(data.length / 4 + 112 + 16).fill(0);
  let diLen = 0;
  for (let i = 0; i + 3 < data.length; i += 4) di[diLen++] = readBe32(data, i);
  const di0 = di[0];
  for (let i = 0; i < 112; i++) {
    const di1 = di[i + 1];
    const di14 = di[i + 14];
    const r1 = (rotl32(di1, 14) ^ rotl32(di1, 25) ^ (di1 >>> 3)) >>> 0;
    const r2 = (rotl32(di14, 13) ^ rotl32(di14, 15) ^ (di14 >>> 10)) >>> 0;
    di[diLen++] = (di0 + di[i + 9] + r1 + r2) >>> 0;
  }

  const init = new Array(8);
  for (let i = 0; i < 8; i++) init[i] = ror32(hashF13InitRaw[i], countV2 & 31);
  const chosen = hashF13Chosen[ivV0];
  const d = init.slice();
  for (let i = 0; i < chosen[0]; i++) {
    const base = (ivV1 + i) >>> 0;
    const n0v = di[base & 127];
    const n1v = (((d[chosen[3]] ^ d[chosen[4]]) & d[chosen[1]]) ^ d[chosen[3]]) >>> 0;
    const n2 = (rotl32(d[chosen[1]], 26) ^ rotl32(d[chosen[1]], 21) ^ rotl32(d[chosen[1]], 7)) >>> 0;
    const n4 = (n0v + n1v + n2 + tt[base & 63] + d[chosen[5]]) >>> 0;
    const n5 = (rotl32(d[chosen[2]], 30) ^ rotl32(d[chosen[2]], 19) ^ rotl32(d[chosen[2]], 10)) >>> 0;
    const n6 = ((d[chosen[2]] & d[chosen[6]]) | ((d[chosen[2]] | d[chosen[6]]) & d[chosen[7]])) >>> 0;
    const n7 = (n5 + n6) >>> 0;
    const old = d[chosen[9]];
    
    const last = d[d.length - 1];
    for (let k = d.length - 1; k >= 1; k--) d[k] = d[k - 1];
    d[0] = last;
    d[chosen[10]] = (n7 + n4) >>> 0;
    d[chosen[8]] = (old + n4) >>> 0;
  }

  const ret = Buffer.alloc(32);
  for (let i = 0; i < 8; i++) putBe32(ret, i * 4, (d[i] + init[i]) >>> 0);
  for (let i = 0; i < 16; i++) ret[i] = ret[i] ^ ret[i + 16];
  return concat(ret.subarray(0, 16), le32(sumMd5(ret.subarray(0, 16))));
}




function rc4Gorgon(data, key) {
  const s = Buffer.alloc(256);
  for (let i = 0; i < 256; i++) s[i] = i;
  let j = 0;
  for (let i = 0; i < 256; i++) {
    j = (j + s[i] + key[i % key.length]) & 255;
    s[i] = s[j];
  }
  const out = Buffer.alloc(data.length);
  let i = 0;
  j = 0;
  for (let k = 0; k < data.length; k++) {
    i++;
    const x = s[i];
    j += x;
    const y = s[j & 255];
    s[i] = y;
    out[k] = data[k] ^ s[(y + y) & 255];
  }
  return out;
}

function xGorgon(query, body, timestamp, random) {
  const q4 = md5Of(Buffer.from(query, 'utf8')).subarray(0, 4);
  const b4 = body.length > 0 ? md5Of(body).subarray(0, 4) : Buffer.alloc(4);
  const sdk = le32(67503104);
  const input = concat(q4, b4, Buffer.alloc(4), sdk, be32(timestamp));
  const key = Buffer.from([0x4a, 0x40, 0x16, (random >>> 8) & 255, 0x47, 0x6c, 0x01, random & 255]);
  const out = rc4Gorgon(input, key);
  for (let i = 0; i < out.length; i++) {
    const value = rotl8(out[i]);
    const next = i + 1 < out.length ? out[i + 1] : out[0];
    out[i] = ~(reverseBits((next ^ value) & 255) ^ 20) & 255;
  }
  return concat(
    Buffer.from([0x84, 0x04, random & 255, (random >>> 8) & 255, 0x40, 0x01]),
    out,
  ).toString('hex');
}




function aesSrc(data, idx) {
  return idx < data.length ? srcB(data, idx) : 0;
}

function aesPut(out, idx, value) {
  if (idx >= 0 && idx < out.length) out[idx] = value & 0xff;
}

function aesMatrix(bytes) {
  const rows = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]];
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) rows[i][j] = srcB(bytes, i * 4 + j);
  }
  return rows;
}

function aesFlat(rows) {
  const b = Buffer.alloc(16);
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) b[i * 4 + j] = rows[i][j];
  }
  return b;
}

function aesXt(x) {
  if ((x & 128) !== 0) return ((x << 1) ^ 0x1b) & 255;
  return (x << 1) & 255;
}

function aesMix(rows) {
  for (let i = 0; i < 4; i++) {
    const t = (rows[0][i] ^ rows[1][i] ^ rows[2][i] ^ rows[3][i]) & 255;
    const u = rows[0][i];
    rows[0][i] = (rows[0][i] ^ t ^ aesXt(rows[0][i] ^ rows[1][i])) & 255;
    rows[1][i] = (rows[1][i] ^ t ^ aesXt(rows[1][i] ^ rows[2][i])) & 255;
    rows[2][i] = (rows[2][i] ^ t ^ aesXt(rows[2][i] ^ rows[3][i])) & 255;
    rows[3][i] = (rows[3][i] ^ t ^ aesXt(rows[3][i] ^ u)) & 255;
  }
}


function newAesV3(key, khronos) {
  const wordSize = khronos & 3;
  const box = sbox.subarray(wordSize * 256, (wordSize + 1) * 256);
  const con2Table = [[1, 0, 2, 3], [2, 0, 3, 1], [0, 1, 3, 2], [1, 0, 2, 3]];
  const orderTable = [
    [0, 9, 14, 11, 4, 13, 2, 7, 8, 1, 6, 15, 12, 5, 10, 3],
    [0, 9, 14, 15, 4, 13, 2, 7, 8, 1, 6, 3, 12, 5, 10, 11],
    [0, 9, 14, 7, 4, 13, 2, 11, 8, 1, 6, 3, 12, 5, 10, 15],
    [0, 9, 14, 11, 4, 13, 2, 7, 8, 1, 6, 15, 12, 5, 10, 3],
  ];
  const con2 = con2Table[wordSize];
  const order = orderTable[wordSize];
  const initTable = [0xca025ddc, 0x823dc546, 0xc9420583, 0xc298225f];
  const init = initTable[wordSize] >>> 0;
  const initial = Buffer.alloc(16);
  for (let i = 0; i < 4; i++) putLe32(initial, i * 4, init);
  const mk = xorBytes(initial, key);
  const expanded = concat(mk, Buffer.alloc(32));
  let rounds = 8;
  for (let i = 4; i < 12; i++) {
    const at = 4 * (i - 1);
    let x0 = srcB(expanded, at);
    let x1 = srcB(expanded, at + 1);
    let x2 = srcB(expanded, at + 2);
    let x3 = srcB(expanded, at + 3);
    if ((i & 3) === 0) {
      const t = ((init >>> (rounds & 24)) ^ box[x1]) & 255;
      x1 = box[x2];
      x2 = box[x3];
      x3 = box[x0];
      x0 = t;
    }
    rounds += 2;
    setByte(expanded, at + 4, x0 ^ srcB(expanded, at - 12));
    setByte(expanded, at + 5, x1 ^ srcB(expanded, at - 11));
    setByte(expanded, at + 6, x2 ^ srcB(expanded, at - 10));
    setByte(expanded, at + 7, x3 ^ srcB(expanded, at - 9));
  }
  const keys = [];
  for (let i = 0; i < 12; i++) {
    keys.push([srcB(expanded, i * 4), srcB(expanded, i * 4 + 1), srcB(expanded, i * 4 + 2), srcB(expanded, i * 4 + 3)]);
  }
  return { box, con2, order, keys };
}

function aesAdd(rows, ks) {
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) rows[i][j] = (rows[i][j] ^ ks[i][j]) & 255;
  }
}

function aesAddCon(a, rows, ks) {
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) rows[i][j] = (rows[i][j] ^ ks[i][a.con2[j]]) & 255;
  }
}

function aesSub(a, rows) {
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) rows[i][j] = a.box[rows[i][j]];
  }
  const old = rows.map((r) => r.slice());
  for (let i = 0; i < 4; i++) rows[i] = old[a.con2[i]].slice();
}

function aesShift(a, rows) {
  const b = aesFlat(rows);
  for (let i = 0; i < 16; i++) rows[(i / 4) | 0][i % 4] = b[a.order[i]];
}

function aesShiftCon(a, rows) {
  const old = rows.map((r) => r.slice());
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) rows[i][j] = old[i][a.con2[j]];
  }
}

function aesSubKeys(a, from) {
  return a.keys.slice(from, from + 4);
}

function aesBlock(a, value) {
  const rows = aesMatrix(value);
  aesAddCon(a, rows, aesSubKeys(a, 0));
  for (let i = 1; i < 3; i++) {
    aesSub(a, rows);
    aesShift(a, rows);
    if (i === 1) {
      aesShiftCon(a, rows);
      aesMix(rows);
    }
    aesAddCon(a, rows, aesSubKeys(a, i * 4));
  }
  aesAdd(rows, aesSubKeys(a, 4));
  return aesFlat(rows);
}


function aesEncrypt(a, data, iv) {
  const plaintext = Buffer.alloc(32);
  for (let i = 0; i < 31; i++) {
    const at = i * 8;
    const n0 = (aesSrc(data, at) >> 4) & 2;
    const n1 = n0 | (aesSrc(data, at + 1) & 64);
    const n2 = n1 | ((aesSrc(data, at + 2) >> 2) & 1);
    const n3 = n2 | ((aesSrc(data, at + 3) << 3) & 128);
    const n4 = n3 | ((aesSrc(data, at + 4) >> 1) & 4);
    const n5 = n4 | ((aesSrc(data, at + 5) << 3) & 16);
    const n6 = n5 | ((aesSrc(data, at + 6) << 5) & 32);
    plaintext[i] = n6 | ((aesSrc(data, at + 7) >> 4) & 8);
  }
  plaintext[31] = 1;
  const blocks = [];
  let previous = Buffer.from(iv);
  for (let i = 0; i < plaintext.length; i += 16) {
    const value = aesBlock(a, xorBytes(plaintext.subarray(i, i + 16), previous));
    blocks.push(value);
    previous = value;
  }
  const key = concat(...blocks);
  const out = Buffer.from(data);
  for (let i = 0; i < 31; i++) {
    const at = i * 8;
    const k = key[i];
    aesPut(out, at, (aesSrc(out, at) & 0xdf) | ((k << 4) & 32));
    aesPut(out, at + 1, (aesSrc(out, at + 1) & 0xbf) | (k & 64));
    aesPut(out, at + 2, (aesSrc(out, at + 2) & 0xfb) | ((k << 2) & 4));
    aesPut(out, at + 3, (aesSrc(out, at + 3) & 0xef) | ((k >>> 3) & 16));
    aesPut(out, at + 4, (aesSrc(out, at + 4) & 0xf7) | ((k + k) & 8));
    aesPut(out, at + 5, (aesSrc(out, at + 5) & 0xfd) | ((k >>> 3) & 2));
    aesPut(out, at + 6, (aesSrc(out, at + 6) & 0xfe) | ((k >>> 5) & 1));
    aesPut(out, at + 7, (aesSrc(out, at + 7) & 0x7f) | ((k << 4) & 128));
  }
  return concat(key.subarray(key.length - 1), out);
}




function xmxor(data, key) {
  const encoded = Buffer.alloc(data.length);
  for (let i = 0; i < data.length; i++) {
    const at = (i * 4) & 28;
    const d0 = srcB(key, at);
    const d1 = srcB(key, at + 1);
    let d2 = (rotl8(srcB(data, i)) + d0) >>> 0;
    d2 = (~d2 ^ d1) >>> 0;
    d2 = rotl8_3(d2 & 0xff);
    d2 = (d2 + d1) & 255;
    d2 = (d2 ^ d0) & 255;
    encoded[data.length - i - 1] = ~d2 & 255;
  }
  const n = encoded.length;
  const last = encoded[n - 1] ^ encoded[n - 2];
  const first = encoded[0];
  encoded[0] = ((~last >>> 0) + first) & 255;
  encoded[1] = ((encoded[0] ^ encoded[n - 1] ^ 254) + encoded[1]) & 255;
  encoded[2] = (encoded[2] + ((((last - first) >>> 0) ^ rotl8_3(encoded[1])) ^ 2)) & 255;
  for (let i = 0; i < n - 4; i++) {
    const temp = (rotl8_3(encoded[i + 2]) ^ encoded[i + 1] ^ (i + 3)) >>> 0;
    encoded[i + 3] = ((~temp >>> 0) + encoded[i + 3]) & 255;
  }
  encoded[n - 1] = encoded[n - 1] ^ encoded[n - 2];
  let sum = 0;
  for (let i = 0; i < n - 1; i++) sum += encoded[i + 1];
  encoded[0] = ((encoded[0] ^ encoded[1]) + sum) & 255;
  return encoded;
}


function keyHash(signKey, random) {
  const r = random >>> 0;
  const hash = sm3(concat(signKey, le32(r), signKey));
  const d1 = (r >>> 16) & 255;
  let d2 = ((d1 << 11) | (r >>> 24)) ^ (d1 >>> 5) ^ d1;
  d2 = ~d2 >>> 0;
  return [hash, le32(d2)];
}


function rndInt(n) {
  return n === 0 ? 0 : randomInt(n);
}


function rndInt32() {
  return randomBytes(4).readInt32BE(0);
}


function deviceProto(deviceID) {
  return proto([
    [1, 1, 'sint'], [2, 2, 'sint'], [3, '8662'], [4, deviceID],
    [5, processNonce], [6, '!noperm!'], [7, -888888, 'sint'], [8, -888888, 'sint'],
    [9, 3, 'sint'], [10, -888888, 'sint'], [11, '!notset!'],
    [12, 'Asia/Shanghai,8'], [13, 'zh_CN'], [14, 4, 'sint'],
    [16, 0, 'float'], [17, 0, 'float'], [18, 0, 'float'], [19, 0, 'float'],
    [20, 0, 'float'], [21, 0, 'float'], [22, '16'], [23, 41, 'sint'],
    [24, 36, 'sint'], [25, processStarted, 'sint'], [26, processStarted, 'sint'],
    [27, processStarted, 'sint'], [28, processStarted, 'sint'], [29, -1, 'sint'],
    [30, '25053RT47C'], [31, 'Redmi'], [32, '25053RT47C'], [33, '25053RT47C'],
    [34, 'Xiaomi'], [35, 'Redmi'], [36, 'Redmi'], [38, 31, 'sint'],
  ]);
}


function buildMedusa(rawURL, body, khronos, deviceID, version) {
  const bodyMd5 = body.length > 0 ? md5Of(body) : Buffer.alloc(16);
  const query = queryOf(rawURL);
  const querySm3 = sm3(Buffer.from(query, 'utf8'));
  const ts = le32(khronos >>> 0);
  const queryBodyTs = hashF13(querySm3, bodyMd5, ts, khronos);

  const messageRand = randomBytes(4);
  const messageRandU = readLe32(messageRand, 0);
  const envLaunch = 100 + rndInt(21);
  const envPid = 10001 + rndInt(2000);
  const env = proto([
    [1, envLaunch, 'sint'], [2, 146331399, 'sint'], [3, 146331396, 'sint'],
    [5, 7, 'sint'], [6, 'v04.06.04.03-bugfix'], [7, envPid, 'sint'],
    [12, deviceProto(deviceID), 'message'],
    [13, proto([[1, Math.floor(Date.now() / 1000), 'sint'], [2, -2, 'sint'], [4, 200, 'sint']]), 'message'],
    [14, version],
  ]);
  const queryHash = sm3(concat(Buffer.from(query, 'utf8'), bodyMd5, Buffer.from('none')));

  const nested = proto([[1, 111, 'sint'], [2, 10, 'sint'], [3, 694367, 'sint'], [5, 586952199, 'sint']]);
  const message = proto([
    [1, medusaMagic16, 'bytes'], [2, 3, 'sint'], [3, messageRandU, 'sint'],
    [4, '8662'], [5, deviceID], [6, '1588093228'], [7, version],
    [8, 'v04.06.04-ml-android'], [9, 67503104, 'sint'],
    [10, medusaMagic8, 'bytes'], [12, khronos, 'sint'],
    [13, queryBodyTs, 'bytes'], [14, querySm3.subarray(0, 6), 'bytes'],
    [15, nested, 'message'], [16, processNonce], [17, khronos, 'sint'],
    [19, queryHash, 'bytes'], [20, 'none'], [21, 312, 'sint'],
    [23, env, 'message'],
    [24, '{"cmr":16777216,"cmr2":16777216,"un_h":1879194040,"vpn":0,"kd":0,"fkd":3672518972,"pd":-1872573247,"dyn":"","do":0,"tk":true}'],
  ]);

  const random = rndInt32();
  const [hash, seed] = keyHash(medusaSignKey, random);
  let transformed = xmxor(message, hash);
  transformed = concat(medusaMagic8, transformed);
  
  for (let i = 0, j = transformed.length - 1; i < j; i++, j--) {
    const t = transformed[i];
    transformed[i] = transformed[j];
    transformed[j] = t;
  }
  for (let i = 0; i < transformed.length; i++) transformed[i] ^= seed[~i & 3];
  const check = (((querySm3[0] & 63) << 14) | 0x18000001 | ((queryBodyTs[0] & 63) << 8)) >>> 0;
  const xmRand = rndInt32();
  const packed = concat(
    Buffer.from([0x35]),
    le32(xmRand >>> 0),
    le32(check),
    transformed,
    Buffer.from([(random >>> 16) & 255, (random >>> 24) & 255]),
  );
  const a = newAesV3(medusaAESKey, khronos);
  const encrypted = aesEncrypt(a, packed, medusaAESIV);
  const versionBytes = Buffer.from('03000000f7e85ffad7d7dc3bd62ac87057cf6118', 'hex');
  const prefix = Buffer.alloc(20);
  const kh = khronos >>> 0;
  for (let i = 0; i < 20; i += 4) putLe32(prefix, i, readLe32(versionBytes, i) ^ kh);
  return concat(
    prefix,
    Buffer.from([random & 255, (random >>> 8) & 255, 0, 1]),
    encrypted,
  ).toString('base64');
}


function helios(khronos) {
  return heliosWith(khronos, rndInt32());
}

function heliosWith(khronos, random) {
  const digest = md5Of(concat(le32(random >>> 0), Buffer.from('8662')));
  const ascii = Buffer.from(digest.toString('hex'), 'ascii');
  const words = [readU64Le(ascii, 0), readU64Le(ascii, 8), readU64Le(ascii, 16), readU64Le(ascii, 24)];

  
  const queue = [words[2], words[3]];
  let b0 = words[0];
  let b8 = words[1];
  const table = new Array(35).fill(0n);
  table[0] = words[0];
  for (let i = 0; i < 34; i++) {
    let x8 = (rotr64(b8, 8) + b0) & U64;
    x8 ^= BigInt(i);
    queue.push(x8);
    x8 = (x8 ^ rotr64(b0, 61)) & U64;
    table[i + 1] = x8;
    b0 = x8;
    b8 = queue[0];
    queue.shift();
  }
  const tb = Buffer.from(`${khronos}-1588093228-8662`, 'ascii');
  const padLen = Math.floor((tb.length + 1 + 15) / 16) * 16;
  const fill = (16 - (tb.length % 16)) & 0xff;
  const pad = Buffer.alloc(padLen, fill);
  tb.copy(pad, 0);

  let all = le32(random >>> 0);
  for (let at = 0; at < pad.length; at += 16) {
    let a = readU64Le(pad, at);
    let b = readU64Le(pad, at + 8);
    for (let i = 0; i < 34; i++) {
      b = table[i] ^ ((a + rotr64(b, 8)) & U64);
      a = b ^ rotr64(a, 61);
    }
    const block = Buffer.alloc(16);
    putU64Le(block, 0, a);
    putU64Le(block, 8, b);
    all = concat(all, block);
  }
  return all.toString('base64');
}



function queryOf(rawURL) {
  const i = rawURL.indexOf('?');
  return i < 0 ? '' : rawURL.slice(i + 1);
}

function paramOf(query, key, fallback) {
  for (const kv of query.split('&')) {
    const eq = kv.indexOf('=');
    if (eq <= 0) continue;
    if (kv.slice(0, eq) === key) {
      const v = kv.slice(eq + 1);
      if (v.length > 0) return v;
    }
  }
  return fallback;
}


export function BranchOf(rawURL, body, khronos) {
  const bodyBuf = toBodyBuffer(body);
  const bodyMd5 = bodyBuf.length > 0 ? md5Of(bodyBuf) : Buffer.alloc(16);
  const q = sm3(Buffer.from(queryOf(rawURL), 'utf8'));
  const iv = getIv(getIv(getIv(0x20230928, q), bodyMd5), le32(Number(khronos) >>> 0));
  const low = iv & 15;
  return low - ((low * 171) >> 9) * 3;
}

function toBodyBuffer(body) {
  if (body == null) return Buffer.alloc(0);
  if (Buffer.isBuffer(body)) return body;
  if (typeof body === 'string') return Buffer.from(body, 'utf8');
  return Buffer.from(body);
}



export function Sign(rawURL, body, khronos) {
  let ts = Math.floor(Number(khronos));
  if (!Number.isFinite(ts) || ts <= 0) ts = Math.floor(Date.now() / 1000);
  const bodyBuf = toBodyBuffer(body);
  const gorgonRandom = rndInt(65536);
  const query = queryOf(rawURL);
  return {
    'x-gorgon': xGorgon(query, bodyBuf, ts, gorgonRandom),
    'x-khronos': String(ts),
    'x-ladon': be32(ts >>> 0).toString('base64'),
    'x-argus': le32(ts >>> 0).toString('base64'),
    'x-helios': helios(ts),
    'x-medusa': buildMedusa(rawURL, bodyBuf, ts,
      paramOf(query, 'device_id', '0'),
      paramOf(query, 'version_name', '7.1.3.32')),
  };
}


export const __test = {
  sm3,
  md5Of,
  getIv,
  sumMd5,
  hashF13,
  md5SumV3,
  branch2SV,
  xGorgon,
  heliosWith,
  keyHash,
  xmxor,
  newAesV3,
  aesBlock,
  aesEncrypt,
  le32,
  be32,
  queryOf,
  paramOf,
  deviceProto,
  proto,
  setProcessState(nonce, started) {
    processNonce = nonce;
    processStarted = started;
  },
};

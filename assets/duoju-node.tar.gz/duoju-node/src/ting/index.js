

import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { BrowserClient } from '../core/client.js';
import { TingMedia, externalBase } from './media.js';
import { createRegistry, catOrDefault, proxyPlayURL } from './registry.js';
import {
  initTeen, teenEnabled, setTeenEnabled, teenBlocked, isAdultProvider,
  teenPlaceholderCard, teenPlaceholderDetail, loopbackOnly, teenSameOrigin, teenScheme,
} from './teen.js';
import { AppVersion, atoiDefault, firstNonEmpty, setDataDir } from './client.js';
import { setupDNS } from './dns.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const webRoot = path.join(__dirname, '../../web/ting');




function goJSONStringify(v) {
  return JSON.stringify(v)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}


function writeJSON(res, resp) {
  const out = { code: resp.code };
  if (resp.msg) out.msg = resp.msg;
  if (resp.data !== undefined && resp.data !== null) out.data = resp.data;
  const body = goJSONStringify(out) + '\n';
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cache-Control', 'no-store');
  res.send(body);
}


function writeError(res, status, msg) {
  const body = goJSONStringify({ code: status, msg }) + '\n';
  res.status(status);
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.send(body);
}

function writeRawJSON(res, obj) {
  const body = goJSONStringify(obj) + '\n';
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.send(body);
}

function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`请求超时(${ms}ms)`)), ms);
  });
  return Promise.race([Promise.resolve(promise), timeout]).finally(() => clearTimeout(timer));
}


function sortSearchCards(cards, wd) {
  if (cards.length < 2 || String(wd || '').trim() === '') return;
  const kw = String(wd).toLowerCase();
  cards.sort((a, b) => {
    const mi = String(a.vod_name || '').toLowerCase().includes(kw);
    const mj = String(b.vod_name || '').toLowerCase().includes(kw);
    if (mi && !mj) return -1;
    if (!mi && mj) return 1;
    return 0;
  });
}

const rootAssetExt = {
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.json': 'application/json; charset=utf-8',
};

export class TingServer {
  
  constructor({ dataDir } = {}) {
    if (dataDir) setDataDir(dataDir);
    initTeen();
    setupDNS();
    this.port = 0;
    this.client = new BrowserClient();
    this.media = new TingMedia(this.client);
    this.reg = createRegistry(this.client, this.media);
    this.app = express();
    this.app.disable('x-powered-by');
    this.setupRoutes();
  }

  
  setupRoutes() {
    const app = this.app;
    const s = this;

    app.use((req, res, next) => {
      const start = Date.now();
      res.on('finish', () => {
        if (req.path.startsWith('/media')) return;
        const ms = ((Date.now() - start) / 1e6).toFixed(0);
        console.log(`${req.method} ${req.path} ${ms}ms`);
      });
      next();
    });

    app.all('/api/platform', (req, res) => s.handlePlatform(req, res));
    app.all('/api/cats', (req, res) => s.handleCats(req, res));
    app.all('/api/home', (req, res) => s.handleList(req, res));
    app.all('/api/category', (req, res) => s.handleList(req, res));
    app.all('/api/search', (req, res) => s.handleSearch(req, res));
    app.all('/api/detail', (req, res) => s.handleDetail(req, res));
    app.all('/api/play', (req, res) => s.handlePlay(req, res));

    app.all('/web/api/teen', (req, res) => s.handleWebTeen(req, res));

    
    app.use('/web', express.static(webRoot, { fallthrough: true }));

    app.all('/media/audio', (req, res) => this.media.handleAudio(req, res));
    app.all('/media', (req, res) => this.media.handleAudio(req, res));
    app.all('/media/img', (req, res) => this.media.handleImg(req, res));

    app.all('/internal/hello', (req, res) => s.handleHello(req, res));

    
    app.use((req, res) => s.handleRoot(req, res));
  }

  handleHello(req, res) {
    if (!loopbackOnly(req)) {
      res.status(403).setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.send('forbidden');
      return;
    }
    
    writeRawJSON(res, { app: 'duoju-ting', ok: true, pid: process.pid, port: this.port, version: AppVersion });
  }

  handleRoot(req, res) {
    if (req.path !== '/') {
      if (s_serveRootAsset(req, res)) return;
      writeError(res, 404, 'not found');
      return;
    }
    const accept = String(req.headers.accept || '').toLowerCase();
    if (accept.includes('text/html')) {
      s_serveIndex(req, res);
      return;
    }
    
    writeJSON(res, {
      code: 200,
      msg: 'duoju-ting ok',
      data: {
        api: ['/api/platform', '/api/cats', '/api/home', '/api/category', '/api/search', '/api/detail', '/api/play', '/media/audio', '/media/img'],
        name: '多聚听书后台',
        port: this.port,
        version: AppVersion,
        web: '/web/',
      },
    });
  }

  handlePlatform(req, res) {
    const all = this.reg.platformList();
    const teen = teenEnabled();
    const visible = [];
    const adults = [];
    let blocked = 0;
    for (const p of all) {
      if (isAdultProvider(this.reg.provider(p.key))) {
        const vp = { ...p };
        if (teen) {
          blocked++;
          vp.name = '🔞 ' + p.name;
        }
        adults.push(vp);
        continue;
      }
      visible.push(p);
    }
    visible.push(...adults);
    
    writeJSON(res, { code: 200, data: { blocked, platforms: visible, teen } });
  }

  handleCats(req, res) {
    const key = String(req.query.plat || '').trim();
    const p = this.reg.provider(key);
    if (!p) {
      writeError(res, 400, '未知平台: ' + key);
      return;
    }
    if (teenBlocked(p)) {
      writeJSON(res, { code: 200, data: { cats: [], plat: key, teen: true } });
      return;
    }
    writeJSON(res, { code: 200, data: { cats: p.cats(), plat: key, teen: false } });
  }

  async handleList(req, res) {
    let key = String(req.query.plat || '').trim();
    if (key === '') key = 'kw';
    const p = this.reg.provider(key);
    if (!p) {
      writeError(res, 400, '未知平台: ' + key);
      return;
    }
    const cat = catOrDefault(p, String(req.query.cat || ''));
    const page = atoiDefault(String(req.query.page || ''), 1);
    if (teenBlocked(p)) {
      writeJSON(res, {
        code: 200,
        data: { category: cat, list: [teenPlaceholderCard(key)], page, plat: key, teen: true },
      });
      return;
    }
    try {
      const cards = await withTimeout(p.list(cat, page), 45000);
      writeJSON(res, { code: 200, data: { category: cat, list: cards, page, plat: key } });
    } catch (err) {
      writeError(res, 502, '抓取列表失败: ' + err.message);
    }
  }

  async handleSearch(req, res) {
    const wd = String(req.query.wd || '').trim();
    if (wd === '') {
      writeError(res, 400, '缺少关键词');
      return;
    }
    const page = atoiDefault(String(req.query.page || ''), 1);
    const platRaw = String(req.query.plat || '');
    if (!('plat' in req.query) || platRaw.trim() === '') {
      await this.aggregateSearch(req, res, wd, page, String(req.query.plats || ''));
      return;
    }
    const key = platRaw.trim();
    const p = this.reg.provider(key);
    if (!p) {
      writeError(res, 400, '未知平台: ' + key);
      return;
    }
    if (teenBlocked(p)) {
      writeJSON(res, {
        code: 200,
        data: { list: [teenPlaceholderCard(key)], page, plat: key, teen: true, wd },
      });
      return;
    }
    try {
      const cards = await withTimeout(p.search(wd, page), 60000);
      sortSearchCards(cards, wd);
      writeJSON(res, { code: 200, data: { list: cards, page, plat: key, wd } });
    } catch (err) {
      writeError(res, 502, '搜索失败: ' + err.message);
    }
  }

  async aggregateSearch(req, res, wd, page, plats) {
    let all = this.reg.providers();
    plats = String(plats || '').trim();
    if (plats !== '') {
      const want = new Set(
        plats.split(',').map((k) => k.trim()).filter((k) => k !== '')
      );
      all = all.filter((p) => want.has(p.key()));
    }
    if (all.length === 0) {
      writeJSON(res, {
        code: 200,
        data: { list: [], page, platforms: [], totalPlatforms: 0, wd },
      });
      return;
    }
    
    const results = await Promise.all(
      all.map(async (p) => {
        if (teenBlocked(p)) return null;
        try {
          const cards = await withTimeout(p.search(wd, page), 12000);
          if (Array.isArray(cards) && cards.length > 0) return cards;
          return null;
        } catch {
          return null;
        }
      })
    );

    const merged = [];
    const hitPlats = [];
    for (let i = 0; i < all.length; i++) {
      const cards = results[i];
      if (!cards) continue;
      hitPlats.push(all[i].key());
      for (const c of cards) {
        if (String(c.vod_pic || '').trim() === '' && String(c.vod_name || '').trim() === '') continue;
        const cc = { ...c };
        cc.vod_plat = all[i].key();
        merged.push(cc);
      }
    }

    sortSearchCards(merged, wd);
    writeJSON(res, {
      code: 200,
      data: { list: merged, page, platforms: hitPlats, totalPlatforms: all.length, wd },
    });
  }

  async handleDetail(req, res) {
    const id = String(req.query.id || '').trim();
    if (id === '') {
      writeError(res, 400, '缺少 id');
      return;
    }
    let key = String(req.query.plat || '').trim();
    if (key === '') key = 'kw';
    const p = this.reg.provider(key);
    if (!p) {
      writeError(res, 400, '未知平台: ' + key);
      return;
    }
    if (teenBlocked(p)) {
      writeJSON(res, { code: 200, data: teenPlaceholderDetail(key) });
      return;
    }
    try {
      const detail = await withTimeout(p.detail(id), 60000);
      detail.vod_class = firstNonEmpty(detail.vod_class, p.name());
      writeJSON(res, { code: 200, data: detail });
    } catch (err) {
      writeError(res, 502, '抓取详情失败: ' + err.message);
    }
  }

  async handlePlay(req, res) {
    const ref = String(req.query.url || '').trim();
    if (ref === '') {
      writeError(res, 400, '缺少 url（章节凭证）');
      return;
    }
    let key = String(req.query.plat || '').trim();
    if (key === '') key = 'kw';
    const p = this.reg.provider(key);
    if (!p) {
      writeError(res, 400, '未知平台: ' + key);
      return;
    }
    if (teenBlocked(p) || String(ref).trim().startsWith(teenScheme)) {
      writeJSON(res, { code: 200, data: { referer: '', src: '', teen: true, url: '' } });
      return;
    }
    let result;
    try {
      result = await withTimeout(p.play(ref), 45000);
    } catch (err) {
      writeError(res, 502, '解析播放地址失败: ' + err.message);
      return;
    }
    const base = externalBase(req);
    let playURL = proxyPlayURL(base, result);
    if (result.local) {
      playURL = base + result.local;
    }
    writeJSON(res, { code: 200, data: { referer: result.referer, src: result.src, url: playURL } });
  }

  
  async handleWebTeen(req, res) {
    if (!loopbackOnly(req)) {
      writeError(res, 403, '仅本机可访问');
      return;
    }
    if (req.method === 'GET') {
      writeJSON(res, { code: 200, data: { teen: teenEnabled() } });
      return;
    }
    if (req.method !== 'POST') {
      writeError(res, 405, 'method not allowed');
      return;
    }
    if (!teenSameOrigin(req)) {
      writeError(res, 403, '来源不合法');
      return;
    }
    let body = '';
    try {
      for await (const ch of req) body += ch;
    } catch {}
    let payload = null;
    try {
      payload = JSON.parse(body);
    } catch {
      payload = null;
    }
    if (payload === null || typeof payload !== 'object') {
      writeError(res, 400, '参数错误');
      return;
    }
    const action = payload.action;
    if (action === 'disable') {
      setTeenEnabled(false);
      writeJSON(res, { code: 200, data: { teen: false }, msg: '青少年模式已关闭' });
    } else if (action === 'enable') {
      setTeenEnabled(true);
      writeJSON(res, { code: 200, data: { teen: true }, msg: '青少年模式已开启' });
    } else {
      writeError(res, 400, '未知 action');
    }
  }
}


function s_serveRootAsset(req, res) {
  const name = req.path.replace(/^\//, '');
  if (name === '' || name.includes('..')) return false;
  const ct = rootAssetExt[path.extname(name).toLowerCase()];
  if (!ct) return false;
  let data;
  try {
    data = fs.readFileSync(path.join(webRoot, name));
  } catch {
    return false;
  }
  res.setHeader('Content-Type', ct);
  res.setHeader('Cache-Control', 'public, max-age=600');
  res.send(data);
  return true;
}


function s_serveIndex(req, res) {
  let data;
  try {
    data = fs.readFileSync(path.join(webRoot, 'index.html'));
  } catch {
    writeError(res, 500, '前端资源缺失');
    return;
  }
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache');
  res.send(data);
}

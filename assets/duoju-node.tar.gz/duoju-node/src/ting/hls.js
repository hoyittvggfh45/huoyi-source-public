


import { firstNonEmpty } from './client.js';

export const defaultMediaUA = 'Mozilla/5.0 (Linux; Android 13; M2012K11AC) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

export function hlsIsPlaylist(u) {
  const clean = String(u || '').split('?')[0];
  return clean.toLowerCase().endsWith('.m3u8');
}


export function proxyAudioURL(raw, ref, ua) {
  const parts = [];
  if (ref) parts.push(`ref=${encodeURIComponent(ref).replace(/[!'()*]|%20/g, (m) => (m === '%20' ? '+' : '%' + m.charCodeAt(0).toString(16).toUpperCase()))}`);
  parts.push(`u=${encodeURIComponent(raw).replace(/[!'()*]|%20/g, (m) => (m === '%20' ? '+' : '%' + m.charCodeAt(0).toString(16).toUpperCase()))}`);
  if (ua) parts.push(`ua=${encodeURIComponent(ua).replace(/[!'()*]|%20/g, (m) => (m === '%20' ? '+' : '%' + m.charCodeAt(0).toString(16).toUpperCase()))}`);
  return '?' + parts.join('&');
}

export async function fetchUpstream(client, target, ref, ua, rng, timeoutMs = 30 * 60 * 1000) {
  const headers = {
    'User-Agent': ua,
    Accept: '*/*',
    'Accept-Encoding': 'identity',
  };
  if (ref) headers.Referer = ref;
  if (rng) headers.Range = rng;
  return client.do('GET', target, headers, { media: true, timeoutMs });
}


export async function readLimited(stream, limit) {
  const chunks = [];
  let size = 0;
  for await (const chunk of stream) {
    chunks.push(chunk);
    size += chunk.length;
    if (size > limit) break;
  }
  return Buffer.concat(chunks);
}


export async function serveHLS(client, res, target, ref, ua) {
  let resp;
  try {
    resp = await fetchUpstream(client, target, ref, ua, '');
  } catch {
    return httpPlainError(res, 502, 'upstream error');
  }
  if (resp.status < 200 || resp.status >= 300) {
    try { resp.stream.destroy?.(); } catch {}
    return httpPlainError(res, resp.status, `upstream HTTP ${resp.status}`);
  }
  let body;
  try {
    body = await readLimited(resp.stream, 4 * 1024 * 1024);
  } catch {
    return httpPlainError(res, 502, 'upstream read error');
  }
  let base = null;
  try { base = new URL(target); } catch { base = null; }

  const rewriteTagURIs = (line, prefix) => {
    const idx = line.indexOf(prefix);
    if (idx < 0) return line;
    const head = line.slice(0, idx + prefix.length);
    const rest = line.slice(idx + prefix.length);
    const end = rest.indexOf('"');
    if (end < 0) return line;
    const raw = rest.slice(0, end);
    if (raw === '') return line;
    let abs = raw;
    if (!abs.startsWith('http://') && !abs.startsWith('https://') && base) {
      try { abs = new URL(raw, base).toString(); } catch {}
    }
    return head + proxyAudioURL(abs, ref, ua) + rest.slice(end);
  };

  const out = [];
  for (const line of body.toString('utf8').split('\n')) {
    const trimmed = line.trim();
    if (trimmed === '') {
      out.push(line);
      continue;
    }
    if (trimmed.startsWith('#')) {
      let fixed = rewriteTagURIs(line, 'URI="');
      fixed = rewriteTagURIs(fixed, 'AUDIO="');
      fixed = rewriteTagURIs(fixed, 'VIDEO="');
      out.push(fixed);
      continue;
    }
    let abs = trimmed;
    if (!abs.startsWith('http://') && !abs.startsWith('https://') && base) {
      let parsed = null;
      try { parsed = new URL(trimmed, base); } catch { parsed = null; }
      if (parsed) abs = parsed.toString();
      else abs = `${base.protocol}//${base.host}${trimmed}`;
    }
    out.push(proxyAudioURL(abs, ref, ua));
  }
  res.setHeader('Content-Type', 'application/vnd.apple.mpegurl; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Range');
  res.send(out.join('\n'));
}

export function httpPlainError(res, status, msg) {
  res.status(status);
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.send(msg);
}


export function uaOr(u) {
  return firstNonEmpty(u, defaultMediaUA);
}

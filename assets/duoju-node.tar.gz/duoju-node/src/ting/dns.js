


import dns from 'node:dns';
import { execFile } from 'node:child_process';

const fallbackDNSServers = ['223.5.5.5', '119.29.29.29', '114.114.114.114'];

let dnsInstalled = false;
let dnsServersList = [];
let patched = false;
let origLookup = null;

function withTimeout(promise, ms) {
  return Promise.race([
    Promise.resolve(promise),
    new Promise((_, reject) => setTimeout(() => reject(new Error('dns probe timeout')), ms)),
  ]);
}


async function probeResolver(resolver) {
  if (!resolver) return false;
  try {
    const addrs = await withTimeout(resolver.resolve4('www.baidu.com'), 2000);
    return Array.isArray(addrs) && addrs.length > 0;
  } catch {
    return false;
  }
}

function currentDNSServers() {
  return dnsServersList;
}


function detectDNSServers() {
  return new Promise((resolve) => {
    const out = [];
    const props = ['net.dns1', 'net.dns2'];
    let idx = 0;
    const next = () => {
      if (idx >= props.length) {
        resolve(out.concat(fallbackDNSServers));
        return;
      }
      const prop = props[idx++];
      execFile('getprop', [prop], { timeout: 1500 }, (err, stdout) => {
        if (!err) {
          const s = String(stdout || '').trim();
          if (s && !s.includes(' ')) out.push(s.includes(':') ? s : s + ':53');
        }
        next();
      });
    };
    try { next(); } catch { resolve(out.concat(fallbackDNSServers)); }
  });
}

async function installFallback() {
  dnsServersList = await detectDNSServers();
  const r = new dns.promises.Resolver();
  r.setServers(dnsServersList.slice());
  if (!(await probeResolver(r))) return false;
  installLookupPatch(r);
  return true;
}


function installLookupPatch(resolver) {
  if (patched) return;
  origLookup = dns.lookup;
  patched = true;
  const lookup = function (hostname, options, callback) {
    if (typeof options === 'function') {
      callback = options;
      options = {};
    }
    origLookup(hostname, options, (err, ...args) => {
      if (!err) return callback(null, ...args);
      const family = (options && options.family) || 0;
      const finish = (addresses) => {
        if (!addresses.length) return callback(err);
        const all = family === 6 ? addresses.filter((a) => a.includes(':')) : family === 4 ? addresses.filter((a) => !a.includes(':')) : addresses;
        const pick = all.length ? all : addresses;
        const address = pick[0];
        if (family === 0 && options && options.all) return callback(null, pick.map((a) => ({ address: a, family: a.includes(':') ? 6 : 4 })));
        callback(null, address, address.includes(':') ? 6 : 4);
      };
      const jobs = [];
      if (family !== 6) jobs.push(resolver.resolve4(hostname).catch(() => []));
      if (family !== 4) jobs.push(resolver.resolve6(hostname).catch(() => []));
      Promise.all(jobs).then((rs) => finish(rs.flat())).catch(() => callback(err));
    });
  };
  try {
    dns.lookup = lookup;
  } catch {
    patched = false;
  }
}

function removeLookupPatch() {
  if (!patched) return;
  try { dns.lookup = origLookup; } catch {}
  patched = false;
}


export function setupDNS() {
  if (dnsInstalled) return;
  dnsInstalled = true;
  init();
}

async function init() {
  if (await probeResolver(new dns.promises.Resolver())) {
    startWatchdog();
    return;
  }
  if (await installFallback()) {
    startWatchdog();
  }
}


function startWatchdog() {
  const timer = setInterval(() => {
    watchdogTick().catch(() => {});
  }, 3 * 60 * 1000);
  if (typeof timer.unref === 'function') timer.unref();
}

async function watchdogTick() {
  const systemOK = await probeResolver(new dns.promises.Resolver());
  if (patched) {
    if (systemOK) {
      removeLookupPatch();
      return;
    }
    dnsServersList = [];
    await installFallback();
  } else if (!systemOK) {
    await installFallback();
  }
}

export { currentDNSServers };

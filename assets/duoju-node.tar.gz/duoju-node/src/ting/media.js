

import { pipeline } from 'node:stream/promises';
import { defaultUA, firstNonEmpty } from './client.js';
import { hlsIsPlaylist, serveHLS, httpPlainError, readLimited, uaOr } from './hls.js';

const HOP_HEADERS = new Set([
  'connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization',
  'te', 'trailer', 'transfer-encoding', 'upgrade', 'host',
]);


function detectContentType(b) {
  if (b.length >= 4 && b[0] === 0x00 && b[1] === 0x00 && b[2] === 0x01 && b[3] === 0x00) return 'image/x-icon';
  if (b.length >= 2 && b[0] === 0x42 && b[1] === 0x4d) return 'image/bmp';
  if (b.length >= 6 && (b.toString('latin1', 0, 6) === 'GIF87a' || b.toString('latin1', 0, 6) === 'GIF89a')) return 'image/gif';
  if (b.length >= 12 && b.toString('latin1', 0, 4) === 'RIFF' && b.toString('latin1', 8, 12) === 'WEBP') return 'image/webp';
  if (b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 && b[4] === 0x0d && b[5] === 0x0a && b[6] === 0x1a && b[7] === 0x0a) return 'image/png';
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg';
  return 'application/octet-stream';
}

class ImgCache {
  constructor(budget) {
    this.items = new Map(); 
    this.budget = budget;
    this.used = 0;
  }

  get(key) {
    const e = this.items.get(key);
    if (!e) return null;
    if (Date.now() > e.expiresAt) {
      this.items.delete(key);
      this.used -= e.data.length;
      return null;
    }
    return e;
  }

  put(key, ct, data) {
    if (data.length > this.budget) return;
    const old = this.items.get(key);
    if (old) this.used -= old.data.length;
    this.used += data.length;
    while (this.used > this.budget && this.items.size > 0) {
      const k = this.items.keys().next().value;
      const e = this.items.get(k);
      this.items.delete(k);
      this.used -= e.data.length;
    }
    this.items.set(key, { ct, data, expiresAt: Date.now() + 6 * 3600 * 1000 });
  }
}

export class TingMedia {
  constructor(client) {
    this.client = client;
    this.imgCache = new ImgCache(8 * 1024 * 1024);
  }

  
  static normalizeTarget(raw) {
    let target = String(raw || '').trim();
    if (target.startsWith('//')) target = 'https:' + target;
    return target;
  }

  static validTarget(target) {
    let u;
    try { u = new URL(target); } catch { return null; }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    return u;
  }

  
  async handleAudio(req, res) {
    const q = req.query;
    const target = TingMedia.normalizeTarget(q.u);
    if (target === '') return httpPlainError(res, 400, 'missing u');
    if (!TingMedia.validTarget(target)) return httpPlainError(res, 400, 'bad url');
    if (hlsIsPlaylist(target)) {
      return serveHLS(this.client, res, target, String(q.ref || ''), uaOr(q.ua));
    }

    const headers = {
      'User-Agent': uaOr(q.ua),
      Accept: '*/*',
      'Icy-MetaData': '1',
    };
    if (q.ref) headers.Referer = String(q.ref);
    if (req.headers.range) headers.Range = req.headers.range;

    let resp;
    try {
      resp = await this.client.do('GET', target, headers, { media: true, timeoutMs: 30 * 60 * 1000 });
    } catch (err) {
      return httpPlainError(res, 502, 'upstream error: ' + (err && err.message ? err.message : String(err)));
    }

    for (const [k, v] of Object.entries(resp.headers || {})) {
      if (HOP_HEADERS.has(k)) continue;
      try { res.setHeader(k, v); } catch {}
    }
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Accept-Ranges', 'bytes');
    res.status(resp.status);
    try {
      await pipeline(resp.stream, res);
    } catch {}
  }

  
  async handleImg(req, res) {
    const q = req.query;
    const target = TingMedia.normalizeTarget(q.u);
    if (target === '') return httpPlainError(res, 400, 'missing u');
    const u = TingMedia.validTarget(target);
    if (!u) return httpPlainError(res, 400, 'bad url');

    const cached = this.imgCache.get(target);
    if (cached) {
      res.setHeader('Content-Type', cached.ct);
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cache-Control', 'public, max-age=21600');
      res.status(200);
      res.send(cached.data);
      return;
    }

    let body = null;
    let ct = '';
    let lastErr = null;
    for (let attempt = 0; attempt < 2; attempt++) {
      if (attempt === 1) await new Promise((r) => setTimeout(r, 500));
      const headers = {
        'User-Agent': uaOr(q.ua),
        Accept: 'image/avif,image/webp,image/png,image/jpeg,image/*',
        'Accept-Encoding': 'identity',
      };
      if (q.ref) headers.Referer = String(q.ref);
      else if (u.host) headers.Referer = `${u.protocol}//${u.host}/`;

      let resp;
      try {
        resp = await this.client.do('GET', target, headers, { media: true, timeoutMs: 25000 });
      } catch (err) {
        lastErr = err;
        continue;
      }
      let b;
      try {
        b = await readLimited(resp.stream, 8 * 1024 * 1024);
      } catch (err) {
        lastErr = err;
        continue;
      }
      if (resp.status < 200 || resp.status >= 300) {
        lastErr = new Error(`HTTP ${resp.status}`);
        continue;
      }
      if (b.length === 0) {
        lastErr = new Error('空响应');
        continue;
      }
      body = b;
      ct = String(resp.headers['content-type'] || '');
      break;
    }
    if (!body || body.length === 0) {
      return httpPlainError(res, 502, 'upstream error: ' + (lastErr && lastErr.message ? lastErr.message : String(lastErr)));
    }
    if (!ct.startsWith('image/')) {
      ct = detectContentType(body);
    }
    this.imgCache.put(target, ct, body);
    res.setHeader('Content-Type', ct);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'public, max-age=21600');
    res.status(200);
    res.send(body);
  }
}


export function externalBase(req) {
  const ext = String(req.headers['x-jdd-external'] || '').trim();
  if (ext) return ext;
  return 'http://' + (req.headers.host || '127.0.0.1');
}

export { defaultUA, firstNonEmpty };

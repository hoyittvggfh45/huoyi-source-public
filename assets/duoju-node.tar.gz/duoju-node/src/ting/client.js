

import { createHash, randomUUID } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';


export const defaultUA = 'Mozilla/5.0 (Linux; Android 13; M2012K11AC) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

export const desktopUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

export const clientUA = desktopUA;

export function errText(e) {
  if (!e) return '';
  if (typeof e === 'string') return e;
  return e.message || String(e);
}

export function md5hex(s) {
  return createHash('md5').update(String(s), 'utf8').digest('hex');
}


export function queryEscape(s) {
  return encodeURIComponent(String(s)).replace(
    /[!'()*]|%20/g,
    (m) => (m === '%20' ? '+' : '%' + m.charCodeAt(0).toString(16).toUpperCase())
  );
}
export const encode = queryEscape;


export const queryEscapeUTF8 = queryEscape;

export function newUUIDv4() {
  return randomUUID();
}


export function atoiDefault(s, def) {
  s = String(s ?? '').trim();
  if (s === '') return def;
  let n = 0;
  for (const ch of s) {
    if (ch < '0' || ch > '9') return def;
    n = n * 10 + (ch.charCodeAt(0) - 48);
    if (n > 1_000_000_000) return def;
  }
  if (n <= 0) return def;
  return n;
}


export function firstNonEmpty(...vals) {
  for (const v of vals) {
    const t = String(v ?? '').trim();
    if (t !== '') return t;
  }
  return '';
}


export function splitN2(s, sep) {
  const i = String(s).indexOf(sep);
  if (i < 0) return [String(s), ''];
  return [String(s).slice(0, i), String(s).slice(i + sep.length)];
}


export function kwID(v) {
  if (typeof v === 'number') {
    if (!Number.isFinite(v)) return '';
    return String(Math.trunc(v));
  }
  if (typeof v === 'string') return v;
  return '';
}


export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}


const COOKIE_ATTR_NAMES = new Set(['expires', 'max-age', 'path', 'domain', 'secure', 'httponly', 'samesite', 'version', 'comment']);

function hostOf(u) {
  try { return new URL(u).host.toLowerCase(); } catch { return ''; }
}

export class CookieJar {
  constructor() {
    this.byHost = new Map(); 
  }

  cookieHeader(url) {
    const jar = this.byHost.get(hostOf(url));
    if (!jar || jar.size === 0) return '';
    return [...jar.entries()].map(([k, v]) => `${k}=${v}`).join('; ');
  }

  set(url, name, value) {
    const host = hostOf(url);
    if (!host) return;
    let jar = this.byHost.get(host);
    if (!jar) { jar = new Map(); this.byHost.set(host, jar); }
    if (value === '') jar.delete(name); else jar.set(name, value);
  }

  
  store(url, headers) {
    const sc = headers && headers['set-cookie'];
    if (!sc) return;
    const parts = String(sc).split(/,(?=[^;,]+(?:=|;))/);
    for (const part of parts) {
      const m = /^\s*([^=;\s]+)\s*=\s*([^;]*)/.exec(part);
      if (!m) continue;
      const name = m[1];
      if (COOKIE_ATTR_NAMES.has(name.toLowerCase())) continue;
      this.set(url, name, m[2].trim());
    }
  }
}



function mergeHeaders(base, extra) {
  const out = { ...base };
  if (extra) {
    for (const [k, v] of Object.entries(extra)) {
      if (v === undefined || v === null) continue;
      out[k] = v;
    }
  }
  return out;
}


async function rawFetch(client, method, api, body, headers, timeoutMs) {
  const h = mergeHeaders({ 'User-Agent': defaultUA, Accept: '*/*', 'Accept-Encoding': 'identity' }, headers);
  const resp = await client.do(method, api, h, {
    noBrowserHeaders: true,
    withoutCookieJar: true,
    timeoutMs,
    body,
  });
  if (resp.status < 200 || resp.status >= 300) {
    try { resp.stream.destroy?.(); } catch {}
    const err = new Error('EOF');
    err.status = resp.status;
    throw err;
  }
  return resp;
}


async function jarFetch(client, jar, method, api, body, headers, timeoutMs) {
  const cookie = jar ? jar.cookieHeader(api) : '';
  const h = mergeHeaders(headers, cookie ? { Cookie: cookie } : {});
  const resp = await client.do(method, api, h, {
    noBrowserHeaders: true,
    withoutCookieJar: true,
    timeoutMs,
    body,
  });
  if (jar) jar.store(api, resp.headers);
  return resp;
}

export async function httpGetBytes(client, api, headers = {}, timeoutMs = 30000) {
  const resp = await rawFetch(client, 'GET', api, undefined, headers, timeoutMs);
  return resp.buffer();
}

export async function httpGet(client, api, headers = {}, timeoutMs = 30000) {
  const buf = await httpGetBytes(client, api, headers, timeoutMs);
  return buf.toString('utf8');
}

export const httpGetJSON = httpGet;

export async function httpPostJSON(client, api, body, headers = {}, timeoutMs = 30000) {
  const resp = await rawFetch(client, 'POST', api, String(body ?? ''), mergeHeaders({ 'Content-Type': 'application/json' }, headers), timeoutMs);
  return (await resp.buffer()).toString('utf8');
}

export async function httpPostForm(client, api, form, headers = {}, timeoutMs = 30000) {
  const resp = await rawFetch(client, 'POST', api, String(form ?? ''), mergeHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' }, headers), timeoutMs);
  return (await resp.buffer()).toString('utf8');
}


export async function getHTMLJar(client, jar, api, referer = '', timeoutMs = 20000) {
  const h = mergeHeaders({ 'User-Agent': desktopUA }, referer ? { Referer: referer } : {});
  const resp = await jarFetch(client, jar, 'GET', api, undefined, h, timeoutMs);
  if (resp.status < 200 || resp.status >= 300) {
    try { resp.stream.destroy?.(); } catch {}
    throw new Error('EOF');
  }
  return (await resp.buffer()).toString('utf8');
}



export function desktopHeaders(referer = '') {
  const h = { 'User-Agent': desktopUA };
  if (referer) h.Referer = referer;
  return h;
}

export async function getHTML(client, api, referer = '') {
  return httpGet(client, api, desktopHeaders(referer));
}


export async function resolveFinal(client, api, referer = '') {
  let current = api;
  const headers = desktopHeaders(referer);
  for (let hop = 0; hop < 10; hop++) {
    let resp;
    try {
      resp = await client.do('GET', current, headers, { noBrowserHeaders: true, withoutCookieJar: true, timeoutMs: 30000 });
    } catch {
      return '';
    }
    const loc = resp.headers.location;
    if (loc && [301, 302, 303, 307, 308].includes(resp.status)) {
      try { await resp.buffer(); } catch {}
      try { current = new URL(loc, current).toString(); continue; } catch { return ''; }
    }
    try { resp.stream.destroy?.(); } catch {}
    return current;
  }
  return current;
}


export function encodeQuerySorted(obj) {
  const keys = Object.keys(obj).filter((k) => obj[k] !== undefined && obj[k] !== null).sort();
  const parts = [];
  for (const k of keys) parts.push(`${queryEscape(k)}=${queryEscape(obj[k])}`);
  return parts.join('&');
}


export const AppVersion = '1.9.0';

let dataDirUser = '';
let dataDirGot = '';

export function setDataDir(dir) {
  const d = String(dir || '').trim();
  if (d) {
    dataDirUser = d;
    dataDirGot = '';
  }
}

export function getDataDir() {
  if (dataDirGot) return dataDirGot;
  const cands = [];
  if (dataDirUser) cands.push(dataDirUser);
  cands.push(process.cwd());
  for (const d of cands) {
    if (!d) continue;
    try {
      fs.mkdirSync(d, { recursive: true });
      dataDirGot = d;
      return d;
    } catch {}
  }
  dataDirGot = process.cwd();
  return dataDirGot;
}

export function dataFilePath(name) {
  return path.join(getDataDir(), name);
}

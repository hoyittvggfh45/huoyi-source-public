


let gbkDecoder = null;
let gbkEncoderMap = null;

function getDecoder() {
  if (!gbkDecoder) gbkDecoder = new TextDecoder('gbk');
  return gbkDecoder;
}

function getEncoderMap() {
  if (gbkEncoderMap) return gbkEncoderMap;
  const dec = getDecoder();
  const map = new Map(); 
  const buf = Buffer.alloc(2);
  for (let lead = 0x81; lead <= 0xfe; lead++) {
    buf[0] = lead;
    for (let trail = 0x40; trail <= 0xfe; trail++) {
      if (trail === 0x7f) continue;
      buf[1] = trail;
      let s;
      try { s = dec.decode(buf); } catch { continue; }
      if (s.length !== 1 || s === '\uFFFD') continue;
      if (!map.has(s)) map.set(s, buf.toString('latin1'));
    }
  }
  gbkEncoderMap = map;
  return map;
}


export function gbkDecode(buf) {
  try {
    return getDecoder().decode(buf);
  } catch {
    return Buffer.isBuffer(buf) ? buf.toString('latin1') : String(buf);
  }
}


function queryEscapeBytes(byteStr) {
  let r = '';
  for (const ch of byteStr) {
    const c = ch.charCodeAt(0);
    if ((c >= 0x41 && c <= 0x5a) || (c >= 0x61 && c <= 0x7a) || (c >= 0x30 && c <= 0x39) || c === 0x2d || c === 0x5f || c === 0x2e || c === 0x7e) {
      r += ch;
    } else if (c === 0x20) {
      r += '+';
    } else {
      const hex = c.toString(16).toUpperCase();
      r += '%' + (hex.length < 2 ? '0' : '') + hex;
    }
  }
  return r;
}



export function gbkEncodeQuery(s) {
  s = String(s ?? '');
  const map = getEncoderMap();
  const out = [];
  let ok = true;
  for (const ch of s) {
    const c = ch.codePointAt(0);
    if (c < 0x80) { out.push(ch); continue; }
    const g = map.get(ch);
    if (g === undefined) { ok = false; break; }
    out.push(g);
  }
  if (!ok) {
    
    return queryEscapeBytes(Buffer.from(s, 'utf8').toString('latin1'));
  }
  return queryEscapeBytes(out.join(''));
}

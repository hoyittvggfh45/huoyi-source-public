
import { desktopHeaders, getHTML } from './client.js';

export const desktopUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';


export const reTag = /<[^>]*>/gis;
export const reSpaces = /\s+/g;
export const reAnchor = /<a\s[^>]*?href\s*=\s*["']([^"']*)["'][^>]*>([\s\S]*?)<\/a>/gis;
export const reImgData = /<img[^>]*?\b(?:data-original|data-src|data-echo)\s*=\s*["']([^"']+)["']/gis;
export const reImgSrc = /<img[^>]*?\bsrc\s*=\s*["']([^"']+)["']/gis;
export const reListItem = /<li[^>]*>([\s\S]*?)<\/li>/gis;


const NAMED_ENTITIES = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', ensp: ' ', emsp: ' ',
  thinsp: ' ', zwnj: '', zwj: '', copy: '©', reg: '®', trade: '™',
  hellip: '…', mdash: '—', ndash: '–', lsquo: '\u2018', rsquo: '\u2019',
  ldquo: '“', rdquo: '”', middot: '·', bull: '•', deg: '°',
  times: '×', divide: '÷', plusmn: '±', laquo: '«', raquo: '»',
  iexcl: '¡', cent: '¢', pound: '£', yen: '¥', sect: '§', para: '¶',
  eacute: 'é', egrave: 'è', agrave: 'à', ccedil: 'ç', uuml: 'ü', ouml: 'ö', auml: 'ä',
  szlig: 'ß', ntilde: 'ñ', frac12: '½', frac14: '¼', sup2: '²', sup3: '³', micro: 'µ',
};

export function unescapeHTML(s) {
  if (!s || !s.includes('&')) return s;
  return String(s).replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z][a-zA-Z0-9]*);?/g, (m, body) => {
    if (body[0] === '#') {
      const hex = body[1] === 'x' || body[1] === 'X';
      const n = parseInt(body.slice(hex ? 2 : 1), hex ? 16 : 10);
      if (!Number.isFinite(n) || n < 0 || n > 0x10ffff) return m;
      try { return String.fromCodePoint(n); } catch { return m; }
    }
    const name = body.toLowerCase();
    if (name in NAMED_ENTITIES) return NAMED_ENTITIES[name];
    return m;
  });
}


export function htmlText(s) {
  s = String(s ?? '').replace(reTag, ' ');
  s = unescapeHTML(s);
  return s.replace(reSpaces, ' ').trim();
}

export function htmlLink(href = '', text = '') {
  return { href, text };
}

export function findLinks(s) {
  const out = [];
  let m;
  reAnchor.lastIndex = 0;
  while ((m = reAnchor.exec(s)) !== null) {
    out.push(htmlLink(unescapeHTML(m[1]), htmlText(m[2])));
  }
  return out;
}

export function findFirstLink(s) {
  const l = findLinks(s);
  return l.length > 0 ? l[0] : htmlLink();
}


export function findImg(base, s) {
  for (const re of [reImgData, reImgSrc]) {
    let m;
    re.lastIndex = 0;
    while ((m = re.exec(s)) !== null) {
      const u = absURL(base, String(m[1]).trim());
      if (u) return u;
    }
  }
  return '';
}


export function splitList(s) {
  const out = [];
  let m;
  reListItem.lastIndex = 0;
  while ((m = reListItem.exec(s)) !== null) out.push(m[1]);
  return out;
}


export function absURL(base, href) {
  href = String(href ?? '').trim();
  if (href === '' || href.startsWith('#')) return '';
  if (href.startsWith('http://') || href.startsWith('https://')) return href;
  if (href.startsWith('//')) return 'https:' + href;
  let b;
  try { b = new URL(base); } catch { return href; }
  if (href.startsWith('/')) return `${b.protocol}//${b.host}${href}`;
  let dir = b.pathname;
  const i = dir.lastIndexOf('/');
  dir = i >= 0 ? dir.slice(0, i + 1) : '/';
  try {
    return new URL(href, `${b.protocol}//${b.host}${dir}`).toString();
  } catch {
    return href;
  }
}


export function firstGroup(re, s) {
  const m = re.exec(s);
  return m && m.length > 1 ? m[1] : '';
}


export function allGroups(re, s) {
  const out = [];
  let m;
  const re2 = new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g');
  while ((m = re2.exec(s)) !== null) {
    if (m.length > 1) out.push(m[1]);
  }
  return out;
}

export { desktopHeaders, getHTML };

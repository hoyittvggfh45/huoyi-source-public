
import { teenEnabled as hubEnabled, setTeen as hubSet } from '../teenhub.js';
import { Card, BookDetail, Chapter, AudioPlay } from './types.js';


export function isAdultProvider(p) {
  return !!(p && typeof p.adult === 'function' && p.adult());
}

export const teenScheme = 'teen://';
export const teenPlaceholderID = '__teen__';


export function initTeen() {}

export function teenEnabled() {
  return hubEnabled();
}

export function setTeenEnabled(enabled) {
  hubSet(enabled);
}

export function teenBlocked(p) {
  return teenEnabled() && isAdultProvider(p);
}

export function teenBlockedKey(providerFn, key) {
  const p = providerFn(key);
  if (!p) return false;
  return teenBlocked(p);
}

export function teenPlaceholderCard(plat) {
  return Card({
    id: teenPlaceholderID,
    name: '【青少年模式已隐藏】',
    remarks: '成人内容 · 关闭青少年模式后查看',
    cat: 'adult',
    desc: '该来源标记为成人内容，青少年模式下不可见。请在设置中关闭青少年模式后查看。',
    plat,
  });
}

export function teenPlaceholderDetail(plat) {
  return BookDetail({
    id: teenPlaceholderID,
    name: '【青少年模式已隐藏】',
    desc: '该来源标记为成人内容，青少年模式下不可见。请在设置中关闭青少年模式后查看。',
    tag: 'adult',
    remarks: '关闭青少年模式后查看',
    chapters: [Chapter(1, '解锁提示', teenScheme + 'unlock')],
    count: 1,
  });
}

export function teenPlaceholderPlay() {
  return AudioPlay({});
}

export function loopbackOnly(req) {
  let host = String((req.socket && req.socket.remoteAddress) || '');
  if (host.startsWith('::ffff:')) host = host.slice(7);
  return host === '127.0.0.1' || host === '::1' || host === '[::1]' || host === 'localhost';
}

export function teenSameOrigin(req) {
  const origin = String(req.headers.origin || '').trim();
  const referer = String(req.headers.referer || '').trim();
  let probe = origin || referer;
  if (!probe) return true;
  let after = probe;
  const i = after.indexOf('://');
  if (i >= 0) after = after.slice(i + 3);
  const j = after.search(/[/?]/);
  if (j >= 0) after = after.slice(0, j);
  let host = after;
  const k = host.lastIndexOf(':');
  if (k >= 0) host = host.slice(0, k).replace(/^\[|\]$/g, '');
  return host === '127.0.0.1' || host === '::1' || host === 'localhost' || host.startsWith('127.');
}



import { newAsmrmoonProvider, newAsmrdProvider } from './providers/asmr_alist.js';
import { newAsmreggProvider, newAsaoProvider } from './providers/asmr_static.js';
import { BiliProvider } from './providers/bili.js';
import { BkProvider } from './providers/bookan.js';
import { FalooProvider } from './providers/faloo.js';
import { KwProvider } from './providers/kw.js';
import { PtcmsProvider, LETING_CONFIGS } from './providers/letting.js';
import { MeProvider } from './providers/missevan.js';
import { PcProvider } from './providers/podcast.js';
import { SyfmProvider } from './providers/syfm.js';
import { TswProvider } from './providers/tsw.js';
import { TyProvider } from './providers/ty.js';
import { TyfmProvider } from './providers/tyfm.js';
import { XmProvider } from './providers/xm.js';
import { YuntuProvider } from './providers/yuntu.js';
import { Platform } from './types.js';
import { encodeQuerySorted } from './client.js';


export function createRegistry(client, media) {
  const order = [
    newAsmrmoonProvider(client, media), 
    newAsmrdProvider(client, media),
    newAsmreggProvider(client, media), 
    newAsaoProvider(client, media),
    new BiliProvider(client, media), 
    new BkProvider(client, media), 
    new FalooProvider(client, media), 
    new KwProvider(client, media), 
    new PtcmsProvider(client, media, LETING_CONFIGS[0]), 
    new PtcmsProvider(client, media, LETING_CONFIGS[1]),
    new MeProvider(client, media), 
    new PcProvider(client, media), 
    new SyfmProvider(client, media), 
    new TswProvider(client, media), 
    new TyProvider(client, media), 
    new TyfmProvider(client, media), 
    new XmProvider(client, media), 
    new YuntuProvider(client, media), 
  ];

  const registry = new Map();
  for (const p of order) {
    const k = String(p.key()).toLowerCase();
    if (!registry.has(k)) registry.set(k, p);
  }

  return {
    order,
    
    provider(key) {
      return registry.get(String(key || '').toLowerCase().trim()) || null;
    },
    providers() {
      return order.slice();
    },
    platformList() {
      return order.map((p) => Platform(p.key(), p.name(), p.desc()));
    },
  };
}


export function catOrDefault(p, cat) {
  if (String(cat || '').trim() !== '' && cat !== 'undefined') {
    return cat;
  }
  const cats = typeof p.cats === 'function' ? p.cats() : [];
  if (cats.length > 0) return cats[0].id;
  return '';
}


export function proxyPlayURL(mediaBase, ap) {
  const q = { u: ap.src };
  if (ap.referer) q.ref = ap.referer;
  if (ap.ua) q.ua = ap.ua;
  return `${mediaBase}/media/audio?${encodeQuerySorted(q)}`;
}


import {
  httpGet, encode, firstNonEmpty, kwID,
} from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';

export class KwProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'kw'; }
  name() { return '酷我听书'; }
  desc() { return '酷我听书：有声小说/相声评书/音乐/影视原声'; }

  cats() {
    return [
      { id: '2', name: '有声小说' },
      { id: '4', name: '教育学习' },
      { id: '1', name: '儿童故事' },
    ];
  }

  async list(cat, page) {
    if (cat === '') cat = '2';
    const api = `http://tingshu.kuwo.cn/v2/api/search/filter/albums?classifyId=${encode(cat)}&notrace=0&source=kwplayer_ar_9.1.8.1_tvivo.apk&platform=1&kweexVersion=1.1.5&uid=2511482006&sortType=playCnt&loginUid=540339516&bksource=kwbook_ar_9.1.8.1_tvivo.apk&rn=12&categoryId=${encode(cat)}&pn=${page}`;
    const body = await httpGet(this.client, api);
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('酷我列表解析失败: ' + err.message);
    }
    const items = (resp && resp.data && resp.data.data) || [];
    const out = [];
    for (const it of items) {
      const id = kwID(it.albumId);
      if (id === '') continue;
      out.push(Card({
        id,
        name: firstNonEmpty(it.albumName, '未知专辑'),
        pic: it.coverImg || '',
        remarks: it.title || '',
      }));
    }
    return out;
  }

  async search(wd, page) {
    const api = `http://search.kuwo.cn/r.s?client=kt&all=${encode(wd)}&ft=album&newsearch=1&itemset=web_2013&cluster=0&pn=${page - 1}&rn=21&rformat=json&encoding=utf8&show_copyright_off=1&vipver=MUSIC_8.0.3.0_BCS75&show_series_listen=1&version=9.1.8.1`;
    const body = await httpGet(this.client, api);
    const strict = body.replace(/'/g, '"');
    let resp;
    try {
      resp = JSON.parse(strict);
    } catch (err) {
      throw new Error('酷我搜索解析失败: ' + err.message);
    }
    const list = (resp && resp.albumlist) || [];
    const out = [];
    for (const it of list) {
      const id = kwID(it.albumid);
      if (id === '') continue;
      let remarks = it.pub || '';
      const n = kwID(it.musiccnt);
      if (n !== '') remarks = firstNonEmpty(remarks, n + '集');
      out.push(Card({
        id,
        name: firstNonEmpty(it.name, '未知专辑'),
        pic: firstNonEmpty(it.img, it.pic),
        remarks,
        author: it.artist || '',
      }));
    }
    return out;
  }

  async detail(id) {
    const api = `http://search.kuwo.cn/r.s?stype=albuminfo&user=8d378d72qw28f5f4&uid=2511552006&loginUid=540129516&loginSid=958467960&prod=kwplayer_ar_9.1.8.1&bkprod=kwbook_ar_9.1.8.1&source=kwplayer_ar_9.1.8.1_tvivo.apk&bksource=kwbook_ar_9.1.8.1_tvivo.apk&corp=kuwo&albumid=${encode(id)}&pn=0&rn=5000&show_copyright_off=1&vipver=MUSIC_8.2.0.0_BCS17&mobi=1&iskwbook=1`;
    const body = await httpGet(this.client, api);
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('酷我详情解析失败: ' + err.message);
    }
    const musiclist = (resp && resp.musiclist) || [];
    const chapters = [];
    musiclist.forEach((t, i) => {
      const rid = t.musicrid || '';
      if (rid === '') return;
      chapters.push(Chapter(i + 1, cleanKuwo(t.name || ''), rid));
    });
    return BookDetail({
      id,
      name: cleanKuwo(firstNonEmpty(resp.name, resp.album, '未知专辑')),
      pic: resp.img || '',
      desc: cleanKuwo(resp.info || ''),
      author: cleanKuwo(resp.artist || ''),
      remarks: `共${chapters.length}集`,
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    const rid = String(ref || '').trim();
    if (rid === '') throw new Error('缺少曲目 rid');
    const api = `http://mobi.kuwo.cn/mobi.s?f=web&source=kwplayerhd_ar_4.3.0.8_tianbao_T1A_qirui.apk&type=convert_url_with_sign&rid=${encode(rid)}&br=320kmp3`;
    const body = await httpGet(this.client, api);
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('酷我播放解析失败: ' + err.message);
    }
    const url = resp && resp.data && resp.data.url;
    if (!url) throw new Error('酷我未返回音频地址');
    return AudioPlay({ src: url, referer: 'http://mobi.kuwo.cn/' });
  }
}

export function cleanKuwo(s) {
  return String(s || '').split('\\u0026').join('&');
}


import { httpGet, firstNonEmpty } from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';

const pcHost = 'https://getpodcast.xyz';
const pcPageSize = 20;
const pcWebUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

let pcData = null;
let pcFetched = 0;

function unescapeXML(s) {
  if (!s || !String(s).includes('&')) return String(s ?? '');
  return String(s)
    .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => { try { return String.fromCodePoint(parseInt(h, 16)); } catch { return _; } })
    .replace(/&#(\d+);/g, (_, d) => { try { return String.fromCodePoint(parseInt(d, 10)); } catch { return _; } })
    .replace(/&(amp|lt|gt|quot|apos);/g, (_, n) => ({ amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" }[n]));
}

function xmlText(s) {
  return unescapeHTMLLite(s);
}

function unescapeHTMLLite(s) {
  
  return unescapeXML(String(s ?? '')).replace(/<[^>]*>/g, '').trim();
}

async function pcShows(client) {
  if (pcData && Date.now() - pcFetched < 10 * 60 * 1000) return pcData;
  const body = await httpGet(client, pcHost, { 'User-Agent': pcWebUA });
  const marker = 'window.__INITIAL_DATA__ = ';
  const s = body.indexOf(marker);
  if (s < 0) throw new Error('播客首页数据缺失');
  const e = body.indexOf('</script>', s);
  if (e < 0) throw new Error('播客首页数据缺失');
  let raw = body.slice(s + marker.length, e).trim();
  if (raw.endsWith(';')) raw = raw.slice(0, -1);
  let payload;
  try {
    payload = JSON.parse(raw);
  } catch (err) {
    throw new Error('播客数据解析失败: ' + err.message);
  }
  const featured = (payload && payload.featured) || [];
  if (featured.length === 0) throw new Error('播客数据为空');
  pcData = featured;
  pcFetched = Date.now();
  return pcData;
}

async function pcFilter(client, cat, wd, page) {
  const all = await pcShows(client);
  wd = String(wd || '').trim();
  const out = [];
  for (const p of all) {
    if (!p.rssUrl) continue;
    if (cat !== '' && !pcHasTag(p.tags || [], cat)) continue;
    if (wd !== '' && !String(p.title || '').includes(wd) && !String(p.author || '').includes(wd)) continue;
    out.push(Card({
      id: p.rssUrl,
      name: firstNonEmpty(p.title, '未知播客'),
      pic: p.cover || '',
      remarks: p.author || '',
      author: p.author || '',
      desc: p.description || '',
    }));
  }
  const start = (page - 1) * pcPageSize;
  if (start >= out.length) return [];
  return out.slice(start, start + pcPageSize);
}

function pcHasTag(tags, want) {
  return (tags || []).some((t) => t === want);
}


function parseRSS(body) {
  const chanM = /<channel[\s\S]*?<\/channel>/i.exec(body);
  const chan = chanM ? chanM[0] : body;
  const firstItem = chan.search(/<item[\s>]/i);
  const head = firstItem >= 0 ? chan.slice(0, firstItem) : chan;

  const pick = (src, tag) => {
    const m = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, 'i').exec(src);
    return m ? m[1] : '';
  };

  let chanTitle = xmlText(pick(head, 'title'));
  let chanDesc = xmlText(pick(head, 'description'));
  let chanImg = '';
  const imgBlock = /<image[^>]*>[\s\S]*?<\/image>/i.exec(head);
  if (imgBlock) chanImg = xmlText(pick(imgBlock[0], 'url')).replace(/<[^>]*>/g, '').trim();

  const items = [];
  const reItem = /<item[\s\S]*?<\/item>/gi;
  let m;
  while ((m = reItem.exec(chan)) !== null) {
    const blk = m[0];
    const title = xmlText(pick(blk, 'title'));
    const enc = /<enclosure[^>]*>/i.exec(blk);
    let url = '';
    if (enc) {
      const um = /url\s*=\s*"([^"]*)"/i.exec(enc[0]) || /url\s*=\s*'([^']*)'/i.exec(enc[0]);
      if (um) url = um[1];
    }
    items.push({ title, url });
  }
  return { title: chanTitle, image: chanImg, description: chanDesc, items };
}

export class PcProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'podcast'; }
  name() { return '播客'; }
  desc() { return '精选中文播客：商业财经/科技/人文历史/喜剧/语言学习等（RSS 订阅）'; }

  cats() {
    return [
      { id: '', name: '全部' },
      { id: '商业财经', name: '商业财经' },
      { id: '科技', name: '科技' },
      { id: '人文历史', name: '人文历史' },
      { id: '影视娱乐', name: '影视娱乐' },
      { id: '喜剧', name: '喜剧' },
      { id: '社会与文化', name: '社会与文化' },
      { id: '教育', name: '教育' },
      { id: '语言学习', name: '语言学习' },
      { id: '健康与健身', name: '健康与健身' },
      { id: '新闻', name: '新闻' },
      { id: '故事奇谈', name: '故事奇谈' },
      { id: '心理与健康', name: '心理与健康' },
      { id: '儿童故事', name: '儿童故事' },
    ];
  }

  async list(cat, page) {
    return pcFilter(this.client, cat, '', page);
  }

  async search(wd, page) {
    return pcFilter(this.client, '', wd, page);
  }

  async detail(ref) {
    const meta = pcMeta(ref);
    const body = await httpGet(this.client, ref, { 'User-Agent': pcWebUA });
    const feed = parseRSS(body);
    const chapters = [];
    for (let i = 0; i < feed.items.length; i++) {
      const it = feed.items[i];
      if (!it.url) continue;
      chapters.push(Chapter(chapters.length + 1, firstNonEmpty(String(it.title || '').trim(), `第${i + 1}期`), it.url));
      if (chapters.length >= 200) break;
    }
    if (chapters.length === 0) throw new Error('RSS 无可播放单集');
    return BookDetail({
      id: ref,
      name: firstNonEmpty(feed.title, meta.vod_name, '播客'),
      pic: firstNonEmpty(feed.image, meta.vod_pic),
      desc: firstNonEmpty(String(feed.description || '').trim(), meta.vod_content || ''),
      author: meta.vod_director || '',
      remarks: `共${chapters.length}期`,
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    if (!String(ref || '').includes('://')) {
      throw new Error('播客播放凭证无效');
    }
    return AudioPlay({ src: ref });
  }
}


export function pcMeta(rss) {
  if (!pcData) return Card({});
  for (const p of pcData) {
    if (p.rssUrl === rss) {
      return Card({ name: p.title || '', pic: p.cover || '', author: p.author || '', desc: p.description || '' });
    }
  }
  return Card({});
}


import crypto from 'node:crypto';
import { httpGet, httpPostForm, encode, firstNonEmpty, splitN2 } from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';

export const xmHost = 'https://ct-api.weiguangshanyao.com';
export const xmPkg = 'com.hm.hmysct';
export const xmSignKey = '0b333bcfeef42fa3630942f77c2a1d64e041857de4407af4fd2cd32622c98b1';
export const xmDeviceID = 'duojuting0000000000000000000000';


export function ctSign(query) {
  const q = String(query).startsWith('?') ? String(query).slice(1) : String(query);
  const m = new Map();
  for (const kv of q.split('&')) {
    const i = kv.indexOf('=');
    if (i >= 0) m.set(kv.slice(0, i), kv.slice(i + 1));
  }
  const keys = [...m.keys()].sort();
  const parts = keys.map((k) => `${k}=${m.get(k)}`);
  return crypto.createHmac('sha256', xmSignKey).update(parts.join('&') + xmSignKey).digest('hex');
}

const xmSess = { UserID: '', Token: '' };
let xmSessExp = 0;
let xmLoginPromise = null;


export async function xmLogin(client) {
  if (xmSess.Token && Date.now() < xmSessExp) return xmSess;
  if (xmLoginPromise) return xmLoginPromise;
  xmLoginPromise = (async () => {
    const q = 'zhanwei=0&device_id=' + xmDeviceID + '&package_name=' + xmPkg;
    const body = await httpPostForm(client, `${xmHost}/user/guest_login`, q, { 'ct-sign': ctSign(q) });
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('喜马拉雅登录解析失败: ' + err.message);
    }
    if (!resp || resp.code !== 0 || !resp.data || !resp.data.token) {
      throw new Error(`喜马拉雅登录失败 code=${resp ? resp.code : ''}`);
    }
    xmSess.UserID = resp.data.userid || '';
    xmSess.Token = resp.data.token;
    xmSessExp = Date.now() + 24 * 60 * 60 * 1000;
    return xmSess;
  })();
  try {
    return await xmLoginPromise;
  } finally {
    xmLoginPromise = null;
  }
}

export function xmInvalidate() {
  xmSess.UserID = '';
  xmSess.Token = '';
  xmSessExp = 0;
}

async function xmGet(client, api, query, sess) {
  return httpGet(client, `${api}?${query}`, {
    Authorization: 'Bearer ' + sess.Token,
    'ct-sign': ctSign(query),
  });
}

async function xmPost(client, api, form, sess) {
  return httpPostForm(client, api, form, {
    Authorization: 'Bearer ' + sess.Token,
    'ct-sign': ctSign(form),
  });
}


function xmParseAlbums(body) {
  let resp;
  try {
    resp = JSON.parse(body);
  } catch (err) {
    throw new Error('喜马拉雅列表解析失败: ' + err.message);
  }
  if (!resp || resp.code !== 0) {
    throw new Error(`喜马拉雅接口返回 code=${resp ? resp.code : ''}`);
  }
  const albums = (resp.data && resp.data.albums) || [];
  const out = [];
  for (const a of albums) {
    if ((a.album_id || 0) > 0) {
      out.push(
        Card({
          id: String(a.album_id),
          name: firstNonEmpty(a.album_title, '未知专辑'),
          pic: a.cover_url || '',
          remarks: firstNonEmpty(a.subscribe_count_desc, (a.author && a.author.nickname) || ''),
          author: (a.author && a.author.nickname) || '',
          desc: a.album_intro || '',
        })
      );
    }
  }
  return out;
}

export class XmProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'xm'; }
  name() { return '喜马拉雅'; }
  desc() { return '喜马拉雅：听书/相声评书/历史/人文/广播剧等海量专辑（镜像接口）'; }

  cats() {
    return [
      { id: '3', name: '听书' },
      { id: '12', name: '相声评书' },
      { id: '9', name: '历史' },
      { id: '39', name: '人文' },
      { id: '1', name: '头条' },
      { id: '13', name: '学习成长' },
      { id: '15', name: '广播剧场' },
    ];
  }

  async list(cat, page) {
    if (cat === '') cat = '3';
    let sess;
    try {
      sess = await xmLogin(this.client);
    } catch (err) {
      throw err;
    }
    let q = 'category_id=' + encode(cat) + '&tag=&page=' + page +
      '&device_id=' + xmDeviceID + '&userid=' + sess.UserID + '&package_name=' + xmPkg;
    const body = await xmGet(this.client, `${xmHost}/book/album_list`, q, sess);
    let out;
    try {
      out = xmParseAlbums(body);
    } catch (err) {
      if (String(body).includes('签名错误')) {
        xmInvalidate();
        let sess2 = null;
        try {
          sess2 = await xmLogin(this.client);
        } catch {
          sess2 = null;
        }
        if (sess2) {
          const q2 = q.replace('userid=' + sess.UserID, 'userid=' + sess2.UserID);
          try {
            const body2 = await xmGet(this.client, `${xmHost}/book/album_list`, q2, sess2);
            return xmParseAlbums(body2);
          } catch {
            
          }
        }
      }
      throw err;
    }
    return out;
  }

  async search(wd, page) {
    const sess = await xmLogin(this.client);
    const q = 'keyword=' + encode(wd) + '&page=' + page +
      '&device_id=' + xmDeviceID + '&userid=' + sess.UserID + '&package_name=' + xmPkg;
    const body = await xmGet(this.client, `${xmHost}/book/search_albums`, q, sess);
    return xmParseAlbums(body);
  }

  async detail(id) {
    const sess = await xmLogin(this.client);
    const q = 'album_id=' + encode(id) + '&device_id=' + xmDeviceID + '&userid=' + sess.UserID + '&package_name=' + xmPkg;
    const body = await xmGet(this.client, `${xmHost}/book/album_info`, q, sess);
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('喜马拉雅详情解析失败: ' + err.message);
    }
    if (!resp || resp.code !== 0) {
      throw new Error(`喜马拉雅详情 code=${resp ? resp.code : ''}`);
    }
    const info = (resp.data && typeof resp.data === 'object') ? resp.data : {};

    const chapters = [];
    let totalPage = 1;
    for (let page = 1; page <= totalPage && page <= 60; page++) {
      const tq = 'album_id=' + encode(id) + '&page=' + page +
        '&device_id=' + xmDeviceID + '&userid=' + sess.UserID + '&package_name=' + xmPkg;
      let tbody;
      try {
        tbody = await xmPost(this.client, `${xmHost}/book/album_tracks`, tq, sess);
      } catch (err) {
        if (page === 1) throw err;
        break;
      }
      let tresp;
      try {
        tresp = JSON.parse(tbody);
      } catch (err) {
        throw new Error('喜马拉雅章节解析失败: ' + err.message);
      }
      if (!tresp || tresp.code !== 0) break;
      const tdata = tresp.data || {};
      if ((tdata.total_page || 0) > totalPage) totalPage = tdata.total_page;
      for (const t of tdata.tracks || []) {
        chapters.push(Chapter(chapters.length + 1, t.track_title || '', `${id}#${t.track_id}`));
      }
      if (!tdata.tracks || tdata.tracks.length === 0) break;
    }

    return BookDetail({
      id,
      name: firstNonEmpty(info.album_title, '喜马拉雅专辑 ' + id),
      pic: info.cover_url || '',
      desc: info.album_intro || '',
      author: (info.author && info.author.nickname) || '',
      remarks: `共${chapters.length}集`,
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    const [albumID, trackID] = splitN2(ref, '#');
    if (albumID === '' || trackID === '') {
      throw new Error('喜马拉雅播放凭证无效');
    }
    const sess = await xmLogin(this.client);
    const q = 'album_id=' + encode(albumID) + '&track_ids=[' + encode(trackID) + ']' +
      '&device_id=' + xmDeviceID + '&userid=' + sess.UserID + '&package_name=' + xmPkg;
    const body = await xmPost(this.client, `${xmHost}/book/batch_play_urls`, q, sess);
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('喜马拉雅播放解析失败: ' + err.message);
    }
    if (!resp || resp.code !== 0 || !resp.data || Object.keys(resp.data).length === 0) {
      throw new Error('喜马拉雅音频解析失败（可能为付费章节）');
    }
    for (const k of Object.keys(resp.data)) {
      const v = resp.data[k];
      if (v && v.play_url) {
        return AudioPlay({ src: v.play_url });
      }
    }
    throw new Error('喜马拉雅音频解析失败');
  }
}

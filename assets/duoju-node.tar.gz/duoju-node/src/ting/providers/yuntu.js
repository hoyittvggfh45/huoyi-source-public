
import { httpGet, encode, firstNonEmpty, splitN2 } from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';

export const yuntuHost = 'https://api-micro.yuntuys.com';
export const yuntuReferer = 'https://www.yuntuys.com/';


function yuntuParseBooks(body) {
  let resp;
  try {
    resp = JSON.parse(body);
  } catch (err) {
    throw new Error('云图解析失败: ' + err.message);
  }
  if (!resp || resp.code !== 200) {
    throw new Error(`云图接口返回 code=${resp ? resp.code : ''}`);
  }
  const list = (resp.data && resp.data.list) || [];
  const out = [];
  for (const b of list) {
    if ((b.id || 0) > 0) {
      out.push(
        Card({
          id: String(b.id),
          name: firstNonEmpty(b.name, '未知书籍'),
          pic: b.cover || '',
          remarks: firstNonEmpty(b.anchor, b.author),
          author: firstNonEmpty(b.anchor, b.author),
          desc: b.summary || '',
        })
      );
    }
  }
  return out;
}

export class YuntuProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'yuntu'; }
  name() { return '云图有声'; }
  desc() { return '云图有声：名著/广播剧/党建/国学/亲子等正版精品有声书'; }

  cats() {
    return [
      { id: '125', name: '豆瓣高分' },
      { id: '126', name: '广播剧' },
      { id: '127', name: '影视同期' },
      { id: '585', name: '先锋党建' },
      { id: '973', name: '鉴赏导读' },
      { id: '1666', name: '人气畅销' },
      { id: '2220', name: '诺奖作家作品' },
      { id: '904', name: '自我进化' },
      { id: '905', name: '品质生活' },
      { id: '906', name: '前沿科学' },
      { id: '907', name: '情感心理' },
      { id: '908', name: '职场升级' },
      { id: '909', name: '商业财经' },
      { id: '910', name: '亲子家庭' },
      { id: '131', name: '世界名著' },
      { id: '132', name: '中国文学' },
      { id: '133', name: '外国文学' },
      { id: '134', name: '国学经典' },
      { id: '135', name: '诗词散文' },
      { id: '136', name: '人物传记' },
      { id: '2223', name: '古典文学' },
      { id: '139', name: '科学幻想' },
      { id: '140', name: '官场商战' },
      { id: '141', name: '军事谍战' },
      { id: '142', name: '悬疑推理' },
      { id: '143', name: '现代都市' },
      { id: '144', name: '怪奇物语' },
      { id: '335', name: '侠义江湖' },
    ];
  }

  async list(cat, page) {
    if (cat === '') cat = '125';
    const api = `${yuntuHost}/ytys/book/page/${page}/20?clazz=${encode(cat)}&dept=101&version=108`;
    const body = await httpGet(this.client, api, { Referer: yuntuReferer });
    return yuntuParseBooks(body);
  }

  async search(wd, page) {
    const api = `${yuntuHost}/ytys/book/search/${page}/20?search=${encode(wd)}&version=108&dept=101`;
    const body = await httpGet(this.client, api, { Referer: yuntuReferer });
    return yuntuParseBooks(body);
  }

  async detail(id) {
    const api = `${yuntuHost}/ytys/book/detail/101/108/${encode(id)}`;
    const body = await httpGet(this.client, api, { Referer: yuntuReferer });
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('云图详情解析失败: ' + err.message);
    }
    const book = (resp && resp.data && typeof resp.data === 'object') ? resp.data : {};

    const chapters = [];
    let pages = 1;
    for (let page = 1; page <= pages && page <= 50; page++) {
      const ca = `${yuntuHost}/ytys/chapter/page/${page}/200?history=true&sortBy=ASC&version=108&dept=101&book=${encode(id)}`;
      let cbody;
      try {
        cbody = await httpGet(this.client, ca, { Referer: yuntuReferer });
      } catch (err) {
        if (page === 1) throw err;
        break;
      }
      let cresp;
      try {
        cresp = JSON.parse(cbody);
      } catch (err) {
        throw new Error('云图章节解析失败: ' + err.message);
      }
      if (!cresp || cresp.code !== 200) break;
      const cpage = (cresp.data && cresp.data.page) || {};
      if ((cpage.pages || 0) > pages) pages = cpage.pages;
      for (const t of cpage.list || []) {
        chapters.push(Chapter(chapters.length + 1, t.name || '', `${id}#${t.id}`));
      }
      if (!cpage.list || cpage.list.length === 0) break;
    }

    return BookDetail({
      id,
      name: firstNonEmpty(book.name, '云图书籍 ' + id),
      pic: book.cover || '',
      desc: book.summary || '',
      author: firstNonEmpty(book.anchor, book.author),
      remarks: `共${chapters.length}集`,
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    const [bookID, chapID] = splitN2(ref, '#');
    if (bookID === '' || chapID === '') {
      throw new Error('云图播放凭证无效');
    }
    const api = `${yuntuHost}/ytys/chapter/get/${encode(chapID)}?version=108&dept=101`;
    const body = await httpGet(this.client, api, { Referer: yuntuReferer });
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('云图播放解析失败: ' + err.message);
    }
    const audio = resp && resp.data ? resp.data.audio : '';
    if (!resp || resp.code !== 200 || !audio) {
      throw new Error('云图音频解析失败');
    }
    return AudioPlay({ src: audio, referer: yuntuReferer });
  }
}

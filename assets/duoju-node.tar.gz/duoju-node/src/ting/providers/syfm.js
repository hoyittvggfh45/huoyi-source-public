
import { httpGet, encode, md5hex, firstNonEmpty } from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay, flex } from '../types.js';

const syfmSite = 'https://m.mekui.com';
const syfmAPI = syfmSite + '/ecmsapi/index.php?';
const syfmKey = '056a308c515e16b2fe5a5c631319339cbc60a8ee0e03d016';

function syfmHeaders() {
  return {
    Referer: syfmSite + '/',
    Accept: 'application/json, text/plain, */*',
  };
}

async function syfmGet(client, query) {
  const body = await httpGet(client, syfmAPI + query, syfmHeaders());
  try {
    return JSON.parse(body);
  } catch (err) {
    throw new Error('书音FM解析失败: ' + err.message);
  }
}

function syfmErr(code, ...msgs) {
  if (code === 1) return null;
  return new Error('书音FM: ' + firstNonEmpty(...msgs));
}

function syfmBookID(classID, id) {
  return classID + '-' + id;
}

function syfmSplitBook(id) {
  const parts = String(id).split('-');
  if (parts.length >= 2) return [parts[0], parts.slice(1).join('-')];
  return ['', id];
}

function syfmSplitRef(ref) {
  const parts = String(ref).split('-');
  if (parts.length >= 3) return [parts[1], parts[2]];
  return ['', ''];
}

function syfmToCard(b) {
  return Card({
    id: syfmBookID(flex(b.classid), flex(b.id)),
    name: firstNonEmpty(String(b.title || '').trim(), '未知专辑'),
    pic: b.titlepic || '',
    remarks: b.filetype || '',
    author: b.player || '',
    desc: b.moviesay || '',
  });
}

export class SyfmProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'syfm'; }
  name() { return '书音FM'; }
  desc() { return '书音FM：有声小说/广播剧/评书/百家讲坛/相声小品/戏曲/儿童等'; }

  cats() {
    return [
      { id: '28', name: '有声小说' }, { id: '29', name: '广播剧' }, { id: '30', name: '评书' }, { id: '31', name: '百家讲坛' },
      { id: '34', name: '养生' }, { id: '35', name: '娱乐' }, { id: '59', name: '粤语' }, { id: '66', name: '车载专区' },
      { id: '81', name: '戏曲' }, { id: '91', name: '相声小品' }, { id: '98', name: '音乐' }, { id: '100', name: '儿童' },
    ];
  }

  async list(cat, page) {
    if (cat === '') cat = '28';
    const r = await syfmGet(this.client, `act=list&mod=movie&classid=${encode(cat)}&page=${page}&pagesize=20&sort=${encode('onclick desc')}`);
    const err = syfmErr(r.code, r.message, r.msg);
    if (err) throw err;
    const out = [];
    for (const b of (r.data && r.data.list) || []) {
      if (flex(b.id) === '') continue;
      out.push(syfmToCard(b));
    }
    return out;
  }

  async search(wd, page) {
    const r = await syfmGet(this.client, `act=search&mod=movie&keyword=${encode(wd)}&page=${page}&pagesize=20`);
    const err = syfmErr(r.code, r.message, r.msg);
    if (err) throw err;
    const out = [];
    for (const b of (r.data && r.data.list) || []) {
      if (flex(b.id) === '') continue;
      out.push(syfmToCard(b));
    }
    return out;
  }

  async detail(id) {
    const [classID, albumID] = syfmSplitBook(id);
    if (albumID === '') throw new Error(`书音FM书籍 id 无效: ${id}`);

    const d = await syfmGet(this.client, `mod=movie&act=detail&id=${encode(albumID)}`);
    const derr = syfmErr(d.code, d.message);
    if (derr) throw derr;
    const det = (d.data && d.data.detail) || {};

    const chapters = [];
    for (let page = 1; page <= 20; page++) {
      let c;
      try {
        c = await syfmGet(this.client, `mod=movie&act=movielist&id=${encode(albumID)}&pagesize=500&page=${page}`);
      } catch (err) {
        if (page === 1) throw err;
        break;
      }
      if (c.code !== 1) break;
      for (const e of (c.data && c.data.moielist) || []) {
        if (flex(e.id) === '') continue;
        let title = String(e.title || '').trim();
        if (title === '') title = '第 ' + flex(e.id) + ' 集';
        chapters.push(Chapter(chapters.length + 1, title, `${classID}-${albumID}-${flex(e.id)}`));
      }
      if (page >= ((c.data && c.data.totalpage) || 0)) break;
    }

    const name = firstNonEmpty(String(det.title || '').trim(), '书音FM专辑 ' + albumID);
    let remarks = `共${chapters.length}集`;
    if (det.filetype) remarks += ' · ' + det.filetype;
    return BookDetail({
      id,
      name,
      pic: det.titlepic || '',
      desc: det.moviesay || '',
      author: firstNonEmpty(det.player, det.playadmin),
      remarks,
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    const [albumID, no] = syfmSplitRef(ref);
    if (albumID === '' || no === '') throw new Error(`书音FM章节凭证无效: ${ref}`);
    const t = String(Math.floor(Date.now() / 1000));
    const sign = md5hex(`act=wapseries&id=${albumID}&mod=movie&movieId=${no}&t=${t}&token=${syfmKey}`);
    const a = await syfmGet(this.client, `act=wapseries&mod=movie&id=${encode(albumID)}&movieId=${encode(no)}&t=${t}&token=${sign}`);
    const err = syfmErr(a.code, a.message, a.msg);
    if (err) throw err;
    let audio = (a.data && a.data.SeriesUrl) || '';
    if (audio === '') {
      for (const u of (a.data && a.data.signed_urls) || []) {
        if (String(u).trim() !== '') {
          audio = String(u).trim();
          break;
        }
      }
    }
    if (audio === '') {
      throw new Error('书音FM这一集没有给出播放地址（可能需要登录或会员）');
    }
    return AudioPlay({ src: audio, referer: syfmSite + '/' });
  }
}

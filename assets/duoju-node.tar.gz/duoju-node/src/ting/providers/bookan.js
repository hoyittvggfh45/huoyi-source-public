
import {
  httpGet, encode, firstNonEmpty, kwID,
} from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';

const bkHost = 'https://api.bookan.com.cn';
const bkEsHost = 'https://es.bookan.com.cn';

export class BkProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'bookan'; }
  name() { return '博看听书'; }
  desc() { return '博看听书：少年读物/儿童文学/国学经典/相声评书等'; }

  cats() {
    return [
      { id: '1305', name: '少年读物' },
      { id: '1304', name: '儿童文学' },
      { id: '1320', name: '国学经典' },
      { id: '1306', name: '文艺少年' },
      { id: '1309', name: '育儿心经' },
      { id: '1310', name: '心理哲学' },
      { id: '1307', name: '青春励志' },
      { id: '1312', name: '历史小说' },
      { id: '1303', name: '故事会' },
      { id: '1317', name: '音乐戏剧' },
      { id: '1319', name: '相声评书' },
    ];
  }

  async list(cat, page) {
    if (cat === '') cat = '1305';
    const api = `${bkHost}/voice/book/list?instance_id=25304&page=${page}&category_id=${encode(cat)}&num=24`;
    const body = await httpGet(this.client, api);
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('博看列表解析失败: ' + err.message);
    }
    const items = (resp && resp.data && resp.data.list) || [];
    const out = [];
    for (const it of items) {
      const id = kwID(it.id);
      if (id === '') continue;
      const extra = it.extra || {};
      out.push(Card({
        id,
        name: firstNonEmpty(it.name, '未知书籍'),
        pic: it.cover || '',
        remarks: extra.category || '',
        author: extra.author || '',
        desc: extra.intro || '',
      }));
    }
    return out;
  }

  async search(wd, page) {
    const api = `${bkEsHost}/api/v3/voice/book?instanceId=25304&keyword=${encode(wd)}&pageNum=${page}&limitNum=20`;
    const body = await httpGet(this.client, api);
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('博看搜索解析失败: ' + err.message);
    }
    const items = (resp && resp.data && resp.data.list) || [];
    const out = [];
    for (const it of items) {
      const id = kwID(it.id);
      if (id === '') continue;
      const extra = it.extra || {};
      out.push(Card({
        id,
        name: firstNonEmpty(it.name, '未知书籍'),
        pic: it.cover || '',
        author: extra.author || '',
        desc: extra.intro || '',
        remarks: extra.category || '',
      }));
    }
    return out;
  }

  async detail(id) {
    
    let metaName = '';
    let metaPic = '';
    let metaAuthor = '';
    let metaDesc = '';
    try {
      const list = await this.search(id, 1);
      for (const c of list) {
        if (c.vod_id === id) {
          metaName = c.vod_name;
          metaPic = c.vod_pic;
          metaAuthor = c.vod_director || '';
          metaDesc = c.vod_content || '';
          break;
        }
      }
    } catch {}

    const units = [];
    let firstCreatedAt = '';
    for (let page = 1; page <= 20; page++) {
      const api = `${bkHost}/voice/album/units?album_id=${encode(id)}&page=${page}&num=200&order=1`;
      let body;
      try {
        body = await httpGet(this.client, api);
      } catch (err) {
        if (page === 1) throw err;
        break;
      }
      let resp;
      try {
        resp = JSON.parse(body);
      } catch (err) {
        throw new Error('博看详情解析失败: ' + err.message);
      }
      const data = (resp && resp.data) || {};
      const list = data.list || [];
      if (page === 1) {
        const total = data.total || 0;
        if (total <= 0) break;
        if (list.length > 0) firstCreatedAt = String(list[0].created_at || '');
      }
      for (const it of list) {
        if (it.file) units.push({ title: it.title || '', file: it.file || '' });
      }
      if (units.length >= (data.total || 0)) break;
      if (page > Math.floor((data.total || 0) / 200) + 2) break;
    }

    const chapters = [];
    units.forEach((u, i) => {
      chapters.push(Chapter(i + 1, u.title, u.file));
    });
    let remarks = `共${chapters.length}集`;
    if (firstCreatedAt) remarks += ' · 创建于' + firstCreatedAt.slice(0, 10);
    return BookDetail({
      id,
      name: firstNonEmpty(metaName, '博看专辑 ' + id),
      pic: metaPic,
      desc: metaDesc,
      author: metaAuthor,
      remarks,
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    const file = String(ref || '').trim();
    if (file === '' || !file.includes('://')) {
      throw new Error('博看播放凭证无效');
    }
    return AudioPlay({ src: file });
  }
}


import { httpGet, defaultUA } from '../client.js';
import { unescapeHTML } from '../html.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';


const staticAsmrAlbumRe = /<item>[\s\S]*?<title>([^<]+)<\/title>\s*<link>([^<]+)<\/link>/g;
const staticAsmrNumPrefix = /^\s*\d+[.、．]\s*/;

function matchAll(re, s) {
  const re2 = new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g');
  const out = [];
  let m;
  while ((m = re2.exec(s)) !== null) {
    out.push(m);
    if (m.index === re2.lastIndex) re2.lastIndex++;
  }
  return out;
}

function firstMatch(re, s) {
  const re2 = new RegExp(re.source, re.flags.replace('g', ''));
  return re2.exec(s);
}

export class StaticAsmrProvider {
  
  constructor(client, media, cfg) {
    this.client = client;
    this.media = media;
    this.cfg = cfg;
  }

  key() { return this.cfg.key; }
  name() { return this.cfg.name; }
  desc() { return this.cfg.desc; }
  adult() { return true; }

  cats() {
    return [{ id: 'all', name: '全部' }];
  }

  async albums() {
    const cached = staticAsmrCache.get(this.cfg.key);
    if (cached && Date.now() - cached.at < staticAsmrCacheTTL) return cached.albums;
    let body;
    try {
      body = await httpGet(this.client, this.cfg.base + '/index.xml');
    } catch (err) {
      if (cached) return cached.albums;
      throw err;
    }
    const albums = [];
    for (const m of matchAll(staticAsmrAlbumRe, body)) {
      let link = String(m[2]).trim();
      if (!link.includes('/plays/')) continue;
      if (link.startsWith('/')) link = this.cfg.base + link;
      const name = unescapeHTML(String(m[1]).trim());
      if (name === '') continue;
      albums.push({ name, url: link });
    }
    if (albums.length === 0) {
      if (cached) return cached.albums;
      throw new Error(`${this.cfg.key} 未解析到专辑`);
    }
    staticAsmrCache.set(this.cfg.key, { albums, at: Date.now() });
    return albums;
  }

  async list(cat, page) {
    const albums = await this.albums();
    const start = (page - 1) * 30;
    if (start >= albums.length) return [];
    const end = Math.min(start + 30, albums.length);
    const cards = [];
    for (const a of albums.slice(start, end)) {
      cards.push(Card({ id: a.url, name: a.name, plat: this.cfg.key, author: this.cfg.name }));
    }
    return cards;
  }

  async search(wd, page) {
    const albums = await this.albums();
    const kw = String(wd).trim().toLowerCase();
    const matched = [];
    for (const a of albums) {
      if (a.name.toLowerCase().includes(kw)) matched.push(a);
    }
    const start = (page - 1) * 30;
    if (start >= matched.length) return [];
    const end = Math.min(start + 30, matched.length);
    const cards = [];
    for (const a of matched.slice(start, end)) {
      cards.push(Card({ id: a.url, name: a.name, plat: this.cfg.key, author: this.cfg.name }));
    }
    return cards;
  }

  async detail(id) {
    if (!String(id).includes('/plays/')) {
      throw new Error('专辑地址无效');
    }
    const body = await httpGet(this.client, id, { Referer: this.cfg.base + '/' });
    const chapters = [];
    for (const m of matchAll(this.cfg.audioRe, body)) {
      const href = unescapeHTML(m[1]);
      const mediaURL = this.cfg.fixURL(href);
      if (mediaURL === '') continue;
      let name = unescapeHTML(String(m[2]).trim());
      name = name.replace(staticAsmrNumPrefix, '');
      if (name === '') {
        try {
          const u = new URL(mediaURL);
          const segs = u.pathname.split('/');
          name = segs[segs.length - 1];
          try {
            name = decodeURIComponent(name);
          } catch {}
        } catch {}
      }
      chapters.push(Chapter(chapters.length + 1, name, mediaURL));
    }
    if (chapters.length === 0) {
      throw new Error(`${this.cfg.key} 未找到音频`);
    }
    return BookDetail({
      id,
      name: this.albumName(id, body),
      tag: this.cfg.name,
      author: this.cfg.name,
      remarks: `共${chapters.length}集`,
      chapters,
      count: chapters.length,
    });
  }

  albumName(pageURL, body) {
    const m = firstMatch(staticAsmrAlbumRe, body);
    if (m && unescapeHTML(String(m[1]).trim()) !== '') {
      return unescapeHTML(String(m[1]).trim());
    }
    try {
      const u = new URL(pageURL);
      const segs = u.pathname.replace(/^\/+|\/+$/g, '').split('/');
      if (segs.length > 0) {
        let dec = '';
        try {
          dec = decodeURIComponent(segs[segs.length - 1]);
        } catch {}
        if (dec !== '') return dec;
      }
    } catch {}
    return this.cfg.name;
  }

  async play(ref) {
    if (!String(ref).startsWith('http')) {
      throw new Error('播放凭证无效');
    }
    return AudioPlay({ src: staticAsmrResolve(ref), ua: defaultUA });
  }
}



const staticAsmrCache = new Map(); 
const staticAsmrCacheTTL = 10 * 60 * 1000;


export function staticAsmrResolve(u) {
  const marker = 'getfile/?path=';
  const i = String(u).indexOf(marker);
  if (i >= 0) {
    let raw = String(u).slice(i + marker.length);
    const j = raw.indexOf('&');
    if (j >= 0) raw = raw.slice(0, j);
    if (raw.startsWith('/')) {
      return 'https://asmr.121231234.xyz' + raw;
    }
  }
  return u;
}


export function newAsmreggProvider(client, media) {
  return new StaticAsmrProvider(client, media, {
    key: 'asmregg',
    name: '蛋蛋ASMR',
    desc: 'asmregg 中文音声（成人内容）',
    base: 'https://a.asmregg.top',
    audioRe: /href="(https?:\/\/[^"]*getfile\/\?path=[^"]+)"[^>]*>([\s\S]*?)<\/a>/g,
    fixURL: (u) => String(u).replace('http://asmregg.top/', 'https://asmregg.top/'),
  });
}


export function newAsaoProvider(client, media) {
  return new StaticAsmrProvider(client, media, {
    key: 'asao',
    name: '阿骚ASMR',
    desc: 'asao 中文音声（成人内容）',
    base: 'https://asao.lat',
    audioRe: /href="(\/files\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/g,
    fixURL: (u) => (String(u).startsWith('/') ? 'https://asao.lat' + u : u),
  });
}

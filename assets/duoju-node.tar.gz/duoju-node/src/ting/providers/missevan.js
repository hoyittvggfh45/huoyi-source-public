
import { httpGet } from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';
import { htmlText, firstGroup } from '../html.js';

export const meHost = 'https://www.missevan.com';
export const meUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';

function meHeaders() {
  return { 'User-Agent': meUA, Referer: meHost + '/', 'Accept-Language': 'zh-CN,zh;q=0.9' };
}

const reMeItem = /<div[^>]*class="(?:vw-frontsound-container|recommend_channel_each)[^"]*"[^>]*>/gis;
const reMeLink = /<a[^>]*href="\/sound\/(\d+)"[^>]*>/i;
const reMeImg = /data-original="([^"]+)"/i;
const reMeAlt = /alt="([^"]*)"/i;
const reMeTitle = /<div[^>]*class="[^"]*frontsound-title[^"]*"[^>]*>([\s\S]*?)<\/div>/is;
const reMeTime = /<div[^>]*class="[^"]*frontsound-time[^"]*"[^>]*>([\s\S]*?)<\/div>/is;
const reMeView = /<div[^>]*class="[^"]*viewcount[^"]*"[^>]*>([\s\S]*?)<\/div>/is;

function meBlocks(page) {
  const locs = [];
  let m;
  reMeItem.lastIndex = 0;
  while ((m = reMeItem.exec(page)) !== null) locs.push(m.index);
  if (locs.length === 0) return [];
  const out = [];
  for (let i = 0; i < locs.length; i++) {
    const end = i + 1 < locs.length ? locs[i + 1] : page.length;
    out.push(page.slice(locs[i], end));
  }
  return out;
}

function meAbs(u) {
  u = String(u || '').trim();
  if (u.startsWith('//')) return 'https:' + u;
  if (u.startsWith('/')) return meHost + u;
  return u;
}

function meCover(raw) {
  raw = String(raw || '').trim();
  if (raw === '' || raw.includes('lazy_load')) return '';
  return meAbs(raw);
}

function meCards(page) {
  const out = [];
  const seen = new Set();
  for (const blk of meBlocks(page)) {
    const m = reMeLink.exec(blk);
    if (!m) continue;
    const id = m[1];
    if (seen.has(id)) continue;
    let name = htmlText(firstGroup(reMeTitle, blk));
    if (name === '') name = String(firstGroup(reMeAlt, blk) || '').trim();
    if (name === '') continue;
    seen.add(id);
    let remarks = htmlText(firstGroup(reMeTime, blk));
    const v = htmlText(firstGroup(reMeView, blk));
    if (v !== '') remarks += ' · ' + v + ' 播放';
    out.push(Card({
      id,
      name,
      pic: meCover(firstGroup(reMeImg, blk)),
      remarks,
      cat: '音声',
      plat: 'missevan',
    }));
  }
  return out;
}

function meCatalogURL(cat, page) {
  if (page < 1) page = 1;
  return `${meHost}/sound/m/${cat}?p=${page}`;
}

let meIdxCards = [];
let meIdxTime = 0;

async function meIndex(client) {
  if (Date.now() - meIdxTime < 15 * 60 * 1000 && meIdxCards.length > 0) return meIdxCards;
  const ids = ['1', '4', '155', '101', '109', '108', '8', '11', '6', '16', '17', '157'];
  const guard = new Promise((resolve) => setTimeout(() => resolve(null), 40000));
  const jobs = Promise.all(ids.map((c) =>
    httpGet(client, meCatalogURL(c, 1), meHeaders(), 40000).then(meCards).catch(() => [])
  ));
  const results = await Promise.race([jobs, guard]);
  const all = results ? results.flat() : [];
  if (all.length === 0) {
    if (meIdxCards.length > 0) return meIdxCards;
    throw new Error('missevan: 索引为空');
  }
  meIdxCards = all;
  meIdxTime = Date.now();
  return all;
}

export class MeProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'missevan'; }
  name() { return '猫耳FM'; }
  desc() { return '猫耳FM：ASMR 音声/助眠/广播剧/有声书，官方 getsound 接口出 HLS 直链'; }

  cats() {
    return [
      { id: '1', name: '音频专区' }, { id: '4', name: '情感专区' }, { id: '155', name: 'ACG专区' },
      { id: '101', name: '自然音ASMR' }, { id: '109', name: '女性向专区' }, { id: '108', name: '声音恋人' },
      { id: '8', name: '音乐专区' }, { id: '11', name: '故事专区' }, { id: '6', name: '听书专区' },
      { id: '16', name: '轻小说' }, { id: '17', name: '网络小说' }, { id: '157', name: '自习室' },
    ];
  }

  async list(cat, page) {
    if (String(cat || '').trim() === '') cat = '1';
    const body = await httpGet(this.client, meCatalogURL(cat, page), meHeaders());
    return meCards(body);
  }

  async search(wd, page) {
    wd = String(wd || '').trim().toLowerCase();
    if (wd === '') return [];
    const all = await meIndex(this.client);
    const out = [];
    for (const c of all) {
      if (String(c.vod_name).toLowerCase().includes(wd)) {
        out.push(c);
        if (out.length >= 30) break;
      }
    }
    return out;
  }

  async detail(id) {
    const u = `${meHost}/sound/getsound?soundid=${String(id || '').trim()}`;
    const body = await httpGet(this.client, u, meHeaders());
    let payload;
    try {
      payload = JSON.parse(body);
    } catch {
      throw new Error('missevan: 详情解析失败');
    }
    const s = payload && payload.info && payload.info.sound;
    if (!s || !s.id) throw new Error('missevan: 声音不存在');
    let pic = meCover(s.front_cover);
    if (pic === '') pic = meCover(s.cover_image);
    let remarks = '';
    if (s.duration > 0) {
      const m = Math.floor(s.duration / 60);
      const sec = s.duration % 60;
      remarks = `${m}分${String(sec).padStart(2, '0')}秒`;
    }
    if (s.pay_type !== 0) remarks += ' · 付费';
    return BookDetail({
      id,
      name: s.soundstr || '',
      pic,
      desc: s.intro || '',
      tag: '音声',
      remarks,
      author: s.user ? s.user.name || '' : '',
      chapters: [Chapter(1, s.soundstr || '', id)],
      count: 1,
    });
  }

  async play(ref) {
    const id = String(ref || '').trim();
    const u = `${meHost}/sound/getsound?soundid=${id}`;
    const body = await httpGet(this.client, u, meHeaders());
    let payload;
    try {
      payload = JSON.parse(body);
    } catch {
      throw new Error('missevan: 播放信息解析失败');
    }
    const s = payload && payload.info && payload.info.sound;
    let src = s ? s.soundurl_128 || '' : '';
    if (src === '') src = s ? s.soundurl || '' : '';
    if (src === '') throw new Error('missevan: 无可用音频地址');
    return AudioPlay({ src: meAbs(src), referer: meHost + '/', ua: meUA });
  }
}


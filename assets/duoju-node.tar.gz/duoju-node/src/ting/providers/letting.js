
import { CookieJar, queryEscapeUTF8 } from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';
import { htmlText, firstGroup, unescapeHTML } from '../html.js';

export const ptcmsMobileUA = 'Mozilla/5.0 (Linux; Android 13; MI 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';

const rePtcmsBookDir = /href=["'](\/bookdir\/[^"']+)["']/;
const rePtcmsChapTtl = /<a[^>]+href=["'][^"']*\/tingshu\/(\d+)\/(\d+)\.html["'][^>]*\btitle=["']([^"']+)["']/gis;
const rePtcmsSalt = /<meta\s+name="_c"\s+content="([^"]+)"/;
const rePtcmsMetaB = /<meta\s+name="_b"\s+content="(\d+)"/;
const rePtcmsMetaP = /<meta\s+name="_p"\s+content="(\d+)"/;
const rePtcmsTitle1 = /<h1[^>]*>([\s\S]*?)<\/h1>/is;
const rePtcmsAuthor = /\/boyin\/\d+\.html["'][^>]*>([\s\S]*?)<\/a>/is;
const rePtcmsDesc = /<meta\s+name="description"\s+content="([^"]+)"/;
const rePtcmsCover = /<img[^>]+(?:data-original|data-src|src)=["']([^"']*(?:cover|uploads)[^"']*\.(?:jpg|png|jpeg)[^"']*)["']/i;
const rePtcmsStatus = /(连载|完结)/;
const rePtcmsReversed = /var\s+reversed\s*=\s*"([^"]+)"/;
const rePtcmsToken = /var\s+token\s*=\s*'([^']+)'/;
const rePtcmsBookID = /\/book\/(\d+)\.html/;
const rePtcmsListBlock = /<a[^>]+href=["'][^"']*\/book\/(\d+)\.html["'][^>]*>([\s\S]*?)<\/a>/gi;
const rePtcmsIframe = /<iframe[^>]+src=["']([^"']*player\.html[^"']*)["']/is;
const rePtcmsPlayerSrc = /(?:mp3|m4a|oga|wav)\s*:\s*'([^']*)'\s*\+\s*(\w+)\s*(?:\+\s*'([^']*)')?/;

export const LETING_CONFIGS = [
  { key: 'leting', name: '乐听网', site: 'https://m.leting.vip', wwwSite: 'https://www.leting.vip', desc: '乐听网有声小说：玄幻/武侠/悬疑/言情/名著/评书等（酷我 CDN 音源）' },
  { key: 'qdysw', name: '起点有声', site: 'https://m.qdysw.com', wwwSite: 'https://www.qdysw.com', desc: '起点有声网有声小说：与乐听网同库，玄幻/武侠/悬疑/言情/评书等（酷我 CDN 音源）' },
];


const sharedJar = new CookieJar();

export function ptcmsSolveGuard(body) {
  const m = rePtcmsReversed.exec(body);
  if (!m || !m[1]) return '';
  const r = m[1].split('').reverse().join('');
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(r)) return '';
  let js;
  try {
    js = Buffer.from(r, 'base64').toString('utf8');
  } catch {
    return '';
  }
  const tm = rePtcmsToken.exec(js);
  return tm ? tm[1] : '';
}

async function ptcmsFetch(client, method, rawURL, body, headers) {
  const cookie = sharedJar.cookieHeader(rawURL);
  const h = { ...headers };
  if (cookie) h.Cookie = cookie;
  const resp = await client.do(method, rawURL, h, {
    noBrowserHeaders: true,
    withoutCookieJar: true,
    timeoutMs: 20000,
    body,
  });
  sharedJar.store(rawURL, resp.headers);
  return resp;
}

async function ptcmsGet(client, site, rawURL) {
  for (let attempt = 0; attempt < 2; attempt++) {
    const resp = await ptcmsFetch(client, 'GET', rawURL, undefined, {
      'User-Agent': ptcmsMobileUA,
      Referer: site + '/',
      'Accept-Encoding': 'identity',
    });
    const body = (await resp.buffer()).toString('utf8');
    const token = ptcmsSolveGuard(body);
    if (token === '') return body;
    sharedJar.set(rawURL, 'pt_guid', token);
    sharedJar.set(rawURL, 'ptcms_guard_retry', '1');
  }
  throw new Error('ptcms get 不可达');
}

async function ptcmsPostJSON(client, site, rawURL, body) {
  const resp = await ptcmsFetch(client, 'POST', rawURL, String(body), {
    'User-Agent': ptcmsMobileUA,
    'Content-Type': 'application/json',
    Referer: site + '/',
    'Accept-Encoding': 'identity',
  });
  if (resp.status !== 200) {
    try { resp.stream.destroy?.(); } catch {}
    throw new Error(`HTTP ${resp.status}`);
  }
  return resp.buffer();
}

export class PtcmsProvider {
  constructor(client, media, cfg = LETING_CONFIGS[0]) {
    this.client = client;
    this.media = media;
    this.cfg = cfg;
  }

  key() { return this.cfg.key; }
  name() { return this.cfg.name; }
  desc() { return this.cfg.desc; }

  cats() {
    return [
      { id: 'xhqh', name: '玄幻奇幻' },
      { id: 'wxxx', name: '武侠仙侠' },
      { id: 'xytl', name: '悬疑推理' },
      { id: 'lsjs', name: '历史军事' },
      { id: 'xdyq', name: '现代言情' },
      { id: 'gdyq', name: '古代言情' },
      { id: 'wxmz', name: '文学名著' },
      { id: 'gxjd', name: '国学经典' },
      { id: 'dajs', name: '档案纪实' },
      { id: 'xsqy', name: '相声曲艺' },
      { id: 'zwts', name: '自我提升' },
      { id: 'ertong', name: '儿童频道' },
      { id: 'pingshu', name: '长篇评书' },
    ];
  }

  abs(u) {
    if (String(u).startsWith('http')) return u;
    return this.cfg.site + u;
  }

  async list(cat, page) {
    if (page < 1) page = 1;
    const u = `${this.cfg.site}/api/ajax/list?sort=1&key=1&tg=&order=1&page=${page}`;
    const resp = await ptcmsFetch(this.client, 'GET', u, undefined, {
      'User-Agent': ptcmsMobileUA,
      Referer: `${this.cfg.site}/book/${cat}/lastupdate/${page}.html`,
      'Accept-Encoding': 'identity',
    });
    const raw = await resp.buffer();
    let lr;
    try {
      lr = JSON.parse(raw.toString('utf8'));
    } catch (err) {
      
      
      const m = /position (\d+)/.exec(String(err?.message || ''));
      if (m) {
        try {
          lr = JSON.parse(raw.toString('utf8', 0, parseInt(m[1], 10)));
        } catch (err2) {
          throw new Error(`${this.cfg.name}列表解析: ${err2.message}`);
        }
      } else {
        throw new Error(`${this.cfg.name}列表解析: ${err.message}`);
      }
    }
    const data = (lr && lr.data) || [];
    const cards = [];
    for (const it of data) {
      const m = rePtcmsBookID.exec(it.url || '');
      const id = m ? m[1] : '';
      if (id === '' || !it.title) continue;
      let remark = it.serialize_text || '';
      const h = it.hits;
      if (typeof h === 'string' && h !== '') remark += ' · ' + h + '人听过';
      else if (typeof h === 'number' && h > 0) remark += ` · ${Math.round(h)}人听过`;
      cards.push(Card({
        id,
        name: it.title,
        pic: this.abs(it.pic || ''),
        cat: it.category || '',
        remarks: remark,
        author: it.boyin || '',
        desc: it.content || '',
      }));
    }
    if (cards.length === 0) return [];
    return cards;
  }

  async search(wd, page) {
    if (page > 1) return [];
    const form = 'searchword=' + queryEscapeUTF8(wd);
    const searchURL = this.cfg.wwwSite + '/search.html';
    const post = async () => {
      const resp = await ptcmsFetch(this.client, 'POST', searchURL, form, {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded',
        Referer: this.cfg.wwwSite + '/',
        'Accept-Encoding': 'identity',
      });
      return (await resp.buffer()).toString('utf8');
    };
    let body = await post();
    const token = ptcmsSolveGuard(body);
    if (token !== '') {
      sharedJar.set(searchURL, 'pt_guid', token);
      sharedJar.set(searchURL, 'ptcms_guard_retry', '1');
      body = await post();
    }
    return ptcmsBooks(body);
  }

  async detail(id) {
    id = String(id || '').trim();
    if (id === '') throw new Error(`${this.cfg.name}书籍 id 无效`);
    const pageHTML = await ptcmsGet(this.client, this.cfg.site, `${this.cfg.site}/book/${id}.html`);
    const det = { id, chapters: [] };
    det.name = htmlText(firstGroup(rePtcmsTitle1, pageHTML));
    if (det.name === '') det.name = htmlText(firstGroup(rePtcmsDesc, pageHTML));
    det.author = htmlText(firstGroup(rePtcmsAuthor, pageHTML));
    det.desc = unescapeHTML(firstGroup(rePtcmsDesc, pageHTML));
    const pic = firstGroup(rePtcmsCover, pageHTML);
    if (pic !== '') det.pic = this.abs(pic);
    det.remarks = firstGroup(rePtcmsStatus, pageHTML);

    const dirPath = firstGroup(rePtcmsBookDir, pageHTML);
    if (dirPath === '') throw new Error(`${this.cfg.name}未找到章节目录`);
    let no = 0;
    const seen = new Set();
    for (let pg = 1; pg <= 200; pg++) {
      let u = `${this.cfg.site}${dirPath}`;
      if (pg > 1) {
        u += dirPath.includes('?') ? `&page=${pg}&sort=asc` : `?page=${pg}&sort=asc`;
      } else {
        u += '?sort=asc';
      }
      let dirHTML;
      try {
        dirHTML = await ptcmsGet(this.client, this.cfg.site, u);
      } catch {
        break;
      }
      let added = 0;
      let m;
      rePtcmsChapTtl.lastIndex = 0;
      while ((m = rePtcmsChapTtl.exec(dirHTML)) !== null) {
        const chapID = m[2];
        const key = id + '#' + chapID;
        if (seen.has(key)) continue;
        seen.add(key);
        no++;
        let name = unescapeHTML(m[3]);
        const li = name.lastIndexOf('_');
        if (li >= 0 && li < name.length - 1) name = name.slice(li + 1);
        if (name.endsWith('在线收听')) name = name.slice(0, -('在线收听'.length));
        det.chapters.push({ no, name: name.trim(), url: key });
        added++;
      }
      if (added === 0) break;
    }
    det.count = det.chapters.length;
    if (det.count === 0) throw new Error(`${this.cfg.name}章节目录为空`);
    return BookDetail({
      id: det.id,
      name: det.name,
      pic: det.pic || '',
      desc: det.desc || '',
      tag: '',
      remarks: det.remarks || '',
      author: det.author || '',
      chapters: det.chapters,
      count: det.count,
    });
  }

  async playViaPlayer(pageHTML) {
    const iframe = firstGroup(rePtcmsIframe, pageHTML);
    if (iframe === '') return '';
    const playerURL = this.abs(iframe);
    let body;
    try {
      const resp = await ptcmsFetch(this.client, 'GET', playerURL, undefined, {
        'User-Agent': ptcmsMobileUA,
        Referer: playerURL,
        'Accept-Encoding': 'identity',
      });
      body = (await resp.buffer()).toString('utf8');
    } catch {
      return '';
    }
    const m = rePtcmsPlayerSrc.exec(body);
    if (!m) return '';
    let tail = '';
    const vm = new RegExp(`(?:^|[^a-zA-Z0-9_])${m[2].replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*=\\s*'([^']*)'`).exec(body);
    if (vm) tail = vm[1];
    const u = m[1] + tail + (m[3] || '');
    return u.startsWith('http') ? u : '';
  }

  async play(ref) {
    const [bookID, chapID] = String(ref || '').split('#');
    if (!bookID || !chapID) {
      throw new Error(`${this.cfg.name}章节凭证无效: ${ref}`);
    }
    const pageHTML = await ptcmsGet(this.client, this.cfg.site, `${this.cfg.site}/tingshu/${bookID}/${chapID}.html`);
    const salt = firstGroup(rePtcmsSalt, pageHTML);
    if (salt === '') {
      const audio = await this.playViaPlayer(pageHTML);
      if (audio !== '') return AudioPlay({ src: audio, referer: this.cfg.site + '/' });
      let head = pageHTML.trim();
      if (head.length > 200) head = head.slice(0, 200);
      throw new Error(`${this.cfg.name}播放页缺少凭证(salt) head=${JSON.stringify(head)}`);
    }

    let nid = firstGroup(rePtcmsMetaB, pageHTML);
    let cid = firstGroup(rePtcmsMetaP, pageHTML);
    if (nid === '') nid = bookID;
    if (cid === '') cid = chapID;
    const inner = `{"novelid":"${nid}","chapterid":"${cid}","type":1,"salt":"${salt}"}`;
    const encodedData = Buffer.from(queryEscapeUTF8(inner), 'utf8').toString('base64');
    const payload = JSON.stringify({ encodedData });
    let raw;
    try {
      raw = await ptcmsPostJSON(this.client, this.cfg.site, this.cfg.site + '/api/act/readplay', payload);
    } catch (err) {
      throw new Error(`${this.cfg.name}播放接口: ${err.message}`);
    }
    let pr;
    try {
      pr = JSON.parse(raw.toString('utf8'));
    } catch {
      pr = null;
    }
    if (!pr || !pr.audioUrl) {
      let diag = raw.toString('utf8');
      if (diag.length > 120) diag = diag.slice(0, 120);
      throw new Error(`${this.cfg.name}未返回音频地址: ${diag}`);
    }
    return AudioPlay({ src: pr.audioUrl, ua: ptcmsMobileUA });
  }
}

function ptcmsBooks(pageHTML) {
  const out = [];
  const seen = new Set();
  let m;
  rePtcmsListBlock.lastIndex = 0;
  while ((m = rePtcmsListBlock.exec(pageHTML)) !== null) {
    const id = m[1];
    const name = htmlText(m[2]);
    if (name === '' || seen.has(id)) continue;
    seen.add(id);
    out.push(Card({ id, name }));
  }
  return out;
}

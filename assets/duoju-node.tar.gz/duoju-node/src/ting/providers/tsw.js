
import { getHTML, encode } from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';
import { htmlText, findLinks, findImg, firstGroup, absURL as absURLTing } from '../html.js';

export const tswSite = 'https://m.tingshuwang.cc';

const reTswBook = /<li[^>]*>([\s\S]*?)<\/li>/gi;
const reTswIntro = /<p[^>]*class="[^"]*intro[^"]*"[^>]*>([\s\S]*?)<\/p>/is;
const reTswChap = /<ul[^>]*class="[^"]*chapter-list-data[^"]*"[^>]*>([\s\S]*?)<\/ul>/is;
const reTswVideo = /videourl\s*:\s*'([^']*)'/;
const reTswVType = /videotype\s*:\s*'([^']*)'/;

const reTswTitle = /<h5[^>]*>([\s\S]*?)<\/h5>/is;
const reTswTitleA = /<a[^>]+title="([^"]+)"/is;
const reTswAuthor = /<em[^>]*class="[^"]*author[^"]*"[^>]*>([\s\S]*?)<\/em>/is;
const reTswCover = /<div[^>]+class="[^"]*\bcover\b[^"]*"[^>]*>([\s\S]*?)<\/div>/is;
const reTswBookName = /<h1[^>]*class="[^"]*bookname[^"]*"[^>]*>([\s\S]*?)<\/h1>/is;
const reTswBookIntro = /<div[^>]*class="[^"]*book-intro[^"]*"[^>]*>([\s\S]*?)<\/div>/is;
const reTswAuthorSpan = /<span[^>]*class="[^"]*author[^"]*"[^>]*>([\s\S]*?)<\/span>/is;

function tswBooks(html) {
  const out = [];
  const seen = new Set();
  let m;
  reTswBook.lastIndex = 0;
  while ((m = reTswBook.exec(html)) !== null) {
    const block = m[1];

    let href = '';
    let title = '';
    const t = reTswTitle.exec(block);
    if (t) {
      const a = findFirstLink(t[1]);
      href = a.href;
      title = a.text;
    }
    if (title === '') title = String(firstGroup(reTswTitleA, block) || '').trim();
    if (href === '') href = findFirstLink(block).href;
    if (href === '' || title === '') continue;
    if (!href.includes('/book/')) continue;

    let id = href.replace(/^\/+|\/+$/g, '');
    const i = id.lastIndexOf('/');
    if (i >= 0) id = id.slice(i + 1);
    id = id.replace(/\.html$/, '');
    if (id === '' || seen.has(id)) continue;
    seen.add(id);

    let author = '';
    const am = reTswAuthor.exec(block);
    if (am) author = htmlText(am[1]);
    let pic = '';
    const cm = reTswCover.exec(block);
    if (cm) pic = findImg(tswSite + '/', cm[1]);
    if (pic === '') pic = findImg(tswSite + '/', block);
    out.push(Card({
      id,
      name: title,
      pic,
      author,
      desc: htmlText(firstGroup(reTswIntro, block)),
    }));
  }
  return out;
}

function findFirstLink(s) {
  const l = findLinks(s);
  return l.length > 0 ? l[0] : { href: '', text: '' };
}

export class TswProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'tsw'; }
  name() { return '听书网'; }
  desc() { return '听书网：玄幻武侠/恐怖悬疑/都市言情/军事历史等有声小说，音频直链'; }

  cats() {
    return [
      { id: '', name: '全部' }, { id: 'lianzai', name: '连载' }, { id: 'wanjie', name: '完结' },
      { id: 'xuanhuanwuxia', name: '玄幻武侠' }, { id: 'kongbuxuanyi', name: '恐怖悬疑' }, { id: 'dushiyanqing', name: '都市言情' },
      { id: 'zhichangshangzhan', name: '职场商战' }, { id: 'tuilixiaoshuo', name: '推理小说' }, { id: 'junshilishi', name: '军事历史' },
      { id: 'wangyoujingji', name: '网游竞技' }, { id: 'zongyiyule', name: '综艺娱乐' },
    ];
  }

  async list(cat, page) {
    const slug = cat !== '' ? cat + '/' : '';
    let u = `${tswSite}/book/${slug}index.html`;
    if (page > 1) u = `${tswSite}/book/${slug}index_${page}.html`;
    const body = await getHTML(this.client, u, tswSite + '/');
    return tswBooks(body);
  }

  async search(wd, page) {
    if (page > 1) return null; 
    const u = `${tswSite}/so/${encode(wd)}/`;
    const body = await getHTML(this.client, u, tswSite + '/');
    return tswBooks(body);
  }

  async detail(id) {
    if (id === '') throw new Error('听书网书籍 id 为空');
    const bookURL = `${tswSite}/book/${id}/`;
    const body = await getHTML(this.client, bookURL, tswSite + '/');

    let name = htmlText(firstGroup(reTswBookName, body));
    if (name === '') name = '听书网 ' + id;

    const intro = htmlText(firstGroup(reTswBookIntro, body));

    const chapters = [];
    const chap = reTswChap.exec(body);
    if (chap) {
      for (const a of findLinks(chap[1])) {
        if (a.href === '' || a.text === '') continue;
        chapters.push(Chapter(chapters.length + 1, a.text, absURLTing(bookURL, a.href)));
      }
    }

    let author = '';
    const am = reTswAuthorSpan.exec(body);
    if (am) author = htmlText(am[1]);

    let pic = '';
    const cm = reTswCover.exec(body);
    if (cm) pic = findImg(bookURL, cm[1]);
    if (pic === '') pic = findImg(bookURL, body);

    return BookDetail({
      id,
      name,
      pic,
      desc: intro,
      author,
      remarks: `共${chapters.length}集`,
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    if (!String(ref || '').startsWith('http')) {
      throw new Error('听书网播放凭证无效');
    }
    const body = await getHTML(this.client, ref, tswSite + '/');
    const audio = String(firstGroup(reTswVideo, body) || '').trim();
    const vtype = firstGroup(reTswVType, body);
    if (!audio.startsWith('http') || vtype === 'tc') {
      throw new Error('这一集听书网没有提供可直接播放的音频');
    }
    return AudioPlay({ src: audio, referer: tswSite + '/' });
  }
}



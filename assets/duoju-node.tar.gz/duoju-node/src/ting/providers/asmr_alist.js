
import { httpPostJSON, firstNonEmpty, defaultUA } from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';

const alistAudioExt = new Set(['.mp3', '.m4a', '.wav', '.flac', '.aac', '.ogg', '.m4b']);

function alistAudioFile(name) {
  const i = String(name).lastIndexOf('.');
  if (i < 0) return false;
  return alistAudioExt.has(String(name).slice(i).toLowerCase());
}

function alistJoin(parent, name) {
  return String(parent).replace(/\/$/, '') + '/' + name;
}

function alistBaseName(p) {
  p = String(p).replace(/\/$/, '');
  const i = p.lastIndexOf('/');
  if (i >= 0) return p.slice(i + 1);
  return p;
}

export class AlistAsmrProvider {
  
  constructor(client, media, cfg) {
    this.client = client;
    this.media = media;
    this.cfg = cfg;
  }

  key() { return this.cfg.key; }
  name() { return this.cfg.name; }
  desc() { return this.cfg.desc; }
  adult() { return true; }

  cats() {
    return [{ id: this.cfg.root, name: '全部' }];
  }

  async fsList(path, page, perPage) {
    const body = await httpPostJSON(
      this.client,
      this.cfg.base + '/api/fs/list',
      JSON.stringify({ path, page, per_page: perPage, password: '', refresh: false }),
      null
    );
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error(`${this.cfg.key} 解析失败: ` + err.message);
    }
    if (!resp || resp.code !== 200) {
      throw new Error(`${this.cfg.key} 列表失败: ` + firstNonEmpty(resp && resp.message, String(resp ? resp.code : '')));
    }
    return resp;
  }

  async list(cat, page) {
    if (cat === '' || cat === 'undefined') cat = this.cfg.root;
    const resp = await this.fsList(cat, page, 30);
    const content = (resp.data && resp.data.content) || [];
    const cards = [];
    for (const it of content) {
      if (!it.is_dir) continue;
      cards.push(
        Card({
          id: alistJoin(cat, it.name),
          name: it.name,
          plat: this.cfg.key,
          author: this.cfg.name,
        })
      );
    }
    return cards;
  }

  async search(wd, page) {
    const body = await httpPostJSON(
      this.client,
      this.cfg.base + '/api/fs/search',
      JSON.stringify({ keywords: wd, page, per_page: 30, parent_files: [], scope: 0 }),
      null
    );
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error(`${this.cfg.key} 搜索解析失败: ` + err.message);
    }
    if (!resp || resp.code !== 200) {
      throw new Error(`${this.cfg.key} 搜索失败: ` + firstNonEmpty(resp && resp.message, String(resp ? resp.code : '')));
    }
    const seen = new Set();
    const cards = [];
    for (const it of (resp.data && resp.data.content) || []) {
      if (it.is_dir || !alistAudioFile(it.name)) continue;
      const parent = String(it.parent || '').replace(/\/$/, '');
      if (parent === '' || seen.has(parent)) continue;
      seen.add(parent);
      cards.push(
        Card({
          id: parent,
          name: alistBaseName(parent),
          remarks: it.name,
          plat: this.cfg.key,
          author: this.cfg.name,
        })
      );
    }
    return cards;
  }

  async detail(id) {
    const paths = [id];
    const chapters = [];
    let visited = 0;
    while (paths.length > 0 && visited < 40 && chapters.length < 800) {
      const cur = paths.shift();
      visited++;
      let resp;
      try {
        resp = await this.fsList(cur, 1, 200);
      } catch (err) {
        if (chapters.length === 0 && visited === 1) throw err;
        continue;
      }
      let pageNo = 2;
      for (;;) {
        for (const it of (resp.data && resp.data.content) || []) {
          const full = alistJoin(cur, it.name);
          if (it.is_dir) {
            if (paths.length + visited < 40) paths.push(full);
            continue;
          }
          if (!alistAudioFile(it.name)) continue;
          chapters.push(Chapter(chapters.length + 1, it.name, full));
          if (chapters.length >= 800) break;
        }
        const total = (resp.data && resp.data.total) || 0;
        if (chapters.length >= 800 || pageNo * 200 > total + 200 || pageNo > 10) break;
        let next;
        try {
          next = await this.fsList(cur, pageNo, 200);
        } catch {
          break;
        }
        resp = next;
        pageNo++;
      }
    }
    if (chapters.length === 0) {
      throw new Error(`${this.cfg.key} 未找到音频文件`);
    }
    return BookDetail({
      id,
      name: alistBaseName(id),
      tag: this.cfg.name,
      author: this.cfg.name,
      remarks: `共${chapters.length}集`,
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    if (!String(ref).startsWith('/')) {
      throw new Error('播放凭证无效');
    }
    const body = await httpPostJSON(
      this.client,
      this.cfg.base + '/api/fs/get',
      JSON.stringify({ path: ref, password: '' }),
      null
    );
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error(`${this.cfg.key} 播放解析失败: ` + err.message);
    }
    const rawURL = resp && resp.data ? resp.data.raw_url : '';
    if (!resp || resp.code !== 200 || !rawURL) {
      throw new Error(`${this.cfg.key} 音频地址获取失败: ` + firstNonEmpty(resp && resp.message, String(resp ? resp.code : '')));
    }
    return AudioPlay({ src: rawURL, referer: this.cfg.base + '/', ua: defaultUA });
  }
}


export function newAsmrmoonProvider(client, media) {
  return new AlistAsmrProvider(client, media, {
    key: 'asmrmoon',
    name: 'ASMRFM',
    desc: 'asmrmoon 中文音声音频（成人内容）',
    base: 'https://asmrmoon.com',
    root: '/中文音声',
  });
}


export function newAsmrdProvider(client, media) {
  return new AlistAsmrProvider(client, media, {
    key: 'asmrd',
    name: 'ASMR岛',
    desc: 'asmrd 中日音声音频（成人内容）',
    base: 'https://www.asmrd.com',
    root: '/asmr',
  });
}


import { createHash } from 'node:crypto';
import { httpGet, encode, sleep, firstNonEmpty } from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';

export const biliWebUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

function biliHeaders() {
  return { 'User-Agent': biliWebUA, Referer: 'https://www.bilibili.com/' };
}

const wbiMixinTab = [46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13, 37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52];

const wbiFallback = ['7cd084941338484aae1ad9425b84077c', '4932caff0ff746eab6f01bf08b70ac45'];
let wbiKeys = ['', ''];
let wbiKeysAt = 0;

function lastDot(s) {
  let i = s.lastIndexOf('/');
  if (i >= 0) s = s.slice(i + 1);
  i = s.lastIndexOf('.');
  if (i >= 0) s = s.slice(0, i);
  return s;
}

async function getWbiKeys(client) {
  if (Date.now() - wbiKeysAt < 30 * 60 * 1000 && wbiKeys[0]) return wbiKeys;
  try {
    const body = await httpGet(client, 'https://api.bilibili.com/x/web-interface/nav', biliHeaders());
    const resp = JSON.parse(body);
    const img = resp && resp.data && resp.data.wbi_img;
    if (img && img.img_url) {
      wbiKeys = [lastDot(img.img_url), lastDot(img.sub_url || '')];
      wbiKeysAt = Date.now();
      return wbiKeys;
    }
  } catch {}
  wbiKeys = wbiFallback.slice();
  wbiKeysAt = Date.now();
  return wbiKeys;
}

async function encWbi(client, params) {
  const keys = await getWbiKeys(client);
  const orig = keys[0] + keys[1];
  let mixin = '';
  for (const n of wbiMixinTab) mixin += orig[n] || '';
  if (mixin.length > 32) mixin = mixin.slice(0, 32);
  params = { ...params, wts: String(Math.floor(Date.now() / 1000)) };
  const names = Object.keys(params).sort();
  const parts = [];
  for (const k of names) {
    const v = params[k].replace(/[!'()*]/g, '');
    parts.push(`${encode(k)}=${encode(v)}`);
  }
  const qs = parts.join('&');
  const sum = createHash('md5').update(qs + mixin, 'utf8').digest('hex');
  return `${qs}&w_rid=${sum}`;
}


function stripTags(s) {
  return String(s || '').replace(/<[^>]*>/gis, '');
}

function biliFmt(v) {
  let play = v.play || 0;
  let like = 0;
  if (v.stat) {
    play = v.stat.view || 0;
    like = v.stat.like || 0;
  }
  let pic = v.pic || '';
  if (pic.startsWith('//')) pic = 'https:' + pic;
  let id = v.bvid || '';
  if (id === '') id = String(v.aid || 0);
  return Card({
    id,
    name: stripTags(v.title),
    pic,
    remarks: `▶️${play} ❤️${like}`,
    author: v.owner ? v.owner.name || '' : '',
    desc: v.description || '',
  });
}

function parseBiliSearchAll(body) {
  let resp;
  try {
    resp = JSON.parse(body);
  } catch (err) {
    throw new Error('B站搜索解析失败: ' + err.message);
  }
  if (!resp || resp.code !== 0) {
    throw new Error(`B站搜索失败: code=${resp ? resp.code : '?'}`);
  }
  const blocks = (resp.data && resp.data.result) || [];
  let videos = [];
  for (const blk of blocks) {
    if (blk.result_type === 'video') { videos = blk.data || []; break; }
  }
  const out = [];
  for (const v of videos) {
    const c = biliFmt(v);
    if (c.vod_id !== '') out.push(c);
  }
  return out;
}

export class BiliProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'bili'; }
  name() { return '哔哩有声'; }
  desc() { return '哔哩有声：B站有声小说/广播剧/评书合集'; }

  cats() {
    return [
      { id: '有声小说', name: '有声小说' },
      { id: '广播剧', name: '广播剧' },
      { id: '评书', name: '评书' },
      { id: '有声漫画', name: '有声漫画' },
      { id: '历史评书', name: '历史评书' },
    ];
  }

  async list(cat, page) {
    if (cat === '') cat = '有声小说';
    const q = await encWbi(this.client, {
      page: String(page),
      page_size: '40',
      keyword: cat,
      search_type: 'video',
    });
    const api = 'https://api.bilibili.com/x/web-interface/wbi/search/all/v2?' + q;
    const body = await httpGet(this.client, api, biliHeaders());
    return parseBiliSearchAll(body);
  }

  async search(wd, page) {
    const api = `https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword=${encode(wd)}&page=${page}`;
    let body;
    try {
      body = await httpGet(this.client, api, biliHeaders());
    } catch (err) {
      await sleep(1200);
      body = await httpGet(this.client, api, biliHeaders());
    }
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('B站搜索解析失败: ' + err.message);
    }
    if (!resp || resp.code !== 0) {
      throw new Error(`B站搜索失败: code=${resp ? resp.code : '?'}（可能需要 buvid Cookie）`);
    }
    const results = (resp.data && resp.data.result) || [];
    const out = [];
    for (const it of results) {
      if (it.type !== 'video') continue;
      const c = biliFmt(it);
      if (c.vod_id !== '') out.push(c);
    }
    return out;
  }

  async detail(id) {
    let param = 'bvid=' + encode(id);
    if (!String(id).toUpperCase().startsWith('BV')) {
      param = 'aid=' + encode(id);
    }
    const api = 'https://api.bilibili.com/x/web-interface/view/detail?' + param;
    const body = await httpGet(this.client, api, biliHeaders());
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('B站详情解析失败: ' + err.message);
    }
    const view = (resp && resp.data && (resp.data.View || resp.data.view)) || null;
    if (!resp || resp.code !== 0 || !view) {
      throw new Error(`B站详情获取失败: code=${resp ? resp.code : '?'}`);
    }
    let pic = view.pic || '';
    if (pic.startsWith('//')) pic = 'https:' + pic;
    let idOut = view.bvid || '';
    if (idOut === '') idOut = String(view.aid || 0);
    const pages = view.pages || [];
    const chapters = [];
    pages.forEach((pg, i) => {
      chapters.push(Chapter(i + 1, pg.part || '', `${view.aid}+${pg.cid}`));
    });
    return BookDetail({
      id: idOut,
      name: stripTags(view.title),
      pic,
      desc: view.description || '',
      tag: view.tname || '',
      remarks: view.owner ? view.owner.name || '' : '',
      author: view.owner ? view.owner.name || '' : '',
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    ref = String(ref || '').trim().split(' ').join('+');
    const parts = ref.split('+');
    if (parts.length !== 2 || parts[0] === '' || parts[1] === '') {
      throw new Error('播放凭证无效（应为 aid+cid）');
    }
    for (const qn of ['116', '64']) {
      const api = `https://api.bilibili.com/x/player/playurl?avid=${encode(parts[0])}&cid=${encode(parts[1])}&qn=${qn}&type=mp4&platform=html5`;
      let body;
      try {
        body = await httpGet(this.client, api, biliHeaders());
      } catch {
        continue;
      }
      let resp;
      try {
        resp = JSON.parse(body);
      } catch {
        continue;
      }
      const durl = resp && resp.data && resp.data.durl;
      if (!resp || resp.code !== 0 || !durl || durl.length === 0) continue;
      const u = durl[0].url;
      if (u) return AudioPlay({ src: u, referer: 'https://www.bilibili.com/' });
    }
    throw new Error('B站未返回可播地址');
  }
}

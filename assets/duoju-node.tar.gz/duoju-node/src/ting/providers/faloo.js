
import { httpGetBytes } from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';
import { htmlText, absURL, firstGroup } from '../html.js';
import { gbkDecode, gbkEncodeQuery } from '../gbk.js';

export const falooSite = 'https://ts.faloo.com';

const reFalooItem = /<div class='audio_info_l'>([\s\S]*?)<\/a><\/div>/gi;
const reFalooA = /<a[^>]+href="([^"]+)"[^>]*title="([^"]*)"/is;
const reFalooImg = /<img[^>]+src='([^']+)'/is;
const reFalooAuther = /<dd class='audio_auther'>([^<]*)<\/dd>/is;
const reFalooIntr = /<dd class='audio_intr'>([^<]*)<\/dd>/is;
const reFalooEps = /shengyin\.png'\s*\/>(\d+)\s*集/;
const reFalooID = /\/listen\/(\d+)\.html/;

const reFalooTitle = /<div class='d_audio_content'>[\s\S]*?<dd class='audio_name'>([^<]+)<\/dd>/is;
const reFalooCover = /d_audio_img'><img[^>]+src="([^"]+)"/is;
const reFalooDesc = /<div[^>]+id=.quanbu.[^>]*>([\s\S]*?)<\/div>/is;
const reFalooMeta = /<dd class='audio_auther'>([^<]*)<\/dd>/is;

const reFalooChap = /<li class='content'>([\s\S]*?)<\/li>/gi;
const reFalooChN = /<dd class='audio_name'>([\s\S]*?)<\/dd>/is;
const reFalooChU = /<input[^>]+type='hidden'[^>]+value='([^']+\.mp3)'/is;
const reFalooAltName = /bookimg[^>]+alt="([^"]+)"/;

function falooCard(block) {
  const a = reFalooA.exec(block);
  if (!a || a.length < 3) return null;
  const m = reFalooID.exec(a[1]);
  const id = m ? m[1] : '';
  if (id === '') return null;
  let remarks = '';
  const eps = reFalooEps.exec(block);
  if (eps) remarks = '共' + eps[1] + '集';
  return Card({
    id,
    name: htmlText(a[2]),
    pic: absURL(falooSite + '/', htmlText(firstGroup(reFalooImg, block))),
    author: htmlText(firstGroup(reFalooAuther, block)).replace(/^作者:/, ''),
    desc: htmlText(firstGroup(reFalooIntr, block)),
    remarks,
  });
}

function falooCards(html) {
  const out = [];
  const seen = new Set();
  let m;
  reFalooItem.lastIndex = 0;
  while ((m = reFalooItem.exec(html)) !== null) {
    const c = falooCard(m[1]);
    if (!c || seen.has(c.vod_id)) continue;
    seen.add(c.vod_id);
    out.push(c);
  }
  return out;
}

export class FalooProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'faloo'; }
  name() { return '飞卢听书'; }
  desc() { return '飞卢小说网听书频道：玄幻/都市/同人等原创有声书，mp3 直链'; }

  cats() {
    return [
      { id: '0', name: '全部' }, { id: '1', name: '玄幻奇幻' }, { id: '2', name: '武侠仙侠' }, { id: '3', name: '都市言情' },
      { id: '4', name: '历史军事' }, { id: '5', name: '网游竞技' }, { id: '6', name: '科幻灵异' }, { id: '7', name: '同人小说' },
    ];
  }

  async list(cat, page) {
    if (cat === '') cat = '0';
    const u = `${falooSite}/category/${cat}/${page}.html`;
    const body = await this.getHTMLRaw(u, falooSite + '/');
    return falooCards(gbkDecode(body));
  }

  async search(wd, page) {
    const u = `${falooSite}/category/0/${page}.html?k=${gbkEncodeQuery(wd)}`;
    const body = await this.getHTMLRaw(u, falooSite + '/');
    return falooCards(gbkDecode(body));
  }

  
  async getHTMLRaw(api, referer) {
    return httpGetBytes(this.client, api, { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', Referer: referer });
  }

  async detail(id) {
    if (id === '') throw new Error('飞卢书籍 id 为空');
    const bookURL = `${falooSite}/listen/${id}.html`;
    const body = await this.getHTMLRaw(bookURL, falooSite + '/');
    const h = gbkDecode(body);

    let name = htmlText(firstGroup(reFalooTitle, h));
    if (name === '') {
      const m = reFalooAltName.exec(h);
      if (m) name = m[1];
    }
    if (name === '') name = '飞卢听书 ' + id;

    let intro = htmlText(firstGroup(reFalooDesc, h));
    const pubIdx = intro.indexOf('发布：');
    if (pubIdx > 0) intro = intro.slice(0, pubIdx).trim();

    let author = '';
    let tag = '';
    let mm;
    const reMeta = new RegExp(reFalooMeta.source, reFalooMeta.flags.includes('g') ? reFalooMeta.flags : reFalooMeta.flags + 'g');
    while ((mm = reMeta.exec(h)) !== null) {
      const t = htmlText(mm[1]);
      if (t.startsWith('作者:') && author === '') author = t.replace(/^作者:/, '');
      else if (t.startsWith('分类:') && tag === '') tag = t.replace(/^分类:/, '');
    }

    const pic = absURL(bookURL, htmlText(firstGroup(reFalooCover, h)));

    const chapters = [];
    let cm;
    reFalooChap.lastIndex = 0;
    while ((cm = reFalooChap.exec(h)) !== null) {
      const block = cm[1];
      const url = firstGroup(reFalooChU, block);
      if (!url.startsWith('http')) continue;
      const raw = firstGroup(reFalooChN, block);
      let title = htmlText(raw).trim();
      title = title.split('试听').join('').trim();
      chapters.push(Chapter(chapters.length + 1, title, url));
    }
    if (chapters.length === 0) {
      throw new Error('飞卢详情未解析到章节（页面结构可能已变更）');
    }

    return BookDetail({
      id,
      name,
      pic,
      desc: intro,
      tag,
      author,
      remarks: `共${chapters.length}集`,
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    if (!String(ref || '').startsWith('http')) {
      throw new Error('飞卢播放凭证无效');
    }
    return AudioPlay({ src: ref, referer: falooSite + '/' });
  }
}


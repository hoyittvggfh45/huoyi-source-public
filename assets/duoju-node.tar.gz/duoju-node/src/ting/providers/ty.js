
import { createCipheriv } from 'node:crypto';
import { httpGet, encode, md5hex, firstNonEmpty, splitN2 } from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay } from '../types.js';

const tyHost = 'https://api.itingshu.iiisss.top';
const tyToket = 'z7jhAuyG95HkBONdHjJMl6C7yfxVnKoz';
const tyKey = 'YwWZ2ufB1+cDAKPJ';
const tyKoten = 'eZ2xE6-j03xNIRlu2RPRnhBzaQZ-z9H5AU104wF1m4l3o9oAOVUHM0UCA_qYCi4dv7BImUCOzE3W7aD3DQGTS0ptz6P2JlZWJ510BG8vj_ps8S73L0D4iIxxpBys5urm';
const tySign = 'CoXx8z8MukyNyslnWhncGSl32YPJlPUQ/WowicoFBMg=';
const tyVer = '3.5.0';
const tyNovelD = 'com.itingshu.hearbook';

function tyHeaders() {
  const ts = Math.floor(Date.now() / 1000);
  return [{
    'User-Agent': 'uni-app',
    'x-Requested-With': tyNovelD,
    sign: tySign,
    'Content-Type': 'application/json',
  }, ts];
}

async function tyGet(client, path) {
  const [hdr, ts] = tyHeaders();
  const api = `${tyHost}${path}&time=${ts}&token=${md5hex(tyToket + String(ts))}&appVersion=${tyVer}`;
  return httpGet(client, api, hdr);
}


function tyAESEncrypt(plain) {
  const key = Buffer.from(tyKey, 'utf8');
  const cipher = createCipheriv('aes-128-ecb', key, null);
  return Buffer.concat([cipher.update(Buffer.from(plain, 'utf8')), cipher.final()]);
}

function tyCover(n) {
  return firstNonEmpty(n.cover, n.covers);
}

function tyCard(n) {
  const catName = n.category && n.category.name ? n.category.name : '';
  let remarks = firstNonEmpty(n.zhubo, catName);
  if (n.isover === '1') remarks = '完结 · ' + remarks;
  return Card({
    id: n.id || '',
    name: firstNonEmpty(n.name, '未知书籍'),
    pic: tyCover(n),
    remarks,
    author: firstNonEmpty(n.zhubo, catName),
    desc: n.intro || '',
  });
}

export class TyProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'ty'; }
  name() { return '听友'; }
  desc() { return '听友：玄幻/灵异/都市/评书/儿童等海量有声小说'; }

  cats() {
    return [
      { id: '0', name: '全部小说' }, { id: '1', name: '玄幻修真' }, { id: '11', name: '灵异惊悚' }, { id: '5', name: '都市言情' },
      { id: '7', name: '军事历史' }, { id: '12', name: '官场商战' }, { id: '3', name: '综艺娱乐' }, { id: '8', name: '儿童故事' },
      { id: '4', name: '长篇评书' }, { id: '9', name: '网游竞技' }, { id: '2', name: '相声戏曲' }, { id: '6', name: '百家讲坛' },
      { id: '14', name: '其他有声' }, { id: '15', name: '人物传记' }, { id: '16', name: '通俗文学' }, { id: '17', name: '经典纪实' },
    ];
  }

  async list(cat, page) {
    if (cat === '') cat = '0';
    const path = `/api/itingshu/categorylist?id=${encode(cat)}&limit=20&offset=${page}&orderid=0&isover=0&chapternum=0`;
    const body = await tyGet(this.client, path);
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('听友列表解析失败: ' + err.message);
    }
    const out = [];
    for (const w of (resp && resp.playlists) || []) {
      if (w.novel && w.novel.id) out.push(tyCard(w.novel));
    }
    return out;
  }

  async search(wd, page) {
    const path = `/api/itingshu/cloudsearch?key=${encode(wd)}&type=1&limit=30&offset=${page}&types=lastupdate`;
    const body = await tyGet(this.client, path);
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('听友搜索解析失败: ' + err.message);
    }
    const out = [];
    for (const w of (resp && resp.data) || []) {
      if (w.novel && w.novel.id) out.push(tyCard(w.novel));
    }
    return out;
  }

  async detail(id) {
    const path = `/api/itingshu/bookinfo?id=${encode(id)}&limit=1&offset=1&sorttype=asc`;
    const body = await tyGet(this.client, path);
    let resp;
    try {
      resp = JSON.parse(body);
    } catch {
      throw new Error('听友详情解析失败');
    }
    if (!resp || resp.code !== 200) throw new Error('听友详情解析失败');
    const info = resp.playlist || {};

    const chapters = [];
    for (let page = 1; page <= 100; page++) {
      const dpath = `/api/itingshu/bookdirs?id=${encode(id)}&limit=100&offset=${page}&sorttype=asc`;
      let dbody;
      try {
        dbody = await tyGet(this.client, dpath);
      } catch (err) {
        if (page === 1) throw err;
        break;
      }
      let dresp;
      try {
        dresp = JSON.parse(dbody);
      } catch (err) {
        throw new Error('听友章节解析失败: ' + err.message);
      }
      if (!dresp || dresp.code !== 200 || !(dresp.list || []).length) break;
      for (const t of dresp.list) {
        chapters.push(Chapter(chapters.length + 1, t.name || '', `${id}#${t.id}`));
      }
      const total = info.chapterlist ? info.chapterlist.total || 0 : 0;
      if (chapters.length >= total && total > 0) break;
    }

    return BookDetail({
      id,
      name: firstNonEmpty(info.name, '听友书籍 ' + id),
      pic: info.coverImgUrl || '',
      desc: info.description || '',
      author: firstNonEmpty(info.zhubo, info.creator ? info.creator.nickname : ''),
      remarks: `共${chapters.length}集`,
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    const [bookID, chapID] = splitN2(ref, '#');
    if (bookID === '' || chapID === '') throw new Error('听友播放凭证无效');
    const [hdr, ts] = tyHeaders();
    const tsStr = String(ts);
    const inner = `"${tyVer}-${ts}-${md5hex(bookID + '-' + chapID + '.mp3')}"`;
    const innerEnc = tyAESEncrypt(inner).toString('base64');
    const payload = JSON.stringify({ bookID, chapterID: chapID, time: ts, koten: tyKoten, sign: innerEnc });
    const encPayload = tyAESEncrypt(payload).toString('base64');
    const api = `${tyHost}/api/itingshu/audio?encrypted=${encode(encPayload)}&time=${tsStr}&token=${md5hex(tyToket + tsStr)}&appVersion=${tyVer}`;
    const body = await httpGet(this.client, api, hdr);
    let resp;
    try {
      resp = JSON.parse(body);
    } catch (err) {
      throw new Error('听友播放解析失败: ' + err.message);
    }
    const src0 = resp && resp.data && resp.data.src;
    if (!resp || resp.code !== 200 || !src0) throw new Error('听友音频解析失败');

    let src = src0;
    const i = src.indexOf('://');
    if (i > 0) {
      let host = src.slice(i + 3);
      const j = host.indexOf('/');
      if (j > 0) host = host.slice(0, j);
      if (host.endsWith('ting13.top') && src.startsWith('https:')) {
        src = 'http:' + src.slice(6);
      }
    }
    return AudioPlay({ src });
  }
}


import {
  httpGet, httpPostJSON, encode, firstNonEmpty, atoiDefault, newUUIDv4, splitN2,
} from '../client.js';
import { Card, BookDetail, Chapter, AudioPlay, flex } from '../types.js';

const tyfmSite = 'https://www.tingyou.fm';
const tyfmAPI = tyfmSite + '/listening-api';


const tyfmSession = newUUIDv4();

function tyfmHeaders() {
  return {
    Referer: tyfmSite + '/listening',
    Accept: 'application/json',
    'x-listening-session': tyfmSession,
    'x-listening-timezone': 'Asia/Shanghai',
  };
}

function tyfmFixCover(c) {
  if (String(c).startsWith('http://')) {
    return 'https://' + String(c).slice('http://'.length);
  }
  return c;
}

function tyfmBestIntro(a) {
  return firstNonEmpty(a.synopsis, a.description, a.intro);
}


function tyfmAlbums(r, s) {
  if (r && r.data && r.data.length > 0) return r.data;
  if (r && r.items && r.items.length > 0) return r.items;
  if (s && s.results && s.results.length > 0) return s.results;
  if (s && s.items && s.items.length > 0) return s.items;
  return [];
}

function tyfmToCard(a) {
  let id = flex(a.id);
  if (id === '') id = a.title || '';
  let status = '已完结';
  if (a.status === 1) status = '连载中';
  let remarks = status;
  if ((a.count || 0) > 0) remarks = `${a.count}集 · ${status}`;
  return Card({
    id,
    name: firstNonEmpty(String(a.title || '').trim(), '未知专辑'),
    pic: tyfmFixCover(a.cover_url || ''),
    remarks,
    author: firstNonEmpty(a.teller, a.author),
    desc: tyfmBestIntro(a),
  });
}

export class TyfmProvider {
  constructor(client, media) {
    this.client = client;
    this.media = media;
  }

  key() { return 'tyfm'; }
  name() { return '听友听书'; }
  desc() { return '听友听书：有声小说/评书/相声/百家讲坛/历史军事等'; }

  cats() {
    return [
      { id: '2', name: '有声小说' },
      { id: '1', name: '评书' },
      { id: 'rank:popular', name: '排行榜·最热' },
      { id: 'rank:new', name: '排行榜·最新' },
      { id: 'rank:updated', name: '排行榜·最近更新' },
      { id: 'rank:comprehensive', name: '排行榜·综合' },
    ];
  }

  async list(cat, page) {
    if (page < 1) page = 1;
    let url = `${tyfmAPI}/category?page=${page}`;
    if (String(cat).startsWith('rank:')) {
      url += '&sort=' + encode(String(cat).slice('rank:'.length));
    } else {
      if (cat === '') cat = '2';
      url += `&category=${encode(cat)}&type=&sort=popular`;
    }
    const body = await httpGet(this.client, url, tyfmHeaders());
    let r;
    try {
      r = JSON.parse(body);
    } catch (err) {
      throw new Error('听友听书列表解析失败: ' + err.message);
    }
    const albums = tyfmAlbums(r, null);
    const out = [];
    for (const a of albums) {
      if (flex(a.id) === '') continue;
      out.push(tyfmToCard(a));
    }
    return out;
  }

  async search(wd, page) {
    if (page < 1) page = 1;
    const body = await httpPostJSON(this.client, `${tyfmAPI}/search`, JSON.stringify({ keyword: wd, page }), tyfmHeaders());
    let s;
    try {
      s = JSON.parse(body);
    } catch (err) {
      throw new Error('听友听书搜索解析失败: ' + err.message);
    }
    const albums = tyfmAlbums(null, s);
    const out = [];
    for (const a of albums) {
      if (flex(a.id) === '') continue;
      out.push(tyfmToCard(a));
    }
    return out;
  }

  async detail(id) {
    if (String(id || '').trim() === '') throw new Error('听友听书书籍 id 无效');

    const dbody = await httpGet(this.client, `${tyfmAPI}/album/${encode(id)}`, tyfmHeaders());
    let a;
    try {
      a = JSON.parse(dbody);
    } catch (err) {
      throw new Error('听友听书详情解析失败: ' + err.message);
    }
    const albumID = firstNonEmpty(flex(a.id), id);

    let status = '已完结';
    if (a.status === 1) status = '连载中';
    let remarks = status;
    if ((a.count || 0) > 0) remarks = `共${a.count}集 · ${status}`;

    const chapters = [];
    let cbody;
    try {
      cbody = await httpGet(this.client, `${tyfmAPI}/chapters/${encode(albumID)}`, tyfmHeaders());
    } catch (err) {
      if (chapters.length === 0) throw err;
      cbody = null;
    }
    if (cbody) {
      let c;
      try {
        c = JSON.parse(cbody);
      } catch {
        c = null;
      }
      if (c) {
        for (const ch of c.chapters || []) {
          if ((ch.index || 0) <= 0) continue;
          let title = String(ch.title || '').trim();
          if (title === '') title = `第${ch.index}集`;
          chapters.push(Chapter(ch.index, title, `${albumID}#${ch.index}`));
        }
      }
    }

    return BookDetail({
      id: albumID,
      name: firstNonEmpty(String(a.title || '').trim(), '听友听书 ' + albumID),
      pic: tyfmFixCover(a.cover_url || ''),
      desc: tyfmBestIntro(a),
      author: firstNonEmpty(a.teller, a.author),
      remarks,
      chapters,
      count: chapters.length,
    });
  }

  async play(ref) {
    const [albumID, idxStr] = splitN2(ref, '#');
    if (albumID === '' || idxStr === '') {
      throw new Error(`听友听书章节凭证无效: ${ref}`);
    }
    const body = await httpPostJSON(this.client, `${tyfmAPI}/play`, JSON.stringify({ album_id: albumID, chapter_idx: atoiDefault(idxStr, 0) }), tyfmHeaders());
    let r;
    try {
      r = JSON.parse(body);
    } catch (err) {
      throw new Error('听友听书播放解析失败: ' + err.message);
    }
    if (r.error || !String(r.play_url || '').startsWith('http')) {
      let msg = r.message;
      if (!msg) msg = '未返回播放地址';
      throw new Error(`听友听书: ${msg}`);
    }
    return AudioPlay({ src: r.play_url, referer: tyfmSite + '/listening' });
  }
}

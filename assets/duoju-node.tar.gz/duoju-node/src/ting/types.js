



export function Card({ id = '', name = '', pic = '', remarks = '', cat = '', author = '', desc = '', plat = '' } = {}) {
  const c = {
    vod_id: id,
    vod_name: name,
    vod_pic: pic,
    vod_remarks: remarks,
    vod_class: cat,
  };
  if (author) c.vod_director = author;
  if (desc) c.vod_content = desc;
  if (plat) c.vod_plat = plat;
  return c;
}

export function Cat(id, name) {
  return { id, name };
}

export function Chapter(no, name, url) {
  return { no, name, url };
}

export function BookDetail({ id, name = '', pic = '', desc = '', tag = '', remarks = '', author = '', chapters = [], count = 0 } = {}) {
  return {
    vod_id: id,
    vod_name: name,
    vod_pic: pic,
    vod_content: desc,
    vod_class: tag,
    vod_remarks: remarks,
    vod_director: author,
    chapters: chapters || [],
    chapter_count: count,
  };
}

export function AudioPlay({ src = '', referer = '', ua = '', direct = false, local = '' } = {}) {
  const a = { src };
  if (referer) a.referer = referer;
  if (ua) a.ua = ua;
  if (direct) a.direct = true;
  if (local) a.local = local;
  return a;
}

export function Platform(key, name, desc = '') {
  const p = { key, name };
  if (desc) p.desc = desc;
  return p;
}


export function flex(v) {
  if (v === undefined || v === null) return '';
  if (typeof v === 'string') return v;
  return String(v);
}

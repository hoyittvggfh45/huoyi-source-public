


export const bootstrapJS = String.raw`(function () {
  var N = globalThis.__jdd;
  var B = globalThis.Buffer;

  function hasHeader(h, name) {
    for (var k in h) {
      if (Object.prototype.hasOwnProperty.call(h, k) && k.toLowerCase() === name) return true;
    }
    return false;
  }

  function buildRequest(url, options) {
    options = options || {};
    var headers = {};
    if (options.headers) {
      for (var k in options.headers) {
        if (Object.prototype.hasOwnProperty.call(options.headers, k)) {
          var hv = options.headers[k];
          if (hv !== undefined && hv !== null) headers[k] = String(hv);
        }
      }
    }
    var method = String(options.method || 'get').toLowerCase();
    var body = null;
    if (options.form) {
      var ps = new URLSearchParams();
      for (var fk in options.form) {
        if (Object.prototype.hasOwnProperty.call(options.form, fk) && options.form[fk] !== undefined && options.form[fk] !== null) {
          ps.append(fk, options.form[fk]);
        }
      }
      body = B.from(ps.toString(), 'utf8');
      if (!hasHeader(headers, 'content-type')) headers['Content-Type'] = 'application/x-www-form-urlencoded';
    } else if (options.formData) {
      var ps2 = new URLSearchParams();
      for (var dk in options.formData) {
        if (Object.prototype.hasOwnProperty.call(options.formData, dk)) {
          var dv = options.formData[dk];
          if (dv !== undefined && dv !== null) {
            if (typeof dv === 'object' && dv.value !== undefined) ps2.append(dk, dv.value);
            else ps2.append(dk, dv);
          }
        }
      }
      body = B.from(ps2.toString(), 'utf8');
      if (!hasHeader(headers, 'content-type')) headers['Content-Type'] = 'application/x-www-form-urlencoded';
    } else if (options.body !== undefined && options.body !== null) {
      var raw = options.body;
      if (typeof raw === 'string') {
        body = B.from(raw, 'utf8');
      } else if (B.isBuffer(raw)) {
        body = raw;
      } else if (typeof ArrayBuffer !== 'undefined' && raw instanceof ArrayBuffer) {
        body = B.from(new Uint8Array(raw));
      } else if (raw instanceof Uint8Array) {
        body = B.from(raw);
      } else {
        body = B.from(JSON.stringify(raw), 'utf8');
        if (!hasHeader(headers, 'content-type')) headers['Content-Type'] = 'application/json';
      }
    }
    return {
      method: method,
      url: String(url),
      headers: headers,
      body: body,
      timeout: typeof options.timeout === 'number' && options.timeout > 0 ? Math.min(options.timeout, 60000) : 60000
    };
  }

  function URLSearchParams(init) {
    this._p = [];
    if (typeof init === 'string') {
      var s = init.replace(/^\?/, '');
      if (s) {
        var parts = s.split('&');
        for (var i = 0; i < parts.length; i++) {
          if (!parts[i]) continue;
          var kv = parts[i].split('=');
          this._p.push([
            decodeURIComponent(String(kv[0] || '').replace(/\+/g, ' ')),
            decodeURIComponent(String(kv[1] === undefined ? '' : kv[1]).replace(/\+/g, ' '))
          ]);
        }
      }
    } else if (init && typeof init === 'object') {
      if (Array.isArray(init)) {
        for (var j = 0; j < init.length; j++) this._p.push([String(init[j][0]), String(init[j][1])]);
      } else {
        for (var k in init) {
          if (Object.prototype.hasOwnProperty.call(init, k)) this._p.push([String(k), String(init[k])]);
        }
      }
    }
  }
  URLSearchParams.prototype.append = function (k, v) { this._p.push([String(k), String(v)]); };
  URLSearchParams.prototype.set = function (k, v) {
    k = String(k);
    this._p = this._p.filter(function (p) { return p[0] !== k; });
    this._p.push([k, String(v)]);
  };
  URLSearchParams.prototype.get = function (k) {
    k = String(k);
    for (var i = 0; i < this._p.length; i++) if (this._p[i][0] === k) return this._p[i][1];
    return null;
  };
  URLSearchParams.prototype.getAll = function (k) {
    k = String(k);
    var out = [];
    for (var i = 0; i < this._p.length; i++) if (this._p[i][0] === k) out.push(this._p[i][1]);
    return out;
  };
  URLSearchParams.prototype.has = function (k) { return this.get(k) !== null; };
  URLSearchParams.prototype['delete'] = function (k) {
    k = String(k);
    this._p = this._p.filter(function (p) { return p[0] !== k; });
  };
  URLSearchParams.prototype.toString = function () {
    var out = [];
    for (var i = 0; i < this._p.length; i++) {
      out.push(encodeURIComponent(this._p[i][0]) + '=' + encodeURIComponent(this._p[i][1]));
    }
    return out.join('&');
  };
  URLSearchParams.prototype.forEach = function (fn, thisArg) {
    for (var i = 0; i < this._p.length; i++) fn.call(thisArg, this._p[i][1], this._p[i][0], this);
  };
  URLSearchParams.prototype.keys = function () { return this._p.map(function (p) { return p[0]; }); };
  URLSearchParams.prototype.values = function () { return this._p.map(function (p) { return p[1]; }); };

  function URL(input, base) {
    var s = String(input);
    if (base && !/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(s)) {
      var b = String(base);
      var m = /^([a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^\/?#]*)(.*)$/.exec(b);
      if (m) s = m[1] + (s.charAt(0) === '/' ? s : '/' + s);
    }
    this.href = s;
    var r = /^([a-zA-Z][a-zA-Z0-9+.-]*:)\/\/([^\/?#]*)([^?#]*)(\?[^#]*)?(#.*)?$/.exec(s);
    if (r) {
      this.protocol = r[1];
      this.host = r[2];
      this.hostname = String(r[2]).split(':')[0];
      this.port = String(r[2]).split(':')[1] || '';
      this.pathname = r[3] || '/';
      this.search = r[4] || '';
      this.hash = r[5] || '';
      this.origin = r[1] + '//' + r[2];
    } else {
      this.protocol = '';
      this.host = '';
      this.hostname = '';
      this.port = '';
      this.pathname = s;
      this.search = '';
      this.hash = '';
      this.origin = 'null';
    }
    this.searchParams = new URLSearchParams(this.search);
  }
  URL.prototype.toString = function () { return this.href; };
  URL.prototype.toJSON = function () { return this.href; };

  function TextEncoder() {}
  TextEncoder.prototype.encode = function (s) { return B.from(String(s), 'utf8'); };
  TextEncoder.prototype.encodeInto = function (s, d) {
    var b = B.from(String(s), 'utf8');
    d.set(b);
    return { read: String(s).length, written: b.length };
  };
  function TextDecoder() {}
  TextDecoder.prototype.decode = function (b) { return B.from(b).toString('utf8'); };

  var lx = {
    version: '2.0.0',
    env: 'desktop',
    platform: 'web',
    EVENT_NAMES: { request: 'request', inited: 'inited', updateAlert: 'updateAlert' },
    currentScriptInfo: N.scriptInfo,
    request: function (url, options, callback) { return N.request(buildRequest(url, options), callback); },
    on: function (name, handler) { if (name === 'request') N.onRequest(handler); },
    send: function (name, data) { N.send(name, data); },
    utils: {
      buffer: {
        from: function (d, e) { return B.from(d, e); },
        bufToString: function (b, f) {
          if (B.isBuffer(b)) return b.toString(f);
          return B.from(b, 'binary').toString(f);
        }
      },
      crypto: {
        md5: function (s) { return N.md5(s); },
        aesEncrypt: function (buf, mode, key, iv) { return N.aesEncrypt(buf, mode, key, iv); },
        rsaEncrypt: function (buf, key) { return N.rsaEncrypt(buf, key); },
        randomBytes: function (n) { return N.randomBytes(n); }
      },
      zlib: {
        inflate: function (b) { return N.inflate(b); },
        deflate: function (b) { return N.deflate(b); }
      }
    }
  };

  globalThis.lx = lx;
  globalThis.Lx = lx;
  globalThis.__jddAwait = function (p, id) {
    try {
      Promise.resolve(p).then(function (v) {
        N.done(id, true, v);
      }, function (e) {
        N.done(id, false, (e && e.message) ? String(e.message) : String(e));
      });
    } catch (e) {
      N.done(id, false, String((e && e.message) || e));
    }
  };

  globalThis.buildRequest = buildRequest;
  globalThis.fetch = function (url, options) { return N.fetch(buildRequest(url, options)); };
  globalThis.URLSearchParams = URLSearchParams;
  globalThis.URL = URL;
  globalThis.TextEncoder = TextEncoder;
  globalThis.TextDecoder = TextDecoder;
  globalThis.atob = function (s) { return B.from(String(s), 'base64').toString('binary'); };
  globalThis.btoa = function (s) { return B.from(String(s), 'binary').toString('base64'); };
  globalThis.setTimeout = function (fn, ms) {
    var args = Array.prototype.slice.call(arguments, 2);
    return N.setTimeout(fn, ms, ...args);
  };
  globalThis.clearTimeout = function (id) { N.clearTimeout(id); };
  globalThis.setInterval = function (fn, ms) {
    var args = Array.prototype.slice.call(arguments, 2);
    var tick = Math.max(Number(ms) || 0, 16);
    var timer = { id: 0, fn: fn, args: args, stopped: false };
    var run = function () {
      if (timer.stopped) return;
      try { fn.apply(null, args); } catch (e) {}
      timer.id = N.setTimeout(run, tick);
    };
    timer.id = N.setTimeout(run, tick);
    return timer;
  };
  globalThis.clearInterval = function (t) {
    if (t && typeof t === 'object') {
      t.stopped = true;
      if (t.id) N.clearTimeout(t.id);
    } else if (t !== undefined && t !== null) {
      N.clearTimeout(t);
    }
  };
  globalThis.setImmediate = function (fn) {
    var args = Array.prototype.slice.call(arguments, 1);
    return N.setTimeout(fn, 0, ...args);
  };

  globalThis.console = {
    log: N.log, info: N.log, warn: N.log, error: N.log,
    debug: N.log, trace: N.log, dir: N.log, table: N.log,
    group: function () {}, groupEnd: function () {}, groupCollapsed: function () {},
    time: function () {}, timeEnd: function () {}, count: function () {},
    countReset: function () {}, assert: function () {}, clear: function () {}
  };

  globalThis.process = {
    nextTick: function (fn) {
      var args = Array.prototype.slice.call(arguments, 1);
      setTimeout(function () { fn.apply(null, args); }, 0);
    },
    env: { NODE_ENV: 'production' },
    version: 'v18.0.0',
    platform: 'linux',
    on: function () {},
    once: function () {},
    exit: function () {}
  };

  globalThis.module = { exports: {} };
  globalThis.exports = globalThis.module.exports;
  globalThis.require = function (m) {
    if (m === 'buffer') return { Buffer: B };
    if (m === 'crypto') return lx.utils.crypto;
    if (m === 'zlib') return lx.utils.zlib;
    if (m === 'url') return { URL: URL, URLSearchParams: URLSearchParams };
    if (m === 'path') {
      return {
        join: function () { return Array.prototype.slice.call(arguments).join('/'); },
        basename: function (p) { return String(p).split('/').pop(); },
        dirname: function (p) { return String(p).split('/').slice(0, -1).join('/'); }
      };
    }
    throw new Error('模块 ' + m + ' 不允许在沙箱中加载');
  };
  globalThis.crypto = lx.utils.crypto;
  globalThis.global = globalThis;
  globalThis.window = globalThis;
  globalThis.self = globalThis;
})();`;

export const musicFreeShim = String.raw`(function () {
  var mf = globalThis.module && globalThis.module.exports;
  if (!mf || typeof mf !== 'object' || (!mf.platform && !mf.search && !mf.getMediaSource)) {
    globalThis.__jdd.send('updateAlert', { message: 'MusicFree 插件未导出有效对象 (缺少 platform/search/getMediaSource)' });
    return;
  }
  var platform = mf.platform || 'unknown';
  var sourceId = String(platform).toLowerCase().replace(/[^a-z0-9]/g, '');
  var actions = ['musicUrl'];
  if (typeof mf.search === 'function') actions.push('search');
  if (typeof mf.getLyric === 'function') actions.push('lyric');
  if (typeof mf.getMediaSource !== 'function' && typeof mf.search !== 'function') {
    globalThis.__jdd.send('updateAlert', { message: 'MusicFree 插件缺少可用能力' });
    return;
  }
  var qualityMap = { '128k': 'standard', '192k': 'standard', '320k': 'high', 'flac': 'lossless', '24bit': 'lossless' };
  var sources = {};
  sources[sourceId] = { name: platform, type: 'music', actions: actions, qualitys: ['128k', '320k', 'flac'] };
  globalThis.lx.on('request', async function (data) {
    if (data.action === 'musicUrl') {
      if (typeof mf.getMediaSource !== 'function') throw new Error('插件不支持获取播放链接');
      var q = qualityMap[data.quality] || 'high';
      var item = data.musicInfo || data.info;
      if (item && !item.id) item = Object.assign({}, item, { id: item.songmid });
      var r = await mf.getMediaSource(item, q);
      if (!r) throw new Error('未获取到播放链接');
      return { url: (r && typeof r === 'object') ? (r.url || r.src) : r, type: data.quality };
    }
    if (data.action === 'search') {
      if (typeof mf.search !== 'function') throw new Error('插件不支持搜索');
      var res = await mf.search(data.keyword, data.page || 1, data.type || 'music');
      if (!res) return { isEnd: true, data: [] };
      var list = (res.data || []).map(function (it) {
        return {
          name: it.title || it.name || '',
          singer: it.artist || it.author || '',
          album: it.album || '',
          songmid: it.id || it.songmid || '',
          img: it.artwork || it.pic || it.cover || '',
          source: sourceId,
          interval: it.duration || 0
        };
      });
      return { isEnd: res.isEnd === undefined ? true : res.isEnd, data: list, total: res.total || list.length };
    }
    if (data.action === 'lyric') {
      if (typeof mf.getLyric !== 'function') throw new Error('插件不支持歌词');
      var r2 = await mf.getLyric((data.musicInfo || data.info) || {});
      if (!r2) return { lyric: '' };
      return { lyric: r2.rawLrc || r2.lrc || r2.lyric || '', tlyric: r2.translation || r2.trc || '' };
    }
    throw new Error('不支持的操作: ' + data.action);
  });
  globalThis.lx.send('inited', { status: true, sources: sources });
})();`;

export function wrappedScript(script) {
  return '(function(){\n' + script + '\n})();\n';
}

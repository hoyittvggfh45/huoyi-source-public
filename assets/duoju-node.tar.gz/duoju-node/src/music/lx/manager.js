
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { newEngine } from './engine.js';
import { firstNonEmpty } from '../common.js';
import { BrowserClient } from '../../core/client.js';

let scriptDir = '';
let defaultManager = null;

export function setDir(dir) {
  scriptDir = path.join(dir, 'Script');
}

export function getDir() {
  return scriptDir;
}


function newEntry(o) {
  return {
    id: o.id,
    name: o.name,
    description: o.description,
    version: o.version,
    author: o.author,
    homepage: o.homepage,
    enabled: o.enabled,
    allowUnsafeVM: o.allowUnsafeVM,
    supportedSources: o.supportedSources,
    enabledSources: o.enabledSources,
    isMusicFree: o.isMusicFree,
  };
}

const reComment = /\/\*[*!]([\s\S]*?)\*\//;
const reName = /@name\s+(.+)/;
const reDesc = /@description\s+(.+)/;
const reVer = /@version\s+(.+)/;
const reAuthor = /@author\s+(.+)/;
const reRepo = /@(?:repository|homepage)\s+(.+)/;
const rePlat = /platform\s*[:=]\s*['"]([^'"]+)['"]/;
const reVer2 = /version\s*[:=]\s*['"]([^'"]+)['"]/;
const reAuth2 = /author\s*[:=]\s*['"]([^'"]+)['"]/;

export function extractMetadata(script) {
  const meta = { name: '', description: '', version: '', author: '', homepage: '' };
  const cm = reComment.exec(script);
  if (cm) {
    const comment = cm[1];
    const pick = (re) => {
      const mm = re.exec(comment);
      return mm ? mm[1].trim() : '';
    };
    meta.name = pick(reName);
    meta.description = pick(reDesc);
    meta.version = pick(reVer);
    meta.author = pick(reAuthor);
    meta.homepage = pick(reRepo);
  }
  if (meta.name === '') {
    const mm = rePlat.exec(script);
    if (mm) meta.name = mm[1].trim();
  }
  if (meta.version === '') {
    const mm = reVer2.exec(script);
    if (mm) meta.version = mm[1].trim();
  }
  if (meta.author === '') {
    const mm = reAuth2.exec(script);
    if (mm) meta.author = mm[1].trim();
  }
  return meta;
}

const reMFCJS = /module\.exports\s*=/;
const reMFNoLX = /globalThis\s*\[\s*['"]lx['"]\s*\]/;
const reMFLxOn = /lx\s*\.\s*on\s*\(/;
const reMFExpo = /exports\.\w+\s*=/;
const reMFPlat = /\bplatform\s*[:=]/;
const reMFSearc = /\bsearch\s*[:=]/;

export function isMusicFreePlugin(script) {
  if (reMFCJS.test(script) && !reMFNoLX.test(script) && !reMFLxOn.test(script)) {
    return true;
  }
  if (reMFExpo.test(script) && reMFPlat.test(script) && reMFSearc.test(script)) {
    return true;
  }
  return false;
}

function sanitizeID(id) {
  let s = String(id ?? '').trim();
  s = s.replaceAll('\\', '_').replaceAll('/', '_').replaceAll(':', '_').replaceAll('..', '_');
  return s;
}

function versionStr(v) {
  
  if (v === undefined || v === null) return '<nil>';
  if (typeof v === 'number') return String(v);
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  return String(v);
}

class Manager {
  constructor(dir) {
    this.dir = dir;
    this.entries = [];
    this.engines = new Map();
    this.status = new Map();
    this.stats = new Map();
    this.engineMeta = new Map(); 
  }

  metaPath() {
    return path.join(this.dir, 'sources.json');
  }

  loadMeta() {
    let data;
    try {
      data = fs.readFileSync(this.metaPath());
    } catch {
      return;
    }
    let list;
    try {
      list = JSON.parse(data.toString('utf8'));
    } catch {
      return;
    }
    if (!Array.isArray(list)) return;
    for (const raw of list) {
      if (!raw || typeof raw !== 'object' || !raw.id) continue;
      const e = newEntry({
        id: String(raw.id),
        name: String(raw.name ?? ''),
        description: String(raw.description ?? ''),
        version: raw.version ?? '',
        author: String(raw.author ?? ''),
        homepage: String(raw.homepage ?? ''),
        enabled: !!raw.enabled,
        allowUnsafeVM: !!raw.allowUnsafeVM,
        supportedSources: Array.isArray(raw.supportedSources) ? raw.supportedSources.map(String) : null,
        enabledSources: Array.isArray(raw.enabledSources) ? raw.enabledSources.map(String) : null,
        isMusicFree: !!raw.isMusicFree,
      });
      if (e.enabledSources === null) {
        e.enabledSources = e.supportedSources ? [...e.supportedSources] : [];
      }
      this.entries.push(e);
    }
  }

  saveMeta() {
    const list = this.entries.map((e) => newEntry(e));
    let data;
    try {
      data = JSON.stringify(list, null, 2);
    } catch {
      return;
    }
    try {
      fs.mkdirSync(this.dir, { recursive: true });
      const tmp = this.metaPath() + '.tmp';
      fs.writeFileSync(tmp, data);
      fs.renameSync(tmp, this.metaPath());
    } catch {}
  }

  scriptPath(id) {
    return path.join(this.dir, sanitizeID(id) + '.js');
  }

  find(id) {
    return this.entries.find((e) => e.id === id) || null;
  }

  indexOf(id) {
    return this.entries.findIndex((e) => e.id === id);
  }

  setStatus(id, st) {
    if (st === null || st === undefined) this.status.delete(id);
    else this.status.set(id, st);
  }

  getStatus(id) {
    const st = this.status.get(id);
    if (!st) return { status: 'unknown' };
    return st;
  }

  async engineFor(id) {
    const eng = this.engines.get(id);
    if (eng) return eng;
    const entry = this.find(id);
    if (!entry) throw new Error(`源不存在: ${id}`);
    return await this.loadEntry(entry);
  }

  async loadEntry(entry) {
    let data = null;
    try {
      data = fs.readFileSync(this.scriptPath(entry.id));
    } catch {
      try {
        data = fs.readFileSync(path.join(this.dir, entry.id));
      } catch {
        data = null;
      }
    }
    if (data === null) {
      this.setStatus(entry.id, { status: 'failed', error: '脚本文件不存在' });
      throw new Error(`脚本文件不存在: ${entry.id}`);
    }
    const script = data.toString('utf8');
    const meta = extractMetadata(script);
    const sm = {
      id: entry.id,
      name: firstNonEmpty(meta.name, entry.name, entry.id),
      description: firstNonEmpty(meta.description, entry.description),
      version: firstNonEmpty(meta.version, versionStr(entry.version)),
      author: firstNonEmpty(meta.author, entry.author),
      homepage: firstNonEmpty(meta.homepage, entry.homepage),
      rawScript: script,
      isMusicFree: isMusicFreePlugin(script),
    };
    let eng;
    try {
      eng = await newEngine(sm, 10000);
    } catch (e) {
      this.setStatus(entry.id, { status: 'failed', error: e.message || String(e) });
      throw e;
    }
    const supported = Object.keys(eng.Sources()).sort();

    this.engines.set(entry.id, eng);
    entry.supportedSources = supported;
    if (!entry.enabledSources || entry.enabledSources.length === 0) {
      entry.enabledSources = [...supported];
    } else {
      const keep = [];
      for (const s of entry.enabledSources) {
        if (supported.includes(s)) keep.push(s);
      }
      entry.enabledSources = keep;
    }
    this.setStatus(entry.id, { status: 'success' });
    this.saveMeta();
    return eng;
  }

  dropEngine(id) {
    const e = this.engines.get(id);
    if (e) e.close();
    this.engines.delete(id);
  }

  preload() {
    const entries = [...this.entries];
    for (const e of entries) {
      if (!e.enabled) {
        this.setStatus(e.id, { status: 'disabled' });
        continue;
      }
      this.engineFor(e.id).catch(() => {});
    }
  }

  init() {
    this.preload();
  }

  list() {
    const out = [];
    for (const e of this.entries) {
      let st = this.getStatus(e.id);
      if (st.status === 'unknown' && e.enabled) {
        st = { status: 'unknown' };
      }
      const src = e.supportedSources ? [...e.supportedSources] : [];
      const en = e.enabledSources ? [...e.enabledSources] : [];
      out.push({ ...newEntry(e), supportedSources: src, enabledSources: en, status: st });
    }
    return out;
  }

  async getScript(id) {
    try {
      return fs.readFileSync(this.scriptPath(id)).toString('utf8');
    } catch {
      try {
        return fs.readFileSync(path.join(this.dir, id)).toString('utf8');
      } catch {
        throw new Error(`源脚本不存在: ${id}`);
      }
    }
  }

  async add(id, script, opts = {}) {
    id = sanitizeID(id);
    if (id === '' || script === '') {
      throw new Error('缺少 id 或 script 参数');
    }
    fs.mkdirSync(this.dir, { recursive: true });
    const p = this.scriptPath(id);
    fs.writeFileSync(p, script);
    const meta = extractMetadata(script);
    let enabled = true;
    if (opts.enabled !== undefined && opts.enabled !== null) enabled = !!opts.enabled;
    const entry = newEntry({
      id,
      name: firstNonEmpty(meta.name, opts.name, id),
      description: firstNonEmpty(meta.description, opts.description),
      version: firstNonEmpty(meta.version, opts.version, '1'),
      author: firstNonEmpty(meta.author, opts.author),
      homepage: firstNonEmpty(meta.homepage, opts.homepage),
      enabled,
      allowUnsafeVM: !!opts.allowUnsafeVM,
      supportedSources: null,
      enabledSources: null,
      isMusicFree: isMusicFreePlugin(script),
    });
    const i = this.indexOf(id);
    if (i >= 0) {
      entry.supportedSources = this.entries[i].supportedSources;
      entry.enabledSources = this.entries[i].enabledSources;
      this.entries[i] = entry;
    } else {
      this.entries.push(entry);
    }
    this.saveMeta();

    if (!enabled) {
      this.setStatus(id, { status: 'disabled' });
      return entry;
    }

    try {
      await this.loadEntry(entry);
    } catch (e) {
      try { fs.unlinkSync(p); } catch {}
      const j = this.indexOf(id);
      if (j >= 0) this.entries.splice(j, 1);
      this.saveMeta();
      throw new Error(`此规则脚本不可用：${e.message || e}`);
    }
    return { ...this.find(id) };
  }

  async update(id, up = {}) {
    const i = this.indexOf(id);
    if (i < 0) throw new Error(`源不存在: ${id}`);
    const entry = this.entries[i];
    let reload = false;
    if (up.script !== undefined && up.script !== null) {
      let p = this.scriptPath(id);
      if (!fs.existsSync(p)) p = path.join(this.dir, id);
      fs.writeFileSync(p, up.script);
      const meta = extractMetadata(up.script);
      if (meta.name !== '') entry.name = meta.name;
      if (meta.description !== '') entry.description = meta.description;
      if (meta.version !== '') entry.version = meta.version;
      if (meta.author !== '') entry.author = meta.author;
      if (meta.homepage !== '') entry.homepage = meta.homepage;
      entry.isMusicFree = isMusicFreePlugin(up.script);
      reload = true;
    }
    if (up.enabled !== undefined && up.enabled !== null) {
      entry.enabled = !!up.enabled;
      if (up.enabled) reload = true;
    }
    if (up.allowUnsafeVM !== undefined && up.allowUnsafeVM !== null) {
      entry.allowUnsafeVM = !!up.allowUnsafeVM;
    }
    if (up.name !== undefined && up.name !== null) entry.name = up.name;
    if (up.description !== undefined && up.description !== null) entry.description = up.description;
    if (up.hasSrcList) {
      entry.enabledSources = up.enabledSources || [];
    }
    const out = { ...entry };
    this.saveMeta();

    if (!entry.enabled) {
      this.dropEngine(id);
      this.setStatus(id, { status: 'disabled' });
      return out;
    }
    if (reload) {
      this.dropEngine(id);
      try {
        await this.engineFor(id);
      } catch (e) {
        return out; 
      }
    }
    return out;
  }

  async delete(id) {
    const i = this.indexOf(id);
    if (i < 0) throw new Error(`源不存在: ${id}`);
    this.entries.splice(i, 1);
    this.saveMeta();
    this.dropEngine(id);
    this.setStatus(id, null);
    try { fs.unlinkSync(this.scriptPath(id)); } catch {}
    try { fs.unlinkSync(path.join(this.dir, id)); } catch {}
  }

  async toggle(id, enabled) {
    return this.update(id, { enabled: !!enabled });
  }

  async togglePlatform(id, platform, enabled) {
    const i = this.indexOf(id);
    if (i < 0) throw new Error(`源不存在: ${id}`);
    const entry = this.entries[i];
    if (!entry.supportedSources || !entry.supportedSources.includes(platform)) {
      throw new Error(`源不支持平台: ${platform}`);
    }
    let list = entry.enabledSources;
    if (!list) list = [...entry.supportedSources];
    if (enabled) {
      if (!list.includes(platform)) list = [...list, platform];
    } else {
      list = list.filter((s) => s !== platform);
    }
    entry.enabledSources = list;
    const out = { ...entry };
    this.saveMeta();
    return out;
  }

  async reorder(ids) {
    if (!ids || ids.length === 0) throw new Error('缺少 ids 数组参数');
    const byID = new Map();
    for (const e of this.entries) byID.set(e.id, e);
    const reordered = [];
    for (const id of ids) {
      const e = byID.get(id);
      if (e) {
        reordered.push(e);
        byID.delete(id);
      }
    }
    const rest = this.entries.filter((e) => byID.has(e.id));
    this.entries = [...reordered, ...rest];
    this.saveMeta();
    return reordered.length + rest.length;
  }

  async reload() {
    for (const e of [...this.entries]) {
      this.dropEngine(e.id);
    }
    this.preload();
  }

  statusList() {
    return this.entries.map((e) => ({
      id: e.id, name: e.name, enabled: e.enabled, status: this.getStatus(e.id),
    }));
  }

  loaded() {
    const ids = [...this.engines.keys()].sort();
    const out = [];
    for (const id of ids) {
      const e = this.engines.get(id);
      const entry = this.find(id);
      out.push({
        id,
        name: e.meta.name,
        description: e.meta.description,
        version: e.meta.version,
        author: e.meta.author,
        homepage: e.meta.homepage,
        script: e.meta.rawScript,
        isMusicFree: e.meta.isMusicFree,
        sources: e.Sources(),
        enabled: entry === null || entry.enabled,
        allowUnsafeVM: entry !== null && entry.allowUnsafeVM,
      });
    }
    return out;
  }

  count() {
    return this.engines.size;
  }

  async candidatesFor(source) {
    const entries = [...this.entries];
    const out = [];
    for (const e of entries) {
      if (!e.enabled) continue;
      if (e.enabledSources && e.enabledSources.length > 0) {
        if (!e.enabledSources.includes(source)) continue;
      }
      let eng;
      try {
        eng = await this.engineFor(e.id);
      } catch {
        continue;
      }
      if (!eng) continue;
      if (eng.Supports(source)) out.push(eng);
    }
    return out;
  }

  async hasSource(source) {
    const c = await this.candidatesFor(source);
    return c.length > 0;
  }

  scriptSourceCandidates(source) {
    if (source === 'qs') return ['qsvip', 'qs'];
    return [source];
  }

  async getMusicURL(source, songmid, quality, songInfo) {
    const normalized = normalizeSongInfo(songInfo);
    for (const q of qualityFallback(quality)) {
      const tasks = [];
      for (const ss of this.scriptSourceCandidates(source)) {
        for (const eng of await this.candidatesFor(ss)) {
          tasks.push({ eng, scriptSource: ss, name: eng.meta.name });
        }
      }
      if (tasks.length === 0) {
        return null;
      }
      const info = { musicInfo: normalized, quality: q, type: q };
      if (source === 'qs') {
        let id = normalized.id;
        if (id === undefined || id === null || id === '') id = songmid;
        let sm = normalized.songmid;
        if (sm === undefined || sm === null || sm === '') sm = songmid;
        info.id = id;
        info.songmid = sm;
      }
      const settled = await Promise.all(tasks.map(async (t) => {
        try {
          const v = await t.eng.call('musicUrl', t.scriptSource, info, 45000);
          return { t, v };
        } catch (e) {
          return { t, err: e };
        }
      }));
      const results = [];
      for (const o of settled) {
        const key = o.t.eng.meta.id + '|' + o.t.scriptSource;
        if (o.err || o.v === undefined || o.v === null) {
          this.trackScript(key, songmid, false, '');
          continue;
        }
        const url = pickURL(o.v);
        if (url === '') {
          this.trackScript(key, songmid, false, '');
          continue;
        }
        if (!(await validateAudioURL(url))) {
          this.trackScript(key, songmid, false, '');
          continue;
        }
        this.trackScript(key, songmid, true, url);
        results.push({
          url, type: q, from: 'script',
          sourceName: o.t.name, sourceId: o.t.eng.meta.id,
        });
      }
      if (results.length > 0) {
        return results;
      }
    }
    return null;
  }

  trackScript(key, songmid, ok, url) {
    let st = this.stats.get(key);
    if (!st) {
      st = { failCount: 0, sameCount: 0, lastURL: '', lastSongmid: '' };
      this.stats.set(key, st);
    }
    if (ok) {
      st.failCount = 0;
      if (url !== st.lastURL) {
        st.lastURL = url;
        st.lastSongmid = songmid;
        st.sameCount = 1;
      } else if (songmid !== st.lastSongmid) {
        st.lastSongmid = songmid;
        st.sameCount++;
      }
    } else {
      st.failCount++;
      st.sameCount = 0;
      st.lastURL = '';
    }
    const shouldDisable = st.failCount >= 3 || st.sameCount >= 3;
    if (shouldDisable) {
      this.stats.delete(key);
      const parts = key.split('|');
      if (parts.length === 2) {
        const e = this.find(parts[0]);
        if (e && !e.isMusicFree) {
          this.togglePlatform(parts[0], parts[1], false).catch(() => {});
        }
      }
    }
  }
}

const qualityOrder = ['24bit', 'flac', '320k', '192k', '128k'];

export function qualityFallback(q) {
  for (let i = 0; i < qualityOrder.length; i++) {
    if (qualityOrder[i] === q) return qualityOrder.slice(i);
  }
  return ['128k'];
}

export function normalizeSongInfo(songInfo) {
  const out = {};
  for (const k of Object.keys(songInfo || {})) {
    out[k] = songInfo[k];
  }
  const meta = out.meta && typeof out.meta === 'object' && !Array.isArray(out.meta) ? out.meta : null;
  if (!meta) return out;
  for (const k of Object.keys(meta)) {
    out[k] = meta[k];
  }
  const copyIf = (dst, src) => {
    if (meta[src] !== undefined && meta[src] !== null) {
      if (typeof out[dst] === 'string' && out[dst] === '') {
        out[dst] = meta[src];
      }
    }
  };
  copyIf('songmid', 'songId');
  copyIf('img', 'picUrl');
  copyIf('hash', 'hash');
  copyIf('albumId', 'albumId');
  copyIf('copyrightId', 'copyrightId');
  copyIf('strMediaMid', 'strMediaMid');
  copyIf('albumMid', 'albumMid');
  copyIf('lrcUrl', 'lrcUrl');
  copyIf('mrcUrl', 'mrcUrl');
  copyIf('trcUrl', 'trcUrl');
  return out;
}

export function pickURL(v) {
  if (typeof v === 'string') return v;
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    for (const k of ['url', 'musicUrl', 'src']) {
      const s = v[k];
      if (typeof s === 'string' && s !== '') return s;
    }
  }
  return '';
}

const audioCheckClient = new BrowserClient({ timeoutMs: 6000 });

export async function validateAudioURL(u) {
  if (!u) return false;
  if (u.startsWith('/api/') || u.startsWith('/music/')) return true;
  if (!u.startsWith('http')) return false;
  let resp;
  try {
    resp = await audioCheckClient.do('GET', u, {
      Range: 'bytes=0-1',
      'User-Agent': 'Mozilla/5.0',
    }, { noBrowserHeaders: true, withoutCookieJar: true, timeoutMs: 6000 });
  } catch {
    return false;
  }
  if (resp.status < 200 || resp.status >= 300) return false;
  const ct = String(resp.headers['content-type'] || '').toLowerCase();
  if (ct.includes('audio') || ct.includes('octet-stream') || ct.includes('mpegurl')) return true;
  if (ct.includes('json') || ct.includes('html') || ct.includes('xml') || ct.includes('text/')) return false;
  return (resp.contentLength || 0) > 10000;
}

export function Default() {
  if (!defaultManager) {
    let dir = scriptDir;
    if (!dir) {
      dir = path.join(os.tmpdir(), 'jdd-music', 'Script');
    }
    try {
      fs.mkdirSync(dir, { recursive: true });
    } catch {}
    defaultManager = new Manager(dir);
    defaultManager.loadMeta();
    defaultManager.preload();
  }
  return defaultManager;
}

export function resetForTest() {
  defaultManager = null;
}


import vm from 'node:vm';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { bootstrapJS, musicFreeShim, wrappedScript } from './bootstrap.js';
import { BrowserClient } from '../../core/client.js';
import { zlibInflate } from '../crypto.js';

const STATUS_TEXT = {
  200: 'OK', 201: 'Created', 204: 'No Content', 301: 'Moved Permanently', 302: 'Found',
  304: 'Not Modified', 307: 'Temporary Redirect', 308: 'Permanent Redirect',
  400: 'Bad Request', 401: 'Unauthorized', 403: 'Forbidden', 404: 'Not Found',
  405: 'Method Not Allowed', 408: 'Request Timeout', 418: "I'm a teapot",
  429: 'Too Many Requests', 500: 'Internal Server Error', 502: 'Bad Gateway',
  503: 'Service Unavailable', 504: 'Gateway Timeout',
};

function statusText(code) {
  return STATUS_TEXT[code] || '';
}

export class Engine {
  constructor(meta) {
    this.meta = meta;
    this.reqFn = null;
    this.sources = {};
    this.okInit = false;
    this.logs = [];
    this.timers = new Map();
    this.timerSeq = 0;
    this.closed = false;
    this.client = new BrowserClient({ timeoutMs: 60000 });
    this._initResolve = null;
    this._initReject = null;
    this.ctx = null;
  }

  appendLog(level, msg) {
    if (this.logs.length < 400) {
      this.logs.push('[' + level + '] ' + msg);
    }
  }

  Logs() {
    return this.logs.slice();
  }

  Sources() {
    return { ...this.sources };
  }

  Supports(source) {
    return Object.prototype.hasOwnProperty.call(this.sources, source);
  }

  SupportsAny(...sources) {
    for (const s of sources) {
      if (this.Supports(s)) return true;
    }
    return false;
  }

  close() {
    if (this.closed) return;
    this.closed = true;
    for (const t of this.timers.values()) clearTimeout(t);
    this.timers.clear();
  }

  setupGlobals() {
    const self = this;
    const native = {
      scriptInfo: {
        name: this.meta.name,
        description: this.meta.description,
        version: this.meta.version,
        author: this.meta.author,
        homepage: this.meta.homepage,
        rawScript: this.meta.rawScript,
      },
      request: (spec, callback) => self.jsRequest(spec, callback),
      fetch: (spec) => self.jsFetch(spec),
      onRequest: (fn) => {
        if (typeof fn === 'function') self.reqFn = fn;
      },
      send: (name, data) => self.jsSend(name, data),
      done: () => {  },
      md5: (v) => {
        const data = toBuffer(v);
        return crypto.createHash('md5').update(data).digest('hex');
      },
      aesEncrypt: (buf, mode, key, iv) => self.jsAESEncrypt(buf, mode, key, iv),
      rsaEncrypt: (buf, keyText) => self.jsRSAEncrypt(buf, keyText),
      randomBytes: (n) => {
        let k = Number(n) | 0;
        if (!(k > 0)) k = 16;
        return crypto.randomBytes(k);
      },
      inflate: (b) => new Promise((resolve, reject) => {
        try {
          resolve(zlibInflate(toBuffer(b)));
        } catch (e) {
          reject(new Error(e.message || String(e)));
        }
      }),
      deflate: (b) => new Promise((resolve, reject) => {
        try {
          resolve(zlib.deflateSync(toBuffer(b)));
        } catch (e) {
          reject(new Error(e.message || String(e)));
        }
      }),
      setTimeout: (fn, ms, ...args) => self.jsSetTimeout(fn, ms, args),
      clearTimeout: (id) => self.jsClearTimeout(id),
      textEncoder: (v) => Buffer.from(String(v ?? ''), 'utf8'),
      textDecoder: (v) => toBuffer(v).toString('utf8'),
      log: (...args) => {
        const parts = args.map((a) => {
          try { return typeof a === 'string' ? a : String(a); } catch { return ''; }
        });
        self.appendLog('log', parts.join(' '));
      },
    };

    const sandbox = { Buffer, __jdd: native };
    this.ctx = vm.createContext(sandbox);
    vm.runInContext(bootstrapJS, this.ctx, { filename: 'jdd-bootstrap.js' });
  }

  runScript() {
    try {
      vm.runInContext(wrappedScript(this.meta.rawScript), this.ctx, { filename: 'script_' + this.meta.id + '.js' });
    } catch (e) {
      return new Error('脚本执行错误: ' + (e && e.message ? e.message : String(e)));
    }
    if (this.meta.isMusicFree) {
      try {
        vm.runInContext(musicFreeShim, this.ctx, { filename: 'jdd-musicfree-shim.js' });
      } catch (e) {
        return new Error(e && e.message ? e.message : String(e));
      }
    }
    return null;
  }

  jsSend(name, data) {
    switch (name) {
      case 'inited': {
        if (data !== undefined && data !== null) {
          const sv = data && data.sources;
          const so = sv && typeof sv === 'object' && !Array.isArray(sv) ? sv : null;
          if (so) {
            this.sources = {};
            for (const k of Object.keys(so)) {
              const raw = so[k];
              this.sources[k] = raw && typeof raw === 'object' && !Array.isArray(raw) ? { ...raw } : {};
            }
          }
        }
        this.closure = null;
        if (this._initResolve) {
          const r = this._initResolve;
          this._initResolve = null;
          this._initReject = null;
          r();
        }
        break;
      }
      case 'updateAlert': {
        let payload = data;
        let raw = '';
        try { raw = JSON.stringify(payload) ?? ''; } catch { raw = ''; }
        const err = new Error('发现新版本,需要更新: ' + raw);
        if (this._initReject) {
          const r = this._initReject;
          this._initResolve = null;
          this._initReject = null;
          r(err);
        }
        break;
      }
    }
  }

  async call(action, source, info, timeoutMs) {
    const fn = this.reqFn;
    if (!fn) {
      throw new Error(`源 ${this.meta.name} 未注册 request 处理器`);
    }
    const input = { action, source };
    const infoObj = {};
    for (const k of Object.keys(info || {})) {
      input[k] = info[k];
      infoObj[k] = info[k];
    }
    input.info = infoObj;
    let res;
    try {
      res = fn(input);
    } catch (e) {
      throw new Error(e && e.message ? e.message : String(e));
    }
    
    return await withTimeout(Promise.resolve(res), timeoutMs, '获取超时');
  }

  jsSetTimeout(fn, ms, args) {
    if (typeof fn !== 'function') return 0;
    let delay = Number(ms);
    if (!Number.isFinite(delay)) delay = 0;
    if (delay < 0) delay = 0;
    const self = this;
    const id = ++this.timerSeq;
    const t = setTimeout(() => {
      self.timers.delete(id);
      if (self.closed) return;
      try {
        fn(...args);
      } catch (e) {
        self.appendLog('error', '定时器回调错误: ' + (e && e.message ? e.message : String(e)));
      }
    }, delay);
    this.timers.set(id, t);
    return id;
  }

  jsClearTimeout(id) {
    const t = this.timers.get(Number(id));
    if (t) {
      clearTimeout(t);
      this.timers.delete(Number(id));
    }
  }

  jsAESEncrypt(buf, mode, key, iv) {
    const data = toBuffer(buf);
    const m = normalizeAESMode(mode);
    const keyBuf = toBuffer(key);
    const ivBuf = toBuffer(iv);
    const out = aesEncrypt(data, m, keyBuf, ivBuf);
    return out;
  }

  jsRSAEncrypt(buf, keyText) {
    const data = toBuffer(buf);
    return rsaEncrypt(data, String(keyText ?? ''));
  }

  jsRequest(spec, callback) {
    if (typeof callback !== 'function') return () => {};
    let cancelled = false;
    (async () => {
      let err = null;
      let resp = null;
      let bodyVal = null;
      try {
        resp = await doRequest(this.client, spec);
      } catch (e) {
        err = e && e.message ? e.message : String(e);
      }
      if (cancelled) return;
      if (err) {
        try { callback(err, null, null); } catch (e) { this.appendLog('error', 'request 回调错误: ' + e.message); }
        return;
      }
      bodyVal = bodyToJS(resp);
      try {
        callback(null, {
          statusCode: resp.status,
          statusMessage: statusText(resp.status),
          headers: resp.headers,
          body: bodyVal,
        }, bodyVal);
      } catch (e) {
        this.appendLog('error', 'request 回调错误: ' + (e && e.message ? e.message : String(e)));
      }
    })();
    return function cancel() { cancelled = true; };
  }

  async jsFetch(spec) {
    const resp = await doRequest(this.client, spec);
    const text = resp.body.toString('utf8');
    const obj = {
      ok: resp.status >= 200 && resp.status < 300,
      status: resp.status,
      statusText: statusText(resp.status),
      url: resp.finalURL,
      headers: resp.headers,
      text: () => Promise.resolve(text),
      json: () => new Promise((resolve, reject) => {
        try {
          resolve(JSON.parse(text));
        } catch {
          reject(new Error('invalid json response body'));
        }
      }),
      arrayBuffer: () => Promise.resolve(resp.body),
      buffer: () => Promise.resolve(resp.body),
    };
    return obj;
  }
}

function toBuffer(v) {
  if (v === undefined || v === null) return Buffer.alloc(0);
  if (Buffer.isBuffer(v)) return v;
  if (v instanceof Uint8Array) return Buffer.from(v.buffer, v.byteOffset, v.byteLength);
  if (v instanceof ArrayBuffer) return Buffer.from(new Uint8Array(v));
  if (typeof v === 'string') return Buffer.from(v, 'utf8');
  if (Array.isArray(v)) return Buffer.from(v);
  return Buffer.from(String(v), 'utf8');
}

function normalizeAESMode(mode) {
  let m = String(mode ?? '').toLowerCase().trim();
  if (m === '') return 'cbc';
  if (m.startsWith('aes')) {
    const parts = m.split('-');
    m = parts[parts.length - 1];
  }
  return m;
}

function pkcs7Pad(data, blockSize) {
  const n = blockSize - (data.length % blockSize);
  return Buffer.concat([data, Buffer.alloc(n, n)]);
}

function aesEncrypt(data, mode, key, iv) {
  const bs = 16;
  switch (key.length) {
    case 16: case 24: case 32: break;
    default: throw new Error('crypto/aes: invalid key size ' + key.length);
  }
  const fitIV = (inn) => {
    const out = Buffer.alloc(bs);
    if (inn) inn.copy(out, 0, 0, Math.min(inn.length, bs));
    return out;
  };
  const cipherOf = (m) => crypto.createCipheriv(
    m === 'ecb' ? 'aes-' + (key.length * 8) + '-ecb'
      : 'aes-' + (key.length * 8) + '-' + m,
    key, m === 'ecb' ? null : fitIV(iv),
  );
  switch (mode) {
    case 'ecb': {
      let d = data;
      if (d.length % bs !== 0) d = pkcs7Pad(d, bs);
      const c = cipherOf('ecb');
      c.setAutoPadding(false);
      return Buffer.concat([c.update(d), c.final()]);
    }
    case 'cbc': {
      let d = data;
      if (d.length % bs !== 0) d = pkcs7Pad(d, bs);
      const c = cipherOf('cbc');
      c.setAutoPadding(false);
      return Buffer.concat([c.update(d), c.final()]);
    }
    case 'cfb': {
      const c = cipherOf('cfb');
      return Buffer.concat([c.update(data), c.final()]);
    }
    case 'ofb': {
      const c = cipherOf('ofb');
      return Buffer.concat([c.update(data), c.final()]);
    }
    case 'ctr': {
      const c = cipherOf('ctr');
      return Buffer.concat([c.update(data), c.final()]);
    }
  }
  throw new Error('不支持的加密模式: ' + mode);
}

function rsaEncrypt(data, keyText) {
  let keyObj = null;
  try {
    keyObj = crypto.createPublicKey(keyText);
  } catch {
    try {
      keyObj = crypto.createPrivateKey(keyText);
    } catch {
      throw new Error('RSA 公钥解析失败');
    }
  }
  try {
    return crypto.publicEncrypt({ key: keyObj, padding: crypto.constants.RSA_PKCS1_PADDING }, data);
  } catch (e) {
    throw new Error('RSA 公钥解析失败');
  }
}

async function doRequest(client, spec) {
  const s = spec || {};
  let method = 'GET';
  if (s.method) method = String(s.method).toUpperCase();
  const url = String(s.url || '');
  if (!url) throw new Error('请求地址为空');
  let timeoutMs = 60000;
  if (s.timeout !== undefined && s.timeout !== null) {
    let ms = Number(s.timeout) | 0;
    if (ms > 0) {
      if (ms > 60000) ms = 60000;
      timeoutMs = ms;
    }
  }
  const headers = {};
  if (s.headers && typeof s.headers === 'object') {
    for (const [k, v] of Object.entries(s.headers)) {
      if (v === undefined || v === null) continue;
      headers[k] = String(v);
    }
  }
  if (!headers['User-Agent'] && !headers['user-agent']) {
    headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36';
  }
  let body;
  if (s.body !== undefined && s.body !== null) {
    body = toBuffer(s.body);
    if (body.length === 0) body = undefined;
  }
  const resp = await client.do(method, url, headers, {
    noBrowserHeaders: true,
    withoutCookieJar: true,
    body,
    timeoutMs,
  });
  let buf = await resp.buffer();
  if (buf.length > 48 << 20) buf = buf.slice(0, 48 << 20);
  return {
    status: resp.status,
    statusText: statusText(resp.status),
    headers: resp.headers,
    contentType: String(resp.headers['content-type'] || ''),
    body: buf,
    finalURL: url,
  };
}

function bodyToJS(res) {
  const lct = String(res.contentType || '').toLowerCase();
  const trimmed = res.body.slice ? trimSpace(res.body) : res.body;
  const first = trimmed.length > 0 ? trimmed[0] : 0;
  const isJSONish = lct.includes('json') || (trimmed.length > 0 && (first === 0x7b || first === 0x5b));
  if (isJSONish) {
    try {
      return JSON.parse(res.body.toString('utf8'));
    } catch {}
  }
  if (lct === '' || lct.includes('text') || lct.includes('xml') ||
      lct.includes('javascript') || lct.includes('mpegurl') ||
      lct.includes('urlencoded') || lct.includes('html')) {
    return res.body.toString('utf8');
  }
  return res.body;
}

function trimSpace(b) {
  let start = 0;
  let end = b.length;
  const isSpace = (c) => c === 0x20 || c === 0x09 || c === 0x0a || c === 0x0d || c === 0x0b || c === 0x0c;
  while (start < end && isSpace(b[start])) start++;
  while (end > start && isSpace(b[end - 1])) end--;
  return b.subarray(start, end);
}

function withTimeout(promise, ms, msg) {
  return new Promise((resolve, reject) => {
    let done = false;
    const t = setTimeout(() => {
      if (done) return;
      done = true;
      reject(new Error(msg));
    }, ms);
    Promise.resolve(promise).then(
      (v) => {
        if (done) return;
        done = true;
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        if (done) return;
        done = true;
        clearTimeout(t);
        reject(new Error(e && e.message ? e.message : String(e)));
      },
    );
  });
}


export async function newEngine(meta, timeoutMs = 10000) {
  const e = new Engine(meta);
  e.setupGlobals();
  let initTimer = null;
  const initPromise = new Promise((resolve, reject) => {
    e._initResolve = resolve;
    e._initReject = reject;
    initTimer = setTimeout(() => {
      if (e._initReject) {
        const r = e._initReject;
        e._initResolve = null;
        e._initReject = null;
        r(new Error('初始化超时（10秒）'));
      }
    }, timeoutMs);
    if (initTimer && typeof initTimer.unref === 'function') initTimer.unref();
  });
  const runErr = e.runScript();
  if (runErr) {
    clearTimeout(initTimer);
    e.close();
    throw runErr;
  }
  try {
    await initPromise;
  } catch (err) {
    clearTimeout(initTimer);
    e.close();
    throw err;
  }
  clearTimeout(initTimer);
  e.okInit = true;
  return e;
}

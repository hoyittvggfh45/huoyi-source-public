
import { get as httpGet } from '../http.js';
import { lxOK, lxFail, lxBadReq, readBody, asString, asBoolPtr, asStringPtr } from '../resp.js';

export function register(app, manager) {
  const h = makeHandlers(manager);
  app.all('/api/source/import-url', h.importURL);
  app.all('/api/source/list', h.list);
  app.all('/api/source/script', h.script);
  app.all('/api/source/add', h.add);
  app.all('/api/source/update', h.update);
  app.all('/api/source/delete', h.delete);
  app.all('/api/source/toggle', h.toggle);
  app.all('/api/source/toggle-platform', h.togglePlatform);
  app.all('/api/source/reload', h.reload);
  app.all('/api/source/status', h.status);
  app.all('/api/source/loaded', h.loaded);
  app.all('/api/source/reorder', h.reorder);
  app.all('/api/source/test', h.test);
  
  app.use('/api/source', (req, res) => {
    lxFail(res, 404, 'not found');
  });
}

function makeHandlers(manager) {
  return {
    async importURL(req, res) {
      if (req.method !== 'POST') {
        lxFail(res, 405, '仅支持 POST');
        return;
      }
      const body = await readBody(req);
      const url = asString(body, 'url');
      if (url === '') {
        lxBadReq(res, '缺少 url 参数');
        return;
      }
      let d;
      try {
        d = await httpGet(url, { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' });
      } catch (e) {
        lxFail(res, 500, '获取远程脚本失败: ' + (e.message || e));
        return;
      }
      
      if (d.status !== undefined && (d.status < 200 || d.status >= 300)) {
        lxFail(res, 500, '获取远程脚本失败: HTTP ' + d.status);
        return;
      }
      if (d.body.length > 16 << 20) d.body = d.body.slice(0, 16 << 20);
      if (d.body.length < 10) {
        lxBadReq(res, '获取到的脚本内容为空或无效');
        return;
      }
      lxOK(res, { url, content: d.body.toString('utf8') });
    },

    list(req, res) {
      lxOK(res, manager.list());
    },

    async script(req, res) {
      const id = String(req.query.id || '').trim();
      if (id === '') {
        lxBadReq(res, '缺少 id 参数');
        return;
      }
      try {
        const script = await manager.getScript(id);
        res.status(200);
        res.setHeader('Content-Type', 'text/javascript; charset=utf-8');
        res.setHeader('Cache-Control', 'no-store');
        res.end(script);
      } catch (e) {
        lxFail(res, 500, e.message || String(e));
      }
    },

    async add(req, res) {
      if (req.method !== 'POST') {
        lxFail(res, 405, '仅支持 POST');
        return;
      }
      const body = await readBody(req);
      const id = asString(body, 'id');
      const script = asString(body, 'script');
      if (id === '' || script === '') {
        lxBadReq(res, '缺少 id 或 script 参数');
        return;
      }
      try {
        const entry = await manager.add(id, script, {
          name: asString(body, 'name'),
          description: asString(body, 'description'),
          version: asString(body, 'version'),
          author: asString(body, 'author'),
          homepage: asString(body, 'homepage'),
          enabled: asBoolPtr(body, 'enabled'),
          allowUnsafeVM: boolValue(body, 'allowUnsafeVM'),
        });
        lxOK(res, entry);
      } catch (e) {
        lxFail(res, 500, e.message || String(e));
      }
    },

    async update(req, res) {
      if (req.method !== 'PUT' && req.method !== 'POST') {
        lxFail(res, 405, '仅支持 PUT');
        return;
      }
      const body = await readBody(req);
      const id = asString(body, 'id');
      if (id === '') {
        lxBadReq(res, '缺少 id 参数');
        return;
      }
      const up = {
        script: asStringPtr(body, 'script'),
        enabled: asBoolPtr(body, 'enabled'),
        name: asStringPtr(body, 'name'),
        description: asStringPtr(body, 'description'),
      };
      if ('allowUnsafeVM' in body) {
        if (typeof body.allowUnsafeVM === 'boolean') up.allowUnsafeVM = body.allowUnsafeVM;
      }
      if (Array.isArray(body.enabledSources)) {
        up.hasSrcList = true;
        up.enabledSources = body.enabledSources.filter((s) => typeof s === 'string');
      }
      try {
        const entry = await manager.update(id, up);
        lxOK(res, entry);
      } catch (e) {
        lxFail(res, 500, e.message || String(e));
      }
    },

    async delete(req, res) {
      if (req.method !== 'POST' && req.method !== 'DELETE') {
        lxFail(res, 405, '仅支持 POST');
        return;
      }
      const body = await readBody(req);
      const id = asString(body, 'id');
      if (id === '') {
        lxBadReq(res, '缺少 id 参数');
        return;
      }
      try {
        await manager.delete(id);
        lxOK(res, { success: true, id });
      } catch (e) {
        lxFail(res, 500, e.message || String(e));
      }
    },

    async toggle(req, res) {
      if (req.method !== 'POST') {
        lxFail(res, 405, '仅支持 POST');
        return;
      }
      const body = await readBody(req);
      const id = asString(body, 'id');
      const enabled = asBoolPtr(body, 'enabled');
      if (id === '' || enabled === null) {
        lxBadReq(res, '缺少 id 或 enabled 参数');
        return;
      }
      try {
        const entry = await manager.toggle(id, enabled);
        lxOK(res, entry);
      } catch (e) {
        lxFail(res, 500, e.message || String(e));
      }
    },

    async togglePlatform(req, res) {
      if (req.method !== 'POST') {
        lxFail(res, 405, '仅支持 POST');
        return;
      }
      const body = await readBody(req);
      const id = asString(body, 'id');
      const platform = asString(body, 'platform');
      const enabled = asBoolPtr(body, 'enabled');
      if (id === '' || platform === '' || enabled === null) {
        lxBadReq(res, '缺少 id、platform 或 enabled 参数');
        return;
      }
      try {
        const entry = await manager.togglePlatform(id, platform, enabled);
        lxOK(res, entry);
      } catch (e) {
        lxFail(res, 500, e.message || String(e));
      }
    },

    async reload(req, res) {
      if (req.method !== 'POST') {
        lxFail(res, 405, '仅支持 POST');
        return;
      }
      try {
        await manager.reload();
        lxOK(res, { success: true });
      } catch (e) {
        lxFail(res, 500, e.message || String(e));
      }
    },

    status(req, res) {
      lxOK(res, manager.statusList());
    },

    loaded(req, res) {
      lxOK(res, manager.loaded());
    },

    async reorder(req, res) {
      if (req.method !== 'POST') {
        lxFail(res, 405, '仅支持 POST');
        return;
      }
      const body = await readBody(req);
      const raw = body.ids;
      if (!Array.isArray(raw) || raw.length === 0) {
        lxBadReq(res, '缺少 ids 数组参数');
        return;
      }
      const ids = raw.filter((s) => typeof s === 'string');
      try {
        const n = await manager.reorder(ids);
        lxOK(res, { count: n });
      } catch (e) {
        lxFail(res, 500, e.message || String(e));
      }
    },

    async test(req, res) {
      if (req.method !== 'POST') {
        lxFail(res, 405, '仅支持 POST');
        return;
      }
      const body = await readBody(req);
      const source = asString(body, 'source');
      const songmid = asString(body, 'songmid');
      let quality = asString(body, 'quality');
      if (quality === '') quality = '128k';
      if (source === '' || songmid === '') {
        lxBadReq(res, '缺少 source 或 songmid 参数');
        return;
      }
      const songInfo = { songmid, source };
      for (const k of Object.keys(body)) {
        if (k === 'source') continue;
        songInfo[k] = body[k];
      }
      const results = await manager.getMusicURL(source, songmid, quality, songInfo);
      if (!results || results.length === 0) {
        lxFail(res, 404, '所有规则脚本获取 ' + source + ' 链接失败');
        return;
      }
      lxOK(res, results.map((it) => ({ url: it.url, type: it.type, sourceName: it.sourceName })));
    },
  };
}

function boolValue(m, key) {
  if (m && typeof m[key] === 'boolean') return m[key];
  return false;
}


import crypto from 'node:crypto';
import zlib from 'node:zlib';

export function md5Hex(s) {
  return crypto.createHash('md5').update(Buffer.from(String(s), 'utf8')).digest('hex');
}

export function md5Upper(s) {
  return md5Hex(s).toUpperCase();
}

export function sha1Hex(s) {
  return crypto.createHash('sha1').update(Buffer.from(String(s), 'utf8')).digest('hex');
}

export function pkcs7Pad(data, blockSize) {
  const n = blockSize - (data.length % blockSize);
  return Buffer.concat([data, Buffer.alloc(n, n)]);
}

export function pkcs7Unpad(data) {
  if (data.length === 0) return data;
  const n = data[data.length - 1];
  if (n === 0 || n > data.length) return data;
  return data.subarray(0, data.length - n);
}

function aesCipherName(key, mode) {
  const bits = key.length * 8;
  if (![128, 192, 256].includes(bits)) throw new Error('crypto/aes: invalid key size ' + key.length);
  return `aes-${bits}-${mode}`;
}

function fitIV(iv, blockSize) {
  const out = Buffer.alloc(blockSize);
  if (iv && iv.length > 0) Buffer.from(iv).copy(out, 0, 0, Math.min(iv.length, blockSize));
  return out;
}

export function aesCBCEncrypt(plain, key, iv) {
  const bs = 16;
  if (!(iv && iv.length)) iv = Buffer.alloc(bs);
  const padded = pkcs7Pad(Buffer.from(plain), bs);
  const cipher = crypto.createCipheriv(aesCipherName(key, 'cbc'), key, Buffer.from(iv));
  cipher.setAutoPadding(false);
  return Buffer.concat([cipher.update(padded), cipher.final()]);
}

export function aesCBCDecrypt(cipherData, key, iv) {
  const bs = 16;
  if (!(iv && iv.length)) iv = Buffer.alloc(bs);
  const decipher = crypto.createDecipheriv(aesCipherName(key, 'cbc'), key, Buffer.from(iv));
  decipher.setAutoPadding(false);
  return pkcs7Unpad(Buffer.concat([decipher.update(Buffer.from(cipherData)), decipher.final()]));
}

export function aesECBEncrypt(plain, key) {
  const bs = 16;
  let data = Buffer.from(plain);
  if (data.length % bs !== 0) data = pkcs7Pad(data, bs);
  const cipher = crypto.createCipheriv(aesCipherName(key, 'ecb'), key, null);
  cipher.setAutoPadding(false);
  return Buffer.concat([cipher.update(data), cipher.final()]);
}

export function aesECBDecrypt(cipherData, key) {
  const decipher = crypto.createDecipheriv(aesCipherName(key, 'ecb'), key, null);
  decipher.setAutoPadding(false);
  return pkcs7Unpad(Buffer.concat([decipher.update(Buffer.from(cipherData)), decipher.final()]));
}

export function aesCTRDecrypt(cipherData, key, iv) {
  const decipher = crypto.createDecipheriv(aesCipherName(key, 'ctr'), key, fitIV(iv, 16));
  return Buffer.concat([decipher.update(Buffer.from(cipherData)), decipher.final()]);
}

export function zlibInflate(data) {
  const attempts = [zlib.inflateSync, zlib.gunzipSync, zlib.inflateRawSync];
  let lastErr = null;
  for (const fn of attempts) {
    try { return fn(Buffer.from(data)); } catch (err) { lastErr = err; }
  }
  throw lastErr || new Error('inflate failed');
}

export function zlibDeflate(data) {
  return zlib.deflateSync(Buffer.from(data));
}

export function base64Std(b) {
  return Buffer.from(b).toString('base64');
}

export function base64URL(b) {
  return Buffer.from(b).toString('base64url');
}

export function base64Decode(s) {
  s = String(s ?? '').trim();
  if (/^[A-Za-z0-9+/]*={0,2}$/.test(s)) {
    return Buffer.from(s, 'base64');
  }
  return Buffer.from(s.replace(/=+$/, ''), 'base64');
}

export function hexDecode(s) {
  return Buffer.from(String(s ?? '').trim(), 'hex');
}



const wyPublicKeyPEM = '-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDgtQn2JZ34ZC28NWYpAUd98iZ37BUrX/aKzmFbt7clFSs6sXqHauqKWqdtLkF2KexO40H1YTX8z2lSgBBOAxLsvaklV8k4cBFK9snQXE9/DDaFt6Rr7iVZMldczhC0JNgTz+SHXT6CBHuX3e9SdB1Ua44oncaTWz7OBGLbCiK45wIDAQAB\n-----END PUBLIC KEY-----\n';


function parseRSAPublicKey(pem) {
  const body = Buffer.from(
    pem.replace(/-----BEGIN PUBLIC KEY-----/, '').replace(/-----END PUBLIC KEY-----/, '').replace(/\s+/g, ''),
    'base64'
  );
  let pos = 0;
  const readTLV = () => {
    const tag = body[pos++];
    let len = body[pos++];
    if (len & 0x80) {
      const n = len & 0x7f;
      len = 0;
      for (let i = 0; i < n; i++) len = len * 256 + body[pos++];
    }
    return { tag, start: pos, len };
  };
  const seq = readTLV(); 
  const alg = readTLV(); 
  pos = alg.start + alg.len;
  const bitstr = readTLV(); 
  pos = bitstr.start + 1; 
  const keySeq = readTLV(); 
  pos = keySeq.start;
  const nTlv = readTLV();
  const n = body.subarray(nTlv.start, nTlv.start + nTlv.len);
  const eTlv = readTLV();
  const e = body.subarray(eTlv.start, eTlv.start + eTlv.len);
  void seq;
  return { n: Buffer.from(n), e: Buffer.from(e) };
}

let wyRSAKey = null;
try { wyRSAKey = parseRSAPublicKey(wyPublicKeyPEM); } catch { wyRSAKey = null; }

function modPow(base, exp, mod) {
  let result = 1n;
  let b = base % mod;
  let e = exp;
  while (e > 0n) {
    if (e & 1n) result = (result * b) % mod;
    b = (b * b) % mod;
    e >>= 1n;
  }
  return result;
}

export function rsaNoPaddingEncrypt(data) {
  if (!wyRSAKey) return null;
  const n = BigInt('0x' + wyRSAKey.n.toString('hex'));
  const e = BigInt('0x' + wyRSAKey.e.toString('hex'));
  const k = (n.toString(2).length + 7) >> 3;
  if (data.length > k) data = data.subarray(0, k);
  const hex = Buffer.from(data).toString('hex');
  const m = BigInt('0x' + (hex || '0'));
  const c = modPow(m, e, n);
  let chex = c.toString(16);
  if (chex.length % 2) chex = '0' + chex;
  const out = Buffer.from(chex, 'hex');
  if (out.length < k) return Buffer.concat([Buffer.alloc(k - out.length), out]);
  return out;
}

export const wyIV = Buffer.from('0102030405060708');
export const wyPresetKey = Buffer.from('0CoJUm6Qyw8W8jud');
export const wyLinuxKey = Buffer.from('rFgB&h#%2?^eDg:Q');
export const wyEapiKey = Buffer.from('e82ckenh8dichen8');
const base62Chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';


function marshalGo(v) {
  return JSON.stringify(sortForJSON(v));
}
function sortForJSON(v) {
  if (Array.isArray(v)) return v.map(sortForJSON);
  if (v && typeof v === 'object') {
    const out = {};
    for (const k of Object.keys(v).sort()) {
      out[k] = v[k] === undefined ? null : sortForJSON(v[k]);
    }
    return out;
  }
  return v;
}

export function randomBase62Bytes(n) {
  const out = Buffer.alloc(n);
  const b = crypto.randomBytes(n);
  for (let i = 0; i < n; i++) out[i] = base62Chars.charCodeAt(b[i] % 62);
  return out;
}

export function reverseBytes(b) {
  return Buffer.from(b).reverse();
}

export function wyWeapi(obj) {
  const text = marshalGo(obj);
  const secretKey = randomBase62Bytes(16);
  const p1 = aesCBCEncrypt(Buffer.from(text, 'utf8'), wyPresetKey, wyIV);
  const b64p1 = Buffer.from(base64Std(p1), 'binary');
  const p2 = aesCBCEncrypt(b64p1, secretKey, wyIV);
  const encSec = rsaNoPaddingEncrypt(reverseBytes(secretKey));
  return {
    params: base64Std(p2),
    encSecKey: encSec ? encSec.toString('hex') : '',
  };
}

export function wyEapi(url, obj) {
  const text = marshalGo(obj);
  const msg = 'nobody' + url + 'use' + text + 'md5forencrypt';
  const digest = md5Hex(msg);
  const data = url + '-36cd479b6b5-' + text + '-36cd479b6b5-' + digest;
  const enc = aesECBEncrypt(Buffer.from(data, 'utf8'), wyEapiKey);
  return enc.toString('hex').toUpperCase();
}

export function wyLinuxapi(obj) {
  const text = marshalGo(obj);
  const enc = aesECBEncrypt(Buffer.from(text, 'utf8'), wyLinuxKey);
  return enc.toString('hex').toUpperCase();
}

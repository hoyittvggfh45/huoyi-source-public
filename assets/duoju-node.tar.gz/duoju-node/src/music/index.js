
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { writeJSON, writeErr, readBody, asString } from './resp.js';
import { proxyAudio } from './proxy.js';
import {
  searchBySource, boardsBySource, boardDetailBySource, songlistBySource,
  songlistDetailBySource, songlistSearchBySource, lyricBySource,
  musicURLBySource, hotSearchBySource, tipSearchBySource,
} from './registry.js';
import * as lx from './lx/manager.js';
import { register as registerLxHandlers } from './lx/handlers.js';
import { parseIntS } from './common.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const webRoot = path.resolve(__dirname, '..', '..', 'web', 'music');

const sourceNames = { kw: '酷我', kg: '酷狗', tx: 'QQ音乐', wy: '网易云', mg: '咪咕', qs: '汽水音乐' };

let dataDir = '';

export function setDataDir(dir) {
  dataDir = String(dir ?? '');
  lx.setDir(dataDir);
}

export function getDataDir() {
  return dataDir;
}

function configPath() {
  if (dataDir === '') return '';
  return path.join(dataDir, 'config.json');
}

function defaultConfig() {
  return {
    quality: '320k',
    qualities: [
      { value: '24bit', label: '24bit 超高清' },
      { value: 'flac', label: 'FLAC 无损' },
      { value: '320k', label: '320kbps 高品' },
      { value: '192k', label: '192kbps 较高' },
      { value: '128k', label: '128kbps 标准' },
    ],
  };
}

function readConfig() {
  const cfg = defaultConfig();
  const p = configPath();
  if (p === '') return cfg;
  let data;
  try {
    data = fs.readFileSync(p);
  } catch {
    return cfg;
  }
  let stored;
  try {
    stored = JSON.parse(data.toString('utf8'));
  } catch {
    return cfg;
  }
  if (stored && typeof stored.quality === 'string' && stored.quality !== '') {
    cfg.quality = stored.quality;
  }
  return cfg;
}

function writeConfig(cfg) {
  const p = configPath();
  if (p === '') return;
  try {
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, JSON.stringify({ quality: cfg.quality, qualities: cfg.qualities }, null, 2));
  } catch {}
}

function requireParam(q, ...names) {
  const out = {};
  for (const n of names) {
    const v = String(q[n] ?? '').trim();
    if (v === '') return null;
    out[n] = v;
  }
  return out;
}

function parseSource(source) {
  const s = String(source ?? '').trim();
  return s in sourceNames ? s : '';
}


function firstQV(q, key) {
  const v = q[key];
  if (v === undefined) return '';
  if (Array.isArray(v)) return v.length > 0 ? String(v[0]) : '';
  return String(v);
}

function qHas(q, key) {
  return Object.prototype.hasOwnProperty.call(q, key);
}


const songlistParsePatterns = [
  { re: /kugou\.com\/songlist\/gcid_([a-zA-Z0-9]+)/i, src: 'kg', kind: 'gcid' },
  { re: /kugou\.com\/yy\/special\/single\/(\d+)/i, src: 'kg', kind: 'special' },
  { re: /kugou\.com\/mixsong\/([a-zA-Z0-9]+)/i, src: 'kg', kind: 'mixsong' },
  { re: /kuwo\.cn\/playlist(?:_detail)?\/(\d+)/i, src: 'kw', kind: 'pid' },
  { re: /kuwo\.cn\/h5app\/playlist\/(\d+)/i, src: 'kw', kind: 'pid' },
  { re: /kuwo\.cn\/album_detail\/(\d+)/i, src: 'kw', kind: 'album' },
  { re: /y\.qq\.com\/n\/ryqq\/playlist\/(\d+)/i, src: 'tx', kind: 'playlist' },
  { re: /y\.qq\.com\/n\/ryqq\/album\/([a-zA-Z0-9]+)/i, src: 'tx', kind: 'album' },
  { re: /music\.163\.com\/(?:#\/)?playlist\?id=(\d+)/i, src: 'wy', kind: 'playlist' },
  { re: /migu\.cn\/v[\d]+\/music\/playlist\/(\d+)/i, src: 'mg', kind: 'playlist' },
  { re: /migu\.cn\/playlist\/([a-zA-Z0-9]+)/i, src: 'mg', kind: 'playlist' },
  { re: /qishui\.com\/playlist\/([a-zA-Z0-9]+)/i, src: 'qs', kind: 'playlist' },
];

const staticTypes = [
  ['.html', 'text/html; charset=utf-8'],
  ['.js', 'application/javascript; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'],
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.svg', 'image/svg+xml'],
  ['.ico', 'image/x-icon'],
  ['.woff2', 'font/woff2'],
  ['.mp3', 'audio/mpeg'],
  ['.m4a', 'audio/mp4'],
];

function contentTypeForStatic(name) {
  for (const [suffix, ct] of staticTypes) {
    if (name.endsWith(suffix)) return ct;
  }
  return 'text/plain';
}

export class MusicServer {
  constructor({ dataDir: dd } = {}) {
    setDataDir(dd);
    this.manager = lx.Default();
    this.app = express();
    this.app.disable('x-powered-by');

    
    this.app.use((req, res, next) => {
      const chunks = [];
      let size = 0;
      let tooLarge = false;
      req.on('data', (c) => {
        if (tooLarge) return;
        size += c.length;
        if (size > 8 << 20) { tooLarge = true; return; }
        chunks.push(c);
      });
      req.on('end', () => {
        req._musicRawBody = tooLarge ? Buffer.alloc(0) : Buffer.concat(chunks);
        next();
      });
      req.on('error', () => {
        req._musicRawBody = Buffer.alloc(0);
        next();
      });
    });

    
    this.app.use((req, res, next) => {
      const qi = req.url.indexOf('?');
      const p = qi >= 0 ? req.url.slice(0, qi) : req.url;
      const query = qi >= 0 ? req.url.slice(qi) : '';
      if (p.startsWith('/api/') && p.endsWith('/')) {
        req.url = p.replace(/\/+$/, '') + query;
      }
      next();
    });

    const h = this.makeHandlers();
    
    this.app.all('/api/music/search', h.search);
    this.app.all('/api/music/leaderboard', h.leaderboard);
    this.app.all('/api/music/leaderboard/detail', h.leaderboardDetail);
    this.app.all('/api/music/songlist', h.songlist);
    this.app.all('/api/music/songlist/detail', h.songlistDetail);
    this.app.all('/api/music/songlist/search', h.songlistSearch);
    this.app.all('/api/music/songlist/parse', h.songlistParse);
    this.app.all('/api/music/lyric', h.lyric);
    this.app.all('/api/music/music-url', h.musicURL);
    this.app.all('/api/music/audio-proxy', h.audioProxy);
    this.app.all('/api/music/audio-proxy/:format', h.audioProxy);
    this.app.all('/api/music/sources', h.sources);
    this.app.all('/api/music/hot-search', h.hotSearch);
    this.app.all('/api/music/tip-search', h.tipSearch);
    
    registerLxHandlers(this.app, this.manager);
    this.app.all('/api/config', h.config);
    
    this.app.all('*', h.static_);

    this.ready = true;
  }

  makeHandlers() {
    const self = this;
    return {
      async search(req, res) {
        const q = req.query;
        const p = requireParam(q, 'keyword');
        if (!p) return writeErr(res, 400, '缺少 keyword 参数');
        const src = parseSource(firstQV(q, 'source'));
        if (src === '') return writeErr(res, 400, '缺少 source 参数');
        let page = parseIntS(firstQV(q, 'page'));
        if (page < 1) page = 1;
        let limit = parseIntS(firstQV(q, 'limit'));
        if (limit < 1) limit = 30;
        try {
          const r = await searchBySource(src, p.keyword, page, limit);
          writeJSON(res, 200, r);
        } catch (e) {
          writeErr(res, 500, e.message || String(e));
        }
      },

      async leaderboard(req, res) {
        const src = parseSource(firstQV(req.query, 'source'));
        if (src === '') return writeErr(res, 400, '缺少 source 参数');
        try {
          const r = await boardsBySource(src);
          writeJSON(res, 200, r);
        } catch (e) {
          writeErr(res, 500, e.message || String(e));
        }
      },

      async leaderboardDetail(req, res) {
        const q = req.query;
        const p = requireParam(q, 'bangid');
        if (!p) return writeErr(res, 400, '缺少 bangid 参数');
        const src = parseSource(firstQV(q, 'source'));
        if (src === '') return writeErr(res, 400, '缺少 source 参数');
        let page = parseIntS(firstQV(q, 'page'));
        if (page < 1) page = 1;
        try {
          const r = await boardDetailBySource(src, p.bangid, page);
          writeJSON(res, 200, r);
        } catch (e) {
          writeErr(res, 500, e.message || String(e));
        }
      },

      async songlist(req, res) {
        const q = req.query;
        const src = parseSource(firstQV(q, 'source'));
        if (src === '') return writeErr(res, 400, '缺少 source 参数');
        let page = parseIntS(firstQV(q, 'page'));
        if (page < 1) page = 1;
        try {
          const r = await songlistBySource(src, firstQV(q, 'sortId'), firstQV(q, 'tagId'), qHas(q, 'tagId'), page);
          writeJSON(res, 200, r);
        } catch (e) {
          writeErr(res, 500, e.message || String(e));
        }
      },

      async songlistDetail(req, res) {
        const q = req.query;
        const p = requireParam(q, 'id');
        if (!p) return writeErr(res, 400, '缺少 id 参数');
        const src = parseSource(firstQV(q, 'source'));
        if (src === '') return writeErr(res, 400, '缺少 source 参数');
        let page = parseIntS(firstQV(q, 'page'));
        if (page < 1) page = 1;
        try {
          const r = await songlistDetailBySource(src, p.id, page, firstQV(q, 'kind'));
          writeJSON(res, 200, r);
        } catch (e) {
          writeErr(res, 500, e.message || String(e));
        }
      },

      async songlistSearch(req, res) {
        const q = req.query;
        const p = requireParam(q, 'keyword');
        if (!p) return writeErr(res, 400, '缺少 keyword 参数');
        const src = parseSource(firstQV(q, 'source'));
        if (src === '') return writeErr(res, 400, '缺少 source 参数');
        let page = parseIntS(firstQV(q, 'page'));
        if (page < 1) page = 1;
        let limit = parseIntS(firstQV(q, 'limit'));
        if (limit < 1) limit = 20;
        try {
          const r = await songlistSearchBySource(src, p.keyword, page, limit);
          writeJSON(res, 200, r);
        } catch (e) {
          writeErr(res, 500, e.message || String(e));
        }
      },

      async songlistParse(req, res) {
        const q = req.query;
        const p = requireParam(q, 'url');
        if (!p) return writeErr(res, 400, '缺少 url 参数');
        let raw = p.url;
        if (!raw.startsWith('http')) raw = 'http://' + raw;
        for (const pat of songlistParsePatterns) {
          const m = pat.re.exec(raw);
          if (m) {
            const id = m[1];
            try {
              const r = await songlistDetailBySource(pat.src, id, 1, '');
              
              writeJSON(res, 200, {
                id, limit: r.limit, list: r.list, page: r.page, source: pat.src, total: r.total, type: pat.kind,
              });
            } catch (e) {
              writeErr(res, 500, e.message || String(e));
            }
            return;
          }
        }
        writeErr(res, 400, '无法识别的歌单链接，支持的平台：酷我、酷狗、QQ 音乐、网易云、咪咕、汽水音乐');
      },

      async lyric(req, res) {
        const q = req.query;
        const p = requireParam(q, 'songmid');
        if (!p) return writeErr(res, 400, '缺少 songmid 参数');
        const src = parseSource(firstQV(q, 'source'));
        if (src === '') return writeErr(res, 400, '缺少 source 参数');
        try {
          const r = await lyricBySource(src, p.songmid, q);
          writeJSON(res, 200, r);
        } catch (e) {
          writeErr(res, 500, e.message || String(e));
        }
      },

      async musicURL(req, res) {
        const q = req.query;
        const p = requireParam(q, 'source', 'songmid');
        if (!p) return writeErr(res, 400, '缺少 source 或 songmid 参数');
        const src = p.source;
        if (parseSource(src) === '') return writeErr(res, 400, '缺少 source 参数');

        let quality = readConfig().quality;
        if (quality === '') quality = '320k';
        const songInfo = {};
        for (const k of Object.keys(q)) {
          if (k === 'source') continue;
          const vs = q[k];
          if (vs === undefined) continue;
          songInfo[k] = Array.isArray(vs) ? (vs.length > 0 ? String(vs[0]) : '') : String(vs);
        }
        if (typeof songInfo._types === 'string') {
          try { songInfo._types = JSON.parse(songInfo._types); } catch {}
        }
        if (typeof songInfo.types === 'string') {
          try { songInfo.types = JSON.parse(songInfo.types); } catch {}
        }
        let scriptItems = null;
        try {
          scriptItems = await self.manager.getMusicURL(src, p.songmid, quality, songInfo);
        } catch {
          scriptItems = null;
        }
        if (scriptItems && scriptItems.length > 0) {
          const out = scriptItems.map((it) => {
            let sid = it.sourceId;
            if (sid === undefined || sid === null || sid === '') sid = it.sourceName;
            return { url: it.url, type: it.type, from: it.from, sourceName: it.sourceName, sourceId: sid };
          });
          return writeJSON(res, 200, out);
        }
        try {
          const items = await musicURLBySource(src, p.songmid, quality, q);
          if (!items || items.length === 0) {
            return writeErr(res, 404, `未找到 ${src} 平台 ${p.songmid} 的播放链接`);
          }
          writeJSON(res, 200, items);
        } catch {
          writeErr(res, 404, `未找到 ${src} 平台 ${p.songmid} 的播放链接`);
        }
      },

      audioProxy(req, res) {
        const q = req.query;
        const audioURL = String(firstQV(q, 'url') ?? '').trim();
        if (audioURL === '') return writeErr(res, 400, '缺少 url 参数');
        let format = String(firstQV(q, 'format') ?? '').trim();
        if (format === '') {
          const p = req.path.startsWith('/api/music/audio-proxy/')
            ? req.path.slice('/api/music/audio-proxy/'.length)
            : '';
          if (p !== '' && !p.includes('/')) format = p;
        }
        if (format === '') format = 'm4a';
        proxyAudio(req, res, audioURL, format, firstQV(q, 'playAuth'));
      },

      sources(req, res) {
        const list = [];
        for (const id of ['kw', 'kg', 'tx', 'wy', 'mg', 'qs']) {
          list.push({ id, name: sourceNames[id] });
        }
        
        writeJSON(res, 200, {
          sources: list,
          userApi: { loaded: self.manager.loaded() },
        });
      },

      async hotSearch(req, res) {
        const src = parseSource(firstQV(req.query, 'source'));
        if (src === '') return writeErr(res, 400, '缺少 source 参数');
        try {
          const items = await hotSearchBySource(src);
          
          writeJSON(res, 200, { list: items, source: src });
        } catch (e) {
          writeErr(res, 500, e.message || String(e));
        }
      },

      async tipSearch(req, res) {
        const q = req.query;
        const p = requireParam(q, 'keyword');
        if (!p) return writeErr(res, 400, '缺少 keyword 参数');
        const src = parseSource(firstQV(q, 'source'));
        if (src === '') return writeErr(res, 400, '缺少 source 参数');
        try {
          const items = await tipSearchBySource(src, p.keyword);
          writeJSON(res, 200, items);
        } catch (e) {
          writeErr(res, 500, e.message || String(e));
        }
      },

      config(req, res) {
        if (req.method === 'POST') {
          let body = {};
          try {
            const raw = req._musicRawBody;
            if (raw && raw.length > 0) body = JSON.parse(raw.toString('utf8'));
          } catch {
            body = {};
          }
          if (!body || typeof body !== 'object' || Array.isArray(body)) body = {};
          const cfg = readConfig();
          if (typeof body.quality === 'string' && body.quality !== '') {
            cfg.quality = body.quality;
          }
          writeConfig(cfg);
          return writeJSON(res, 200, cfg);
        }
        writeJSON(res, 200, readConfig());
      },

      static_(req, res) {
        handleMusicStatic(req, res);
      },
    };
  }
}

function handleMusicStatic(req, res) {
  let name = String(req.path ?? '').replace(/^\/+/, '');
  if (name === '') name = 'index.html';
  if (name.endsWith('/')) name += 'index.html';
  if (name.includes('..')) {
    return writeErr(res, 403, 'forbidden');
  }
  let served = name;
  let data = null;
  try {
    data = fs.readFileSync(path.join(webRoot, name));
  } catch {
    data = null;
  }
  if (data === null) {
    if (name.startsWith('api/')) {
      return writeErr(res, 404, 'not found');
    }
    if (!String(req.path).includes('.')) {
      served = 'index.html';
      try {
        data = fs.readFileSync(path.join(webRoot, 'index.html'));
      } catch {
        data = null;
      }
      if (data === null) {
        return writeErr(res, 404, 'not found');
      }
    } else {
      return writeErr(res, 404, 'not found');
    }
  }
  res.setHeader('Content-Type', contentTypeForStatic(served));
  res.status(200);
  res.end(data);
}

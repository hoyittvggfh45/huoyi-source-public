
import * as kw from './sources/kw.js';
import * as wy from './sources/wy.js';
import * as mg from './sources/mg.js';
import * as tx from './sources/tx.js';
import * as kg from './sources/kg.js';
import * as qs from './sources/qs.js';

export const errUnsupported = new Error('该音乐源暂未内置 Go 实现');

export async function searchBySource(src, keyword, page, limit) {
  switch (src) {
    case 'kw': return kw.kwSearch(keyword, page, limit);
    case 'mg': return mg.mgSearch(keyword, page, limit);
    case 'wy': return wy.wySearch(keyword, page, limit);
    case 'tx': return tx.txSearch(keyword, page, limit);
    case 'kg': return kg.kgSearch(keyword, page, limit);
    case 'qs': return qs.qsSearch(keyword, page, limit);
  }
  throw errUnsupported;
}

export async function boardsBySource(src) {
  switch (src) {
    case 'kw': return kw.kwBoards();
    case 'wy': return wy.wyBoards();
    case 'mg': return mg.mgBoards();
    case 'tx': return tx.txBoards();
    case 'kg': return kg.kgBoards();
    case 'qs': return qs.qsBoards();
  }
  throw errUnsupported;
}

export async function boardDetailBySource(src, bangid, page) {
  switch (src) {
    case 'kw': return kw.kwBoardDetail(bangid, page);
    case 'wy': return wy.wyBoardDetail(bangid, page);
    case 'mg': return mg.mgBoardDetail(bangid, page);
    case 'tx': return tx.txBoardDetail(bangid, page);
    case 'kg': return kg.kgBoardDetail(bangid, page);
    case 'qs': return qs.qsBoardDetail(bangid, page);
  }
  throw errUnsupported;
}

export async function songlistBySource(src, sortId, tagId, hasTag, page) {
  switch (src) {
    case 'kw': return kw.kwSonglist(sortId, tagId, page);
    case 'wy': return wy.wySonglist(page);
    case 'mg': return mg.mgSonglist(page);
    case 'tx': return tx.txSonglist(sortId, page);
    case 'kg': return kg.kgSonglist(sortId, tagId, hasTag, page);
    case 'qs': return qs.qsSonglist(page);
  }
  throw errUnsupported;
}

export async function songlistDetailBySource(src, id, page, kind) {
  switch (src) {
    case 'kw': return kw.kwSonglistDetail(id, page);
    case 'wy': return wy.wySonglistDetail(id, page);
    case 'mg': return mg.mgSonglistDetail(id, page);
    case 'tx': return tx.txSonglistDetail(id, page);
    case 'kg': return kg.kgSonglistDetail(id, page);
    case 'qs': return qs.qsSonglistDetail(id, page);
  }
  throw errUnsupported;
}

export async function songlistSearchBySource(src, keyword, page, limit) {
  switch (src) {
    case 'kw': return kw.kwSonglistSearch(keyword, page, limit);
    case 'wy': return wy.wySonglistSearch(keyword, page, limit);
    case 'mg': return mg.mgSonglistSearch(keyword, page, limit);
    case 'tx': return tx.txSonglistSearch(keyword, page, limit);
    case 'kg': return kg.kgSonglistSearch(keyword, page, limit);
    case 'qs': return qs.qsSonglistSearch(keyword, page, limit);
  }
  throw errUnsupported;
}

export async function lyricBySource(src, songmid, q) {
  switch (src) {
    case 'kw': return kw.kwLyric(songmid);
    case 'wy': return wy.wyLyric(songmid);
    case 'mg': return mg.mgLyric(songmid);
    case 'tx': return tx.txLyric(songmid);
    case 'kg': return kg.kgLyric(songmid);
    case 'qs': return qs.qsLyric(songmid);
  }
  throw errUnsupported;
}

export async function musicURLBySource(src, songmid, quality, q) {
  switch (src) {
    case 'kw': return kw.kwMusicURL(songmid, quality);
    case 'wy': return wy.wyMusicURL(songmid, quality);
    case 'mg': return mg.mgMusicURL(songmid, quality);
    case 'tx': return tx.txMusicURL(songmid, quality);
    case 'kg': return kg.kgMusicURL(songmid, quality);
    case 'qs': return qs.qsMusicURL(songmid, quality);
  }
  throw errUnsupported;
}

export async function hotSearchBySource(src) {
  switch (src) {
    case 'kw': return kw.kwHotSearch();
    case 'wy': return wy.wyHotSearch();
    case 'mg': return mg.mgHotSearch();
    case 'tx': return tx.txHotSearch();
    case 'kg': return kg.kgHotSearch();
    case 'qs': return qs.qsHotSearch();
  }
  throw errUnsupported;
}

export async function tipSearchBySource(src, keyword) {
  switch (src) {
    case 'kw': return kw.kwTipSearch(keyword);
    case 'wy': return wy.wyTipSearch(keyword);
    case 'mg': return mg.mgTipSearch(keyword);
    case 'tx': return tx.txTipSearch(keyword);
    case 'kg': return kg.kgTipSearch(keyword);
    case 'qs': return qs.qsTipSearch(keyword);
  }
  throw errUnsupported;
}



let gbDecoder = null;
let gbFallback = false;
try {
  gbDecoder = new TextDecoder('gb18030');
} catch {
  gbFallback = true;
}

export function gb18030ToUTF8(b) {
  try {
    if (gbDecoder) return gbDecoder.decode(Buffer.from(b));
  } catch {}
  
  void gbFallback;
  return Buffer.from(b).toString('utf8');
}

export function timeNowMillis() {
  return Date.now();
}

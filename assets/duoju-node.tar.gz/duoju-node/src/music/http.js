

import { BrowserClient } from '../core/client.js';

export const desktopUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36';

const DEFAULT_TIMEOUT = 20000;

let sharedClient = null;
export function httpClient() {
  if (!sharedClient) sharedClient = new BrowserClient({ timeoutMs: DEFAULT_TIMEOUT });
  return sharedClient;
}

function normalizeHeaders(headers) {
  const h = {};
  for (const [k, v] of Object.entries(headers || {})) {
    if (v === undefined || v === null) continue;
    h[k] = String(v);
  }
  if (!h['User-Agent'] && !h['user-agent']) h['User-Agent'] = desktopUA;
  return h;
}


function tryParseObject(text) {
  if (!text) return null;
  try {
    const p = JSON.parse(text);
    if (p && typeof p === 'object' && !Array.isArray(p)) return p;
  } catch {}
  return null;
}


async function request(method, url, body, headers, contentType, timeoutMs) {
  const h = normalizeHeaders(headers);
  if (contentType && !h['Content-Type'] && !h['content-type']) h['Content-Type'] = contentType;
  const resp = await httpClient().do(method, url, h, {
    noBrowserHeaders: true,
    withoutCookieJar: true,
    body: body !== undefined && body !== null && body.length > 0 ? body : undefined,
    timeoutMs: timeoutMs || DEFAULT_TIMEOUT,
  });
  const buf = await resp.buffer();
  return { body: buf, json: tryParseObject(buf.toString('utf8')) };
}

export function get(url, headers) {
  return request('GET', url, undefined, headers, '', DEFAULT_TIMEOUT);
}


export async function postJSON(url, payload, headers) {
  let body;
  try {
    body = Buffer.from(JSON.stringify(payload ?? null), 'utf8');
  } catch {
    body = Buffer.from('null', 'utf8');
  }
  return postForm(url, body, headers);
}

export function postForm(url, body, headers) {
  return request('POST', url, body, headers, 'application/x-www-form-urlencoded', DEFAULT_TIMEOUT);
}

export function postRaw(url, body, contentType, headers) {
  return request('POST', url, body, headers, contentType || '', DEFAULT_TIMEOUT);
}

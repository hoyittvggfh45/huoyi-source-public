
import { get, postForm } from '../http.js';
import {
  newSong, smap, slist, sv, str, tonum, parseIntS, formatPlayTime, sizeFormate,
  decodeName, formatPlayCount,
} from '../common.js';
import { md5Hex } from '../crypto.js';
import { mrcDecrypt, mgParseMrc } from '../mrc.js';
import { timeNowMillis } from '../gb.js';

const mgDeviceID = '963B7AA0D21511ED807EE5846EC87D20';
const mgSignatureMD5 = '6cdc72a439cef99a3418d2a78aa28c73';
const mgAppSecret = 'yyapp2d16148780a1dcc7408e06336b98cfd50';
const mgSuccessCode = '000000';

const mgDefaultHeaders = {
  'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',
  Referer: 'https://m.music.migu.cn/',
};

const mgAndroidHeaders = {
  'User-Agent': 'Mozilla/5.0 (Linux; Android 5.1.1; Nexus 6 Build/LYZ28E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Mobile Safari/537.36',
  Referer: 'https://app.c.nf.migu.cn/',
  channel: '0146921',
};

function mgCreateSignature(timeStr, keyword) {
  const sign = md5Hex(keyword + mgSignatureMD5 + mgAppSecret + mgDeviceID + timeStr);
  return { sign, deviceID: mgDeviceID };
}

function mgSignedHeaders(timeStr, keyword) {
  const { sign, deviceID } = mgCreateSignature(timeStr, keyword);
  return {
    uiVersion: 'A_music_3.6.1',
    deviceId: deviceID,
    timestamp: timeStr,
    sign,
    channel: '0146921',
    'User-Agent': 'Mozilla/5.0 (Linux; U; Android 11.0.0; zh-cn; MI 11 Build/OPR1.170623.032) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30',
  };
}

function mgSearchURL(keyword, page, limit, songlist) {
  let sw = '{"song":1,"album":0,"singer":0,"tagSong":1,"mvSong":0,"bestShow":1,"songlist":0,"lyricSong":0}';
  let isCorrect = '0';
  if (songlist) {
    sw = '{"song":0,"album":0,"singer":0,"tagSong":0,"mvSong":0,"bestShow":0,"songlist":1,"lyricSong":0}';
    isCorrect = '1';
  }
  return `https://jadeite.migu.cn/music_search/v3/search/searchAll?isCorrect=${isCorrect}&isCopyright=1&searchSwitch=${encodeURIComponent(sw)}&pageSize=${limit}&text=${encodeURIComponent(keyword)}&pageNo=${page}&sort=0&sid=USS`;
}

function mgSingerNames(v) {
  const names = [];
  for (const it of slist(v) || []) {
    const n = str(sv(smap(it), 'name'));
    if (n !== '') names.push(n);
  }
  return decodeName(names.join('、'));
}

function mgImg(data, v5) {
  let img = str(data.img3);
  if (img === '') img = str(data.img2);
  if (img === '') img = str(data.img1);
  if (img === '' && !v5) {
    const imgs = slist(data.albumImgs);
    if (imgs && imgs.length > 0) {
      img = str(sv(smap(imgs[0]), 'img'));
    }
  }
  if (img !== '' && !img.startsWith('http')) {
    img = 'http://d.musicapp.migu.cn' + img;
  }
  return img;
}

function mgAudioFormats(v, zq) {
  const types = [];
  const tm = {};
  for (const it of slist(v) || []) {
    const f = smap(it);
    if (!f) continue;
    let size = tonum(f.asize);
    if (size === 0) size = tonum(f.isize);
    if (size === 0) size = tonum(f.size);
    if (size === 0) size = tonum(f.androidSize);
    const ss = sizeFormate(Math.trunc(size));
    let qtype = '';
    switch (str(f.formatType)) {
      case 'PQ': qtype = '128k'; break;
      case 'HQ': qtype = '320k'; break;
      case 'SQ': qtype = 'flac'; break;
      default: if (str(f.formatType) === zq) qtype = 'flac24bit'; break;
    }
    if (qtype === '') continue;
    types.push({ type: qtype, size: ss });
    tm[qtype] = { size: ss };
  }
  return { types, tm };
}

function mgSongFromObjectInfo(im) {
  const songID = str(im.songId);
  if (songID === '') return null;
  const s = newSong();
  s.singer = mgSingerNames(im.artists);
  s.name = str(im.songName);
  s.albumName = str(im.album);
  s.albumId = str(im.albumId);
  s.songmid = songID;
  s.copyrightId = str(im.copyrightId);
  s.source = 'mg';
  s.interval = mgInterval(str(im.length));
  s.img = mgImg(im, false);
  s.lrcUrl = str(im.lrcUrl);
  s.mrcUrl = str(im.mrcUrl);
  s.trcUrl = str(im.trcUrl);
  const { types, tm } = mgAudioFormats(im.newRateFormats, 'ZQ');
  s.types = types;
  s._types = tm;
  return s;
}

function mgSongFromV5(im) {
  const songID = str(im.songId);
  if (songID === '') return null;
  const s = newSong();
  s.singer = mgSingerNames(im.singerList);
  s.name = str(im.songName);
  s.albumName = str(im.album);
  s.albumId = str(im.albumId);
  s.songmid = songID;
  s.copyrightId = str(im.copyrightId);
  s.source = 'mg';
  s.interval = formatPlayTime(tonum(im.duration));
  s.img = mgImg(im, true);
  s.lrcUrl = str(im.lrcUrl);
  s.mrcUrl = str(im.mrcUrl);
  s.trcUrl = str(im.trcUrl);
  const { types, tm } = mgAudioFormats(im.audioFormats, 'ZQ');
  s.types = types;
  s._types = tm;
  return s;
}

function mgInterval(s) {
  if (s.length >= 5 && s[s.length - 5] === ':') {
    return s.slice(s.length - 5);
  }
  return '--/--';
}

function mgDedup(rawList, build) {
  const list = [];
  const ids = {};
  for (const it of rawList) {
    const im = smap(it);
    if (!im) continue;
    const sid = str(im.songId);
    if (sid === '' || ids[sid]) continue;
    ids[sid] = true;
    const s = build(im);
    if (s) list.push(s);
  }
  return list;
}

export async function mgSearch(keyword, page, limit) {
  const timeStr = String(timeNowMillis());
  const d = await get(mgSearchURL(keyword, page, limit, false), mgSignedHeaders(timeStr, keyword));
  const raw = d.json;
  if (!raw) throw new Error('mg search invalid json');
  if (str(raw.code) !== mgSuccessCode) {
    throw new Error(`mg search code=${str(raw.code)} info=${str(raw.info)}`);
  }
  const srd = smap(raw.songResultData) || {};
  const list = [];
  const ids = {};
  for (const gi of slist(srd.resultList) || []) {
    for (const iti of slist(gi) || []) {
      const data = smap(iti);
      if (!data) continue;
      const songID = str(data.songId);
      const copyrightID = str(data.copyrightId);
      if (songID === '' || copyrightID === '' || ids[copyrightID]) continue;
      ids[copyrightID] = true;
      const s = newSong();
      s.singer = mgSingerNames(data.singerList);
      s.name = str(data.name);
      s.albumName = str(data.album);
      s.albumId = str(data.albumId);
      s.songmid = songID;
      s.copyrightId = copyrightID;
      s.source = 'mg';
      s.interval = formatPlayTime(tonum(data.duration));
      s.img = mgImg(data, true);
      s.lrcUrl = str(data.lrcUrl);
      s.mrcUrl = str(data.mrcurl);
      s.trcUrl = str(data.trcUrl);
      const { types, tm } = mgAudioFormats(data.audioFormats, 'ZQ24');
      s.types = types;
      s._types = tm;
      list.push(s);
    }
  }
  const total = parseIntS(str(srd.totalCount));
  let allPage = 0;
  if (limit > 0) {
    allPage = Math.trunc((total + limit - 1) / limit);
  }
  return { list, allPage, total, limit, source: 'mg' };
}

export async function mgBoards() {
  const d = await get('https://app.c.nf.migu.cn/pc/bmw/rank/rank-index/v1.0', mgAndroidHeaders);
  const raw = d.json;
  if (!raw) throw new Error('mg boards invalid json');
  if (str(raw.code) !== mgSuccessCode) throw new Error(`mg boards code=${str(raw.code)}`);
  const list = [];
  const seen = {};
  mgWalkBoards(slist(sv(smap(raw.data), 'contents')) || [], list, seen);
  return { list, source: 'mg' };
}

function mgWalkBoards(items, list, seen) {
  for (const it of items) {
    const im = smap(it);
    if (!im) continue;
    const rankID = str(im.rankId);
    if (rankID !== '') {
      if (seen[rankID]) continue;
      seen[rankID] = true;
      
      list.push({ id: 'mg__' + rankID, name: str(im.rankName), bangid: rankID, img: str(im.imageUrl), source: 'mg' });
    } else {
      const c = slist(im.contents);
      if (c && c.length > 0) mgWalkBoards(c, list, seen);
    }
  }
}

export async function mgBoardDetail(bangid, page) {
  const d = await get('https://app.c.nf.migu.cn/MIGUM2.0/v1.0/content/querycontentbyId.do?columnId=' + encodeURIComponent(bangid) + '&needAll=0', mgAndroidHeaders);
  const raw = d.json;
  if (!raw) throw new Error('mg board detail invalid json');
  if (str(raw.code) !== mgSuccessCode) {
    return { total: 0, list: [], limit: 200, page, source: 'mg' };
  }
  const objs = [];
  for (const it of slist(sv(smap(raw.columnInfo), 'contents')) || []) {
    objs.push(sv(smap(it), 'objectInfo'));
  }
  const list = mgDedup(objs, mgSongFromObjectInfo);
  return { total: list.length, list, limit: 200, page, source: 'mg' };
}

export async function mgSonglist(page) {
  const d = await get(`https://app.c.nf.migu.cn/pc/bmw/page-data/playlist-square-recommend/v1.0?templateVersion=2&pageNo=${page}`, mgDefaultHeaders);
  const raw = d.json;
  if (!raw) throw new Error('mg songlist invalid json');
  if (str(raw.code) !== mgSuccessCode) {
    return { list: [], total: 0, page, limit: 30, source: 'mg' };
  }
  const data = smap(raw.data) || {};
  const list = [];
  const c = slist(data.contents);
  if (c && c.length > 0) {
    mgWalkPlaylists(c, list, {});
  } else {
    const items = slist(data.contentItemList) || [];
    if (items.length > 1) {
      for (const it of slist(sv(smap(items[1]), 'itemList')) || []) {
        const im = smap(it);
        if (!im) continue;
        let pc = '';
        const bars = slist(im.barList);
        if (bars && bars.length > 0) {
          pc = str(sv(smap(bars[0]), 'title'));
        }
        
        const o = { play_count: pc, id: str(sv(smap(im.logEvent), 'contentId')), author: '', name: str(im.title) };
        o.img = str(im.imageUrl);
        o.source = 'mg';
        list.push(o);
      }
    }
  }
  return { list, total: 99999, page, limit: 30, source: 'mg' };
}

function mgWalkPlaylists(items, list, seen) {
  for (const it of items) {
    const im = smap(it);
    if (!im) continue;
    const c = slist(im.contents);
    if (c && c.length > 0) {
      mgWalkPlaylists(c, list, seen);
      continue;
    }
    if (str(im.resType) !== '2021') continue;
    const resID = str(im.resId);
    if (resID === '' || seen[resID]) continue;
    seen[resID] = true;
    const o = { play_count: '', id: resID, author: '', name: str(im.txt) };
    o.img = str(im.img);
    if (str(im.txt2) !== '') o.desc = str(im.txt2);
    o.source = 'mg';
    list.push(o);
  }
}

export async function mgSonglistDetail(id, page) {
  let list = [];
  let total = 0;
  try {
    const d = await get(`https://app.c.nf.migu.cn/MIGUM3.0/resource/playlist/song/v2.0?pageNo=${page}&pageSize=50&playlistId=${encodeURIComponent(id)}`, mgDefaultHeaders);
    const raw = d.json;
    if (raw && str(raw.code) === mgSuccessCode) {
      const data = smap(raw.data) || {};
      list = mgDedup(slist(data.songList) || [], mgSongFromV5);
      total = parseIntS(str(data.totalCount));
    }
  } catch (e) {
    throw e;
  }
  let info = null;
  try {
    const d2 = await get('https://c.musicapp.migu.cn/MIGUM3.0/resource/playlist/v2.0?playlistId=' + encodeURIComponent(id), mgDefaultHeaders);
    const raw2 = d2.json;
    if (raw2 && str(raw2.code) === mgSuccessCode) {
      const data = smap(raw2.data) || {};
      let img = str(sv(smap(data.imgItem), 'img'));
      if (img !== '' && !img.startsWith('http')) {
        img = 'http://d.musicapp.migu.cn' + img;
      }
      info = {
        name: str(data.title),
        img,
        desc: str(data.summary),
        author: str(data.ownerName),
        play_count: formatPlayCount(sv(smap(data.opNumItem), 'playNum')),
      };
    }
  } catch {
    
  }
  return { list, page, limit: 50, total, source: 'mg', info };
}

export async function mgSonglistSearch(keyword, page, limit) {
  const timeStr = String(timeNowMillis());
  const d = await get(mgSearchURL(keyword, page, limit, true), mgSignedHeaders(timeStr, keyword));
  const raw = d.json;
  if (!raw) throw new Error('mg songlist search invalid json');
  const sld = smap(raw.songListResultData);
  if (!sld) throw new Error('mg songlist search failed');
  const list = [];
  for (const it of slist(sld.result) || []) {
    const im = smap(it);
    if (!im) continue;
    if (str(im.id) === '') continue;
    const o = { play_count: formatPlayCount(im.playNum), id: str(im.id), author: str(im.userName), name: str(im.name) };
    if (str(im.musicNum) !== '') o.total = str(im.musicNum);
    o.img = str(im.musicListPicUrl);
    o.source = 'mg';
    list.push(o);
  }
  return { list, total: parseIntS(str(sld.totalCount)), page, limit, source: 'mg' };
}

export async function mgMusicInfo(copyrightID) {
  try {
    const d = await postForm('https://c.musicapp.migu.cn/MIGUM2.0/v1.0/content/resourceinfo.do?resourceType=2',
      Buffer.from('resourceId=' + encodeURIComponent(copyrightID), 'utf8'), mgDefaultHeaders);
    const raw = d.json;
    if (!raw) return null;
    for (const it of slist(raw.resource) || []) {
      const im = smap(it);
      if (im && str(im.songId) !== '') return im;
    }
    return null;
  } catch {
    return null;
  }
}

export async function mgLyric(songmid) {
  const info = await mgMusicInfo(songmid);
  if (!info) throw new Error('获取歌词失败');
  const mrcURL = str(info.mrcUrl);
  const lrcURL = str(info.lrcUrl);
  const trcURL = str(info.trcUrl);
  let res;
  if (mrcURL !== '') {
    const text = await mgGetText(mrcURL);
    const [lyric, lxlyric] = mgParseMrc(mrcDecrypt(text));
    res = { lyric, lxlyric };
  } else if (lrcURL !== '') {
    const text = await mgGetText(lrcURL);
    res = { lyric: mgNormalizeLrc(text) };
  } else {
    throw new Error('获取歌词失败');
  }
  if (trcURL !== '') {
    try {
      res.tlyric = await mgGetText(trcURL);
    } catch {
      
    }
  }
  return res;
}

async function mgGetText(u) {
  const d = await get(u, mgAndroidHeaders);
  return d.body.toString('utf8');
}

function mgNormalizeLrc(text) {
  const lines = text.split('\n');
  let withTime = 0;
  for (const line of lines) {
    if (line.length >= 10 && line[0] === '[' && line.slice(0, 10).includes(':')) {
      withTime++;
    }
  }
  if (withTime > 0 && withTime * 2 > lines.length) {
    return text;
  }
  const out = [];
  let current = 0;
  for (let line of lines) {
    line = line.trim();
    if (line === '' || line.startsWith('@')) continue;
    out.push(`[${String(Math.trunc(current / 60)).padStart(2, '0')}:${String(current % 60).padStart(2, '0')}.00]${line}`);
    current += 3;
  }
  return out.join('\n');
}

export async function mgMusicURL(songmid, quality) {
  const info = await mgMusicInfo(songmid);
  if (!info) throw new Error('mg 未找到资源');
  const wantMap = { '128k': 'PQ', '320k': 'HQ', flac: 'SQ', flac24bit: 'ZQ', flac32bit: 'ZQ' };
  let want = wantMap[quality];
  if (!want) want = 'SQ';
  const formats = slist(info.newRateFormats) || [];
  let pick = '';
  for (const it of formats) {
    const f = smap(it);
    if (f && str(f.formatType) === want && str(f.url) !== '') {
      pick = str(f.url);
      break;
    }
  }
  if (pick === '') {
    for (const it of formats) {
      const f = smap(it);
      if (f) {
        const u = str(f.url);
        if (u !== '') {
          pick = u;
          break;
        }
      }
    }
  }
  if (pick === '') throw new Error('mg 未找到播放链接');
  return [{ url: pick, type: quality, from: 'original', sourceName: '咪咕' }];
}

export async function mgHotSearch() {
  const d = await get('http://jadeite.migu.cn:7090/music_search/v3/search/hotword');
  const raw = d.json;
  if (!raw) throw new Error('mg hotsearch invalid json');
  if (str(raw.code) !== mgSuccessCode) throw new Error(`mg hotsearch code=${str(raw.code)}`);
  const list = [];
  const hotwords = slist(sv(smap(raw.data), 'hotwords')) || [];
  if (hotwords.length === 0) return list;
  for (const it of slist(sv(smap(hotwords[0]), 'hotwordList')) || []) {
    const im = smap(it);
    if (!im) continue;
    if (str(im.resourceType) !== 'song') continue;
    list.push({ word: str(im.word) });
  }
  return list;
}

export async function mgTipSearch(keyword) {
  const d = await get('https://app.u.nf.migu.cn/pc/resource/content/tone_search_suggest/v1.0?text=' + encodeURIComponent(keyword));
  const raw = d.json;
  if (!raw) throw new Error('mg tipsearch invalid json');
  const list = [];
  for (const it of slist(sv(smap(raw.data), 'songList')) || []) {
    list.push(str(sv(smap(it), 'songName')));
  }
  return list;
}


import { postForm, get } from '../http.js';
import {
  newSong, smap, slist, sv, str, tonum, num, parseIntS, parseFloatS, formatPlayTime, sizeFormate,
  decodeName, formatPlayCount, qualitySizeMap, qtype, qsize,
} from '../common.js';
import { wyWeapi, wyEapi, wyLinuxapi } from '../crypto.js';
import { wyLyricParse, wyFixTimeLabel } from '../wy_lyric.js';
import { reverseQuality } from '../common.js';

const wyUA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36';

const wyPublicHeaders = { 'User-Agent': wyUA, Referer: 'https://music.163.com/' };

async function wyPublicJSON(url) {
  try {
    const d = await get(url, wyPublicHeaders);
    return d.json;
  } catch {
    return null;
  }
}

function codeStr(v) {
  return v === undefined || v === null ? '<nil>' : str(v);
}

async function wyEapiRequest(apiPath, data) {
  const body = 'params=' + encodeURIComponent(wyEapi(apiPath, data));
  const d = await postForm('http://interface.music.163.com/eapi/batch', Buffer.from(body, 'utf8'), {
    'User-Agent': wyUA,
    Origin: 'https://music.163.com',
    Referer: 'https://music.163.com/',
  });
  return d.json;
}

async function wyWeapiRequest(apiPath, data, referer) {
  const enc = wyWeapi(data);
  const body = 'encSecKey=' + encodeURIComponent(enc.encSecKey) + '&params=' + encodeURIComponent(enc.params);
  const headers = {
    'User-Agent': wyUA,
    Origin: 'https://music.163.com',
  };
  if (referer) headers.Referer = referer;
  const d = await postForm(apiPath, Buffer.from(body, 'utf8'), headers);
  return d.json;
}

export async function wySearch(keyword, page, limit) {
  const m = await wyEapiRequest('/api/search/song/list/page', {
    keyword, needCorrect: '1', channel: 'typing',
    offset: limit * (page - 1), scene: 'normal', total: page === 1, limit,
  });
  if (num(m && m.code) !== 200) throw new Error(`wy search code=${codeStr(m && m.code)}`);
  const data = smap(m && m.data);
  const resources = slist(sv(data, 'resources')) || [];
  const list = [];
  for (const r of resources) {
    const rm = smap(r);
    const base = smap(sv(rm, 'baseInfo'));
    const sd = smap(sv(base, 'simpleSongData'));
    if (!sd) continue;
    const s = wySongFromDetail(sd);
    if (s) list.push(s);
  }
  const total = Math.trunc(num(sv(data, 'totalCount')));
  let allPage = Math.floor(total / limit);
  if (total % limit !== 0) allPage++;
  return { list, allPage, total, limit, source: 'wy' };
}

export function wySongFromDetail(sd) {
  const privilege = smap(sv(sd, 'privilege'));
  if (!privilege) return null;
  const types = [];
  const tm = {};
  const addType = (cond, qtype_, sizeVal) => {
    if (!cond) return;
    let size = '';
    const sm = smap(sizeVal);
    if (sm) size = sizeFormate(Math.trunc(num(sm.size)));
    types.push(qtype(qtype_, size));
    tm[qtype_] = qsize(size);
  };
  addType(wyHasBr(privilege, 'maxBrLevel', 'hires'), 'flac24bit', sv(sd, 'hr'));
  addType(wyMaxBr(privilege, 'maxbr') >= 999000, 'flac', sv(sd, 'sq'));
  addType(wyMaxBr(privilege, 'maxbr') >= 320000, '320k', sv(sd, 'h'));
  addType(wyMaxBr(privilege, 'maxbr') >= 128000, '128k', sv(sd, 'l'));
  reverseQuality(types);
  const ar = [];
  const arList = slist(sv(sd, 'ar'));
  if (arList) {
    for (const a of arList) {
      const am = smap(a);
      if (am) ar.push(str(am.name));
    }
  }
  const al = smap(sv(sd, 'al'));
  const s = newSong();
  s.singer = ar.join('、');
  s.name = str(sd.name);
  if (al) {
    s.albumName = str(al.name);
    s.albumId = str(al.id);
    s.img = str(al.picUrl);
  }
  s.source = 'wy';
  s.interval = formatPlayTime(parseFloatS(str(sd.dt)) / 1000);
  s.songmid = sd.id;
  s.types = types;
  s._types = qualitySizeMap(tm);
  return s;
}

function wyHasBr(p, key, val) {
  return str(sv(p, key)) === val;
}

function wyMaxBr(p, key) {
  return Math.trunc(num(sv(p, key)));
}

export async function wyBoards() {
  let m = await wyPublicJSON('https://music.163.com/api/toplist');
  if (!m || num(m && m.code) !== 200) {
    m = await wyWeapiRequest('https://music.163.com/weapi/toplist', {}, '');
  }
  if (num(m && m.code) !== 200) throw new Error(`wy toplist code=${codeStr(m && m.code)}`);
  const list = slist(m && m.list) || [];
  const boards = [];
  for (const item of list) {
    const im = smap(item);
    if (!im) continue;
    const id = str(im.id);
    boards.push({ id: 'wy__' + id, name: str(im.name), bangid: id, img: str(im.coverImgUrl) });
  }
  return { list: boards, source: 'wy' };
}

export async function wyBoardDetail(bangid, page) {
  let m = await wyPublicJSON('https://music.163.com/api/v6/playlist/detail?id=' + encodeURIComponent(bangid));
  if (!m || num(m && m.code) !== 200) {
    m = await wyWeapiRequest('https://music.163.com/weapi/v3/playlist/detail', {
      id: bangid, n: 100000, p: 1,
    }, '');
  }
  if (num(m && m.code) !== 200) throw new Error(`wy playlist detail code=${codeStr(m && m.code)}`);
  const playlist = smap(m && m.playlist);
  const trackIDs = [];
  const tids = slist(sv(playlist, 'trackIds'));
  if (tids) {
    for (const t of tids) {
      const tm = smap(t);
      if (tm) trackIDs.push(str(tm.id));
    }
  }
  const list = await wySongsByIDs(trackIDs);
  return { total: list.length, list, limit: 100000, page, source: 'wy' };
}

export async function wySongsByIDs(ids) {
  if (ids.length === 0) return [];
  const batches = [];
  for (let i = 0; i < ids.length; i += 100) {
    batches.push(ids.slice(i, Math.min(i + 100, ids.length)));
  }
  const list = [];
  for (const batch of batches) {
    let m = await wyPublicJSON('https://music.163.com/api/song/detail?ids=[' + batch.join(',') + ']');
    if (!m || num(m && m.code) !== 200) {
      const cParts = batch.map((id) => `{"id":${id}}`);
      try {
        m = await wyWeapiRequest('https://music.163.com/weapi/v3/song/detail', {
          c: '[' + cParts.join(',') + ']', ids: '[' + batch.join(',') + ']',
        }, '');
      } catch { continue; }
    }
    if (num(m && m.code) !== 200) continue;
    const songs = slist(m && m.songs) || [];
    for (const sg of songs) {
      const sm = smap(sg);
      if (!sm) continue;
      const s = wySongFromWeapiSong(sm);
      if (s) list.push(s);
    }
  }
  return list;
}

export function wySongFromWeapiSong(sm) {
  const ar = [];
  const arList = slist(sv(sm, 'ar')) || slist(sv(sm, 'artists'));
  if (arList) {
    for (const a of arList) {
      const am = smap(a);
      if (am) ar.push(str(am.name));
    }
  }
  const al = smap(sv(sm, 'al')) || smap(sv(sm, 'album'));
  const s = newSong();
  s.singer = ar.join('、');
  s.name = str(sm.name);
  if (al) {
    s.albumName = str(al.name);
    s.albumId = str(al.id);
    s.img = str(al.picUrl);
  }
  s.source = 'wy';
  s.interval = formatPlayTime(parseFloatS(str(sm.dt)) / 1000);
  s.songmid = sm.id;
  s.types = [];
  s._types = {};
  return s;
}

export async function wySonglist(page) {
  const offset = (page - 1) * 30;
  let m = await wyPublicJSON(
    'https://music.163.com/api/playlist/list?cat=' + encodeURIComponent('全部') +
    '&order=hot&offset=' + offset + '&limit=30&total=true',
  );
  if (!m || num(m && m.code) !== 200) {
    m = await wyWeapiRequest('https://music.163.com/weapi/playlist/list', {
      cat: '全部', order: 'hot', offset, limit: 30, total: true,
    }, '');
  }
  if (num(m && m.code) !== 200) throw new Error(`wy playlist list code=${codeStr(m && m.code)}`);
  const plists = slist(m && m.playlists) || [];
  const list = [];
  for (const p of plists) {
    const pm = smap(p);
    if (!pm) continue;
    const creator = smap(sv(pm, 'creator'));
    const nickname = creator ? str(creator.nickname) : '';
    list.push({
      play_count: wyPlayCount(sv(pm, 'playCount')),
      id: str(pm.id),
      author: nickname,
      name: str(pm.name),
      total: str(sv(pm, 'trackCount')),
      img: str(pm.coverImgUrl),
      source: 'wy',
    });
  }
  const total = Math.trunc(num(m && m.total));
  return { list, total, page, limit: 30, source: 'wy' };
}

function wyPlayCount(v) {
  if (typeof v === 'number' && Number.isFinite(v)) return formatPlayCount(v);
  return '';
}

export async function wySonglistSearch(keyword, page, limit) {
  const m = await wyEapiRequest('/api/cloudsearch/pc', {
    s: keyword, type: 1000, limit, total: page === 1, offset: limit * (page - 1),
  });
  if (num(m && m.code) !== 200) throw new Error(`wy cloudsearch code=${codeStr(m && m.code)}`);
  const result = smap(m && m.result);
  const list = [];
  for (const p of slist(sv(result, 'playlists')) || []) {
    const pm = smap(p);
    list.push({
      play_count: wyPlayCount(sv(pm, 'playCount')),
      id: str(sv(pm, 'id')),
      author: str(sv(smap(sv(pm, 'creator')), 'nickname')),
      name: str(sv(pm, 'name')),
      total: str(sv(pm, 'trackCount')),
      img: str(sv(pm, 'coverImgUrl')),
      desc: str(sv(pm, 'description')),
      source: 'wy',
    });
  }
  return { list, total: Math.trunc(tonum(sv(result, 'playlistCount'))), page, limit, source: 'wy' };
}

async function wyLinuxRequest(apiURL, params) {
  const body = 'eparams=' + encodeURIComponent(wyLinuxapi({ method: 'POST', url: apiURL, params }));
  const d = await postForm('https://music.163.com/api/linux/forward', Buffer.from(body, 'utf8'), {
    'User-Agent': wyUA,
    Cookie: 'MUSIC_U=',
  });
  return d.json;
}

export function wySongFromPrivilege(privilege, item) {
  if (!item || !privilege) return null;
  const types = [];
  const tm = {};
  let size = '';
  if (str(sv(privilege, 'maxBrLevel')) === 'hires') {
    const hr = smap(sv(item, 'hr'));
    if (hr) size = sizeFormate(Math.trunc(tonum(hr.size)));
    types.push(qtype('flac24bit', size));
    tm.flac24bit = qsize(size);
  }
  const maxbr = Math.trunc(tonum(sv(privilege, 'maxbr')));
  
  if (maxbr === 999000) {
    const sq = smap(sv(item, 'sq'));
    if (sq) size = sizeFormate(Math.trunc(tonum(sq.size)));
    types.push(qtype('flac', size));
    tm.flac = qsize(size);
  }
  if (maxbr === 999000 || maxbr === 320000) {
    const h = smap(sv(item, 'h'));
    if (h) size = sizeFormate(Math.trunc(tonum(h.size)));
    types.push(qtype('320k', size));
    tm['320k'] = qsize(size);
  }
  if (maxbr === 999000 || maxbr === 320000 || maxbr === 192000 || maxbr === 128000) {
    const l = smap(sv(item, 'l'));
    if (l) size = sizeFormate(Math.trunc(tonum(l.size)));
    types.push(qtype('128k', size));
    tm['128k'] = qsize(size);
  }
  reverseQuality(types);

  const al = smap(sv(item, 'al'));
  const s = newSong();
  const pc = smap(sv(item, 'pc'));
  if (pc) {
    s.singer = str(pc.ar);
    s.name = str(pc.sn);
    s.albumName = str(pc.alb);
  } else {
    s.singer = wySingerNames(sv(item, 'ar'));
    s.name = str(item.name);
    s.albumName = str(sv(al, 'name'));
  }
  s.albumId = str(sv(al, 'id'));
  s.source = 'wy';
  s.interval = formatPlayTime(tonum(item.dt) / 1000);
  s.songmid = item.id;
  s.img = str(sv(al, 'picUrl'));
  s.types = types;
  s._types = qualitySizeMap(tm);
  return s;
}

export function wySingerNames(v) {
  const names = [];
  for (const it of slist(v) || []) {
    const n = str(sv(smap(it), 'name'));
    if (n !== '') names.push(n);
  }
  return decodeName(names.join('、'));
}

export async function wySonglistDetail(id, page) {
  if (/[?&:/]/.test(id)) {
    const m = /\/playlist\/(\d+)/.exec(id);
    if (m) id = m[1];
  }
  const m = await wyLinuxRequest('https://music.163.com/api/v3/playlist/detail', {
    id, n: 100000, s: 8,
  });
  if (num(m && m.code) !== 200) throw new Error(`wy playlist detail code=${codeStr(m && m.code)}`);
  const playlist = smap(m && m.playlist) || {};
  const trackIDs = slist(playlist.trackIds) || [];
  const privileges = slist(m && m.privileges) || [];
  let list = [];
  if (trackIDs.length === privileges.length) {
    let i = 0;
    for (const it of slist(playlist.tracks) || []) {
      const item = smap(it);
      const prRaw = smap(privileges[i]);
      i++;
      let pr = prRaw;
      if (!pr || str(sv(pr, 'id')) !== str(sv(item, 'id'))) {
        pr = wyFindPrivilege(privileges, str(sv(item, 'id')));
      }
      if (!pr) continue;
      const s = wySongFromPrivilege(pr, item);
      if (s) list.push(s);
    }
  } else {
    const limit = 1000;
    const start = (page - 1) * limit;
    const end = limit * page;
    const ids = [];
    for (let i = 0; i < trackIDs.length; i++) {
      if (i < start || i >= end) continue;
      ids.push(str(sv(smap(trackIDs[i]), 'id')));
    }
    list = await wySongsByIDs(ids);
  }
  const creator = smap(playlist.creator);
  const info = {
    name: str(playlist.name),
    img: str(playlist.coverImgUrl),
    desc: str(playlist.description),
    author: str(sv(creator, 'nickname')),
    play_count: formatPlayCount(playlist.playCount),
  };
  return { list, page, limit: 1000, total: trackIDs.length, source: 'wy', info };
}

function wyFindPrivilege(privileges, id) {
  for (const p of privileges) {
    const pm = smap(p);
    if (str(sv(pm, 'id')) === id) return pm;
  }
  return null;
}

export async function wyLyric(songmid) {
  const m = await wyEapiRequest('/api/song/lyric/v1', {
    id: songmid, cp: false, tv: 0, lv: 0, rv: 0, kv: 0, yv: 0, ytv: 0, yrv: 0,
  });
  if (num(m && m.code) !== 200) throw new Error(`wy lyric code=${codeStr(m && m.code)}`);
  const lrc = str(sv(smap(m && m.lrc), 'lyric'));
  if (lrc === '') throw new Error('Get lyric failed');
  const [lrcText, tlrcText, rlrcText] = wyFixTimeLabel(
    lrc, str(sv(smap(m.tlyric), 'lyric')), str(sv(smap(m.romalrc), 'lyric'))
  );
  const res = wyLyricParse(
    str(sv(smap(m.yrc), 'lyric')), str(sv(smap(m.ytlrc), 'lyric')), str(sv(smap(m.yromalrc), 'lyric')),
    lrcText, tlrcText, rlrcText
  );
  if (res.lyric === undefined || res.lyric === '') throw new Error('Get lyric failed');
  return res;
}

export async function wyMusicURL(songmid, quality) {
  let br = 320000;
  switch (quality) {
    case '128k': br = 128000; break;
    case 'flac': br = 999000; break;
    case 'flac24bit': br = 1999000; break;
  }
  let m = await wyPublicJSON(
    'https://music.163.com/api/song/enhance/player/url?ids=[' + songmid + ']&br=' + br,
  );
  if (!m || num(m && m.code) !== 200) {
    m = await wyWeapiRequest('https://music.163.com/weapi/song/enhance/player/url/v1', {
      ids: '[' + songmid + ']', level: wyBrLevel(br), encodeType: 'mp3',
    }, 'https://music.163.com/song?id=' + songmid);
  }
  if (num(m && m.code) !== 200) throw new Error(`wy player url code=${codeStr(m && m.code)}`);
  const data = slist(m && m.data) || [];
  for (const item of data) {
    const im = smap(item);
    if (!im) continue;
    const u = str(im.url);
    if (u === '') continue;
    return [{ url: u, type: quality, from: 'original', sourceName: '网易云', sourceId: '' }];
  }
  throw new Error('no playable url');
}

function wyBrLevel(br) {
  if (br >= 1999000) return 'hires';
  if (br >= 999000) return 'lossless';
  if (br >= 320000) return 'exhigh';
  if (br >= 128000) return 'standard';
  return 'standard';
}

export async function wyHotSearch() {
  let m = await wyPublicJSON('https://music.163.com/api/hotsearchlist/get');
  if (!m || num(m && m.code) !== 200) {
    m = await wyWeapiRequest('https://music.163.com/weapi/hotsearchlist/get', {}, '');
  }
  const data = slist(m && m.data) || [];
  const list = [];
  for (const d of data) {
    const dm = smap(d);
    if (dm) list.push({ word: str(dm.searchWord) });
  }
  return list;
}

export async function wyTipSearch(keyword) {
  let m = await wyPublicJSON(
    'https://music.163.com/api/search/suggest/web?s=' + encodeURIComponent(keyword) + '&limit=8',
  );
  if (!m || num(m && m.code) !== 200) {
    m = await wyWeapiRequest('https://music.163.com/weapi/search/suggest/web', {
      s: keyword,
    }, '');
  }
  const result = smap(m && m.result);
  const songs = slist(sv(result, 'songs')) || [];
  const list = [];
  for (const s of songs) {
    const sm = smap(s);
    if (sm) list.push(str(sm.name) + ' - ' + wySingerNames(sm.artists));
  }
  return list;
}

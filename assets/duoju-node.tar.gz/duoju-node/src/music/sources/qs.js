
import { get, postRaw, desktopUA } from '../http.js';
import {
  newSong, smap, slist, sv, str, tonum, num, parseIntS, formatPlayTime, firstNonEmpty, formatPlayCount,
} from '../common.js';
import { md5Hex } from '../crypto.js';

const qsHeaders = {
  'User-Agent': desktopUA,
  Referer: 'https://music.douyin.com/',
  Cookie: 'odin_tt=1; ttwid=1',
};

const qsChartIcon = 'https://is1-ssl.mzstatic.com/image/thumb/Purple211/v4/23/19/5a/23195ac8-3fbf-d33b-16ed-20854f9afd35/AppIcon-0-0-1x_U007epad-0-1-0-85-220.png/512x512bb.jpg';

const qsChartIDs = [
  { id: '7036274230471712007', name: '热歌榜', desc: '热门歌曲排行榜' },
  { id: '7060812597884869927', name: '新歌榜', desc: '最新发布歌曲' },
];

function qsMustJSON(v) {
  return Buffer.from(JSON.stringify(v), 'utf8');
}

function qsExtractTrack(v) {
  const m = smap(v);
  if (!m) return null;
  if (str(m.id) !== '' && (str(m.name) !== '' || str(m.title) !== '')) {
    return m;
  }
  for (const path of [['track'], ['entity', 'track_wrapper', 'track'], ['track_wrapper', 'track'], ['entity', 'track']]) {
    let cur = m;
    let ok = true;
    for (const k of path) {
      const cm = smap(cur);
      if (!cm) {
        ok = false;
        break;
      }
      cur = cm[k];
    }
    if (ok) {
      const cm = smap(cur);
      if (cm && str(cm.id) !== '') return cm;
    }
  }
  return null;
}

function qsBuildImage(v, suffix) {
  const vm = smap(v);
  if (!vm) return '';
  const urls = slist(vm.urls);
  if (!urls || urls.length === 0) return '';
  let cover = str(urls[0]);
  const uri = str(vm.uri);
  if (uri !== '' && !cover.includes(uri)) {
    cover += uri;
  }
  if (suffix !== '' && !cover.includes('~')) {
    cover += suffix;
  }
  return cover;
}

function qsTrackToSong(track) {
  const artists = slist(track.artists) || [];
  const ar = [];
  for (const a of artists) {
    const am = smap(a);
    if (am) {
      let name = str(am.name);
      if (name === '') name = str(am.simple_display_name);
      if (name !== '') ar.push(name);
    }
  }
  const album = smap(track.album);
  let albumCover = {};
  if (album) {
    const ac = smap(album.url_cover);
    if (ac) albumCover = ac;
  }
  const s = newSong();
  s.singer = ar.join(' / ');
  s.name = str(track.name);
  s.songmid = str(track.id);
  s.songId = str(track.id);
  s.source = 'qs';
  if (album) {
    s.albumName = str(album.name);
    s.albumId = str(album.id);
  }
  s.img = qsBuildImage(albumCover, '~c5_375x375.jpg');
  if (typeof track.duration === 'number') {
    s.interval = formatPlayTime(track.duration / 1000);
  }
  return s;
}

async function qsPostJSON(path, payload) {
  const d = await postRaw('https://api.qishui.com' + path, qsMustJSON(payload), 'application/json; charset=utf-8', qsHeaders);
  return d.json;
}

export async function qsSearch(keyword, page, limit) {
  if (limit > 20) limit = 20;
  if (limit <= 0) limit = 20;
  let cursor = null;
  if (page > 1) {
    cursor = String((page - 1) * limit);
  }
  const m = await qsPostJSON('/luna/search/track?device_platform=web', {
    search_type: 'track', q: keyword, cursor,
    search_id: md5Hex(keyword), search_method: 'input', search_scene: 'search_result',
  });
  if (!m) throw new Error('qs search invalid body');
  const groups = slist(m.result_groups) || [];
  let group = null;
  for (const it of groups) {
    if (str(sv(smap(it), 'id')) === 'tracks') {
      group = smap(it);
      break;
    }
  }
  if (!group && groups.length > 0) {
    group = smap(groups[0]);
  }
  const list = [];
  const seen = {};
  if (group) {
    for (const item of slist(group.data) || []) {
      const track = qsExtractTrack(item);
      if (!track) continue;
      const id = str(track.id);
      if (id === '' || seen[id]) continue;
      seen[id] = true;
      list.push(qsTrackToSong(track));
    }
  }
  let total = list.length;
  if (group) {
    const t = Math.trunc(tonum(group.total));
    if (t > 0) total = t;
  }
  const allPage = Math.trunc((total + limit - 1) / limit);
  return { list, allPage, total, limit, source: 'qs' };
}

export async function qsBoards() {
  const list = [];
  for (const c of qsChartIDs) {
    list.push({ id: c.id, name: c.name, pic: qsChartIcon, desc: c.desc, kind: 'chart', source: 'qs' });
  }
  return { list, source: 'qs' };
}

export async function qsBoardDetail(bangid, page) {
  const d = await get('https://api.qishui.com/luna/charts/' + encodeURIComponent(bangid), qsHeaders);
  const raw = d.json;
  if (!raw) throw new Error('qs board detail invalid json');
  const chart = smap(raw.chart) || {};
  let items = slist(chart.track_ranks) || [];
  if (items.length === 0) items = slist(chart.tracks) || [];
  if (items.length === 0) items = slist(raw.track_ranks) || [];
  if (items.length === 0) items = slist(raw.tracks) || [];
  if (items.length === 0) items = slist(raw.items) || [];
  const list = [];
  const seen = {};
  for (const item of items) {
    const track = qsExtractTrack(item);
    if (!track || seen[str(track.id)]) continue;
    seen[str(track.id)] = true;
    list.push(qsTrackToSong(track));
  }
  return { total: list.length, list, limit: list.length, page, source: 'qs' };
}

export async function qsSonglist(page) {
  let m = await qsPostJSON('/luna/discover', {
    ab_param: '', selected_boost: null, playlist_mix_param: null,
    feed_discover_extra: null, first_request: true,
  });
  if (!m) throw new Error('qs discover invalid body');
  let blocks = slist(m.blocks) || [];
  for (let i = 0; i < 2; i++) {
    let mix = null;
    try {
      mix = await qsPostJSON('/luna/discover/mix', {
        block_type: 'discover_playlist_mix', sub_channel_id: 0,
        latest_douyin_liked_playlist_show_ts: null, feed_discover_extra: {},
        cursor: null, count: 50, session_id: null, ab_param: '',
      });
    } catch {
      continue;
    }
    if (mix) blocks.push({ inner_block: mix.inner_block, title: '推荐' });
  }
  const cards = [];
  const seen = {};
  for (const b of blocks) {
    const bm = smap(b);
    if (!bm) continue;
    let inners = slist(bm.inner_block) || [];
    if (inners.length === 0 && bm.resources != null) {
      inners = [bm];
    }
    for (const inn of inners) {
      const im = smap(inn) || {};
      for (const r of slist(im.resources) || []) {
        const rm = smap(r);
        if (!rm) continue;
        const style = smap(rm.style) || {};
        let kind = str(rm.type);
        if (kind === '') kind = 'radio';
        let rid = str(rm.resource_id);
        if (rid === '') rid = str(im.inner_block_id);
        const marker = kind + ':' + rid;
        if (rid === '' || seen[marker]) continue;
        seen[marker] = true;
        let cover = smap(style.cover_url);
        if (!cover) {
          const cl = slist(style.cover_url_list);
          if (cl && cl.length > 0) cover = smap(cl[0]);
        }
        if (!cover) {
          cover = smap(sv(smap(sv(smap(rm.entity), 'playlist')), 'url_cover'));
        }
        const name = firstNonEmpty(str(style.title), str(im.title), '推荐歌单');
        const desc = firstNonEmpty(str(style.desc), str(bm.title), '为你推荐');
        
        const o = { play_count: '', id: rid, author: '', name };
        o.img = qsBuildImage(cover, '~c5_300x300.jpg');
        if (desc !== '') o.desc = desc;
        o.kind = kind;
        o.source = 'qs';
        cards.push(o);
      }
    }
  }
  return { list: cards, total: cards.length, page, limit: 20, source: 'qs' };
}

function qsTracksToSongs(items) {
  const list = [];
  const seen = {};
  for (const item of items) {
    const track = qsExtractTrack(item);
    if (!track) continue;
    const id = str(track.id);
    if (id === '' || seen[id]) continue;
    seen[id] = true;
    list.push(qsTrackToSong(track));
  }
  return list;
}

async function qsPlaylistDetail(id, page) {
  let cursor = null;
  if (page > 1) {
    cursor = String((page - 1) * 100);
  }
  const m = await qsPostJSON('/luna/playlist/detail', {
    playlist_id: id, cursor, count: 100, type: null,
    feed_playlist_extra: { har: null, commerce_block_pattern: null },
    sort_type: null, session_id: null, reverse: false, ab_param: '', limited_free_scene: 0,
  });
  if (!m || m.playlist == null) {
    return { list: [], page, limit: 100, source: 'qs' };
  }
  const playlist = smap(m.playlist) || {};
  const items = [];
  for (const it of slist(m.media_resources) || []) {
    const im = smap(it);
    if (!im) continue;
    const ent = smap(im.entity);
    if (ent) items.push(ent);
  }
  const list = qsTracksToSongs(items);
  const creator = firstNonEmpty(str(sv(smap(playlist.owner), 'public_name')), str(sv(smap(playlist.owner), 'nickname')));
  const info = {
    name: str(playlist.name),
    img: '',
    desc: str(playlist.desc),
    author: creator,
    play_count: formatPlayCount(playlist.count_tracks),
  };
  info.img = qsBuildImage(playlist.url_cover, '~c5_375x375.jpg');
  let total = Math.trunc(tonum(playlist.count_tracks));
  if (total === 0) total = list.length;
  return { list, page, limit: 100, total, source: 'qs', info };
}

async function qsRadioDetail(id) {
  let m = null;
  try {
    m = await qsPostJSON('/luna/feed/radio/tracks', {
      radio_id: id, played_media: [],
      feed_radio_media_extra: { real_groups: [] },
      flow_type: 2, full_media: true,
    });
  } catch {
    return null;
  }
  if (!m) return null;
  return qsTracksToSongs(slist(m.items) || []);
}

export async function qsSonglistDetail(id, page) {
  let res = null;
  let err = null;
  try {
    res = await qsPlaylistDetail(id, page);
  } catch (e) {
    err = e;
  }
  if (res && res.list && res.list.length > 0) {
    return res;
  }
  const radio = await qsRadioDetail(id);
  if (radio && radio.length > 0) {
    return {
      list: radio, page, limit: 100, total: radio.length, source: 'qs',
      info: { name: '电台', img: '', desc: '', author: '', play_count: '' },
    };
  }
  if (res) return res;
  if (err) throw err;
  return { list: [], page, limit: 100, source: 'qs' };
}

export async function qsSonglistSearch(keyword, page, limit) {
  const cursor = (page - 1) * limit;
  const u = `https://api.qishui.com/luna/pc/search/playlist?q=${encodeURIComponent(keyword)}&cursor=${cursor}&search_method=input&aid=386088&device_platform=web&channel=pc_web`;
  const d = await get(u, qsHeaders);
  const raw = d.json;
  if (!raw) throw new Error('qs songlist search invalid json');
  const resultGroups = slist(raw.result_groups) || [];
  const list = [];
  if (resultGroups.length === 0) {
    return { list, total: 0, page, limit, source: 'qs' };
  }
  const g0 = smap(resultGroups[0]) || {};
  for (const item of slist(g0.data) || []) {
    const im = smap(item);
    if (!im) continue;
    const entity = smap(im.entity);
    if (!entity) continue;
    const pl = smap(entity.playlist);
    if (!pl || str(pl.id) === '') continue;
    const owner = smap(pl.owner);
    const creator = owner ? firstNonEmpty(str(owner.public_name), str(owner.nickname)) : '';
    const o = { play_count: '', id: str(pl.id), author: creator, name: str(pl.title) };
    o.img = qsBuildImage(pl.url_cover, '~c5_300x300.jpg');
    if (str(pl.desc) !== '') o.desc = str(pl.desc);
    o.source = 'qs';
    list.push(o);
  }
  return { list, total: list.length, page, limit, source: 'qs' };
}

export async function qsLyric(songmid) {
  return { lyric: '暂无歌词' };
}

function qsParseStreams(data) {
  const result = [];
  const player = smap(data && data.track_player);
  if (!player) return result;
  let model = player.video_model;
  if (typeof model === 'string' && model !== '') {
    try {
      model = JSON.parse(model);
    } catch {
      model = null;
    }
  }
  const mm = smap(model);
  if (mm) {
    const videoList = slist(mm.video_list) || [];
    for (const item of videoList) {
      const im = smap(item);
      if (!im) continue;
      if (im.encrypt_info != null) continue;
      const meta = smap(im.video_meta);
      if (!meta) continue;
      let bitrate = Math.trunc(num(meta.bitrate));
      if (bitrate === 0) bitrate = Math.trunc(num(meta.real_bitrate));
      const mainURL = str(im.main_url);
      const backupURL = str(im.backup_url);
      let u = mainURL;
      if (u === '') u = backupURL;
      if (u === '') continue;
      result.push({
        key: str(meta.quality), bitrate, url: u,
        label: qsStreamLabel(bitrate, result.length),
      });
    }
  }
  if (result.length === 0) {
    const upi = player.url_player_info;
    if (typeof upi === 'string') {
      result.push({ needFetch: upi });
    }
  }
  return result;
}

function qsStreamLabel(bitrate, index) {
  const kbps = Math.trunc(bitrate / 1000);
  let name;
  if (kbps >= 900) {
    name = '无损音质';
  } else if (kbps >= 190) {
    name = '极高音质';
  } else if (kbps >= 96) {
    name = '标准音质';
  } else {
    name = '省流音质';
  }
  if (kbps > 0) {
    return `${name}(${kbps}K)`;
  }
  return `${name}${index + 1}`;
}

function qsGetQualityType(bitrate, format) {
  const f = String(format || '').toLowerCase();
  if (bitrate > 1000000 || (f === 'flac' && bitrate > 800000)) return 'flac24bit';
  if (bitrate > 800000 || f === 'flac') return 'flac';
  if (bitrate > 200000) return '320k';
  return '128k';
}

async function qsFetchPlayInfo(urlStr) {
  const d = await get(urlStr, qsHeaders);
  const raw = d.json;
  if (!raw) throw new Error('qs play info invalid json');
  const playInfoList = slist(sv(sv(smap(raw.Result), 'data'), 'PlayInfoList')) || [];
  const out = [];
  for (const it of playInfoList) {
    const item = smap(it);
    if (!item) continue;
    let u = str(item.MainPlayUrl);
    if (u === '') u = str(item.BackupPlayUrl);
    if (u === '') continue;
    out.push({
      key: qsGetQualityType(Math.trunc(num(item.Bitrate)), str(item.Format)),
      bitrate: Math.trunc(num(item.Bitrate)), url: u,
      playAuth: str(item.PlayAuth), format: str(item.Format),
      size: Math.trunc(num(item.Size)), duration: Math.trunc(num(item.Duration)),
    });
  }
  return out;
}

export async function qsMusicURL(songmid, quality) {
  const d = await get('https://api.qishui.com/luna/h5/seo_track?track_id=' + songmid + '&device_platform=web', qsHeaders);
  const raw = d.json;
  if (!raw) throw new Error('qs music url invalid json');
  let streams = qsParseStreams(raw);
  let needFetch = '';
  for (const s of streams) {
    if (s.needFetch !== undefined && s.needFetch !== '') needFetch = s.needFetch;
  }
  if (needFetch !== '') {
    try {
      const fetched = await qsFetchPlayInfo(needFetch);
      if (fetched.length > 0) streams = streams.concat(fetched);
    } catch {
      
    }
  }
  const clean = [];
  const seen = {};
  for (const s of streams) {
    if (s.needFetch !== undefined && s.needFetch !== '') continue;
    const key = s.key + '_' + String(s.bitrate);
    if (seen[key]) continue;
    seen[key] = true;
    clean.push(s);
  }
  if (clean.length === 0) throw new Error('qs no streams');

  const order = ['flac24bit', 'flac', '320k', '128k'];
  let start = 0;
  for (let i = 0; i < order.length; i++) {
    if (order[i] === quality) {
      start = i;
      break;
    }
  }
  let selected = null;
  for (let i = start; i < order.length; i++) {
    const q = order[i];
    for (const c of clean) {
      if (qsGetQualityType(c.bitrate, c.format) === q) {
        selected = c;
        break;
      }
    }
    if (selected) break;
  }
  if (!selected) {
    for (const c of clean) {
      if (qsGetQualityType(c.bitrate, '') === '128k') {
        selected = c;
        break;
      }
    }
  }
  if (!selected) {
    selected = clean[clean.length - 1];
  }
  let format = String(selected.format || '').toLowerCase();
  if (format === '') format = 'm4a';
  const proxyPath = '/api/music/audio-proxy?url=' + encodeURIComponent(selected.url) + '&format=' + format;
  const withAuth = selected.playAuth !== undefined && selected.playAuth !== null && selected.playAuth !== '';
  const finalPath = withAuth ? proxyPath + '&playAuth=' + encodeURIComponent(selected.playAuth) : proxyPath;
  return [{ url: finalPath, type: qsGetQualityType(selected.bitrate, format), from: 'original', sourceName: '汽水音乐' }];
}

export async function qsHotSearch() {
  const list = [];
  try {
    const d = await get('https://api.qishui.com/luna/pc/search/hot?aid=386088&app_name=luna_pc&region=cn&device_platform=web', {
      'User-Agent': qsHeaders['User-Agent'],
      Referer: qsHeaders.Referer,
      Accept: 'application/json, text/plain, */*',
    });
    if (d && d.json) {
      const m = d.json;
      let hot = slist(m.hot_list) || [];
      for (const key of ['list', 'items', 'words']) {
        if (hot.length > 0) break;
        hot = slist(m[key]) || [];
      }
      for (let i = 0; i < hot.length; i++) {
        const it = hot[i];
        if (typeof it === 'string') {
          list.push({ keyword: it, rank: i + 1, source: 'qs' });
          continue;
        }
        const im = smap(it);
        if (!im) continue;
        const kw = firstNonEmpty(str(im.keyword), str(im.word), str(im.name), str(im.query));
        if (kw === '') continue;
        let rank = Math.trunc(tonum(im.rank));
        if (rank === 0) rank = Math.trunc(tonum(im.hot));
        if (rank === 0) rank = i + 1;
        const entry = { keyword: kw, rank, source: 'qs' };
        const icon = firstNonEmpty(str(im.icon_url), str(im.icon));
        if (icon !== '') entry.icon = icon;
        list.push(entry);
      }
    }
  } catch {
    
  }
  if (list.length === 0) {
    ['晴天', '七里香', '稻香', '告白气球', '青花瓷', '演员', '平凡之路', '后来', '海阔天空', '红豆'].forEach((k, i) => {
      list.push({ keyword: k, rank: i + 1, source: 'qs' });
    });
  }
  return list;
}

export async function qsTipSearch(keyword) {
  return [];
}

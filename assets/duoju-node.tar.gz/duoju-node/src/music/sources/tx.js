
import { get, postJSON, postRaw, desktopUA } from '../http.js';
import {
  newSong, smap, slist, sv, str, tonum, num, parseIntS, formatPlayTime, sizeFormate,
  decodeName, formatPlayCount, dateFormat,
} from '../common.js';
import { base64Decode } from '../crypto.js';

const txComm = { ct: '19', cv: '18090031', v: '18090031', tmeAppID: 'qqmusic' };

function txMustJSON(v) {
  return Buffer.from(JSON.stringify(v), 'utf8');
}

async function txMusicu(...reqs) {
  const body = { comm: txComm };
  if (reqs.length === 1) {
    body.req = reqs[0];
  } else {
    reqs.forEach((r, i) => {
      body[`req_${i}`] = r;
    });
  }
  const d = await postJSON('https://u.y.qq.com/cgi-bin/musicu.fcg', body, {
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15',
  });
  return d.json;
}

export async function txSearch(keyword, page, limit) {
  const m = await txMusicu({
    module: 'music.search.SearchCgiService', method: 'DoSearchForQQMusicMobile',
    param: {
      search_type: 0, query: keyword, page_num: page, num_per_page: limit,
      highlight: 0, nqc_flag: 0, multi_zhida: 0, cat: 2, grp: 1, sin: 0, sem: 0,
    },
  });
  const req = smap(m && m.req) || {};
  const data = smap(req.data) || {};
  const items = smap(data.body) || {};
  const songList = slist(items.item_song) || [];
  const list = [];
  for (const it of songList) {
    const im = smap(it);
    if (!im) continue;
    const file = smap(im.file);
    if (!file || str(file.media_mid) === '') continue;
    const { types, tm } = txQualityTypes(im.file);
    let albumName = '';
    let albumID = '';
    const album = smap(im.album);
    if (album) {
      albumName = decodeName(str(album.name));
      albumID = str(album.mid);
    }
    const s = newSong();
    s.name = decodeName(str(im.name)) + str(im.title_extra);
    s.singer = txSingers(im.singer);
    s.albumName = albumName;
    s.albumId = albumID;
    s.albumMid = albumID;
    s.strMediaMid = str(file.media_mid);
    s.source = 'tx';
    s.interval = formatPlayTime(num(im.interval));
    s.songmid = str(im.mid);
    s.songId = str(im.id);
    s.img = txImg(albumID, albumName, im.singer);
    s.types = types;
    s._types = tm;
    list.push(s);
  }
  let total = 0;
  const meta = smap(data.meta);
  if (meta) {
    total = Math.trunc(num(meta.estimate_sum));
  }
  let allPage = Math.floor(total / limit);
  if (total % limit !== 0) allPage++;
  return { list, allPage, total, limit, source: 'tx' };
}

function txQualityTypes(file) {
  const fm = smap(file);
  const types = [];
  const tm = {};
  const add = (key, qtype_) => {
    let size = '';
    if (fm && num(fm[key]) > 0) {
      size = sizeFormate(Math.trunc(num(fm[key])));
    }
    if (size === '') return;
    types.push({ type: qtype_, size });
    tm[qtype_] = { size };
  };
  add('size_128mp3', '128k');
  add('size_320mp3', '320k');
  add('size_flac', 'flac');
  add('size_hires', 'flac24bit');
  return { types, tm };
}

function txImg(albumMid, albumName, singers) {
  if (albumMid !== '' && albumMid !== '空' && albumName !== '' && albumName !== '空') {
    return 'https://y.gtimg.cn/music/photo_new/T002R500x500M000' + albumMid + '.jpg';
  }
  const list = slist(singers);
  if (list && list.length > 0) {
    const s0 = smap(list[0]);
    if (s0) {
      return 'https://y.gtimg.cn/music/photo_new/T001R500x500M000' + str(s0.mid) + '.jpg';
    }
  }
  return '';
}

function txSingers(v) {
  const ar = [];
  const list = slist(v);
  if (list) {
    for (const s of list) {
      const sm = smap(s);
      if (!sm) continue;
      const name = str(sm.name);
      if (name === '') continue;
      ar.push(name);
    }
  }
  return decodeName(ar.join('、'));
}

export async function txBoards() {
  const d = await get('https://c.y.qq.com/v8/fcg-bin/fcg_myqq_toplist.fcg?g_tk=1928093487&inCharset=utf-8&outCharset=utf-8&notice=0&format=json&uin=0&needNewCode=1&platform=h5', {
    'User-Agent': desktopUA, Referer: 'https://y.qq.com/',
  });
  const raw = d.json;
  if (!raw) throw new Error('tx toplist invalid json');
  if (parseIntS(str(raw.code)) !== 0) throw new Error(`tx toplist code=${str(raw.code)}`);
  const topList = slist(sv(smap(raw.data), 'topList')) || [];
  const list = [];
  for (const bi of topList) {
    const b = smap(bi);
    if (!b) continue;
    const id = Math.trunc(num(b.id));
    if (id === 201) continue;
    let title = str(b.topTitle);
    if (title.startsWith('巅峰榜·')) title = title.slice('巅峰榜·'.length);
    if (!title.endsWith('榜')) title += '榜';
    let img = str(b.frontPicUrl);
    if (img === '') img = str(b.picUrl);
    list.push({ id: 'tx__' + String(id), name: title, bangid: String(id), img });
  }
  return { list, source: 'tx' };
}

export async function txBoardDetail(bangid, page) {
  const period = await txGetPeriod(bangid);
  const m = await txMusicu({
    module: 'musicToplist.ToplistInfoServer', method: 'GetDetail',
    param: { topid: bangid, num: 300, period },
  });
  const toplist = smap(m && m.toplist) || {};
  const data = smap(toplist.data) || {};
  const songInfos = slist(data.songInfoList) || [];
  const list = [];
  for (const it of songInfos) {
    const im = smap(it);
    if (!im) continue;
    const s = txSongFromInfo(im);
    if (s) list.push(s);
  }
  return { total: list.length, list, limit: 300, page: 1, source: 'tx' };
}

async function txGetPeriod(bangid) {
  const d = await get('https://c.y.qq.com/node/pc/wk_v15/top.html');
  const html = d.body.toString('utf8');
  const re = /data-tid=".+?\/(\d+)" data-date="(\d+)"/g;
  let m;
  while ((m = re.exec(html)) !== null) {
    if (m[1] === bangid) return m[2];
  }
  return '';
}

function txSongFromInfo(im) {
  const file = smap(im.file);
  if (!file) return null;
  const { types, tm } = txQualityTypes(im.file);
  let albumName = '';
  let albumMid = '';
  const album = smap(im.album);
  if (album) {
    albumName = str(album.name);
    albumMid = str(album.mid);
  }
  const s = newSong();
  s.name = decodeName(str(im.title));
  s.singer = txSingers(im.singer);
  s.albumName = decodeName(albumName);
  s.albumId = albumMid;
  s.albumMid = albumMid;
  s.source = 'tx';
  s.interval = formatPlayTime(num(im.interval));
  s.songmid = str(im.mid);
  s.songId = str(im.id);
  s.strMediaMid = str(file.media_mid);
  s.img = txImg(albumMid, albumName, im.singer);
  s.types = types;
  s._types = tm;
  return s;
}

export async function txSonglist(sortId, page) {
  let order = 5;
  if (sortId !== '') {
    
    if (/^[+-]?\d+$/.test(sortId)) {
      const n = parseInt(sortId, 10);
      if (n > 0) {
        order = n;
      } else {
        order = sortId;
      }
    } else {
      order = sortId;
    }
  }
  const body = {
    comm: { cv: 1602, ct: 20 },
    playlist: {
      method: 'get_playlist_by_tag',
      param: {
        id: 10000000, sin: 36 * (page - 1), size: 36, order, cur_page: page,
      },
      module: 'playlist.PlayListPlazaServer',
    },
  };
  const payload = txMustJSON(body).toString('utf8');
  const u = 'https://u.y.qq.com/cgi-bin/musicu.fcg?loginUin=0&hostUin=0&format=json&inCharset=utf-8&outCharset=utf-8&notice=0&platform=wk_v15.json&needNewCode=0&data=' + encodeURIComponent(payload);
  const d = await get(u);
  const m = d.json;
  if (!m) throw new Error('tx songlist invalid body');
  if (Math.trunc(tonum(m.code)) !== 0) throw new Error(`tx songlist code=${Math.trunc(tonum(m.code))}`);
  const data = smap(sv(smap(m.playlist), 'data')) || {};
  const items = [];
  for (const l of slist(data.v_playlist) || []) {
    const lm = smap(l);
    if (!lm) continue;
    const creator = smap(lm.creator_info) || {};
    const songIDs = slist(lm.song_ids) || [];
    let t = '';
    const mt = tonum(lm.modify_time);
    if (mt > 0) t = dateFormat(mt * 1000, 'Y-M-D');
    
    const o = {
      play_count: formatPlayCount(lm.access_num),
      id: str(lm.tid),
      author: decodeName(str(creator.nick)),
      name: decodeName(str(lm.title)),
    };
    if (t !== '') o.time = t;
    o.total = String(songIDs.length);
    o.img = str(lm.cover_url_medium);
    const desc = decodeName(str(lm.desc)).replaceAll('<br>', '\n');
    if (desc !== '') o.desc = desc;
    o.source = 'tx';
    items.push(o);
  }
  return { list: items, total: Math.trunc(tonum(data.total)), page, limit: 36, source: 'tx' };
}

export async function txSonglistDetail(id, page) {
  const u = 'https://c.y.qq.com/qzone/fcg-bin/fcg_ucc_getcdinfo_byids_cp.fcg?type=1&json=1&utf8=1&onlysong=0&new_format=1&disstid=' + id + '&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq.json&needNewCode=0';
  const d = await get(u, {
    'User-Agent': desktopUA, Referer: 'https://y.qq.com/n/yqq/playsquare/' + id + '.html', Origin: 'https://y.qq.com',
  });
  const raw = d.json;
  if (!raw) throw new Error('tx songlist detail invalid json');
  const cdlist = slist(raw.cdlist) || [];
  if (parseIntS(str(raw.code)) !== 0 || cdlist.length === 0) {
    return { list: [], page, limit: 0, total: 0, source: 'tx' };
  }
  const cd0 = smap(cdlist[0]) || {};
  const list = [];
  for (const it of slist(cd0.songlist) || []) {
    const im = smap(it);
    if (!im) continue;
    const s = txSongFromInfo(im);
    if (s) list.push(s);
  }
  const info = {
    name: str(cd0.dissname), img: str(cd0.logo), desc: decodeName(str(cd0.desc)),
    author: str(cd0.nickname), play_count: formatPlayCount(cd0.visitnum),
  };
  return { list, page, limit: list.length, total: list.length, source: 'tx', info };
}

export async function txSonglistSearch(keyword, page, limit) {
  const d = await get('http://c.y.qq.com/soso/fcgi-bin/client_music_search_songlist?page_no=' + (page - 1) + '&num_per_page=' + limit + '&format=json&query=' + encodeURIComponent(keyword) + '&remoteplace=txt.yqq.playlist&inCharset=utf8&outCharset=utf-8', {
    'User-Agent': 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)', Referer: 'http://y.qq.com/portal/search.html',
  });
  const m = d.json;
  if (!m) throw new Error('tx songlist search invalid body');
  if (Math.trunc(tonum(m.code)) !== 0) throw new Error(`tx songlist search code=${Math.trunc(tonum(m.code))}`);
  const data = smap(m.data) || {};
  const list = [];
  for (const it of slist(data.list) || []) {
    const item = smap(it);
    if (!item) continue;
    const ct = tonum(sv(smap(item.creator), 'createtime'));
    let t = '';
    if (ct > 0) t = dateFormat(ct * 1000, 'Y-M-D');
    const o = {
      play_count: formatPlayCount(item.listennum),
      id: String(Math.trunc(tonum(item.dissid))),
      author: decodeName(str(sv(smap(item.creator), 'name'))),
      name: decodeName(str(item.dissname)),
    };
    if (t !== '') o.time = t;
    o.img = str(item.imgurl);
    o.total = String(Math.trunc(tonum(item.song_count)));
    const desc = decodeName(decodeName(str(item.introduction))).replaceAll('<br>', '\n');
    if (desc !== '') o.desc = desc;
    o.source = 'tx';
    list.push(o);
  }
  return { list, total: Math.trunc(tonum(data.sum)), page, limit, source: 'tx' };
}

function txB64(s) {
  if (s === '') return '';
  try {
    return base64Decode(s).toString('utf8');
  } catch {
    return s;
  }
}

export async function txLyric(songmid) {
  const d = await get('https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?songmid=' + songmid + '&g_tk=5381&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&platform=yqq', {
    Referer: 'https://y.qq.com/portal/player.html',
  });
  const raw = d.json;
  if (!raw) throw new Error('tx lyric invalid json');
  if (parseIntS(str(raw.code)) !== 0 || str(raw.lyric) === '') {
    throw new Error(`tx lyric code=${str(raw.code)}`);
  }
  const lyric = decodeName(txB64(str(raw.lyric)));
  const tlyric = decodeName(txB64(str(raw.trans)));
  return { lyric, tlyric };
}

export async function txMusicURL(songmid, quality) {
  
  const guid = String((Date.now() * 1000) % 1000000000);
  const vkey = await txGetVKey(guid);
  let prefix = 'C400';
  let suffix = '.m4a';
  switch (quality) {
    case '128k':
      prefix = 'M500';
      suffix = '.mp3';
      break;
    case 'flac':
    case 'flac24bit':
      prefix = 'F000';
      suffix = '.flac';
      break;
  }
  const u = `http://dl.stream.qqmusic.qq.com/${prefix}${songmid}${suffix}?vkey=${vkey}&guid=${guid}&uin=0&fromtag=66`;
  return [{ url: u, type: quality, from: 'original', sourceName: 'QQ音乐' }];
}

async function txGetVKey(guid) {
  const u = 'https://u.y.qq.com/cgi-bin/musicu.fcg';
  const payload = {
    comm: { ct: '19', cv: '18090031', v: '18090031', tmeAppID: 'qqmusic', g_tk: '5381', authst: '' },
    req: {
      module: 'QQMusicPicServer', method: 'GetPlayInfoData',
      param: { guid, songmid: [], songtype: [], songid: [], filename: [], songfiles: [], context: {} },
    },
  };
  const payloadJSON = txMustJSON(payload).toString('utf8');
  const d = await postRaw(u, Buffer.from('data=' + encodeURIComponent(payloadJSON), 'utf8'), 'application/x-www-form-urlencoded', {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
    Referer: 'https://y.qq.com/',
  });
  const raw = d.json;
  if (!raw) throw new Error('tx vkey invalid json');
  if (parseIntS(str(raw.code)) !== 0) throw new Error(`tx vkey code=${str(raw.code)}`);
  const vkey = str(sv(sv(smap(raw.req), 'data'), 'vkey'));
  if (vkey === '') throw new Error('tx empty vkey');
  return vkey;
}

export async function txHotSearch() {
  const body = {
    comm: {
      ct: '19', cv: '1803', guid: '0', patch: '118',
      psrf_access_token_expiresAt: 0, psrf_qqaccess_token: '', psrf_qqopenid: '',
      psrf_qqunionid: '', tmeAppID: 'qqmusic', tmeLoginType: 0, uin: '0', wid: '0',
    },
    hotkey: {
      method: 'GetHotkeyForQQMusicPC', module: 'tencent_musicsoso_hotkey.HotkeyService',
      param: { search_id: '', uin: 0 },
    },
  };
  const d = await postRaw('https://u.y.qq.com/cgi-bin/musicu.fcg', txMustJSON(body), 'application/json', {
    Referer: 'https://y.qq.com/portal/player.html',
  });
  if (!d.json) throw new Error('该音乐源暂未内置 Go 实现');
  const hotkey = smap(d.json.hotkey) || {};
  const data = smap(hotkey.data) || {};
  const vec = slist(data.vec_hotkey) || [];
  const list = [];
  for (const w of vec) {
    const wm = smap(w);
    if (wm) list.push({ word: str(wm.query) });
  }
  return list;
}

export async function txTipSearch(keyword) {
  const d = await get('https://c.y.qq.com/splcloud/fcgi-bin/smartbox_new.fcg?is_xml=0&format=json&key=' + encodeURIComponent(keyword) + '&loginUin=0&hostUin=0&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq&needNewCode=0', {
    Referer: 'https://y.qq.com/portal/player.html',
  });
  const raw = d.json;
  if (!raw) throw new Error('tx tip search invalid json');
  if (parseIntS(str(raw.code)) !== 0) throw new Error(`tx tip search code=${str(raw.code)}`);
  const itemlist = slist(sv(sv(smap(raw.data), 'song'), 'itemlist')) || [];
  const list = [];
  for (const it of itemlist) {
    const im = smap(it);
    if (!im) continue;
    list.push(str(im.name) + ' - ' + str(im.singer));
  }
  return list;
}

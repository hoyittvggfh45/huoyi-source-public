
import { get } from '../http.js';
import {
  newSong, smap, slist, str, tonum, num, parseIntS, parseFloatS, formatPlayTime,
  decodeName, formatPlayCount, formatSinger, reverseQuality, firstNonEmpty, goNumStr,
} from '../common.js';
import { aesECBEncrypt, aesECBDecrypt, md5Upper, base64Std, base64Decode, zlibInflate } from '../crypto.js';
import { gb18030ToUTF8 } from '../gb.js';

const kwMinfoRe = /level:(\w+),bitrate:(\d+),format:(\w+),size:([\w.]+)/;

export function kwParseMinfo(nMinfo) {
  const types = [];
  const tm = {};
  for (const part of String(nMinfo || '').split(';')) {
    const m = kwMinfoRe.exec(part);
    if (!m) continue;
    const bitrate = m[2];
    const size = m[4].toUpperCase();
    switch (bitrate) {
      case '4000':
        types.push({ type: 'flac24bit', size });
        tm.flac24bit = { size };
        break;
      case '2000':
        types.push({ type: 'flac', size });
        tm.flac = { size };
        break;
      case '320':
        types.push({ type: '320k', size });
        tm['320k'] = { size };
        break;
      case '128':
        types.push({ type: '128k', size });
        tm['128k'] = { size };
        break;
    }
  }
  reverseQuality(types);
  return { types, tm };
}

export async function kwSearch(keyword, page, limit) {
  const u = `http://search.kuwo.cn/r.s?client=kt&all=${encodeURIComponent(keyword)}&pn=${page - 1}&rn=${limit}&uid=794762570&ver=kwplayer_ar_9.2.2.1&vipver=1&show_copyright_off=1&newver=1&ft=music&cluster=0&strategy=2012&encoding=utf8&rformat=json&vermerge=1&mobi=1&issubtitle=1`;
  const d = await get(u);
  const raw = d.json;
  if (!raw) throw new Error('kw search invalid json');
  const abs = slist(raw.abslist) || [];
  if (abs.length === 0) {
    return { list: [], allPage: 0, total: parseIntS(str(raw.TOTAL)), limit, source: 'kw' };
  }
  const list = [];
  for (const it of abs) {
    const item = smap(it);
    if (!item) continue;
    const sid = str(item.MUSICRID).replace('MUSIC_', '');
    const { types, tm } = kwParseMinfo(str(item.N_MINFO));
    const s = newSong();
    s.name = str(item.SONGNAME);
    s.singer = formatSinger(str(item.ARTIST));
    s.albumName = str(item.ALBUM);
    s.albumId = str(item.ALBUMID);
    s.songmid = sid;
    s.source = 'kw';
    s.interval = formatPlayTime(parseFloatS(str(item.DURATION)));
    if (str(item.prob_albumpic) !== '') {
      s.img = str(item.prob_albumpic);
    } else if (str(item.web_albumpic_short) !== '') {
      s.img = 'https://img4.kuwo.cn/star/albumcover/500' + str(item.web_albumpic_short);
    }
    s.types = types;
    s._types = tm;
    list.push(s);
  }
  const total = parseIntS(str(raw.TOTAL));
  let allPage = Math.floor(total / limit);
  if (total % limit !== 0) allPage++;
  return { list, allPage, total, limit, source: 'kw' };
}

export async function kwBoards() {
  const d = await get('http://qukudata.kuwo.cn/q.k?op=query&cont=tree&node=2&pn=0&rn=1000&fmt=json&level=2');
  const raw = d.json;
  if (!raw) throw new Error('kw boards invalid json');
  const child = slist(raw.child) || [];
  const list = [];
  for (const bi of child) {
    const b = smap(bi);
    if (!b) continue;
    if (str(b.source) !== '1') continue;
    let img = str(b.pic);
    if (img === '') img = str(b.img);
    list.push({ id: 'kw__' + str(b.sourceid), name: str(b.name), bangid: str(b.sourceid), img });
  }
  return { list, source: 'kw' };
}

const kwWBDAESKey = Buffer.from([112, 87, 39, 61, 199, 250, 41, 191, 57, 68, 45, 114, 221, 94, 140, 228]);
const kwWBAppID = 'y67sprxhhpws';

function kwMustJSON(v) {
  try {
    return Buffer.from(JSON.stringify(v), 'utf8');
  } catch {
    return Buffer.from('{}', 'utf8');
  }
}

function kwWbdBuildParam(body) {
  const data = aesECBEncrypt(kwMustJSON(body), kwWBDAESKey);
  const encoded = base64Std(data);
  const timeMs = String(Date.now());
  const sign = md5Upper(kwWBAppID + encoded + timeMs);
  return 'data=' + encodeURIComponent(encoded) + '&time=' + timeMs + '&appId=' + kwWBAppID + '&sign=' + sign;
}

function kwWbdDecode(data) {
  const decoded = decodeURIComponent(data);
  const b = base64Decode(decoded);
  const plain = aesECBDecrypt(b, kwWBDAESKey);
  return JSON.parse(plain.toString('utf8'));
}

export async function kwBoardDetail(bangid, page) {
  const body = {
    uid: '', devId: '', sFrom: 'kuwo_sdk', user_type: 'AP',
    carSource: 'kwplayercar_ar_6.0.1.0_apk_keluze.apk', id: bangid, pn: page - 1, rn: 100,
  };
  const u = 'https://wbd.kuwo.cn/api/bd/bang/bang_info?' + kwWbdBuildParam(body);
  const d = await get(u);
  const m = kwWbdDecode(d.body.toString('utf8'));
  const data = smap(m && m.data);
  const musiclist = slist(data && data.musiclist);
  if (!musiclist) {
    return { total: 0, list: [], limit: 100, page, source: 'kw' };
  }
  const list = [];
  for (const mi of musiclist) {
    const item = smap(mi);
    if (!item) continue;
    const { types, tm } = kwParseMinfo(str(item.n_minfo));
    const s = newSong();
    s.name = decodeName(str(item.name));
    s.singer = formatSinger(decodeName(str(item.artist)));
    s.albumName = decodeName(str(item.album));
    s.albumId = str(item.albumId);
    s.songmid = item.id;
    s.source = 'kw';
    s.interval = formatPlayTime(parseFloatS(str(item.duration)));
    s.img = str(item.pic);
    s.types = types;
    s._types = tm;
    list.push(s);
  }
  return { total: parseIntS(str(data.total)), list, limit: 100, page, source: 'kw' };
}

export async function kwSonglist(sortId, tagId, page) {
  let u;
  if (tagId === '') {
    let order = sortId;
    if (order === '') order = 'hot';
    u = `http://wapi.kuwo.cn/api/pc/classify/playlist/getRcmPlayList?loginUid=0&loginSid=0&appUid=76039576&pn=${page}&rn=36&order=${order}`;
  } else {
    const id = tagId.split('-')[0];
    u = `http://wapi.kuwo.cn/api/pc/classify/playlist/getTagPlayList?loginUid=0&loginSid=0&appUid=76039576&pn=${page}&id=${id}&rn=36`;
  }
  const d = await get(u);
  const raw = d.json;
  if (!raw) throw new Error('kw songlist invalid json');
  if (parseIntS(str(raw.code)) !== 200) throw new Error(`kw songlist code=${str(raw.code)}`);
  const data = smap(raw.data) || {};
  const items = slist(data.data) || [];
  const list = [];
  for (const ii of items) {
    const item = smap(ii);
    if (!item) continue;
    let playCount = '';
    if (typeof item.listencnt === 'number') {
      playCount = formatPlayCount(item.listencnt);
    }
    
    const o = { play_count: playCount, id: 'digest-' + str(item.digest) + '__' + str(item.id), author: str(item.uname), name: str(item.name) };
    if (str(item.time) !== '') o.time = str(item.time);
    if (str(item.total) !== '') o.total = str(item.total);
    o.img = str(item.img);
    const gradeStr = str(typeof item.favorcnt === 'number' ? goNumStr(item.favorcnt / 10) : item.favorcnt);
    if (gradeStr !== '') o.grade = gradeStr;
    if (str(item.desc) !== '') o.desc = str(item.desc);
    o.source = 'kw';
    list.push(o);
  }
  return { list, total: Math.trunc(num(data.total)), page: Math.trunc(num(data.pn)), limit: Math.trunc(num(data.rn)), source: 'kw' };
}

function kwFmtNum(v) {
  if (typeof v === 'number') return formatPlayCount(v / 10);
  return str(v);
}

export async function kwSonglistDetail(id, page) {
  if (id.startsWith('digest-')) {
    const parts = id.split('__');
    if (parts.length === 2) {
      const digest = parts[0].replace('digest-', '');
      id = parts[1];
      if (digest === '13') {
        return kwAlbumDetail(id, page);
      }
      if (digest === '5') {
        try {
          const d = await get(`http://qukudata.kuwo.cn/q.k?op=query&cont=ninfo&node=${id}&pn=0&rn=1&fmt=json&src=mbox&level=2`);
          const raw = d.json;
          const child = raw && slist(raw.child);
          if (child && child.length > 0) {
            const c = smap(child[0]);
            if (c && str(c.sourceid) !== '') id = str(c.sourceid);
          }
        } catch {
          
        }
      }
    }
  } else if (/[?&:/]/.test(id)) {
    const m = /\/playlist(?:_detail)?\/(\d+)/.exec(id);
    if (m) id = m[1];
  }
  const u = `http://nplserver.kuwo.cn/pl.svc?op=getlistinfo&pid=${id}&pn=${page - 1}&rn=1000&encode=utf8&keyset=pl2012&identity=kuwo&pcmp4=1&vipver=MUSIC_9.0.5.0_W1&newver=1`;
  const d = await get(u);
  const raw = d.json;
  if (!raw) throw new Error('kw songlist detail invalid json');
  if (str(raw.result) !== 'ok') throw new Error(`kw songlist detail result=${str(raw.result)}`);
  const list = [];
  for (const it of slist(raw.musiclist) || []) {
    const item = smap(it);
    if (!item) continue;
    const { types, tm } = kwParseMinfo(str(item.N_MINFO));
    let img = firstNonEmpty(str(item.pic), str(item.albumpic), str(item.prob_albumpic));
    if (img === '' && str(item.web_albumpic_short) !== '') {
      img = 'https://img4.kuwo.cn/star/albumcover/500' + str(item.web_albumpic_short);
    }
    const s = newSong();
    s.name = decodeName(str(item.name));
    s.singer = formatSinger(decodeName(str(item.artist)));
    s.albumName = decodeName(str(item.album));
    s.albumId = str(item.albumid);
    s.songmid = item.id;
    s.source = 'kw';
    s.interval = formatPlayTime(tonum(item.duration));
    s.img = img;
    s.types = types;
    s._types = tm;
    list.push(s);
  }
  return {
    list, page, limit: Math.trunc(tonum(raw.rn)), total: Math.trunc(tonum(raw.total)), source: 'kw',
    info: {
      name: str(raw.title), img: str(raw.pic), desc: str(raw.info),
      author: str(raw.uname), play_count: formatPlayCount(raw.playnum),
    },
  };
}

export async function kwAlbumDetail(id, page) {
  const u = `http://nplserver.kuwo.cn/pl.svc?op=getlistinfo&pid=${id}&pn=${page - 1}&rn=1000&encode=utf8&keyset=pl2012&identity=kuwo&pcmp4=1&vipver=MUSIC_9.0.5.0_W1&newver=1`;
  const d = await get(u);
  const raw = d.json;
  if (!raw) throw new Error('kw album invalid json');
  if (str(raw.result) !== 'ok') throw new Error(`kw album result=${str(raw.result)}`);
  const list = [];
  for (const ii of slist(raw.musiclist) || []) {
    const item = smap(ii);
    if (!item) continue;
    const { types, tm } = kwParseMinfo(str(item.N_MINFO));
    const s = newSong();
    s.name = decodeName(str(item.name));
    s.singer = formatSinger(decodeName(str(item.artist)));
    s.albumName = decodeName(str(item.album));
    s.songmid = item.id;
    s.source = 'kw';
    s.interval = formatPlayTime(parseFloatS(str(item.duration)));
    s.img = str(item.pic);
    s.types = types;
    s._types = tm;
    list.push(s);
  }
  return {
    list, page, limit: list.length, total: Math.trunc(num(raw.total)), source: 'kw',
    info: { name: str(raw.title), img: str(raw.pic), desc: str(raw.info), author: str(raw.uname), play_count: '' },
  };
}


export function kwObjStr2JSON(s) {
  let out = '';
  let inQuote = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === '\'') {
      const next = i + 1 < s.length ? s[i + 1] : '\0';
      const prev = i > 0 ? s[i - 1] : '\0';
      if (!inQuote && (prev === '{' || prev === ',' || prev === ':' || prev === '[')) {
        out += '"';
        inQuote = true;
      } else if (inQuote && (next === '}' || next === ',' || next === ':' || next === ']')) {
        out += '"';
        inQuote = false;
      } else if (inQuote) {
        out += '\'';
      } else {
        out += '\'';
      }
    } else if (c === '\\' && inQuote && i + 1 < s.length && s[i + 1] === '\'') {
      out += "\\'";
      i++;
    } else {
      out += c;
    }
  }
  return out;
}

const kwLyricKey = Buffer.from('yeelion', 'ascii');

function kwXorBytes(data) {
  const out = Buffer.alloc(data.length);
  for (let i = 0; i < data.length; i++) {
    out[i] = data[i] ^ kwLyricKey[i % kwLyricKey.length];
  }
  return out;
}

export async function kwLyric(songmid) {
  const params = 'user=12345,web,web,web&requester=localhost&req=1&rid=MUSIC_' + songmid + '&lrcx=1';
  const enc = kwXorBytes(Buffer.from(params, 'utf8'));
  const u = 'http://newlyric.kuwo.cn/newlyric.lrc?' + base64Std(enc);
  const d = await get(u);
  const body = d.body;
  const idx = body.indexOf(Buffer.from('\r\n\r\n'));
  if (idx < 0 || !body.slice(0, 10).toString('latin1').startsWith('tp=content')) {
    return { lyric: '暂无歌词' };
  }
  const compressed = body.slice(idx + 4);
  const inflated = zlibInflate(compressed);
  const raw = inflated.toString('latin1');
  if (raw.includes('<')) throw new Error('invalid lyric payload');
  const b64 = raw.trim();
  const b = base64Decode(b64);
  const xored = kwXorBytes(b);
  const lrcText = gb18030ToUTF8(xored);
  const lrcInfo = kwParseLrc(lrcText);
  return { lyric: lrcInfo.lyric, tlyric: lrcInfo.tlyric };
}

export function kwParseLrc(lrc) {
  const lines = lrc.split('\n');
  const tags = [];
  const lrcArr = [];
  const timeRe = /^\[([\d:.]+)\]/;
  const tagRe = /^\[(ver|ti|ar|al|offset|by|kuwo):/;
  const seen = {};
  for (let line of lines) {
    line = line.replace(/\r$/, '').trim();
    const m = timeRe.exec(line);
    if (m) {
      const text = line.replace(timeRe, '');
      lrcArr.push({ time: m[1], text: text.trim() });
    } else if (tagRe.test(line)) {
      tags.push(line);
    }
  }
  const mainLrc = [];
  const transLrc = [];
  for (const item of lrcArr) {
    if (seen[item.time]) {
      transLrc.push('[' + item.time + ']' + item.text);
    } else {
      seen[item.time] = true;
      mainLrc.push('[' + item.time + ']' + item.text);
    }
  }
  const header = tags.join('\n');
  const lyric = header !== ''
    ? header + '\n' + mainLrc.join('\n')
    : mainLrc.join('\n');
  return { lyric, tlyric: transLrc.join('\n') };
}

export async function kwMusicURL(songmid, quality) {
  const u = 'http://antiserver.kuwo.cn/anti.s?type=convert_url3&rid=MUSIC_' + songmid + '&format=mp3&response=url';
  const d = await get(u, { 'User-Agent': 'okhttp/3.9.1' });
  const body = d.body.toString('utf8').trim();
  if (!body.startsWith('http')) throw new Error('kw no playable url');
  return [{ url: body, type: quality, from: 'original', sourceName: '酷我' }];
}

export async function kwHotSearch() {
  const d = await get('http://hotword.kuwo.cn/hotword.s?prod=kwplayer_ar_9.3.0.1&corp=kuwo&newver=2&vipver=9.3.0.1&source=kwplayer_ar_9.3.0.1_40.apk&p2p=1&notrace=0&uid=0&plat=kwplayer_ar&rformat=json&encoding=utf8&tabid=1', {
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9;)',
  });
  const raw = d.json;
  if (!raw) throw new Error('kw hotsearch invalid json');
  if (str(raw.status) !== 'ok') throw new Error(`kw hotsearch status=${str(raw.status)}`);
  const list = [];
  for (const hi of slist(raw.tagvalue) || []) {
    const h = smap(hi);
    if (!h) continue;
    list.push({ word: str(h.key) });
  }
  return list;
}

export async function kwTipSearch(keyword) {
  const d = await get('https://tips.kuwo.cn/t.s?corp=kuwo&newver=3&p2p=1&notrace=0&c=mbox&w=' + encodeURIComponent(keyword) + '&encoding=utf8&rformat=json');
  const raw = d.json;
  if (!raw) throw new Error('kw tipsearch invalid json');
  const list = [];
  for (const ai of slist(raw.WORDITEMS) || []) {
    const a = smap(ai);
    if (!a) continue;
    list.push(str(a.RELWORD));
  }
  return list;
}


import { get, postJSON, desktopUA } from '../http.js';
import {
  newSong, smap, slist, sv, str, tonum, num, parseIntS, parseFloatS, formatPlayTime, sizeFormate,
  decodeName, dateFormat, firstNonEmpty, nowMillis,
} from '../common.js';


function kgPlaylistItem(pc, id, author, name, time, img, total, grade, desc) {
  const o = { play_count: pc, id, author, name, time };
  if (img !== undefined && img !== '') o.img = img;
  if (total !== undefined && total !== null) o.total = total;
  if (grade !== undefined && grade !== null) o.grade = grade;
  o.desc = desc;
  o.source = 'kg';
  return o;
}

function kgDate(v) {
  if (typeof v === 'string') {
    const s = v.trim();
    if (s.length >= 10) return s.slice(0, 10);
    return 'NaN-NaN-NaN';
  }
  const ts = tonum(v);
  if (ts > 0) return dateFormat(ts * 1000, 'Y-M-D');
  return 'NaN-NaN-NaN';
}

function kgPlayCount(v) {
  const n = tonum(v);
  if (n > 100000000) return goNumStr(Math.trunc(n / 10000000) / 10) + '亿';
  if (n > 10000) return goNumStr(Math.trunc(n / 1000) / 10) + '万';
  if (v === null || v === undefined) return 0;
  return n;
}


function goNumStr(f) {
  return String(f);
}

function kgSingers(arr) {
  const names = [];
  for (const si of slist(arr) || []) {
    const s = smap(si);
    if (s && str(s.name) !== '') names.push(str(s.name));
  }
  return names.join('/');
}

export async function kgSearch(keyword, page, limit) {
  const u = `https://songsearch.kugou.com/song_search_v2?keyword=${encodeURIComponent(keyword)}&page=${page}&pagesize=${limit}&userid=0&clientver=&platform=WebFilter&filter=2&iscorrection=1&privilege_filter=0&area_code=1`;
  const d = await get(u);
  const raw = d.json;
  if (!raw) throw new Error('kg search invalid json');
  if (parseIntS(str(raw.error_code)) !== 0) throw new Error(`kg search error_code=${str(raw.error_code)}`);
  const data = smap(raw.data) || {};
  const lists = slist(data.lists) || [];
  const list = [];
  for (const li of lists) {
    const item = smap(li);
    if (!item) continue;
    const types = [];
    const tm = {};
    const addType = (cond, qtype_, hash, sizeVal) => {
      if (!cond || hash === '') return;
      const ss = sizeFormate(Math.trunc(num(sizeVal)));
      types.push({ type: qtype_, size: ss, hash });
      tm[qtype_] = { size: ss, hash };
    };
    const tp = smap(item.trans_param) || {};
    addType(num(item.FileSize) !== 0, '128k', str(item.FileHash), item.FileSize);
    addType(num(item.HQFileSize) !== 0, '320k', str(item.HQFileHash), item.HQFileSize);
    addType(num(item.SQFileSize) !== 0, 'flac', str(item.SQFileHash), item.SQFileSize);
    addType(num(item.ResFileSize) !== 0, 'flac24bit', str(item.ResFileHash), item.ResFileSize);
    let img = str(item.Image);
    if (img === '') img = str(tp.union_cover);
    const s = newSong();
    s.singer = decodeName(kgSingers(item.Singers));
    s.name = decodeName(str(item.SongName));
    s.albumName = decodeName(str(item.AlbumName));
    s.albumId = str(item.AlbumID);
    s.songmid = num(item.Audioid);
    s.source = 'kg';
    s.interval = formatPlayTime(num(item.Duration));
    s._interval = num(item.Duration);
    s.img = img;
    s.hash = str(item.FileHash);
    s.types = types;
    s._types = tm;
    list.push(s);
  }
  const total = Math.trunc(num(data.total));
  let allPage = Math.floor(total / limit);
  if (total % limit !== 0) allPage++;
  return { list, allPage, total, limit, source: 'kg' };
}

export async function kgBoards() {
  const d = await get('http://mobilecdnbj.kugou.com/api/v5/rank/list?version=9108&plat=0&showtype=2&parentid=0&apiver=6&area_code=1&withsong=1');
  const raw = d.json;
  if (!raw) throw new Error('kg rank list invalid json');
  if (Math.trunc(tonum(raw.errcode)) !== 0) throw new Error(`kg rank list errcode=${str(raw.errcode)}`);
  const info = slist(sv(smap(raw.data), 'info')) || [];
  const list = [];
  for (const bi of info) {
    const b = smap(bi);
    if (!b) continue;
    if (Math.trunc(tonum(b.isvol)) !== 1) continue;
    const rankID = str(b.rankid);
    list.push({
      id: 'kg__' + rankID, name: str(b.rankname), bangid: rankID,
      img: str(b.imgurl).replaceAll('{size}', '400'),
    });
  }
  return { list, source: 'kg' };
}

export async function kgBoardDetail(bangid, page) {
  const d = await get(`http://mobilecdnbj.kugou.com/api/v3/rank/song?version=9108&ranktype=1&plat=0&pagesize=100&area_code=1&page=${page}&rankid=${encodeURIComponent(bangid)}&with_res_tag=0&show_portrait_mv=1`);
  const raw = d.json;
  if (!raw) throw new Error('kg rank song invalid json');
  if (Math.trunc(tonum(raw.errcode)) !== 0) {
    return { total: 0, list: [], limit: 100, page, source: 'kg' };
  }
  const data = smap(raw.data) || {};
  const list = [];
  for (const it of slist(data.info) || []) {
    const s = kgSongFromRank(smap(it));
    if (s) list.push(s);
  }
  return { total: Math.trunc(tonum(data.total)), list, limit: 100, page, source: 'kg' };
}

function kgSongFromRank(item) {
  if (!item) return null;
  const { types, tm } = kgRankTypes(item);
  const authors = [];
  for (const a of slist(item.authors) || []) {
    authors.push(sv(smap(a), 'author_name'));
  }
  let img = str(item.album_sizable_cover);
  if (img === '') img = str(sv(smap(item.trans_param), 'union_cover'));
  const s = newSong();
  s.singer = kgSingerList(authors);
  s.name = decodeName(str(item.songname));
  s.albumName = decodeName(str(item.remark));
  s.albumId = str(item.album_id);
  s.songmid = item.audio_id;
  s.source = 'kg';
  s.interval = formatPlayTime(tonum(item.duration));
  s.img = img.replaceAll('{size}', '400');
  s.hash = str(item.hash);
  s.types = types;
  s._types = tm;
  return s;
}

function kgSingerList(names) {
  const out = [];
  for (const n of names) {
    const v = str(n);
    if (v !== '') out.push(v);
  }
  return decodeName(out.join('、'));
}

function kgRankTypes(item) {
  const types = [];
  const tm = {};
  const add = (sizeKey, qtype_, hashKey) => {
    const size = tonum(item[sizeKey]);
    const hash = str(item[hashKey]);
    if (size === 0) return;
    const ss = sizeFormate(Math.trunc(size));
    types.push({ type: qtype_, size: ss, hash });
    tm[qtype_] = { size: ss, hash };
  };
  add('filesize', '128k', 'hash');
  add('320filesize', '320k', '320hash');
  add('sqfilesize', 'flac', 'sqhash');
  add('filesize_high', 'flac24bit', 'hash_high');
  return { types, tm };
}

export async function kgGetMusicInfos(hashs) {
  if (!hashs || hashs.length === 0) return [];
  const objs = hashs.map((h) => ({ hash: h }));
  const packets = [];
  for (let i = 0; i < objs.length; i += 100) {
    packets.push(objs.slice(i, i + 100));
  }
  const list = [];
  const seen = {};
  for (const batch of packets) {
    const payload = {
      data: batch, area_code: '1', show_privilege: 1, show_album_info: '1',
      is_publish: '', appid: 1005, clientver: 11451, mid: '1', dfid: '-',
      clienttime: nowMillis(), key: 'OIlwieks28dk2k092lksi2UIkp',
      fields: 'album_info,author_name,audio_info,ori_audio_name,base,songname,classification,img,album_img',
    };
    const d = await postJSON('http://gateway.kugou.com/v3/album_audio/audio', payload, {
      'KG-THash': '13a3164', 'KG-RC': '1', 'KG-Fake': '0', 'KG-RF': '00869891',
      'User-Agent': 'Android712-AndroidPhone-11451-376-0-FeeCacheUpdate-wifi',
      'x-router': 'kmr.service.kugou.com',
    });
    const raw = d.json;
    if (!raw) throw new Error('kg getMusicInfos invalid json');
    for (const gi of slist(raw.data) || []) {
      const items = slist(gi);
      if (!items || items.length === 0) continue;
      const item = smap(items[0]);
      if (!item) continue;
      const audio = smap(item.audio_info);
      if (!audio) continue;
      const audioID = str(audio.audio_id);
      if (audioID === '' || seen[audioID]) continue;
      seen[audioID] = true;
      const types = [];
      const tm = {};
      const addType = (sizeKey, qtype_, hashKey) => {
        if (str(audio[sizeKey]) === '0') return;
        const hashV = str(audio[hashKey]);
        const sizeV = parseFloatS(str(audio[sizeKey]));
        if (hashV === '' || sizeV === 0) return;
        const ss = sizeFormate(Math.trunc(sizeV));
        types.push({ type: qtype_, size: ss, hash: hashV });
        tm[qtype_] = { size: ss, hash: hashV };
      };
      addType('filesize', '128k', 'hash');
      addType('filesize_320', '320k', 'hash_320');
      addType('filesize_flac', 'flac', 'hash_flac');
      addType('filesize_high', 'flac24bit', 'hash_high');
      const albumInfo = smap(item.album_info);
      const s = newSong();
      s.singer = decodeName(str(item.author_name));
      s.name = decodeName(str(item.songname));
      s.source = 'kg';
      s.songmid = audio.audio_id;
      s.hash = str(audio.hash);
      s.interval = formatPlayTime(parseFloatS(str(audio.timelength)) / 1000);
      let img = '';
      if (albumInfo) {
        img = firstNonEmpty(str(item.img), str(albumInfo.sizable_cover),
          str(sv(smap(audio.trans_param), 'union_cover')), str(albumInfo.pic),
          str(albumInfo.img), str(albumInfo.s_img));
      }
      s.img = img.replace('{size}', '400');
      if (albumInfo) {
        s.albumName = decodeName(str(albumInfo.album_name));
        s.albumId = str(albumInfo.album_id);
      }
      s.types = types;
      s._types = tm;
      list.push(s);
    }
  }
  return list;
}

export async function kgSonglist(sortId, tagId, hasTag, page) {
  const d = await get(`http://www2.kugou.kugou.com/yueku/v9/special/getSpecial?is_ajax=1&cdn=cdn&t=${encodeURIComponent(sortId)}&c=${encodeURIComponent(tagId)}&p=${page}`);
  const raw = d.json;
  if (!raw) throw new Error('kg special invalid json');
  if (Math.trunc(tonum(raw.status)) !== 1) throw new Error(`kg special status=${str(raw.status)}`);
  const list = [];
  for (const pi of slist(raw.special_db) || []) {
    const p = smap(pi);
    if (!p) continue;
    let pc;
    if (p.total_play_count !== undefined && tonum(p.total_play_count) !== 0) {
      pc = tonum(p.total_play_count);
    } else {
      pc = kgPlayCount(p.play_count);
    }
    let t = kgDate(p.publish_time);
    if (t === '') t = kgDate(p.publishtime);
    let total;
    if (p.songcount !== undefined && p.songcount !== null) total = tonum(p.songcount);
    let grade;
    if (p.grade !== undefined && p.grade !== null) grade = tonum(p.grade);
    list.push(kgPlaylistItem(
      pc,
      'id_' + str(p.specialid),
      str(p.nickname),
      str(p.specialname),
      t,
      firstNonEmpty(str(p.img), str(p.imgurl)),
      total,
      grade,
      str(p.intro),
    ));
  }
  
  if (!hasTag) return { list };
  let total = 0;  let limit = 30;
  let infoPage = page;
  let infoURL = 'http://www2.kugou.kugou.com/yueku/v9/special/getSpecial?is_smarty=1&';
  if (tagId !== '') {
    infoURL = 'http://www2.kugou.kugou.com/yueku/v9/special/getSpecial?is_smarty=1&cdn=cdn&t=5&c=' + encodeURIComponent(tagId);
  }
  try {
    const d2 = await get(infoURL);
    const r2 = d2.json;
    if (r2) {
      const params = smap(sv(smap(r2.data), 'params'));
      if (params) {
        total = Math.trunc(tonum(params.total));
        limit = Math.trunc(tonum(params.pagesize));
        const p = Math.trunc(tonum(params.p));
        if (p > 0) infoPage = p;
      }
    }
  } catch {
    
  }
  if (limit === 0) limit = 30;
  return { limit, list, page: infoPage, source: 'kg', total };
}

export async function kgSonglistDetail(id, page) {
  if (id.startsWith('id_')) {
    id = id.slice(3);
  } else if (/[?&:/]/.test(id)) {
    const m = /\/(\d+)\.html/.exec(id);
    if (m) id = m[1];
  }
  const d = await get(`http://www2.kugou.kugou.com/yueku/v9/special/single/${encodeURIComponent(id)}-5-9999.html`);
  const html = d.body.toString('utf8');
  const m = /global\.data = (\[.+\]);/.exec(html);
  if (!m) throw new Error('kg special html no data');
  let raws;
  try {
    raws = JSON.parse(m[1]);
  } catch (e) {
    throw new Error('kg special html parse: ' + e.message);
  }
  if (!Array.isArray(raws)) throw new Error('kg special html parse: not array');
  const hashes = [];
  const seen = {};
  for (const r of raws) {
    const rm = smap(r);
    if (!rm) continue;
    const h = str(rm.hash);
    if (h === '' || seen[h]) continue;
    seen[h] = true;
    hashes.push(h);
  }
  const songs = await kgGetMusicInfos(hashes);
  const info = { name: '', img: '', desc: kgParseHtmlDesc(html), author: '', play_count: '' };
  const mi = /global = \{[\s\S]+?name: "(.+)"[\s\S]+?pic: "(.+)"[\s\S]+?\};/.exec(html);
  if (mi) {
    info.name = mi[1];
    info.img = mi[2];
  }
  return { list: songs, page: 1, limit: 10000, total: songs.length, source: 'kg', info };
}

function kgParseHtmlDesc(html) {
  const prefix = '<div class="pc_specail_text pc_singer_tab_content" id="specailIntroduceWrap">';
  const i = html.indexOf(prefix);
  if (i < 0) return '';
  const after = html.slice(i + prefix.length);
  const j = after.indexOf('</div>');
  if (j < 0) return '';
  return decodeName(after.slice(0, j));
}

export async function kgSonglistSearch(keyword, page, limit) {
  const rawURL = `http://msearchretry.kugou.com/api/v3/search/special?keyword=${encodeURIComponent(keyword)}&page=${page}&pagesize=${limit}&showtype=10&filter=0&version=7910&sver=2`;
  const d = await get(rawURL);
  const raw = d.json;
  if (!raw) throw new Error('kg special search invalid json');
  if (parseIntS(str(raw.errcode)) !== 0) throw new Error(`kg special search errcode=${str(raw.errcode)}`);
  const data = smap(raw.data) || {};
  const list = [];
  for (const pi of slist(data.info) || []) {
    const p = smap(pi);
    if (!p) continue;
    let total;
    if (p.songcount !== undefined && p.songcount !== null) total = tonum(p.songcount);
    let grade;
    if (p.grade !== undefined && p.grade !== null) grade = p.grade;
    list.push(kgPlaylistItem(
      kgPlayCount(p.playcount),
      'id_' + str(p.specialid),
      str(p.nickname),
      str(p.specialname),
      str(p.publishtime).length >= 10 ? str(p.publishtime).slice(0, 10) : '',
      str(p.imgurl),
      total,
      grade,
      str(p.intro),
    ));
  }
  
  return { limit, list, source: 'kg', total: Math.trunc(num(data.total)) };
}

export async function kgLyric(songmid) {
  const d = await get('http://m.kugou.com/app/i/krc.php?cmd=100&hash=' + songmid + '&timelength=99999999', { 'User-Agent': desktopUA });
  const body = d.body.toString('utf8').trim();
  if (body === '' || body.startsWith('<')) {
    return { lyric: '暂无歌词' };
  }
  return { lyric: body };
}

export async function kgMusicURL(songmid, quality) {
  const d = await get('http://m.kugou.com/app/i/getSongInfo.php?cmd=playInfo&hash=' + songmid + '&from=mkpc', { 'User-Agent': desktopUA });
  const raw = d.json;
  if (!raw) throw new Error('kg playInfo invalid json');
  if (Math.trunc(num(raw.status)) !== 1) throw new Error(`kg playInfo status=${str(raw.status)}`);
  let chosen = str(raw.url);
  switch (quality) {
    case '320k':
      if (str(raw.hqUrl) !== '') chosen = str(raw.hqUrl);
      break;
    case 'flac':
    case 'flac24bit':
      if (str(raw.sqUrl) !== '') chosen = str(raw.sqUrl);
      break;
  }
  if (chosen === '') throw new Error('kg no url');
  return [{ url: chosen, type: quality, from: 'original', sourceName: '酷狗' }];
}

export async function kgHotSearch() {
  const d = await get('http://gateway.kugou.com/api/v3/search/hot_tab?signature=ee44edb9d7155821412d220bcaf509dd&appid=1005&clientver=10026&plat=0', {
    dfid: '1ssiv93oVqMp27cirf2CvoF1',
    mid: '156798703528610303473757548878786007104',
    clienttime: '1584257267',
    'x-router': 'msearch.kugou.com',
    'user-agent': 'Android9-AndroidPhone-10020-130-0-searchrecommendprotocol-wifi',
    'kg-rc': '1',
  });
  const raw = d.json;
  if (!raw) throw new Error('kg hotsearch invalid json');
  if (Math.trunc(tonum(raw.errcode)) !== 0) throw new Error(`kg hotsearch errcode=${str(raw.errcode)}`);
  const list = [];
  for (const it of slist(sv(smap(raw.data), 'list')) || []) {
    const im = smap(it);
    if (!im) continue;
    for (const k of slist(im.keywords) || []) {
      const km = smap(k);
      if (!km) continue;
      list.push(decodeName(str(km.keyword)));
    }
  }
  return list;
}

export async function kgTipSearch(keyword) {
  const d = await get('https://searchtip.kugou.com/getSearchTip?MusicTipCount=10&keyword=' + encodeURIComponent(keyword), {
    Referer: 'https://www.kugou.com/',
  });
  const raw = d.json;
  if (!raw) throw new Error('kg tipsearch invalid json');
  const list = [];
  const data = slist(raw.data) || [];
  if (data.length > 0) {
    const first = smap(data[0]);
    for (const r of slist(first && first.RecordDatas) || []) {
      const rm = smap(r);
      if (!rm) continue;
      list.push(str(rm.HintInfo));
    }
  }
  return list;
}

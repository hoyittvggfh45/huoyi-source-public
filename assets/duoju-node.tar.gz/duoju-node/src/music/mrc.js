

export function pad2(n) {
  const s = String(n);
  return s.length < 2 ? '0' + s : s;
}

export function pad3(n) {
  let s = String(n);
  while (s.length < 3) s = '0' + s;
  return s;
}

const mrcDelta = 2654435769n;
const mrcKey = [
  27303562373562475n,
  18014862372307051n,
  22799692160172081n,
  34058940340699235n,
  30962724186095721n,
  27303523720101991n,
  27303523720101998n,
  31244139033526382n,
  28992395054481524n,
];
const M64 = 0xffffffffffffffffn;

const u64 = (x) => BigInt.asUintN(64, x);

export function mrcDecrypt(data) {
  if (data.length < 32) return data;
  const n = Math.floor(data.length / 16);
  const longs = new Array(n);
  for (let i = 0; i < n; i++) {
    const chunk = data.slice(i * 16, (i + 1) * 16);
    if (!/^[0-9a-fA-F]+$/.test(chunk)) return data;
    longs[i] = BigInt('0x' + chunk);
  }
  teaDecryptLongs(longs);
  const units = [];
  for (const l of longs) {
    for (let k = 0; k < 4; k++) {
      units.push(Number((l >> BigInt(16 * k)) & 0xffffn));
    }
  }
  let out = '';
  for (const u of units) out += String.fromCharCode(u);
  return out;
}

function teaDecryptLongs(data) {
  const n = data.length;
  if (n === 0) return;
  const nb = BigInt(n);
  let sum = u64(BigInt(6 + Math.floor(52 / n)) * mrcDelta);
  let v0 = data[0];
  while (sum !== 0n) {
    const y = 3n & (sum >> 2n);
    let i = n;
    for (;;) {
      i--;
      if (i === 0) break;
      const v1 = data[i - 1];
      const ki = Number((3n & BigInt(i)) ^ y);
      const f = u64(
        (u64(u64(v0 ^ sum) + u64(v1 ^ mrcKey[ki]))) ^
          u64(u64(u64(v1 >> 5n) ^ u64(v0 << 2n)) + u64(u64(v0 >> 3n) ^ u64(v1 << 4n)))
      );
      v0 = u64(data[i] - f);
      data[i] = v0;
    }
    const v1 = data[n - 1];
    const f = u64(
      u64(u64(mrcKey[Number(y)] ^ v1) + u64(v0 ^ sum)) ^
        u64(u64(u64(v1 >> 5n) ^ u64(v0 << 2n)) + u64(u64(v0 >> 3n) ^ u64(v1 << 4n)))
    );
    v0 = u64(data[0] - f);
    data[0] = v0;
    sum = u64(sum - mrcDelta);
  }
  void nb;
}

export function mgParseMrc(str) {
  str = String(str ?? '').replaceAll('\r', '');
  const lrcLines = [];
  const lxLines = [];
  for (const line of str.split('\n')) {
    if (line.length < 6) continue;
    const m = /^\s*\[(\d+),\d+\]/.exec(line);
    if (!m) continue;
    const startTime = parseInt(m[1], 10);
    const ms = startTime % 1000;
    const sec = Math.floor(startTime / 1000);
    const timeStr = pad2(Math.floor(sec / 60)) + ':' + pad2(sec % 60) + '.' + pad3(ms);

    const words = line.replace(/^\s*\[(\d+),\d+\]/, '');
    lrcLines.push('[' + timeStr + ']' + words.replace(/\(\d+,\d+\)/g, ''));

    const times = words.match(/\(\d+,\d+\)/g) || [];
    if (times.length === 0) continue;
    const tags = [];
    for (const t of times) {
      const w = /^\((\d+),(\d+)\)$/.exec(t);
      if (!w) continue;
      const wt = parseInt(w[1], 10);
      tags.push('<' + String(wt - startTime) + ',' + w[2] + '>');
    }
    const wordArr = words.split(/\(\d+,\d+\)/);
    let sb = '';
    for (let i = 0; i < tags.length; i++) {
      sb += tags[i];
      if (i < wordArr.length) sb += wordArr[i];
    }
    lxLines.push('[' + timeStr + ']' + sb);
  }
  return [lrcLines.join('\n'), lxLines.join('\n')];
}

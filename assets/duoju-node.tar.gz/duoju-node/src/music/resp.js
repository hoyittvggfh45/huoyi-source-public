

import fs from 'node:fs';

export function writeJSON(res, status, data) {
  res.status(status);
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  const payload = { code: 200 };
  if (data !== undefined && data !== null) payload.data = data;
  res.end(JSON.stringify(payload) + '\n');
}

export function writeErr(res, status, msg) {
  res.status(status);
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify({ code: status, error: msg }) + '\n');
}


export function lxWriteJSON(res, status, payload) {
  res.status(status);
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(payload) + '\n');
}

export function lxOK(res, data) {
  lxWriteJSON(res, 200, { code: 200, data });
}

export function lxFail(res, status, msg) {
  lxWriteJSON(res, status, { code: status, error: msg });
}


export function lxBadReq(res, msg) {
  lxWriteJSON(res, 400, { error: msg });
}



export function readBody(req) {
  if (req && req._musicRawBody !== undefined) {
    const raw = Buffer.isBuffer(req._musicRawBody) && req._musicRawBody.length > 0
      ? req._musicRawBody.toString('utf8') : '';
    if (!raw) return Promise.resolve({});
    try {
      const p = JSON.parse(raw);
      if (p && typeof p === 'object' && !Array.isArray(p)) return Promise.resolve(p);
    } catch {}
    return Promise.resolve({});
  }
  return new Promise((resolve) => {
    const chunks = [];
    let size = 0;
    let aborted = false;
    req.on('data', (c) => {
      if (aborted) return;
      size += c.length;
      if (size > 8 << 20) { aborted = true; resolve({}); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (aborted) return resolve({});
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      try {
        const p = JSON.parse(raw);
        if (p && typeof p === 'object' && !Array.isArray(p)) return resolve(p);
      } catch {}
      resolve({});
    });
    req.on('error', () => resolve({}));
  });
}

export function asString(m, key) {
  if (m && key in m && m[key] !== undefined && m[key] !== null) {
    if (typeof m[key] === 'string') return m[key];
    return sprint(m[key]).trim();
  }
  return '';
}

export function asBoolPtr(m, key) {
  if (!m || !(key in m) || m[key] === undefined || m[key] === null) return null;
  if (typeof m[key] === 'boolean') return m[key];
  return null;
}

export function asStringPtr(m, key) {
  if (!m || !(key in m) || m[key] === undefined || m[key] === null) return null;
  if (typeof m[key] === 'string') return m[key];
  return null;
}


export function sprint(v) {
  if (v === undefined || v === null) return '';
  if (typeof v === 'string') return v;
  if (typeof v === 'number') {
    if (!Number.isFinite(v)) return '';
    if (Number.isInteger(v)) return String(v);
    return String(v);
  }
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  try { return JSON.stringify(v); } catch { return ''; }
}


export function readFileOrNull(p) {
  try {
    return fs.readFileSync(p);
  } catch {
    return null;
  }
}

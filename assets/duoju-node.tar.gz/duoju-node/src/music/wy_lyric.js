
import { pad2, pad3 } from './mrc.js';

export function wyMsFormat(timeMs) {
  if (timeMs < 0) return '';
  const ms = timeMs % 1000;
  const t = Math.floor(timeMs / 1000);
  return '[' + pad2(Math.floor(t / 60)) + ':' + pad2(t % 60) + '.' + ms + ']';
}


export function wyParseHeaderInfo(str) {
  str = String(str ?? '').trim().replaceAll('\r', '');
  if (str === '') return null;
  const out = [];
  for (const line of str.split('\n')) {
    if (!/^\{"/.test(line)) {
      out.push(line);
      continue;
    }
    let info = null;
    try { info = JSON.parse(line); } catch {}
    if (!info || typeof info !== 'object') {
      out.push('');
      continue;
    }
    const tag = wyMsFormat(Number(info.t) || 0);
    if (tag === '') {
      out.push('');
      continue;
    }
    let sb = tag;
    for (const c of info.c || []) sb += (c && c.tx) || '';
    out.push(sb);
  }
  return out;
}

export function wyParseLyric(lines) {
  const lxLines = [];
  const lrcLines = [];
  for (const raw of lines) {
    const line = String(raw ?? '').trim();
    const m = /^\[(\d+),\d+\]/.exec(line);
    if (!m) {
      if (line.startsWith('[offset')) {
        lxLines.push(line);
        lrcLines.push(line);
      }
      continue;
    }
    const startMs = parseInt(m[1], 10);
    const startTimeStr = wyMsFormat(startMs);
    if (startTimeStr === '') continue;
    const words = line.replace(/^\[(\d+),\d+\]/, '');
    lrcLines.push(startTimeStr + words.replace(/\(\d+,\d+,\d+\)/g, ''));

    const times = words.match(/\(\d+,\d+,\d+\)/g) || [];
    if (times.length === 0) continue;
    const tags = [];
    for (const t of times) {
      const w = /^\((\d+),(\d+),\d+\)$/.exec(t);
      if (!w) continue;
      let d = parseInt(w[1], 10) - startMs;
      if (d < 0) d = 0;
      tags.push('<' + String(d) + ',' + w[2] + '>');
    }
    let wordArr = words.split(/\(\d+,\d+,\d+\)/);
    if (wordArr.length > 0) wordArr = wordArr.slice(1);
    let sb = '';
    for (let i = 0; i < tags.length; i++) {
      sb += tags[i];
      if (i < wordArr.length) sb += wordArr[i];
    }
    lxLines.push(startTimeStr + sb);
  }
  return [lrcLines.join('\n'), lxLines.join('\n')];
}

export function wyGetIntv(interval) {
  interval = String(interval ?? '');
  if (interval === '') return 0;
  if (!interval.includes('.')) interval += '.0';
  let arr = interval.split(/[:.]/).map((x) => parseInt(x, 10) || 0);
  while (arr.length < 3) arr = [0, ...arr];
  const m = arr[0], s = arr[1], ms = arr[2];
  return m * 3600000 + s * 1000 + ms;
}

export function wyFixTimeTag(lrc, targetlrc) {
  const lrcLines = lrc.split('\n');
  const targetLines = targetlrc.split('\n');
  let temp = [];
  const newLrc = [];
  for (const line of targetLines) {
    const m = /^\[([\d:.]+)\]/.exec(line);
    if (!m) continue;
    const words = line.replace(/^\[([\d:.]+)\]/, '');
    if (words.trim() === '') continue;
    const t1 = wyGetIntv(m[1]);
    while (lrcLines.length > 0) {
      const lrcLine = lrcLines.shift();
      const lm = /^\[([\d:.]+)\]/.exec(lrcLine);
      if (!lm) continue;
      const t2 = wyGetIntv(lm[1]);
      const diff = t1 - t2;
      if (diff < 100 && diff > -100) {
        const out = line.replace(/^\[([\d:.]+)\]/, lm[0]).trim();
        if (out === '') continue;
        newLrc.push(out);
        break;
      }
      temp.push(lrcLine);
    }
    lrcLines.unshift(...temp);
    temp = [];
  }
  return newLrc.join('\n');
}

export function wyLyricParse(ylrc, ytlrc, yrlrc, lrc, tlrc, rlrc) {
  const info = {};
  if (ylrc !== '') {
    const lines = wyParseHeaderInfo(ylrc);
    if (lines !== null) {
      const [lyric, lxlyric] = wyParseLyric(lines);
      if (ytlrc !== '') {
        const tl = wyParseHeaderInfo(ytlrc);
        if (tl !== null) info.tlyric = wyFixTimeTag(lyric, tl.join('\n'));
      }
      if (yrlrc !== '') {
        const rl = wyParseHeaderInfo(yrlrc);
        if (rl !== null) info.rlyric = wyFixTimeTag(lyric, rl.join('\n'));
      }
      const headers = [];
      for (const l of lines) {
        if (/^\[[\d:.]+\]/.test(l)) headers.push(l);
      }
      info.lyric = headers.join('\n') + '\n' + lyric;
      info.lxlyric = lxlyric;
      return info;
    }
  }
  if (lrc !== '') {
    const lines = wyParseHeaderInfo(lrc);
    if (lines !== null) info.lyric = lines.join('\n');
  }
  if (tlrc !== '') {
    const lines = wyParseHeaderInfo(tlrc);
    if (lines !== null) info.tlyric = lines.join('\n');
  }
  if (rlrc !== '') {
    const lines = wyParseHeaderInfo(rlrc);
    if (lines !== null) info.rlyric = lines.join('\n');
  }
  return info;
}

export function wyFixTimeLabel(lrc, tlrc, romalrc) {
  if (lrc !== '') {
    const newLrc = lrc.replace(/\[(\d{2}:\d{2}):(\d{2})]/g, '[$1.$2]');
    let newTlrc = tlrc;
    if (tlrc !== '') {
      newTlrc = tlrc.replace(/\[(\d{2}:\d{2}):(\d{2})]/g, '[$1.$2]');
    }
    if (newLrc !== lrc || newTlrc !== tlrc) {
      lrc = newLrc;
      tlrc = newTlrc;
      if (romalrc !== '') {
        romalrc = romalrc
          .replace(/\[(\d{2}:\d{2}):(\d{2,3})]/g, '[$1.$2]')
          .replace(/\[(\d{2}:\d{2}\.\d{2})0]/g, '[$1]');
      }
    }
  }
  return [lrc, tlrc, romalrc];
}

export { pad2, pad3 };

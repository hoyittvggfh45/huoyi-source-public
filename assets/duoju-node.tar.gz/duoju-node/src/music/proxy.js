

import { aesCTRDecrypt, base64Decode } from './crypto.js';
import { desktopUA, httpClient } from './http.js';
import { writeErr } from './resp.js';

export function contentTypeFor(format) {
  switch (String(format ?? '').toLowerCase()) {
    case 'mp3': return 'audio/mpeg';
    case 'flac': return 'audio/flac';
    case 'wav': return 'audio/wav';
    case 'aac':
    case 'm4a': return 'audio/mp4';
    case 'ogg': return 'audio/ogg';
    default: return 'application/octet-stream';
  }
}

function bitCount(n) {
  n = n - ((n >> 1) & 0x55555555);
  n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
  return (((n + (n >> 4)) & 0x0f0f0f0f) * 0x01010101) >>> 24;
}

function decodeBase36(c) {
  if (c >= 48 && c <= 57) return c - 48;
  if (c >= 97 && c <= 122) return c - 97 + 10;
  return 0xff;
}

function decryptSpadeInner(keyBytes) {
  const result = Buffer.alloc(keyBytes.length);
  const buff = Buffer.concat([Buffer.from([0xfa, 0x55]), Buffer.from(keyBytes)]);
  for (let i = 0; i < keyBytes.length; i++) {
    let v = keyBytes[i] ^ buff[i] - bitCount(i >>> 0) - 21;
    while (v < 0) v += 255;
    result[i] = v & 0xff;
  }
  return result;
}

export function extractSodaKey(playAuth) {
  const bytesData = base64Decode(playAuth);
  if (bytesData.length < 3) throw new Error('unexpected EOF');
  const paddingLen = (bytesData[0] ^ bytesData[1] ^ bytesData[2]) - 48;
  if (paddingLen < 0 || bytesData.length < paddingLen + 2) throw new Error('unexpected EOF');
  const innerInput = bytesData.subarray(1, bytesData.length - paddingLen);
  const tmpBuff = decryptSpadeInner(innerInput);
  if (tmpBuff.length === 0) throw new Error('unexpected EOF');
  const skipBytes = decodeBase36(tmpBuff[0]);
  const endIndex = 1 + (bytesData.length - paddingLen - 2) - skipBytes;
  if (endIndex > tmpBuff.length || endIndex < 1) throw new Error('unexpected EOF');
  const hexKey = tmpBuff.toString('latin1', 1, endIndex);
  const key = Buffer.from(hexKey, 'hex');
  if (key.length !== 16 && key.length !== 32) throw new Error('unexpected EOF');
  return key;
}

function findBox(data, boxType, start, end) {
  if (end > data.length) end = data.length;
  const target = Buffer.from(boxType, 'latin1');
  let pos = start;
  while (pos + 8 <= end) {
    const size = data.readUInt32BE(pos);
    if (size < 8) break;
    if (data[pos + 4] === target[0] && data[pos + 5] === target[1] && data[pos + 6] === target[2] && data[pos + 7] === target[3]) {
      return { offset: pos, size, data: data.subarray(pos + 8, pos + size) };
    }
    pos += size;
  }
  return null;
}

function parseStsz(data) {
  if (data.length < 12) return [];
  const sampleSizeFixed = data.readUInt32BE(4);
  const sampleCount = data.readUInt32BE(8);
  const sizes = new Array(sampleCount).fill(0);
  if (sampleSizeFixed !== 0) {
    for (let i = 0; i < sampleCount; i++) sizes[i] = sampleSizeFixed;
  } else {
    for (let i = 0; i < sampleCount; i++) {
      if (12 + i * 4 + 4 <= data.length) sizes[i] = data.readUInt32BE(12 + i * 4);
    }
  }
  return sizes;
}

function parseSenc(data) {
  if (data.length < 8) return [];
  const flags = data.readUInt32BE(0) & 0x00ffffff;
  const sampleCount = data.readUInt32BE(4);
  const ivs = [];
  let ptr = 8;
  const hasSubsamples = (flags & 0x02) !== 0;
  for (let i = 0; i < sampleCount; i++) {
    if (ptr + 8 > data.length) break;
    ivs.push(Buffer.from(data.subarray(ptr, ptr + 8)));
    ptr += 8;
    if (hasSubsamples) {
      if (ptr + 2 > data.length) break;
      const subCount = data.readUInt16BE(ptr);
      ptr += 2 + subCount * 6;
    }
  }
  return ivs;
}

export function decryptSodaAudio(fileData, playAuth) {
  const keyBytes = extractSodaKey(playAuth);
  const moov = findBox(fileData, 'moov', 0, fileData.length);
  if (!moov) throw new Error('unexpected EOF');
  let stbl = findBox(fileData, 'stbl', moov.offset, moov.offset + moov.size);
  if (!stbl) {
    const trak = findBox(fileData, 'trak', moov.offset + 8, moov.offset + moov.size);
    if (trak) {
      const mdia = findBox(fileData, 'mdia', trak.offset + 8, trak.offset + trak.size);
      if (mdia) {
        const minf = findBox(fileData, 'minf', mdia.offset + 8, mdia.offset + mdia.size);
        if (minf) stbl = findBox(fileData, 'stbl', minf.offset + 8, minf.offset + minf.size);
      }
    }
  }
  if (!stbl) throw new Error('unexpected EOF');
  const stsz = findBox(fileData, 'stsz', stbl.offset + 8, stbl.offset + stbl.size);
  if (!stsz) throw new Error('unexpected EOF');
  const sampleSizes = parseStsz(stsz.data);
  let senc = findBox(fileData, 'senc', moov.offset + 8, moov.offset + moov.size);
  if (!senc) senc = findBox(fileData, 'senc', stbl.offset + 8, stbl.offset + stbl.size);
  if (!senc) throw new Error('unexpected EOF');
  const ivs = parseSenc(senc.data);
  const mdat = findBox(fileData, 'mdat', 0, fileData.length);
  if (!mdat) throw new Error('unexpected EOF');
  const decryptedData = Buffer.from(fileData);
  let readPtr = mdat.offset + 8;
  const out = [];
  let outLen = 0;
  for (let i = 0; i < sampleSizes.length; i++) {
    const size = sampleSizes[i];
    if (readPtr + size > decryptedData.length) break;
    const chunk = decryptedData.subarray(readPtr, readPtr + size);
    if (i < ivs.length) {
      const paddedIV = Buffer.alloc(16);
      ivs[i].copy(paddedIV);
      const dec = aesCTRDecrypt(chunk, keyBytes, paddedIV);
      out.push(dec);
      outLen += dec.length;
    } else {
      out.push(chunk);
      outLen += chunk.length;
    }
    readPtr += size;
  }
  if (outLen === mdat.size - 8) {
    Buffer.concat(out).copy(decryptedData, mdat.offset + 8);
  }
  const stsd = findBox(fileData, 'stsd', stbl.offset + 8, stbl.offset + stbl.size);
  if (stsd) {
    const stsdData = decryptedData.subarray(stsd.offset, stsd.offset + stsd.size);
    const encaIdx = stsdData.indexOf(Buffer.from('enca', 'latin1'));
    if (encaIdx !== -1) {
      Buffer.from('mp4a', 'latin1').copy(stsdData, encaIdx);
    }
  }
  return decryptedData;
}


export async function proxyAudio(req, res, audioURL, format, playAuth) {
  const headers = {
    'User-Agent': desktopUA,
    Referer: 'https://music.douyin.com/',
  };
  const rangeHeader = req.headers.range;
  
  const passthrough = !playAuth && !!rangeHeader;
  if (passthrough) headers.Range = rangeHeader;

  let resp;
  try {
    resp = await httpClient().do('GET', audioURL, headers, {
      noBrowserHeaders: true,
      withoutCookieJar: true,
      timeoutMs: 120000,
    });
  } catch (err) {
    return writeErr(res, 502, err.message);
  }

  if (passthrough) {
    const passHeaders = ['Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges', 'Last-Modified', 'ETag'];
    for (const k of passHeaders) {
      const v = resp.headers[k.toLowerCase()];
      if (v) res.setHeader(k, v);
    }
    if (!res.getHeader('Accept-Ranges')) res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.status(resp.status || 200);
    const { pipeline } = await import('node:stream/promises');
    try { await pipeline(resp.stream, res); } catch {}
    return;
  }

  if (resp.status !== 200) {
    try { await resp.buffer(); } catch {}
    return writeErr(res, 502, 'upstream status ' + resp.status);
  }
  let data;
  try {
    data = await resp.buffer();
  } catch (err) {
    return writeErr(res, 502, err.message);
  }
  let out = data;
  if (playAuth) {
    try {
      out = decryptSodaAudio(data, playAuth);
    } catch (err) {
      return writeErr(res, 502, 'decrypt failed: ' + err.message);
    }
  }
  res.setHeader('Content-Type', contentTypeFor(format));
  res.setHeader('Content-Length', String(out.length));
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Accept-Ranges', 'bytes');
  res.send(out);
}




export function newSong(extra = {}) {
  
  const s = {
    name: '',
    singer: '',
    albumName: '',
    albumId: '',
    songmid: null,
    source: '',
    interval: '',
    _interval: undefined,
    img: '',
    lrc: null,
    otherSource: undefined,
    types: [],
    _types: {},
    typeUrl: {},
    hash: undefined,
    songId: undefined,
    albumMid: undefined,
    strMediaMid: undefined,
    copyrightId: undefined,
    lrcUrl: undefined,
    mrcUrl: undefined,
    trcUrl: undefined,
  };
  return Object.assign(s, extra);
}

export function qtype(type, size, hash) {
  const t = { type, size };
  if (hash) t.hash = hash;
  return t;
}

export function qsize(size, hash) {
  const q = { size };
  if (hash) q.hash = hash;
  return q;
}


export function qualitySizeMap(tm) {
  const out = {};
  for (const k of Object.keys(tm).sort()) out[k] = tm[k];
  return out;
}

export function reverseQuality(types) {
  types.reverse();
  return types;
}

export function formatPlayTime(seconds) {
  if (!(seconds > 0) || Number.isNaN(seconds)) return '--/--';
  let s = Math.floor(seconds);
  let m = Math.floor(s / 60);
  s = s % 60;
  if (m === 0 && s === 0) return '--/--';
  return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
}

export function sizeFormate(size) {
  size = Math.floor(Number(size) || 0);
  if (size <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  let f = size;
  while (f >= 1024 && i < units.length - 1) {
    f /= 1024;
    i++;
  }
  return f.toFixed(2) + ' ' + units[i];
}

const htmlEntities = {
  '&amp;': '&',
  '&lt;': '<',
  '&gt;': '>',
  '&quot;': '"',
  '&apos;': "'",
  '&nbsp;': ' ',
};

export function decodeName(s) {
  s = String(s ?? '');
  if (s === '') return '';
  s = s.replace(/&#(\d+);/g, (m, n) => {
    const code = parseInt(n, 10);
    if (!Number.isFinite(code)) return m;
    try { return String.fromCodePoint(code); } catch { return m; }
  });
  return s.replace(/&[a-zA-Z]+;/g, (m) => (m in htmlEntities ? htmlEntities[m] : m));
}


export function goNumStr(f) {
  return String(f);
}

export function formatPlayCount(v) {
  const num = tonum(v);
  if (num > 100000000) return goNumStr(Math.trunc(num / 10000000) / 10) + '亿';
  if (num > 10000) return goNumStr(Math.trunc(num / 1000) / 10) + '万';
  return goNumStr(num);
}

export function dateFormat(ms, layout) {
  if (!(ms > 0)) return '';
  const d = new Date(ms);
  const map = {
    Y: String(d.getFullYear()),
    M: String(d.getMonth() + 1).padStart(2, '0'),
    D: String(d.getDate()).padStart(2, '0'),
    h: String(d.getHours()).padStart(2, '0'),
    m: String(d.getMinutes()).padStart(2, '0'),
    s: String(d.getSeconds()).padStart(2, '0'),
  };
  return String(layout).replace(/[YMDhms]/g, (ch) => map[ch]);
}

export function formatSinger(s) {
  return String(s ?? '').replaceAll('&', '、');
}

export function parseFloatS(s) {
  const f = parseFloat(String(s ?? '').trim());
  return Number.isFinite(f) ? f : 0;
}

export function parseIntS(s) {
  const n = parseInt(String(s ?? '').trim(), 10);
  return Number.isFinite(n) ? n : 0;
}


export function smap(v) {
  return v && typeof v === 'object' && !Array.isArray(v) ? v : null;
}


export function sv(obj, key) {
  return obj ? obj[key] : undefined;
}


export function slist(v) {
  return Array.isArray(v) ? v : null;
}

export function tonum(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? v : 0;
  if (typeof v === 'string') {
    const f = parseFloat(v.trim());
    return Number.isFinite(f) ? f : 0;
  }
  if (typeof v === 'boolean') return v ? 1 : 0;
  return 0;
}

export function num(v) {
  return tonum(v);
}


export function str(v) {
  if (v === undefined || v === null) return '';
  if (typeof v === 'string') return v;
  if (typeof v === 'number') return Number.isFinite(v) ? goNumStr(v) : '';
  if (typeof v === 'boolean') return v ? '1' : '0';
  if (typeof v === 'object') {
    try { return JSON.stringify(v); } catch { return String(v); }
  }
  return String(v);
}

export function nowMillis() {
  return Date.now();
}


export function goJSON(v) {
  return JSON.stringify(sortKeys(v));
}

function sortKeys(v) {
  if (Array.isArray(v)) return v.map(sortKeys);
  if (v && typeof v === 'object') {
    const out = {};
    for (const k of Object.keys(v).sort()) {
      const val = v[k];
      out[k] = val === undefined ? null : sortKeys(val);
    }
    return out;
  }
  return v;
}

export function firstNonEmpty(...vals) {
  for (const v of vals) {
    if (v !== undefined && v !== null && String(v).trim() !== '') return v;
  }
  return '';
}
